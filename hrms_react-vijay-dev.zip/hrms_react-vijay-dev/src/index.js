import React, { useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { BrowserRouter }  from 'react-router-dom';
import { Provider } from 'react-redux'; 
import {store} from "../src/Components/store/index"

import '../src/Components/assets/img/favicon.png'
import '../src/Components/assets/css/bootstrap-datetimepicker.min.css'
import '../src/Components/assets/plugins/fontawesome/css/all.min.css'
import '../src/Components/assets/plugins/fontawesome/css/fontawesome.min.css'
import '../src/Components/assets/plugins/select2/css/select2.min.css'
import '../src/Components/assets/css/feather.css'
import '../src/Components/assets/plugins/daterangepicker/daterangepicker.css'
import '../src/Components/assets/css/bootstrap.min.css'
import '../src/Components/assets/css/style.css'

import '../src/Components/assets/img/favicon.png'
import '../src/Components/assets/css/bootstrap.min.css'
import '../src/Components/assets/plugins/fontawesome/css/all.min.css'
import '../src/Components/assets/plugins/fontawesome/css/fontawesome.min.css'
import '../src/Components/assets/css/feather.css'
import '../src/Components/assets/plugins/select2/css/select2.min.css'
// import '../src/Components/assets/plugins/datatables/datatables.min'
import '../src/Components/assets/css/bootstrap-datetimepicker.min.css'
import '../src/Components/assets/plugins/daterangepicker/daterangepicker.css'
import '../src/Components/assets/css/bootstrap-checkbox.css'
// import '../src/Components/assets/js/bootstrap.bundle.js'
import '../src/Components/assets/css/style.css'


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <Provider store={store}>
    <App />
  </Provider>
);

reportWebVitals();


// const data = {
//   firstname:{firstname:["name","ane"]},
//   lastname:{lastname:["bame","name"]},
// }
