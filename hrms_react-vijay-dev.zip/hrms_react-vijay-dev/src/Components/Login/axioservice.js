import axios from "axios";
// import { loginUrl } from "../assets/constants/pageurl";
// import { removeLocalStorage } from "../assets/globals";
//import { store } from '../reduxStore'

// const loginToken = store?.getState()?.app?.token;
const loginToken = "";
// const BASE_URL =  'https://hd-plus.dreamguystech.com/';
const BASE_URL = "https://api.dreamshrms.com/api/auth/";
// const BASE_URL = 'https://hhplus.hybridhero.com'; // qa build backend URL
// import ToastMessage from "../components/toast";
// import { hideLoader } from "../reduxStore/appSlice";

const instance = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/x-www-form-urlencoded",
    "Accept": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Credentials": true,
    "Authorization": 'Bearer ' + (loginToken || "")
  }
});

instance.interceptors.request.use(
  function (config) {
    // Do something before request is sent
    return config;
  },
  function (error) {
    // Do something with request error
    return Promise.reject(error);
  }
);

// Add a response interceptor
instance.interceptors.response.use(undefined, function (err) {
  console.log(err?.response, 'err')
//   store.dispatch(hideLoader())
  if (!err?.response) {
    // ToastMessage(
    //   "error",
    //   "Please check your internet connection or wait until servers are back online"
    // );
  }
  else {

    // if (err?.response?.status == 401) {
    //   console.log(err?.response?.data, 'err')
    //   ToastMessage(
    //     "401",
    //     err?.response?.data ? err?.response?.data : "Unauthorized"
    //   );
    // }
    if (err?.response?.data?.code && err?.response?.data?.code === 401) {
      // Unauthorized and log out
    //   ToastMessage(
    //     "401",
    //     err.response.data.message ? err.response.data.message : "Unauthorized"
    //   );
    //   removeLocalStorage();
    //   window.location.href = loginUrl;
      const errors = JSON.parse(JSON.stringify(err.response.data.errors));
      for (const i in errors) {
        // ToastMessage("error", "Error" + i);
      }
    } else {
      if (err?.response?.data?.code && err?.response?.data?.code == "500") {
        // ToastMessage(
        //   "500",
        //   err.response.data.message
        // );
      }
      if (err?.response?.data?.messages) {
        const errors = JSON.parse(JSON.stringify(err.response.data.messages));
        for (const i in errors) {
        //   ToastMessage("error", errors[i]);
        }
      } else {
        if (Array.isArray(err?.response?.data?.message)) {
          const errors = JSON.parse(JSON.stringify(err.response.data.message));

          for (const i in errors) {
            // ToastMessage("error", errors[i]);
          }
        } else if (err?.response?.data) {
        //   ToastMessage("error", err?.response?.data?.message ? err?.response?.data?.message : err?.response?.data);
        }
        // else if (err?.response?.data) {
        //   for (let msg of err?.response?.data?.name)
        //     ToastMessage("error", msg);
        // }
      }
    }
    return Promise.reject(err);
  }
});

export default instance;