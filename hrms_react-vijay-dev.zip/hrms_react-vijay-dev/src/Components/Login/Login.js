import React, { useEffect, useState } from "react";
import login_banner from "../assets/img/login-banner.png";
import microicon from "../assets/img/microsoft.svg";
import login_logo from "../assets/img/login-logo.svg";
import google from "../assets/img/icons/google.svg";
import { useNavigate } from "react-router-dom";
import Waving_Hand from "../assets/img/Waving_Hand.svg";
import TermconModal from "../Modal/TermconModal";
import PrivacyModal from "../Modal/PrivacyModal";
import "../assets/css/style.css";
import { postData, getDecryptedData } from "../services/apiUrl";
import { useFormik } from "formik";
import * as Yup from "yup";
import { currentConfiguration } from "./Aws";
import { Amplify, Auth, Hub } from "aws-amplify";
import { Link } from "react-router-dom";
import { HiOutlineEye, HiOutlineEyeOff } from "react-icons/hi";
import Auth1 from "../Auth/auth";
import { Loginaction} from "../Employee/ReduxReducer/EmployeeReducer";
import { useDispatch, useSelector } from "react-redux";
import cogoToast from "cogo-toast";
Amplify.configure(currentConfiguration);
// import {loginData} from "../../Components/Employee/ReduxReducer/EmployeeReducer"

function Login() {
  const {token, setToken } = Auth1();
  const [loginData, setLoginData] = useState([]);
  const [showterm, setShowterm] = useState(false);
  const [showprev, setShowprev] = useState(false);
  const [data, setdata] = useState([]);
  const [getToken, setgetToken] = useState();
  const navigate = useNavigate();
  const [login, setLogin] = useState("");
  const [type, setType] = useState("password");
  const Dispatch = useDispatch();
  // const selector = useSelector(selector);
 
  //  if(selector){
  // setToken()
  //  }

  // console.log(selector, "selector");
  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validationSchema: Yup.object({
      email: Yup.string().email("Invalid email format").required("Required!"),
      password: Yup.string()
        .min(4, "Minimum 4 characters")
        .required("Required!"),
    }),
    onSubmit: (values) => {
      setdata(values);
      const getlogin = async () => {
        const preparData = {
          email_id: values.email,
          password: values.password,
        };
        postData("login", preparData, (data, res) => {
          console.log(data, "resss");
          if (data) {
            setToken("token",data?.data?.original?.access_token);
            const token = data?.data?.original?.access_token
            localStorage.setItem('token',JSON.stringify(token));
          }
        });
        console.log(preparData, "preparData");
      };

      getlogin();
    },
  });

	const sucessCallBack = (data, res) => {
    console.log(res,"dtaaaa");
		// Dispatch(loading(false));
		if (data?.code == 200) {
			cogoToast.success(data?.message);
			setToken("token",data?.data?.original?.access_token);
			// setProviderToken(data?.user_token);
			Dispatch(data?.data?.original?.access_token ? Loginaction(data?.data?.original?.access_token ) :"");
			// navigate(data.user_type === 1 ? "/provider-dashboard" : "/customer-dashboard");
			// setTimeout(() => window.location.reload(), 500);
		} else {
			cogoToast.error(data?.error);
		}
	};



  // SOS AWS Login Setup
  useEffect(() => {
    if (sessionStorage.getItem("token")) {
      navigate("/employee");
    }

const login_enc ="70453d863dd4470c8bec975047f7e1152629f4f9b7bbe9bcaeb028bce4a3f72a850533d1ea68e4c1c481cc75cfd212d1c9695da54a523becaebd2f2aa5e537e8fa7f4f9310dab8979f9ffb083df20b16f2b9818812f7508d975d46";
getDecryptedData(login_enc,(data)=>{
  console.log(data,"www");

})
    

    Amplify.configure(currentConfiguration);
    try {
      const unsubscribe = Hub.listen("auth", ({ payload: { event, data } }) => {
        console.log("event", event);

        switch (event) {
          case "signIn":
            console.log("signIn", data);

            if (data?.signInUserSession?.idToken?.payload) {
              var playload = data?.signInUserSession?.idToken?.payload;
              var groups = "";

              if (playload?.identities?.length > 0) {
                if (playload?.identities[0]?.providerName == "Okta") {
                  const getIss = playload?.iss.split("com/")[1];
                  groups = getIss + "_Okta";
                } else {
                  groups = playload["cognito:groups"][1];
                }
              } else {
                groups = playload["cognito:groups"][1];
              }
              var groups = playload["cognito:groups"];
              var email = playload.email;
              console.log("data groups **** ", groups);
              console.log("data email **** ", email);

              if (groups) {
                const preparData = {
                  //                  email: email,
                  //                  org_name: groups,
                  //                 tenant_name: getTenantDetails?.tenant_name ? getTenantDetails?.tenant_name:""
                };
                //               doLogin(preparData);
                //               console.log("deded");
              } else {
                //               Toaster
                console.log(
                  "400",
                  "This email is not matching with our organization."
                );
              }
            }

            break;
          case "signOut":
            console.log("signOut", null);
            break;
          case "customOAuthState":
            console.log("customOAuthState", data);
            break;
          default:
            return;
        }
      });

      Auth.currentAuthenticatedUser()
        .then((currentUser) => {
          if (currentUser?.signInUserSession?.idToken?.payload) {
            var playload = currentUser?.signInUserSession?.idToken?.payload;
            var groups = playload["cognito:groups"];

            var groups = "";

            if (playload?.identities?.length > 0) {
              if (playload?.identities[0]?.providerName == "Okta") {
                const getIss = playload?.iss.split("com/")[1];
                groups = getIss + "_Okta";
              } else {
                groups = playload["cognito:groups"][1];
              }
            } else {
              groups = playload["cognito:groups"][1];
            }

            var email = playload.email;
            console.log("currentUser groups **** ", groups);
            console.log("currentUser email **** ", email);

            if (groups) {
              const preparData = {
                email: email,
                org_name: groups,
              };
              // doLogin(preparData);
            } else {
              // Toaster
              console.log(
                "400",
                "This email is not matching with our organization."
              );
            }
          }
          // console.log("currentUser **** ",JSON.stringify(currentUser))
        })
        .catch(() => console.log("Not signed in"));

      return unsubscribe;
    } catch (error) {
      console.log("error", error);
    }
  }, []);

  return (
    <div className="main-wrapper">
      <div className="row">
        <div className="col-lg-4 col-md-5 col-sm-12 login-wrap-bg pb-0 pt-2">
          <div className="login-wrapper">
            <div className="loginbox" style={{ padding: "10px" }}>
              <div className="logo-img d-flex align-items-center justify-content-between">
                <img src={login_logo} className="img-fluid" alt="Logo" />
                <div className="sign-group ">
                  <a
                    style={{ color: "white", backgroundColor: "#0F233C" }}
                    className="btn sign-up d-flex"
                    onClick={() => navigate("/register")}
                  >
                    Sign Up
                    <i
                      style={{ paddingLeft: "12px", fontSize: "19px" }}
                      class="bi bi-arrow-right"
                    ></i>
                    <span>
                      <i className="fas fa-arrow-right"></i>
                      <i
                        className="fa fa-long-arrow-right"
                        aria-hidden="true"
                      ></i>
                    </span>
                  </a>
                </div>
              </div>
              <h2>Login</h2>
              <p>
                Hey <img src={Waving_Hand} aria-label="sheep" />, Please Enter
                your login details
              </p>
              <form onSubmit={formik.handleSubmit}>
                <div className="form-group">
                  <label className="label">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    name="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.email && formik.touched.email && (
                    <p className="d-flex  text-danger">{formik.errors.email}</p>
                  )}
                </div>

                <div className="form-group">
                  <label className="label">Password</label>
                  <div className="d-flex" style={{ position: "relative" }}>
                    <input
                      type={type}
                      className="form-control"
                      name="password"
                      value={formik.values.password}
                      onChange={formik.handleChange}
                    />
                    {type === "password" ? (
                      <span
                        className="toggle-password "
                        onClick={() => setType("text")}
                      >
                        <HiOutlineEyeOff />
                      </span>
                    ) : (
                      <span
                        onClick={() => setType("password")}
                        className="toggle-password"
                      >
                        {" "}
                        <HiOutlineEye />
                      </span>
                    )}
                    {/* <img
                      style={{ position: "absolute", left: "90%", top: "30%" }}
                      src={eyeicon}
                    ></img> */}
                  </div>
                  {formik.errors.password && formik.touched.password && (
                    <p className="d-flex  text-danger">
                      {formik.errors.password}
                    </p>
                  )}
                </div>

                <div className="form-group d-flex align-items-center justify-content-between">
                  <div className="status-toggle d-flex align-items-center">
                    <input id="rating_1" className="check" type="checkbox" />
                    <label
                      for="rating_1"
                      className="checktoggle checkbox-bg mb-0"
                    ></label>
                    <span>Keep me signed in</span>
                  </div>
                  <span>
                    <a
                      className="forgot-pass"
                      onClick={() => navigate("/forgetpassword")}
                      style={{ color: "#00BDCD" }}
                    >
                      Forgot Password
                    </a>
                  </span>
                </div>
                <button
                  type="submit"
                  className="form-group btn login-submit w-100"
                  style={{ borderRadius: "22px" ,backgroundColor:"lightgray"}}
                >
                  Login
                </button>
                <div className="form-group">
                  <div className="ogin-or" style={{display: "flex",
    justifyContent: "center"}}>
                    <span className="or-line"></span>
                    <span className="span-or">Or Log in With </span>
                  </div>
                </div>

                <div
                  className="social-group d-flex "
                  style={{ justifyContent: " space-around" }}
                >
                  {/* <div className="form-group social-login">
                  <a
                    href="#"
                    className="d-flex align-items-center justify-content-center form-group btn google-login w-100 "
                    id="logPage"
                    style={{ border: "solid 2px #DEDEDE" }}
                  >
                       <div className="d-flex">
                        <Link
                          to="#"
                          onClick={() =>
                            Auth.federatedSignIn({
                              provider: "Google",
                            })
                          }
                        >
                          <span>
                            <img src={google} class="img-fluid" alt="Logo" />
                          </span>
                        </Link>
                      </div>
                    Log in with Google
                  </a>
                </div> */}
                  <div className="form-group social-login pt-0">
                    <p
                      href="#"
                      classNameName="d-flex align-items-center justify-content-center form-group btn google-login w-100"
                    >
                      <div
                        style={{
                          border: "2px solid rgb(222, 222, 222)",
                          borderRadius: "50%",
                          alignItems: "center",
                          width: "50px",
                          height: "50px",
                        }}
                        className="d-flex justify-content-center "
                      >
                        <Link
                          style={{ textDecoration: "none" }}
                          to="#"
                          onClick={() =>
                            Auth.federatedSignIn({
                              provider: "Google",
                            })
                          }
                        >
                          <span>
                            <img src={google} class="img-fluid" alt="Logo" />
                          </span>
                        </Link>
                      </div>
                      <p className="pt-2" style={{ textDecoration: "none" }}>
                        {" "}
                        Google
                      </p>
                    </p>
                  </div>
                  {/* <div className="form-group social-login">
                    <p
                      href="#"
                      classNameName="d-flex align-items-center justify-content-center form-group btn google-login w-100"
                    >
                      <div
                        style={{
                          border: "2px solid rgb(222, 222, 222)",
                          borderRadius: "50%",
                          alignItems: "center",
                          width: "50px",
                          height: "50px",
                        }}
                        className="d-flex -flex justify-content-center"
                      >
                        <Link
                          to="#"
                          onClick={() =>
                            Auth.federatedSignIn({
                              provider: "Octa",
                            })
                          }
                        >
                          <span>
                            <img src={octaicon} class="img-fluid" alt="Logo" />
                          </span>
                        </Link>
                      </div>
                      <p className="pt-2">Octa</p>
                    </p>
                  </div> */}
                  <div>
                    <p
                      href="#"
                      classNameName="d-flex align-items-center justify-content-center ml-2 form-group btn google-login w-100"
                    >
                      <div
                        style={{
                          border: "2px solid rgb(222, 222, 222)",
                          borderRadius: "50%",
                          alignItems: "center",
                          width: "50px",
                          height: "50px",
                        }}
                        className="d-flex -flex justify-content-center"
                      >
                        <Link
                          to="#"
                          onClick={() =>
                            Auth.federatedSignIn({
                              provider: "Microsoft",
                            })
                          }
                        >
                          <span>
                            <img src={microicon} class="img-fluid" alt="Logo" />
                          </span>
                        </Link>
                      </div>
                      <p className="pt-2">Microsoft</p>
                    </p>
                  </div>
                </div>

                <div className="form-group">
                  <div className="terms-policy">
                    <ul>
                      <li>
                        <a onClick={() => setShowterm(true)}>
                          Terms & Conditions
                        </a>
                      </li>
                      {/* <li>|</li> */}
                      <li>
                        <a onClick={() => setShowprev(true)}>Privacy Policy</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="col-lg-8 col-md-7 col-sm-12 login-bg">
          <div className="welcome-login">
            <h2>Smarter . Simpler . Automated .</h2>
            <p>
              With the world's best staff management solutions, users can
              improve retention as well as productivity.
            </p>
          </div>
          <div className="banner-img">
            <img src={login_banner} className="img-fluid" alt="Login Banner" />
          </div>
          <div className="copyright">
            <div className="row">
              <div className="col-md-6">
                <div className="privacy-policy">
                  <p>Copyrights @ Dreams Hrms 2023</p>
                </div>
              </div>
              <div className="col-md-6">
                <div className="copyright-text">
                  <p className="mb-0">
                    Design and Developed by <span>Dreamguy’s</span>
                  </p>
                </div>
              </div>
              <TermconModal showterm={showterm} setShowterm={setShowterm} />
              <PrivacyModal showprev={showprev} setShowprev={setShowprev} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;