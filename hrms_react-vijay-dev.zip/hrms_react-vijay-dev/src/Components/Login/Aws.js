import { Amplify, Auth } from "aws-amplify";
import { BASEURL } from "../apiPath/baseUrl";

Amplify.configure({
  Auth: {
    identityPoolId: "us-east-1:186128823741",
    region: "us-east-1",
    identityPoolRegion: "us-east-1:186128823741",
    userPoolId: "us-east-1_5chMLFdfr",
    userPoolWebClientId: "1d1v8248oophjfpmh6mbn83t0s",
    mandatorySignIn: false,
    signUpVerificationMethod: "token", // 'code' | 'link'
    oauth: {
      domain: "dreamshrms.auth.us-east-1.amazoncognito.com",
      redirectSignIn: "https://tenant1.ms1.dreamshrms.com/",
      redirectSignOut: "https://tenant1.ms1.dreamshrms.com/",
      responseType: "token", // or 'token', note that REFRESH token will only be generated when the responseType is code
    },
  },
});
//https://api.dreamshrms.com/

// Amplify.configure({
//     Auth: {
//         identityPoolId: 'eu-west-1:c9c6118b-d969-45f2-bf24-50a682d29f72',
//         region: 'eu-west-1',
//         identityPoolRegion: 'eu-west-1',
//         userPoolId: 'eu-west-1_v2yAhog2m',
//         userPoolWebClientId: '7baf1msf7f2m9b1gre8n49tj9n',
//         mandatorySignIn: false,
//         signUpVerificationMethod: 'token', // 'code' | 'link'
//         oauth: {
//             domain:'https://dreamshrms.auth.us-east-1.amazoncognito.com',
//             redirectSignIn: 'https://hdplus.hybridhero.com',
//             redirectSignOut: 'https://hdplus.hybridhero.com/',
//             responseType: 'token' // or 'token', note that REFRESH token will only be generated when the responseType is code
//         }
//     }
//   })

export const currentConfiguration = Auth.configure();


