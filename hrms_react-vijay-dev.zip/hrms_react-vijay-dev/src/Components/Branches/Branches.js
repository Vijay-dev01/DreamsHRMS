import React from 'react'
import Header from '../Header'
import { branch1, branch2, branch3, branch4, branchicon, drag1, tooltipicon } from '../imagepath'
import { Link } from 'react-router-dom'
import Footer from '../Footer'

const Branches = () => {
  return (
   <div>
  <div className="main-wrapper">
    {/* Header */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper branches">
      {/* Page Content */}
      <div className="content container">
        <div className="d-flex justify-content-between align-items-center title-row">
          <h2>Branches</h2>
          <div className="mixed-buttons">
            <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-template"><i className="fa fa-plus" aria-hidden="true" />Add Branches</button>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 col-lg-6">
            <div className="item-wrap d-sm-flex justify-content-between align-items-start white-bg w-100">
              <div className="branch-pic flex-sm-grow-0 d-sm-flex align-items-center">
                <img src={branch1} alt />
                <div className="icon-menu text-center">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" style={{}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share as HQ</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="branch-content flex-sm-grow-1">
                <div className="head d-flex justify-content-between align-items-center">
                  <div className="d-flex justify-content-start align-items-center">
                    <span className="icon-bg text-center align-items-center"><img src={branchicon} alt /></span>
                    <h3>Nature</h3>
                    <span className="bg-text">Headquarter</span>
                  </div>
                  <div className="form-check form-switch">
                    <label className="form-check-label" htmlFor="head_1" />
                  </div>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <td><span>Number of Employees</span></td>
                      <td><p>200</p></td>
                    </tr>
                    <tr>
                      <td><span>Geofencing</span></td>
                      <td>
                        <div className="form-check form-switch">
                          <label className="form-check-label" htmlFor="branch_1" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><span>Clock In Limit(Radius)</span></td>
                      <td><p>200 Meter</p></td>
                    </tr>
                    <tr>
                      <td><span>Address</span></td>
                      <td><p>9 Ponderosa Dr, Mayhill, New York - 88339</p></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div className="col-md-12 col-lg-6">
            <div className="item-wrap d-sm-flex justify-content-between align-items-start white-bg">
              <div className="branch-pic flex-sm-grow-0 d-sm-flex align-items-center align-items-center">
                <img src={branch2} alt />
                <div className="icon-menu text-center">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" style={{}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share as HQ</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="branch-content flex-sm-grow-1">
                <div className="head d-flex justify-content-between align-items-center">
                  <div className="d-flex justify-content-start align-items-center">
                    <span className="icon-bg text-center align-items-center"><img src={branchicon} alt /></span>
                    <h3>Nature</h3>
                    {/* <span class="bg-text">Headquarter</span> */}
                  </div>
                  <div className="form-check form-switch">
                    <label className="form-check-label" htmlFor="head_2" />
                  </div>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <td><span>Number of Employees</span></td>
                      <td><p>200</p></td>
                    </tr>
                    <tr>
                      <td><span>Geofencing</span></td>
                      <td>
                        <div className="form-check form-switch">
                          <label className="form-check-label" htmlFor="branch_2" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><span>Clock In Limit(Radius)</span></td>
                      <td><p>200 Meter</p></td>
                    </tr>
                    <tr>
                      <td><span>Address</span></td>
                      <td><p>9 Ponderosa Dr, Mayhill, New York - 88339</p></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div className="row">
          <div className="col-md-12 col-lg-6">
            <div className="item-wrap d-sm-flex justify-content-between align-items-start white-bg">
              <div className="branch-pic flex-sm-grow-0  d-sm-flex align-items-center align-items-center">
                <img src={branch3} alt />
                <div className="icon-menu text-center">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" style={{}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share as HQ</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="branch-content flex-sm-grow-1">
                <div className="head d-flex justify-content-between align-items-center">
                  <div className="d-flex justify-content-start align-items-center">
                    <span className="icon-bg text-center align-items-center"><img src={branchicon} alt /></span>
                    <h3>Nature</h3>
                    {/* <span class="bg-text">Headquarter</span> */}
                  </div>
                  <div className="form-check form-switch">
                    <label className="form-check-label" htmlFor="branch_3" />
                  </div>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <td><span>Number of Employees</span></td>
                      <td><p>200</p></td>
                    </tr>
                    <tr>
                      <td><span>Geofencing</span></td>
                      <td>
                        <div className="form-check form-switch">
                          <label className="form-check-label" htmlFor="branch_3" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><span>Clock In Limit(Radius)</span></td>
                      <td><p>--:--</p></td>
                    </tr>
                    <tr>
                      <td><span>Address</span></td>
                      <td><p>9 Ponderosa Dr, Mayhill, New York - 88339</p></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div className="col-md-12 col-lg-6">
            <div className=" item-wrap d-sm-flex justify-content-start align-items-start white-bg">
              <div className="branch-pic flex-sm-grow-0  d-sm-flex align-items-center align-items-center">
                <img src={branch4} alt />
                <div className="icon-menu text-center">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" style={{}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share as HQ</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="branch-content flex-sm-grow-1">
                <div className="head d-flex justify-content-between align-items-center">
                  <div className="d-flex justify-content-start align-items-center">
                    <span className="icon-bg text-center align-items-center"><img src={branchicon} alt /></span>
                    <h3>Nature</h3>
                  </div>
                  <div className="form-check form-switch">
                    <label className="form-check-label" htmlFor="branch_4" />
                  </div>
                </div>
                <table>
                  <tbody>
                    <tr>
                      <td><span>Number of Employees</span></td>
                      <td><p>200</p></td>
                    </tr>
                    <tr>
                      <td><span>Geofencing</span></td>
                      <td>
                        <div className="form-check form-switch">
                          <label className="form-check-label" htmlFor="branch_4" />
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><span>Clock In Limit(Radius)</span></td>
                      <td><p>--:--</p></td>
                    </tr>
                    <tr>
                      <td><span>Address</span></td>
                      <td><p>9 Ponderosa Dr, Mayhill, New York - 88339</p></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        {/* Footer */}
     <Footer />
        {/* /Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Template Modal */}
  <div className="modal fade onboarding-modal settings" id="add-template" tabIndex={-1} aria-labelledby="add-template" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Branches</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Office Details</h6>
          <form>
            <div className="form-group">
              <label className="label">Office Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Office Name" />
            </div>
            <div className="form-group">
              <label className="label">Office Full Address <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Office Full Address" />
            </div>
            <div className="form-group">
              <label className="label">Office Image <span>*</span></label>
              <div className="drag-drop text-center">
                <div className="upload">
                  <Link to="#"><img src={drag1} /></Link>
                  <p>Drag &amp; drop your files here or choose file <Link to="#">browse</Link></p>
                  <span>Maximum size: 50MB</span>
                </div>
                <input type="file" multiple />
              </div>
            </div>
            <div className="d-flex justify-content-between align-items-center">
              <h6>Geofencing</h6>
              <div className="status-toggle d-flex align-items-center">
              <input id="geofencing_1" class="check" type="checkbox" />
                <label htmlFor="geofencing_1" className="checktoggle checkbox-bg mb-0" />
              </div>
            </div>
            <div className="form-group note">
              <label htmlFor="description" className="d-flex align-items-center">Office Address <span>*</span>
                <img className="tooltip-item" data-bs-toggle="tooltip" data-bs-placement="right" title="You can move pin on map to point your exact location" src={tooltipicon} alt /></label>
              <input type="text" className="form-control" placeholder="Enter Street, City, Country" />
            </div>
            <div className="form-group">
              <label>Clock In Limit(Radius) <span>*</span></label>
              <select className="container p-1 rounded">
                <option>Select Radius</option>
                <option>OPtion 1</option>
                <option>OPtion 2</option>
              </select>
            </div>
            <div className="map responsive-map-container">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1737.6221882978507!2d-98.48650795000005!3d29.421653200000023!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x865c58aa57e6a56f%3A0xf08a9ad66f03e879!2sHenry+B.+Gonzalez+Convention+Center!5e0!3m2!1sen!2sus!4v1393884854786" width={600} height={450} frameBorder={0} style={{border: 0}} />
            </div>
            <div className="form-check form-group">
              <label className="form-check-label" htmlFor="flexCheckDefault">
                Allow clock in/out outside the office
              </label>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Create</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-close" aria-hidden="true" />cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

  )
}

export default Branches
