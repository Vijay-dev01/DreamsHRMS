import React from 'react'
import { Link } from 'react-router-dom'
import { flogo } from './imagepath'

const Footer = () => {
  return (
    <footer className="footer">
  <div className="container">
    <div className="row">
      <div className="col-12 col-sm-12 col-md-6 footer-left no-padding">
        <p>© 2023 Dreams HRMS <Link to="#" className="footer-logo"><img src={flogo} /></Link></p>
      </div>
      <div className="col-12 col-sm-12 col-md-6 footer-right no-padding">
        <ul className="clearfix">
          <li>
            <Link to="#">Privacy Policy</Link>
          </li>
          <li>
            <Link to="#">Terms &amp; Conditions</Link>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>

  )
}

export default Footer
