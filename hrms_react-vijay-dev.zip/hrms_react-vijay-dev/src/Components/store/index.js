import { configureStore } from "@reduxjs/toolkit"
import Rootreducer from "./rootReducer"


export const store = configureStore({
  reducer: {
     Rootreducer,
  },
})
