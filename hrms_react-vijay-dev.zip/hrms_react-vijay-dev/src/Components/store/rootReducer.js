import { combineReducers } from "@reduxjs/toolkit";
import Employee_reducer from "../Employee/ReduxReducer/EmployeeReducer";

const RootReducer = combineReducers({
  Employee_reducer,
});
export default RootReducer;
