import React, { useEffect, useState } from "react";
import login_banner from "./assets/img/login-banner.png";
import login_logo from "./assets/img/login-logo.svg";
import google from "./assets/img/icons/google.svg";
import "./assets/css/style.css";
import { useNavigate } from "react-router-dom";
import invalid_tick from "./assets/img/invalid-tick.svg";
import valid_tick from "./assets/img/valid-tick.svg";
// import Waving_Hand from "../assets/img/Waving_Hand.svg";
import arrow_right from "./assets/img/arrow_right.svg";
import { HiOutlineEye, HiOutlineEyeOff } from "react-icons/hi";
import { TiPencil } from "react-icons/ti";
import { getDecryptedData, postData } from "./services/apiUrl";
import { useSelector } from "react-redux";
import { selectorProvider } from "./Employee/ReduxReducer/EmployeeReducer";
import cogoToast from "cogo-toast";

// import Icon from 'react-icons-kit';
// import {basic_eye} from 'react-icons-kit/linea/basic_eye'
// import {basic_eye_closed} from 'react-icons-kit/linea/basic_eye_closed'
// import {arrows_exclamation} from 'react-icons-kit/linea/arrows_exclamation'
// import {arrows_circle_check} from 'react-icons-kit/linea/arrows_circle_check'

function Signup() {
  const navigate = useNavigate();
  const [type, setType] = useState("password");
  const domain = useSelector(selectorProvider)
console.log(domain.Domain,"domain");
  
  // validated states

  const [upperValidated, setUpperValidated] = useState(false);
  const [numberValidated, setNumberValidated] = useState(false);
  const [specialValidated, setSpecialValidated] = useState(false);
  const [lengthValidated, setLengthValidated] = useState(false);
  const [lowerValidated, setLowerValidated] = useState(false);
  const [data, setData] = useState("");
  const [signupdata, setSignupdata] = useState("");
  console.log(signupdata, "data");

  const handleChange = (value) => {
    setData(value);
    const lower = new RegExp("(?=.*[a-z])");
    const upper = new RegExp("(?=.*[A-Z])");
    const number = new RegExp("(?=.*[0-9])");
    const special = new RegExp("(?=.[!@#$%^&])");
    const length = new RegExp("(?=.{8,})");
    if (upper && number && special && length) {
      setSignupdata(value);
    }
    if (lower.test(value)) {
      setLowerValidated(true);
    } else {
      setLowerValidated(false);
    }
    if (upper.test(value)) {
      setUpperValidated(true);
    } else {
      setUpperValidated(false);
    }
    if (number.test(value)) {
      setNumberValidated(true);
    } else {
      setNumberValidated(false);
    }
    if (special.test(value)) {
      setSpecialValidated(true);
    } else {
      setSpecialValidated(false);
    }
    if (length.test(value)) {
      setLengthValidated(true);
    } else {
      setLengthValidated(false);
    }
  };
  const user_id = localStorage.getItem("user_Id");
  console.log(user_id, "user");

  const handleclick = (e) => {
    e.preventDefault();
    const data = { user_id: user_id, password: signupdata };
    postData("signup-password", data,sucessCallBack) 
    // (data, res) => {
    //   console.log(data, "signup");
    //   if (data.code == 200) {
    //     navigate("/");
    //   }
    // });
  };

  const sucessCallBack = (data, res) => {
    console.log(data, "dtaaaa");
    // Dispatch(loading(false));
    if (data.code == 200) {
      cogoToast.success();
      navigate("/");
      // Dispatch(DomainName(data.DomainName ? data.DomainName : ""));
    } else {
      cogoToast.error();
    }
  };

  useEffect(() => {
  
  }, []);
  const domain_name = localStorage.getItem("register");

  return (
    <div className="main-wrapper">
      <div className="row">
        <div className="col-lg-4 col-md-5 col-sm-12 login-wrap-bg">
          <div className="login-wrapper">
            <div className="signupbox">
              <div className="logo-img d-flex align-items-center justify-content-between">
                <img src={login_logo} className="img-fluid" alt="Logo" />
                <div className="sign-group">
                  <a
                    onClick={() => navigate("/")}
                    class="btn sign-up d-flex"
                    style={{ color: "white", backgroundColor: "#0F233C" }}
                  >
                    Sign in
                    <span>
                      <span>
                        <i
                          style={{ paddingLeft: "12px", fontSize: "19px" }}
                          class="bi bi-arrow-right"
                        ></i>
                      </span>
                    </span>
                  </a>
                </div>
              </div>
              <h2>Sign up</h2>
              <p>
                Hey{" "}
                <span>
                  <i className="fas fa-sign-language"></i>
                </span>
                , Enter the details to create you account
              </p>
              <form>
                {/* <form onSubmit={formik.handleSubmit}> */}
                <div className="form-group">
                  <label className="label">Domain Name </label>
                  <div className="d-flex">
                    {" "}
                    <span>{domain.Domain[0]}</span>
                    <div style={{ color: "#00AEEB" }} className="px-2">
                      <TiPencil /> <span className="px-2">Edit</span>
                    </div>
                  </div>
                  {/* <input type="email" className="form-control" /> */}
                </div>
                <div className="form-group">
                  <label className="form-control-label">Password</label>
                  <div className="pass-group" id="passwordInput">
                    <input
                      className="form-control pass-input"
                      type={type}
                      placeholder="Enter your password"
                      onChange={(e) => handleChange(e.target.value)}
                    />
                    {type === "password" ? (
                      <span
                        className="toggle-password "
                        onClick={() => setType("text")}
                      >
                        <HiOutlineEyeOff />
                      </span>
                    ) : (
                      <span
                        onClick={() => setType("password")}
                        className="toggle-password"
                      >
                        {" "}
                        <HiOutlineEye />
                      </span>
                    )}
                  </div>
                  <div className="valid_password">
                    <div
                      className="valid_password-strength"
                      id="valid_password-value"
                    >
                      <span id="poor"></span>
                      <span id="weak"></span>
                      <span id="strong"></span>
                      <span id="heavy"></span>
                    </div>
                    <div id="passwordInfo"></div>
                  </div>
                  {data.length > 0 ? (
                    <div className="form-password">
                      <div className="password-strength" id="passwordStrength">
                        <span id={lowerValidated ? "lowercase" : ""}></span>
                        <span id={numberValidated ? "number" : ""}></span>
                        <span id={specialValidated ? "special" : ""}></span>
                        <span id={upperValidated ? "upper" : ""}></span>
                      </div>
                      <main className="tracker-box">
                        <div
                          className={
                            lowerValidated ? "validated" : "not-validated"
                          }
                        >
                          {lowerValidated ? (
                            <span className="list-icon green">
                              <img src={valid_tick} />
                            </span>
                          ) : (
                            <span className="list-icon">
                              <img src={invalid_tick} />
                            </span>
                          )}
                          At least one lowercase letter
                        </div>

                        <div
                          className={
                            numberValidated ? "validated" : "not-validated"
                          }
                        >
                          {numberValidated ? (
                            <span className="list-icon green">
                              <img src={valid_tick} />
                            </span>
                          ) : (
                            <span className="list-icon">
                              <img src={invalid_tick} />
                            </span>
                          )}
                          one number
                        </div>
                        <div
                          className={
                            specialValidated ? "validated" : "not-validated"
                          }
                        >
                          {specialValidated ? (
                            <span className="list-icon green">
                              <img src={valid_tick} />
                            </span>
                          ) : (
                            <span className="list-icon">
                              <img src={invalid_tick} />
                            </span>
                          )}
                          one special character
                        </div>
                        <div
                          className={
                            upperValidated ? "validated" : "not-validated"
                          }
                        >
                          {upperValidated ? (
                            <span className="list-icon green">
                              <img src={valid_tick} />
                            </span>
                          ) : (
                            <span className="list-icon">
                              <img src={invalid_tick} />
                            </span>
                          )}
                          one uppercase character
                        </div>
                      </main>
                    </div>
                  ) : (
                    ""
                  )}
                </div>

                <div className="form-group">
                  <div className="status-toggle d-flex align-items-center">
                    <input id="rating_1" className="check" type="checkbox" />
                    <label
                      for="rating_1"
                      className="checktoggle checkbox-bg mb-0"
                    ></label>
                    <span>
                      By Signing up to create an account I accept Company’s
                      <span className="text-decoration-underline">
                        Terms & Privacy
                      </span>
                    </span>
                  </div>
                </div>
                <button
                  onClick={handleclick}
                  className="form-group btn login-submit w-100"
                >
                  Get Started
                </button>
                <div className="form-group">
                  <div className="ogin-or">
                    <span className="or-line"></span>
                    <span className="span-or">Or</span>
                  </div>
                </div>
                <div className="form-group social-login">
                  <a
                    href="#"
                    className="d-flex align-items-center justify-content-center form-group btn google-login w-100"
                  >
                    <span>
                      <img src={google} className="img-fluid" alt="Logo" />
                    </span>
                    Sign up with Google
                  </a>
                </div>
                <div className="form-group">
                  <div className="terms-policy">
                    <ul>
                      <li>
                        <a href="#">Terms & Conditions</a>
                      </li>
                      <li>
                        <a href="#">Privacy Policy</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="col-lg-8 col-md-7 col-sm-12 login-bg">
          <div className="welcome-login">
            <h2>Smarter . Simpler . Automated .</h2>
            <p>
              With the world's best staff management solutions, users can
              improve retention as well as productivity.
            </p>
          </div>
          <div className="banner-img">
            <img src={login_banner} className="img-fluid" alt="Login Banner" />
          </div>
          <div className="copyright">
            <div className="row">
              <div className="col-md-6">
                <div className="privacy-policy">
                  <p>Copyrights @ Dreams Hrms 2023</p>
                </div>
              </div>
              <div className="col-md-6">
                <div className="copyright-text">
                  <p className="mb-0">
                    Design and Developed by <span>Dreamguy’s</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Signup;
