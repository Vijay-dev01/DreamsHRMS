import React, { useEffect, useState } from "react";
import login_banner from "./assets/img/login-banner.png";
import login_logo from "./assets/img/login-logo.svg";
// import eyeicon from "./assets/img/eye.svg";
import { useNavigate, useParams } from "react-router-dom";
import PasswordresetModal from "./Modal/PasswordresetModal";
import arrow_right from "./assets/img/arrow_right.svg";
import * as Yup from "yup";
import axios from "axios";
import { BASEURL } from "./apiPath/baseUrl";
import { useFormik } from "formik";
import { HiOutlineEye, HiOutlineEyeOff } from "react-icons/hi";
import {  postData } from "./services/apiUrl";

function Setpassword() {
  const [show, setShow] = useState(false);
  const [type, setType] = useState("password");
  const [getemail, setGetemail] = useState();
  const navigate = useNavigate();
  const [passwordToken, setpasswordToken] = useState();
  var { token, email } = useParams();
  const checktoken = token.indexOf("=");
  const checkemail = email.indexOf("=");
  const [datapassword, setDatapassword] = useState({
    email_id: "",
    password: "",
    password_confirmation: "",
    token: "",
  });
  console.log(datapassword, "ad");

  // console.log(passwordToken,"passwordToken");
  // console.log(getemail,"passwordToken");
  const handleModal = () => {
    setShow(true);
  };

  const formik = useFormik({
    initialValues: {
      password: "",
      password_confirmation: "",
    },
    validationSchema: Yup.object({
      password: Yup.string()
        .min(4, "Minimum 4 characters")
        .required("Required!"),
      password_confirmation: Yup.string()
        .oneOf([Yup.ref("password")], "Password's not match")
        .required("Required!"),
    }),
    onSubmit: (values) => {
      setDatapassword({
        email_id: getemail,
        password: values.password,
        password_confirmation: values.password_confirmation,
        token: passwordToken,
      });
      postData("reset-password", datapassword, (data, res) => {
        if (res) {
        }
      console.log(data,"data");
      });
      setpassword();
      console.log(values, "values");

    },
  });

  function setpassword(datapassword){

  }

  useEffect(() => {
    setpasswordToken(token.slice(checktoken + 1, token.length));
    setGetemail(email.slice(checkemail + 1, token.length));
  }, []);

  return (
    <div class="main-wrapper">
      <div class="row">
        <div class="col-lg-4 col-md-5 col-sm-12 login-wrap-bg">
          <div class="login-wrapper">
            <div class="loginbox" style={{ padding: "10px" }}>
              <div class="logo-img d-flex align-items-center justify-content-between">
                <img src={login_logo} class="img-fluid" alt="Logo" />
                <div class="sign-group" style={{ color: "white" }}>
                  <a
                    class="btn sign-up d-flex"
                    onClick={() => navigate("/register")}
                  >
                    Sign Up
                    <img class="arrow-icon mx-1" src={arrow_right} />
                    <span>
                      <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                    </span>
                  </a>
                </div>
              </div>
              <h2>Set New Password</h2>
              <p>
                Your new password must be different to previously used password
              </p>
              <form onSubmit={formik.handleSubmit}>
                <div class="form-group">
                  <label class="label">New Password</label>
                  <div className="d-flex" style={{ position: "relative" }}>
                    <input
                      type={type}
                      class="form-control pass-input"
                      name="password"
                      value={formik.password}
                      onChange={formik.handleChange}
                    />
                    {type === "password" ? (
                      <span
                        className="toggle-password "
                        onClick={() => setType("text")}
                      >
                        <HiOutlineEyeOff />
                      </span>
                    ) : (
                      <span
                        onClick={() => setType("password")}
                        className="toggle-password"
                      >
                        {" "}
                        <HiOutlineEye />
                      </span>
                    )}
                    {/* {formik.errors.password && formik.password && (
                  <p style={{ color: "red" }}>{formik.password}</p>
                )} */}
                    {/* <img src={eyeicon}></img> */}
                  </div>
                </div>
                <div class="form-group">
                  <label class="label">Confirm New Password</label>
                  <div className="d-flex" style={{ position: "relative" }}>
                    <input
                      type="password"
                      class="form-control pass-input"
                      name="password_confirmation"
                      value={formik.password_confirmation}
                      onChange={formik.handleChange}
                    />
                    {type === "password" ? (
                      <span
                        className="toggle-password "
                        onClick={() => setType("text")}
                      >
                        <HiOutlineEyeOff />
                      </span>
                    ) : (
                      <span
                        onClick={() => setType("password")}
                        className="toggle-password"
                      >
                        {" "}
                        <HiOutlineEye />
                      </span>
                    )}

                    {/* <img src={eyeicon}></img> */}
                  </div>
                  {/* {formik.errors.password_confirmation && formik.password_confirmation && (
                           <p style={{ color: "red" }}>{formik.password_confirmation}</p>
                         )} */}
                </div>

                <button type="submit" class="form-group btn login-submit w-100">
                  Reset Password
                </button>
                <a
                  class="form-group btn forgot-submit w-100"
                  onClick={() => navigate("/")}
                >
                  Back to Login
                </a>

                <div class="form-group">
                  <div class="terms-policy">
                    <ul>
                      <li>
                        <a href="#">Terms & Conditions</a>
                      </li>
                      <li>
                        <a href="#">Privacy Policy</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="col-lg-8 col-md-7 col-sm-12 login-bg">
          <div class="welcome-login">
            <h2>Smarter . Simpler . Automated .</h2>
            <p>
              With the world's best staff management solutions, users can
              improve retention as well as productivity.
            </p>
          </div>
          <div class="banner-img">
            <img src={login_banner} class="img-fluid" alt="Login Banner" />
          </div>
          <div class="copyright">
            <div class="row">
              <div class="col-md-6">
                <div class="privacy-policy">
                  <p>Copyrights @ Dreams Hrms 2023</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="copyright-text">
                  <p class="mb-0">
                    Design and Developed by <span>Dreamguy’s</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <PasswordresetModal show={show} setShow={setShow} />
    </div>
  );
}
export default Setpassword;
