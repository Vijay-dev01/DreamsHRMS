import login_logo from "./assets/img/login-logo.svg"
import login_banner from "./assets/img/login-banner.png"
import Waving_Hand from "./assets/img/Waving_Hand.svg"
import React from 'react'
import "./assets/css/style.css"


function Organizationdetails() {
  return (
    <div><div class="main-wrapper">
		
    <div class="row">						
        <div class="col-lg-4 col-md-5 col-sm-12 login-wrap-bg">				

            <div class="login-wrapper">
                <div class="organization-login">
                    <div class="logo-img d-flex align-items-center justify-content-between">
                        <img src={login_logo} class="img-fluid" alt="Logo"/>
                        <div class="sign-group">
                            <a href="#" class="btn sign-up">Sign in<span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span></a>
                        </div>
                    </div>
                    <h2>Organization Details</h2>
                    <p>Hey <img src={Waving_Hand} aria-label="sheep" />, Enter the details to create you account</p>
                    <form action="3">
                        <div class="form-group">
                            <label class="label">Company Name</label>
                            <input type="text" class="form-control"/>
                        </div>
                        <div class="form-group">
                            <div class="form-group">
                                <label>Phone</label>
                                <input type="text"  class="form-control" placeholder="Phone Number" name="name"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>What kind of company it</label>
                            <select class="select">
                                <option>Choose</option>
                                <option>IT Service</option>
                                <option>BPO Service</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>What is your role there? <span>*</span></label>
                            <select class="select">
                                <option>Choose</option>
                                <option>Owner</option>
                                <option>Manager</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>How big is the company? <span>*</span></label>
                            <select class="select">
                                <option>Choose</option>
                                <option>51-100</option>
                                <option>61-200</option>
                                <option>75-200</option>
                            </select>
                        </div>
                        <a href="#" class="form-group btn login-submit w-100">Sign Up</a>
                    </form>								
                </div>
            </div>
           				
        </div>

       
        <div class="col-lg-8 col-md-7 col-sm-12 login-bg">
            <div class="welcome-login">
                <h2>Smarter . Simpler .  Automated .</h2>
                <p>With the world's best staff management solutions, users can improve retention as well as productivity.</p>
            </div>
            <div class="banner-img">
                <img src={login_banner} class="img-fluid" alt="Login Banner"/>
            </div>
            <div class="copyright">
                <div class="row">
                    <div class="col-md-6">
                        <div class="privacy-policy">
                            <p>Copyrights @ Dreams Hrms 2023</p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="copyright-text">
                            <p class="mb-0">Design and Developed by <span>Dreamguy’s</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        		
        
    </div>
   
</div>
</div>
  )
}

export default Organizationdetails