import React from 'react'
import { Link } from 'react-router-dom'
import { allpolicies, allreports, avatar1, avatar2, avatar3, avatar5, avatar6, bar, close, empicon, empmenuicon, funnel, icon, line, logo, picon, ricon, rightarrow, search, shiftschedule, sicon, ticon, timeofficon, timesheet } from '../imagepath'
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import { useState } from 'react';
import Header from '../Header';

const Holiday = () => {
  const [handleClick, sethandleClick] = useState(false);

  return (
    <div>
      {/* Main Wrapper */}
      <div className="main-wrapper">
        {/* Header */}
        {/* <header className="header header-fixed header-one">
          <nav className="navbar navbar-expand-lg header-nav">
            <div className="navbar-header">
              <Link id="mobile_btn" to="#">
                <span className="bar-icon">
                  <span />
                  <span />
                  <span />
                </span>
              </Link>
              <Link to="#" className="navbar-brand logo">
                <img src={logo} className="img-fluid" alt="Logo" />
              </Link>
            </div>
            <div className="main-menu-wrapper">
              <ul className="main-nav">
                <li>
                  <Link to="#">
                    <img src={icon} alt /> Dashboard
                  </Link>
                </li>
                <li className="active">
                  <Link to="employees.html">
                    <img src={empicon} alt /> Employees
                  </Link>
                </li>
                <li>
                  <Link to="#">
                    <img src={ticon} alt /> Time off
                  </Link>
                </li>
                <li>
                  <Link to="#">
                    <img src={picon} alt /> Policies
                  </Link>
                </li>
                <li>
                  <Link to="#">
                    <img src={ricon} alt /> Reports
                  </Link>
                </li>
              </ul>
              <ul className="nav header-navbar-rht">
                <li className="nav-item search-item">
                  <div className="top-nav-search">
                    <form action="#">
                      <input type="text" className="form-control" placeholder="Search" />
                      <button className="btn" type="submit"><i className="feather-search" /></button>
                      <span><img src={sicon} alt /></span>
                    </form>
                  </div>
                </li>
                <li className="nav-item quick-link-item dropdown">
                  <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
                    <span>Quick Links <i className="feather-zap" /></span>
                  </Link>
                  <ul className="dropdown-menu clearfix">
                    <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
                    <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
                    <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
                    <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
                    <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
                    <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
                    <li className="w-100 bottom-list-menu">
                      <ul className="sub-menu clearfix">
                        <li><Link to="#">Documentation</Link></li>
                        <li><Link to="#">Changelog v1.4.4</Link></li>
                        <li><Link to="#">Components</Link></li>
                        <li><Link to="#">Support</Link></li>
                        <li><Link to="#">Terms &amp; Conditions</Link></li>
                        <li><Link to="#">About</Link></li>
                      </ul>
                    </li>
                  </ul>
                </li>
                <li className="nav-item nav-icons">
                  <Link to="#">
                    <i className="feather-sun" />
                  </Link>
                </li>
                <li className="nav-item dropdown has-arrow notification-dropdown">
                  <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                    <i className="feather-bell" />
                    <span className="badge">3</span>
                  </Link>
                  <div className="dropdown-menu dropdown-menu-end notifications">
                    <div className="topnav-dropdown-header">
                      <span className="notification-title">Notifications</span>
                      <Link to="#" className="clear-noti"> Clear All</Link>
                    </div>
                    <div className="noti-content">
                      <ul className="notification-list">
                        <li className="notification-message">
                          <Link to="#">
                            <div className="media d-flex">
                              <span className="avatar flex-shrink-0">
                                <img alt src={avatar1} className="rounded-circle" />
                              </span>
                              <div className="media-body flex-grow-1">
                                <p className="noti-details"><span className="noti-title">John Doe</span>
                                  added new task <span className="noti-title">Patient appointment
                                    booking</span></p>
                                <p className="noti-time"><span className="notification-time">4 mins
                                  ago</span></p>
                              </div>
                            </div>
                          </Link>
                        </li>
                        <li className="notification-message">
                          <Link to="#">
                            <div className="media d-flex">
                              <span className="avatar flex-shrink-0">
                                <img alt src={avatar2} className="rounded-circle" />
                              </span>
                              <div className="media-body flex-grow-1">
                                <p className="noti-details"><span className="noti-title">Tarah
                                  Shropshire</span> changed the task name <span className="noti-title">Appointment booking with payment
                                    gateway</span></p>
                                <p className="noti-time"><span className="notification-time">6 mins
                                  ago</span></p>
                              </div>
                            </div>
                          </Link>
                        </li>
                        <li className="notification-message">
                          <Link to="#">
                            <div className="media d-flex">
                              <span className="avatar flex-shrink-0">
                                <img alt src={avatar6} className="rounded-circle" />
                              </span>
                              <div className="media-body flex-grow-1">
                                <p className="noti-details"><span className="noti-title">Misty
                                  Tison</span> added <span className="noti-title">Domenic
                                    Houston</span> and <span className="noti-title">Claire
                                      Mapes</span> to project <span className="noti-title">Doctor
                                        available module</span></p>
                                <p className="noti-time"><span className="notification-time">8 mins
                                  ago</span></p>
                              </div>
                            </div>
                          </Link>
                        </li>
                        <li className="notification-message">
                          <Link to="#">
                            <div className="media d-flex">
                              <span className="avatar flex-shrink-0">
                                <img alt src={avatar5} className="rounded-circle" />
                              </span>
                              <div className="media-body flex-grow-1">
                                <p className="noti-details"><span className="noti-title">Rolland
                                  Webber</span> completed task <span className="noti-title">Patient and Doctor video
                                    conferencing</span></p>
                                <p className="noti-time"><span className="notification-time">12 mins
                                  ago</span></p>
                              </div>
                            </div>
                          </Link>
                        </li>
                        <li className="notification-message">
                          <Link to="#">
                            <div className="media d-flex">
                              <span className="avatar flex-shrink-0">
                                <img alt src={avatar3} className="rounded-circle" />
                              </span>
                              <div className="media-body flex-grow-1">
                                <p className="noti-details"><span className="noti-title">Bernardo
                                  Galaviz</span> added new task <span className="noti-title">Private chat module</span></p>
                                <p className="noti-time"><span className="notification-time">2 days
                                  ago</span></p>
                              </div>
                            </div>
                          </Link>
                        </li>
                      </ul>
                    </div>
                    <div className="topnav-dropdown-footer">
                      <Link to="#">View all Notifications</Link>
                    </div>
                  </div>
                </li>
                <li className="nav-item nav-icons">
                  <Link to="#">
                    <i className="feather-settings" />
                  </Link>
                </li>
                <li className="nav-item nav-icons">
                  <Link to="#">
                    <i className="far fa-circle-question" />
                  </Link>
                </li>
                <li className="nav-item dropdown has-arrow main-drop">
                  <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                    <span className="user-img">
                      <img src={avatar1} className="img-rounded" alt />
                    </span>
                  </Link>
                  <div className="dropdown-menu">
                    <Link className="dropdown-item" to="#">
                      <i className="feather-user-plus" /> My Profile
                    </Link>
                    <Link className="dropdown-item" to="#">
                      <i className="feather-settings" /> Settings
                    </Link>
                    <Link className="dropdown-item" to="#">
                      <i className="feather-log-out" /> Logout
                    </Link>
                  </div>
                </li>
              </ul>
            </div>
          </nav>
        </header> */}
        <Header/>
        {/* /Header */}
        {/* Page Wrapper */}
        <div className="page-wrapper holiday-page">
          {/* Page Content */}
          <div className="content container">
            {/* Page Header */}
            <div className="page-header">
              <div className="row align-items-center">
                <div className="col-lg-4 col-md-6">
                  <h3 className="page-title">Holidays</h3>
                </div>
                <div className="col-lg-8 col-md-6 page-header-btns page-header-position-btns">
                  <div className="calender-view " id="myTab" role="tablist">
                    <button className="nav-link active btn btn-transparent" id="list-tab-holiday" data-bs-toggle="tab" data-bs-target="#list-view-holiday" type="button" role="tab" aria-controls="list" aria-selected="true"><img src={bar} alt />&nbsp;&nbsp;List View</button>
                    <button onClick={() => sethandleClick(true)} className={handleClick ? "nav-link btn btn-transparent active" : "nav-link btn btn-transparent"} id="cal-tab-holiday" data-bs-toggle="tab" data-bs-target="#cal-view-holiday" type="button" role="tab" aria-controls="cal-view-holiday" aria-selected="true"><i className="fa fa-calendar" aria-hidden="true" />

                      &nbsp;&nbsp;Calendar View</button>


                  </div>
                  <Link to="#" className="btn ">
                    <img src={funnel} alt />
                  </Link>
                  <Link to="#" className="btn ">
                    <img src={bar} alt />
                  </Link>
                  <Link to="#" className="btn ">
                    <img src={search} alt />
                  </Link>
                  <Link to="#" className="btn new-employee-btn" data-bs-toggle="modal" data-bs-target="#addholiday">
                    <i className="fa-solid fa-plus" /> New Holiday
                  </Link>
                </div>
              </div>
            </div>

            {/* /Page Header */}
            {/* Shift List */}
            <div className="tab-content">
              <div className="employee-list holiday-list tab-pane fade show active" id="list-view-holiday" role="tabpane2" aria-labelledby="list-tab-holiday">
                <div className="row">
                  <div className="col-sm-12">
                    <div className="card-table">
                      <div className="card-body">
                        <div className="table-responsive">
                          <table className="table table-center table-hover datatable">
                            <thead className="thead-light">
                              <tr>
                                <th># &nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                                <th>Title &nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                                <th>Holiday Date &nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                                <th>Day &nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                                <th>Action&nbsp;&nbsp;</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1</td>
                                <td>Pongal</td>
                                <td>14-01-2023</td>
                                <td>Saturday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>2</td>
                                <td>Pongal holiday</td>
                                <td>15-01-2023</td>
                                <td>Sunday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>3</td>
                                <td>Republic Day</td>
                                <td>26-01-2023</td>
                                <td>Thursday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>4</td>
                                <td>Tamil New Year</td>
                                <td>14-04-2023</td>
                                <td>Friday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>5</td>
                                <td>Ramazana</td>
                                <td>21-04-2023</td>
                                <td>Friday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>6</td>
                                <td>May Day </td>
                                <td>01-05-2023</td>
                                <td>Monday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>7</td>
                                <td>Independence Day</td>
                                <td>15-08-2023</td>
                                <td>Tuesday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>8</td>
                                <td>Krishna Jayanti</td>
                                <td>15-08-2023</td>
                                <td>Tuesday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>9</td>
                                <td>Vinayagar Chathurthi</td>
                                <td>19-09-2023</td>
                                <td>Tuesday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                              <tr>
                                <td>10</td>
                                <td>Gandhi Jayanthi</td>
                                <td>02-10-2023</td>
                                <td>Monday</td>
                                <td className="d-flex align-items-center">
                                  <div className="dropdown dropdown-action">
                                    <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                                    <div className="dropdown-menu dropdown-menu-end">
                                      <ul>
                                        <li>
                                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                        </li>
                                        <li>
                                          <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                        </li>
                                      </ul>
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                          <div className="pagination-wrap d-flex justify-content-between">
                            <p>Rows Per page&nbsp;&nbsp;<span>10</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
                            <ul className="d-flex">
                              <li><Link to="#" className="active">1</Link></li>
                              <li><Link to="#">2</Link></li>
                              <li><Link to="#">3</Link></li>
                              <li><Link to="#">...</Link></li>
                              <li><Link to="#">10</Link></li>
                              <li><Link to="#">11</Link></li>
                              <li><Link to="#">12</Link></li>
                            </ul>
                            <p>Go to page&nbsp; &nbsp; <img src={line} />&nbsp;
                              &nbsp;<img src={rightarrow} /></p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              {/* /Shift List */}
              {/* calendar-tab */}
              <div className="tab-pane fade" id="cal-view-holiday" role="tabpane3" aria-labelledby="cal-tab-holiday">
                <div className>
                  <div id="calendar" />
                </div>
              </div>
              {/* /calendar-tab */}
            </div>
            <FullCalendar
              plugins={[dayGridPlugin]}
              headerToolbar={{
                left: "prev today next",
                center: "title",
                right: ""
              }}
              initialView="dayGridMonth" />
            {/* Footer */}
            <footer className="footer">
              <div className="container">
                <div className="row">
                  <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                    <div className="footer-left">
                      <p>© 2023 Dreams HRMS</p>
                    </div>
                  </div>
                  <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                    <div className="footer-right">
                      <ul>
                        <li>
                          <Link to="#">Privacy Policy</Link>
                        </li>
                        <li>
                          <Link to="#">Terms &amp; Conditions</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </footer>
            {/* Footer */}
          </div>
          {/* /Page Content */}
        </div>
        {/* /Page Wrapper */}
      </div>
      {/* /Main Wrapper */}
      {/* Modal Popup */}
      {/* Modal Popup */}
      <div className="employees-popup add-holiday">
        <div className="modal fade" id="addholiday" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="addholidayLabel" aria-hidden="true">
          <div className="modal-dialog modal-dialog-centered">
            <div className="modal-content">
              <div className="modal-header">
                <h1 className="modal-title" id="addholidayLabel">Add Holiday</h1>
                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><img src={close} /> </button>
              </div>
              <div className="modal-body">
                <div className="multistep-form">
                  <fieldset className="form-inner" id="first">
                    <div className="form-area">
                      <div className="form-details ">
                        <form action="#">
                          <div className="row">
                            <div className="col-lg-12 col-md-6 col-sm-6 ">
                              <div className="input-area">
                                <label className="form-label">Holiday Name </label>
                                <input type="text" className="form-control" placeholder="Enter Holiday Name" required />
                              </div>
                            </div>
                            <div className="col-lg-12 col-md-6 col-sm-6 ">
                              <div className="input-area date-select">
                                <label className="form-label">Holiday Date <span>*</span></label>
                                <input type='date' className='form-control' name='todate' placeholder='Select Date' />
                                {/* <input type="text" className="form-control datetimepicker" placeholder="Select Date" /> */}
                                {/* <span className="icon"> <i className="feather-calendar" /> </span> */}
                              </div>
                            </div>
                          </div>
                        </form>
                      </div>
                    </div>
                    <div className="add-form-btn widget-next-btn submit-btn">
                      <div className="btn-left">
                        <Link className="btn main-btn ">Save</Link>
                        <Link className="btn close-btn me-0" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
                      </div>
                    </div>
                  </fieldset>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Modal */}
    </div>

  )
}

export default Holiday
