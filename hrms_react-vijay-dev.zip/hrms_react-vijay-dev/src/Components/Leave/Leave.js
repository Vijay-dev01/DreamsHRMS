// import React, { useState } from 'react'
// import { allpolicies, allreports, avatar1, avatar2, avatar3, avatar4, avatar5, avatar6, avatar7, close, document, empicon, empmenuicon, funnel, icon, line, logo, logotitle, medical, money, picon, plane, ricon, rightarrow, shiftschedule, sicon, ticon, timeofficon, timesheet } from '../imagepath'
// import { Link } from 'react-router-dom'
// import { DatePicker, Space } from 'antd';
// import dayjs from 'dayjs';
// import customParseFormat from 'dayjs/plugin/customParseFormat';
// import Header from '../Header';

// dayjs.extend(customParseFormat);

// const { RangePicker } = DatePicker;

// const dateFormat = 'YYYY/MM/DD';


// const Leave = () => {
//   const [share, setShare] = useState(false);
//   const [modal, setModal] = useState(false);

//   const shareShow = () => {
//     console.log('click')
//     setShare(true)
//   }

//   const shareClose = () => {
//     console.log('click')
//     setShare(false)
//   }
//   console.log(share);

//   const modalShow = () => {
//     console.log('click')
//     setModal(true)
//   }

//   const modalClose = () => {
//     console.log('click')
//     setModal(false)
//   }
//   console.log(modal);

//   const Employeetab = () => {
//     return (

//       <div onClick={modalClose}>
//         <ul className={modal ? "dropdown-menu clearfix show" : "dropdown-menu clearfix"} style={{ display: modal ? 'block' : 'none' }}>
//           <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
//           <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
//           <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
//           <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
//           <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
//           <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
//           <li className="w-100 bottom-list-menu">
//             <ul className="sub-menu clearfix">
//               <li><Link to="#">Documentation</Link></li>
//               <li><Link to="#">Changelog v1.4.4</Link></li>
//               <li><Link to="#">Components</Link></li>
//               <li><Link to="#">Support</Link></li>
//               <li><Link to="#">Terms &amp; Conditions</Link></li>
//               <li><Link to="#">About</Link></li>
//             </ul>
//           </li>
//         </ul>
//       </div>
//     )
//   }

//   const Share = () => {
//     return (
//       <div className="employees-popup add-leave ">
//         <div className={share ? "modal fade show" : "modal fade"} style={{ display: share ? 'block' : 'none' }} id="addleave" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="addleaveLabel" aria-hidden="true">
//           <div className="modal-dialog modal-dialog-centered">
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h1 className="modal-title" id="addleaveLabel">New Leave Request</h1>
//                 <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><img src={close} onClick={shareClose} /> </button>
//               </div>
//               <div className="modal-body">
//                 <div className="multistep-form">
//                   <fieldset className="form-inner" id="first">
//                     <div className="form-area">
//                       <div className="form-details ">
//                         <form action="#">
//                           <div className="row">
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Leave Type <span>*</span> </label>
//                                 <select className="form-select select">
//                                   <option selected>Select Leave Type</option>
//                                   <option value={1}>Sick Leave</option>
//                                   <option value={2}>Medical Leave</option>
//                                   <option value={3}>Other</option>
//                                 </select>
//                                 <span className="show-msg">Current Available Leave: <span>10
//                                   Days</span> </span>
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area date-select">
//                                 <label className="form-label">Start of Leave <span>*</span></label>
//                                 <input type='date' className='form-control' name='todate' placeholder='Select Date' />
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area date-select">
//                                 <label className="form-label">End of Leave <span>*</span></label>
//                                 <input type='date' className='form-control' name='todate' placeholder='Select Date' />
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Time Range <span>*</span></label>
//                                 <div className="row">
//                                   <div className="col-lg-4 col-md-6 col-sm-6">
//                                     <div className="form-check">
//                                       <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
//                                       <label className="form-check-label" htmlFor="flexRadioDefault1">
//                                         Full time
//                                       </label>
//                                     </div>
//                                   </div>
//                                   <div className="col-lg-4 col-md-6 col-sm-6">
//                                     <div className="form-check">
//                                       <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" defaultChecked />
//                                       <label className="form-check-label" htmlFor="flexRadioDefault2">
//                                         Morning
//                                       </label>
//                                     </div>
//                                   </div>
//                                   <div className="col-lg-4 col-md-6 col-sm-6">
//                                     <div className="form-check">
//                                       <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault3" defaultChecked />
//                                       <label className="form-check-label" htmlFor="flexRadioDefault3">
//                                         Evening
//                                       </label>
//                                     </div>
//                                   </div>
//                                 </div>
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Number of Days</label>
//                                 <input type="text" className="form-control" placeholder required />
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Leave Reason <span>*</span></label>
//                                 <textarea type="text" className="form-control textarea-cls" placeholder="Enter Reason" required defaultValue={""} />
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Attachment</label>
//                                 <div className="employee-upload-img">
//                                   <p>Drop your files here or <span>Browse</span></p>
//                                   <h6>Maximum size: 50MB</h6>
//                                   <input type="file" className="form-control" />
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </form>
//                       </div>
//                     </div>
//                     <div className="add-form-btn widget-next-btn submit-btn">
//                       <div className="btn-left">
//                         <Link className="btn main-btn ">Save</Link>
//                         <Link className="btn close-btn me-0" data-bs-dismiss="modal" aria-label="Close" onClick={shareClose} >Cancel</Link>
//                       </div>
//                     </div>
//                   </fieldset>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     )
//   }
//   return (
//     <div>
//       <div className="main-wrapper">
//         {/* Header */}
//         {/* <header className="header header-fixed header-one">
//           <nav className="navbar navbar-expand-lg header-nav">
//             <div className="navbar-header">
//               <Link id="mobile_btn" to="#">
//                 <span className="bar-icon">
//                   <span />
//                   <span />
//                   <span />
//                 </span>
//               </Link>
//               <Link to="#" className="navbar-brand logo">
//                 <img src={logo} className="img-fluid" alt="Logo" />
//               </Link>
//             </div>
//             <div className="main-menu-wrapper">
//               <ul className="main-nav">
//                 <li>
//                   <Link to="#">
//                     <img src={icon} alt /> Dashboard
//                   </Link>
//                 </li>
//                 <li className="active">
//                   <Link to="employees.html">
//                     <img src={empicon} alt /> Employees
//                   </Link>
//                 </li>
//                 <li>
//                   <Link to="#">
//                     <img src={ticon} alt /> Time off
//                   </Link>
//                 </li>
//                 <li>
//                   <Link to="#">
//                     <img src={picon} alt /> Policies
//                   </Link>
//                 </li>
//                 <li>
//                   <Link to="#">
//                     <img src={ricon} alt /> Reports
//                   </Link>
//                 </li>
//               </ul>
//               <ul className="nav header-navbar-rht">
//                 <li className="nav-item search-item">
//                   <div className="top-nav-search">
//                     <form action="#">
//                       <input type="text" className="form-control" placeholder="Search" />
//                       <button className="btn" type="submit"><i className="feather-search" /></button>
//                       <span><img src={sicon} alt /></span>
//                     </form>
//                   </div>
//                 </li>
//                 <li className="nav-item quick-link-item">
//                   <Link className="btn" to="#" onClick={modalShow}>
//                     <span>Quick Links <i className="feather-zap" /></span>
//                   </Link>
//                   {<Employeetab />}
//                 </li>
//                 <li className="nav-item nav-icons">
//                   <Link to="#">
//                     <i className="feather-sun" />
//                   </Link>
//                 </li>
//                 <li className="nav-item dropdown has-arrow notification-dropdown">
//                   <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
//                     <i className="feather-bell" />
//                     <span className="badge">3</span>
//                   </Link>
//                   <div className="dropdown-menu dropdown-menu-end notifications">
//                     <div className="topnav-dropdown-header">
//                       <span className="notification-title">Notifications</span>
//                       <Link to="#" className="clear-noti"> Clear All</Link>
//                     </div>
//                     <div className="noti-content">
//                       <ul className="notification-list">
//                         <li className="notification-message">
//                           <Link to="#">
//                             <div className="media d-flex">
//                               <span className="avatar flex-shrink-0">
//                                 <img alt src={avatar1} className="rounded-circle" />
//                               </span>
//                               <div className="media-body flex-grow-1">
//                                 <p className="noti-details"><span className="noti-title">John Doe</span>
//                                   added new task <span className="noti-title">Patient appointment
//                                     booking</span></p>
//                                 <p className="noti-time"><span className="notification-time">4 mins
//                                   ago</span></p>
//                               </div>
//                             </div>
//                           </Link>
//                         </li>
//                         <li className="notification-message">
//                           <Link to="#">
//                             <div className="media d-flex">
//                               <span className="avatar flex-shrink-0">
//                                 <img alt src={avatar2} className="rounded-circle" />
//                               </span>
//                               <div className="media-body flex-grow-1">
//                                 <p className="noti-details"><span className="noti-title">Tarah
//                                   Shropshire</span> changed the task name <span className="noti-title">Appointment booking with payment
//                                     gateway</span></p>
//                                 <p className="noti-time"><span className="notification-time">6 mins
//                                   ago</span></p>
//                               </div>
//                             </div>
//                           </Link>
//                         </li>
//                         <li className="notification-message">
//                           <Link to="#">
//                             <div className="media d-flex">
//                               <span className="avatar flex-shrink-0">
//                                 <img alt src={avatar6} className="rounded-circle" />
//                               </span>
//                               <div className="media-body flex-grow-1">
//                                 <p className="noti-details"><span className="noti-title">Misty
//                                   Tison</span> added <span className="noti-title">Domenic
//                                     Houston</span> and <span className="noti-title">Claire
//                                       Mapes</span> to project <span className="noti-title">Doctor
//                                         available module</span></p>
//                                 <p className="noti-time"><span className="notification-time">8 mins
//                                   ago</span></p>
//                               </div>
//                             </div>
//                           </Link>
//                         </li>
//                         <li className="notification-message">
//                           <Link to="#">
//                             <div className="media d-flex">
//                               <span className="avatar flex-shrink-0">
//                                 <img alt src={avatar5} className="rounded-circle" />
//                               </span>
//                               <div className="media-body flex-grow-1">
//                                 <p className="noti-details"><span className="noti-title">Rolland
//                                   Webber</span> completed task <span className="noti-title">Patient and Doctor video
//                                     conferencing</span></p>
//                                 <p className="noti-time"><span className="notification-time">12 mins
//                                   ago</span></p>
//                               </div>
//                             </div>
//                           </Link>
//                         </li>
//                         <li className="notification-message">
//                           <Link to="#">
//                             <div className="media d-flex">
//                               <span className="avatar flex-shrink-0">
//                                 <img alt src={avatar3} className="rounded-circle" />
//                               </span>
//                               <div className="media-body flex-grow-1">
//                                 <p className="noti-details"><span className="noti-title">Bernardo
//                                   Galaviz</span> added new task <span className="noti-title">Private chat module</span></p>
//                                 <p className="noti-time"><span className="notification-time">2 days
//                                   ago</span></p>
//                               </div>
//                             </div>
//                           </Link>
//                         </li>
//                       </ul>
//                     </div>
//                     <div className="topnav-dropdown-footer">
//                       <Link to="#">View all Notifications</Link>
//                     </div>
//                   </div>
//                 </li>
//                 <li className="nav-item nav-icons">
//                   <Link to="#">
//                     <i className="feather-settings" />
//                   </Link>
//                 </li>
//                 <li className="nav-item nav-icons">
//                   <Link to="#">
//                     <i className="far fa-circle-question" />
//                   </Link>
//                 </li>
//                 <li className="nav-item dropdown has-arrow main-drop">
//                   <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
//                     <span className="user-img">
//                       <img src={avatar1} className="img-rounded" alt />
//                     </span>
//                   </Link>
//                   <div className="dropdown-menu">
//                     <Link className="dropdown-item" to="#">
//                       <i className="feather-user-plus" /> My Profile
//                     </Link>
//                     <Link className="dropdown-item" to="#">
//                       <i className="feather-settings" /> Settings
//                     </Link>
//                     <Link className="dropdown-item" to="#">
//                       <i className="feather-log-out" /> Logout
//                     </Link>
//                   </div>
//                 </li>
//               </ul>
//             </div>
//           </nav>
//         </header> */}
//         <Header />
//         {/* /Header */}
//         {/* Page Wrapper */}
//         <div className="page-wrapper leave-page">
//           {/* Page Content */}
//           <div className="content container">
//             {/* Page Header */}
//             <div className="page-header">
//               <div className="row align-items-center">
//                 <div className="col-lg-4 col-md-6">
//                   <h3 className="page-title">Leaves</h3>
//                 </div>
//                 <div className="col-lg-8 col-md-6 page-header-btns page-header-position-btns">
//                   <div className="d-lg-flex justify-content-between align-items-center profile-items">
//                     <div className="day-calendar">
//                       <button className="btn btn-outline-dark date-picker">Day&nbsp;&nbsp;<i className="fa fa-chevron-down" aria-hidden="true" /></button>
//                       <div className="d-inline btn-group">
//                         {/* <button className="btn btn-outline-dark date-picker"><i className="fa fa-chevron-left" aria-hidden="true" /></button><button className="btn btn-outline-dark"> */}
//                         {/* <RangePicker picker="week" /> */}
//                         <RangePicker
//                           defaultValue={[dayjs('2015/01/01', dateFormat), dayjs('2015/01/01', dateFormat)]}
//                           format={dateFormat}
//                         />
//                         {/* &nbsp;&nbsp;</button><button className="btn btn-outline-dark date-picker"><i className="fa fa-chevron-right" aria-hidden="true" /></button> */}
//                       </div>
//                       <button className="btn btn-outline-dark">Week
//                         &nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" />
//                       </button>
//                     </div>
//                   </div>
//                   <Link to="#" className="btn ">
//                     <img src={funnel} alt />
//                   </Link>
//                   <Link to="#" className="btn new-employee-btn" data-bs-toggle="modal" data-bs-target="#addleave">
//                     <i className="fa-solid fa-plus" onClick={shareShow} /> Add Leave
//                   </Link>
//                   {<Share />}
//                 </div>
//               </div>
//             </div>
//             {/* /Page Header */}
//             {/* leave Grid */}
//             <div className="leave-grid-view">
//               <div className="row">
//                 <div className="col-sm-12 col-md-6 col-lg-3 list float-start">
//                   <div className="white-bg">
//                     <div className="d-flex avg-working-hrs">
//                       <div className="flex-grow-1">
//                         <h4>Annual Leave</h4>
//                         <span>13 Employees applied</span>
//                       </div>
//                       <i className="text-center"><img src={money} className="align-middle" alt /></i>
//                     </div>
//                     <div className="percentage">
//                       <div className="depart-team">
//                         <div className="depart-group">
//                           <div className="depart-avatar">
//                             <img src={avatar1} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar2} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar3} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <span className="avatar-title rounded-circle border border-white">35+</span>
//                           </div>
//                         </div>
//                       </div>
//                       <h6 className="footer-text high"><i className="fa-solid fa-arrow-right"> </i> 20</h6>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="col-sm-12 col-md-6 col-lg-3 list float-start">
//                   <div className="white-bg">
//                     <div className="d-flex working-hrs">
//                       <div className="flex-grow-1">
//                         <h4>Medical Leave</h4>
//                         <span>17 Employees applied</span>
//                       </div>
//                       <i className="text-center"><img src={medical} className="align-middle" alt /></i>
//                     </div>
//                     <div className="percentage">
//                       <div className="depart-team">
//                         <div className="depart-group">
//                           <div className="depart-avatar">
//                             <img src={avatar1} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar2} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar3} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <span className="avatar-title rounded-circle border border-white">35+</span>
//                           </div>
//                         </div>
//                       </div>
//                       <h6 className="footer-text low"><i className="fa-solid fa-arrow-right"> </i> 05</h6>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="col-sm-12 col-md-6 col-lg-3 list float-start">
//                   <div className="white-bg">
//                     <div className="d-flex late-login">
//                       <div className="flex-grow-1">
//                         <h4>Vacation Leave</h4>
//                         <span>7 Employees applied</span>
//                       </div>
//                       <i className="text-center"><img src={plane} className="align-middle" alt /></i>
//                     </div>
//                     <div className="percentage">
//                       <div className="depart-team">
//                         <div className="depart-group">
//                           <div className="depart-avatar">
//                             <img src={avatar1} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar2} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar3} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <span className="avatar-title rounded-circle border border-white">35+</span>
//                           </div>
//                         </div>
//                       </div>
//                       <h6 className="footer-text high"><i className="fa-solid fa-arrow-right"> </i> 03</h6>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="col-sm-12 col-md-6 col-lg-3 list float-start">
//                   <div className="white-bg">
//                     <div className="d-flex overtime-hrs">
//                       <div className="flex-grow-1">
//                         <h4>Loss of Pay</h4>
//                         <span>15 Employees applied</span>
//                       </div>
//                       <i className="text-center"><img src={document} className="align-middle" alt /></i>
//                     </div>
//                     <div className="percentage">
//                       <div className="depart-team">
//                         <div className="depart-group">
//                           <div className="depart-avatar">
//                             <img src={avatar1} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar2} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <img src={avatar3} className="avatar-img rounded-circle border border-white " />
//                           </div>
//                           <div className="depart-avatar">
//                             <span className="avatar-title rounded-circle border border-white">35+</span>
//                           </div>
//                         </div>
//                       </div>
//                       <h6 className="footer-text low"><i className="fa-solid fa-arrow-right"> </i> 07</h6>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             {/* /leave Grid */}
//             {/* Page Header */}
//             <div className="page-header second-title">
//               <div className="row align-items-center">
//                 <div className="col-lg-4 col-md-6">
//                   <h3 className="page-title">Leave History <span>25</span></h3>
//                 </div>
//                 <div className="col-lg-8 col-md-6 ">
//                   <div className="mynav2" />
//                 </div>
//               </div>
//             </div>
//             {/* /Page Header */}
//             {/* Leave request */}
//             <div className="leave-request">
//               <div className="row">
//                 <div className="col-lg-12">
//                   <div className="owl-carousel owl-theme featured-slider">
//                     <div className="item index-1">
//                       <div className="leave-popup">
//                         <div className="leave-card">
//                           <div className="card-body">
//                             <div className="card-header">
//                               <div className="depart-avatar">
//                                 <img src={avatar1} className="avatar-img rounded-circle border border-white " />
//                               </div>
//                               <div className="leave-title ">
//                                 <h4>John Smith,<span> UI/UX Designer</span></h4>
//                                 <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Sick Leave</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                             </div>
//                             <div className="card-footer">
//                               <Link to="#" className="btn apply-btn">
//                                 <i className="fa-solid fa-check" /> Approve
//                               </Link>
//                               <Link to="#" className="btn reject-btn" onclick="leaveopen(1)">
//                                 <i className="fa-solid fa-check" /> Reject
//                               </Link>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="leave-inner">
//                           <div className="rejectionpopup rejectionpopup-1">
//                             <div className="leave-part">
//                               <h2>Reason for Rejection</h2>
//                               <div className="leave-msg">
//                                 <form action="#">
//                                   <div className="input-area">
//                                     <textarea type="text" cols={5} className="form-control" placeholder="Enter Season" defaultValue={""} />
//                                   </div>
//                                 </form>
//                                 <div className="leave-btn">
//                                   <Link className="btn main-btn" to="#">Save</Link>
//                                   <Link className="btn close-btn me-0" to="#" onclick="leaveclose(1)" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     <div className="item index-2">
//                       <div className="leave-popup">
//                         <div className="leave-card">
//                           <div className="card-body">
//                             <div className="card-header">
//                               <div className="depart-avatar">
//                                 <img src={avatar5} className="avatar-img rounded-circle border border-white " />
//                               </div>
//                               <div className="leave-title ">
//                                 <h4>John Smith,<span> UI/UX Designer</span></h4>
//                                 <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Sick Leave</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                             </div>
//                             <div className="card-footer">
//                               <Link to="#" className="btn apply-btn">
//                                 <i className="fa-solid fa-check" /> Approve
//                               </Link>
//                               <Link to="#" className="btn reject-btn" onclick="leaveopen(2)">
//                                 <i className="fa-solid fa-check" /> Reject
//                               </Link>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="leave-inner">
//                           <div className="rejectionpopup rejectionpopup-2">
//                             <div className="leave-part">
//                               <h2>Reason for Rejection</h2>
//                               <div className="leave-msg">
//                                 <form action="#">
//                                   <div className="input-area">
//                                     <textarea type="text" cols={5} className="form-control" placeholder="Enter Season" defaultValue={""} />
//                                   </div>
//                                 </form>
//                                 <div className="leave-btn">
//                                   <Link className="btn main-btn" to="#">Save</Link>
//                                   <Link className="btn close-btn me-0" to="#" onclick="leaveclose(2)" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     <div className="item index-3">
//                       <div className="leave-popup">
//                         <div className="leave-card">
//                           <div className="card-body">
//                             <div className="card-header">
//                               <div className="depart-avatar">
//                                 <img src={avatar4} className="avatar-img rounded-circle border border-white " />
//                               </div>
//                               <div className="leave-title ">
//                                 <h4>Smith,<span> Finance Officer</span></h4>
//                                 <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Sick Leave</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                             </div>
//                             <div className="card-footer">
//                               <Link to="#" className="btn apply-btn">
//                                 <i className="fa-solid fa-check" /> Approve
//                               </Link>
//                               <Link to="#" className="btn reject-btn" onclick="leaveopen(3)">
//                                 <i className="fa-solid fa-check" /> Reject
//                               </Link>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="leave-inner">
//                           <div className="rejectionpopup rejectionpopup-3">
//                             <div className="leave-part">
//                               <h2>Reason for Rejection</h2>
//                               <div className="leave-msg">
//                                 <form action="#">
//                                   <div className="input-area">
//                                     <textarea type="text" cols={5} className="form-control" placeholder="Enter Season" defaultValue={""} />
//                                   </div>
//                                 </form>
//                                 <div className="leave-btn">
//                                   <Link className="btn main-btn" to="#">Save</Link>
//                                   <Link className="btn close-btn me-0" to="#" onclick="leaveclose(3)" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     <div className="item index-4">
//                       <div className="leave-popup">
//                         <div className="leave-card">
//                           <div className="card-body">
//                             <div className="card-header">
//                               <div className="depart-avatar">
//                                 <img src={avatar6} className="avatar-img rounded-circle border border-white " />
//                               </div>
//                               <div className="leave-title ">
//                                 <h4>Mike Litorus,<span> UI/UX Designer</span></h4>
//                                 <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Sick Leave</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                             </div>
//                             <div className="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                             </div>
//                             <div className="card-footer">
//                               <Link to="#" className="btn apply-btn">
//                                 <i className="fa-solid fa-check" /> Approve
//                               </Link>
//                               <Link to="#" className="btn reject-btn" onclick="leaveopen(4)">
//                                 <i className="fa-solid fa-check" /> Reject
//                               </Link>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="leave-inner">
//                           <div className="rejectionpopup rejectionpopup-4">
//                             <div className="leave-part">
//                               <h2>Reason for Rejection</h2>
//                               <div className="leave-msg">
//                                 <form action="#">
//                                   <div className="input-area">
//                                     <textarea type="text" cols={5} className="form-control" placeholder="Enter Season" defaultValue={""} />
//                                   </div>
//                                 </form>
//                                 <div className="leave-btn">
//                                   <Link className="btn main-btn" to="#">Save</Link>
//                                   <Link className="btn close-btn me-0" to="#" onclick="leaveclose()" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                     {/* <div class="item">
//                           <div class="leave-card">
//                               <div class="card-body">
//                                   <div class="card-header">
//                                       <div class="depart-avatar">
//                                           <img src={avatar5}
//                                               class="avatar-img rounded-circle border border-white ">
//                                       </div>
//                                       <div class="leave-title ">
//                                           <h4>Richard,<span> Frontend Designer</span></h4>
//                                           <p>Mar 26 - Mar 27, 2023</p>
//                                       </div>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Leave Type:</h5>
//                                       <p>Medical Leave</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>No of Days:</h5>
//                                       <p>1 Days</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Remaining Leave:</h5>
//                                       <p>4 Days</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Leave Reason:</h5>
//                                       <p>Lorem ipsum dolor sit ,</p>
//                                   </div>
//                                   <div class="card-footer">
//                                       <Link to="#" class="btn apply-btn">
//                                           <i class="fa-solid fa-check"></i> Approve
//                                       </Link>
//                                       <Link to="#" class="btn reject-btn">
//                                           <i class="fa-solid fa-check"></i> Reject
//                                       </Link>
//                                   </div>
//                               </div>
//                           </div>
//                       </div>
//                       <div class="item">
//                           <div class="leave-card">
//                               <div class="card-body">
//                                   <div class="card-header">
//                                       <div class="depart-avatar">
//                                           <img src={avatar6}
//                                               class="avatar-img rounded-circle border border-white ">
//                                       </div>
//                                       <div class="leave-title ">
//                                           <h4>Smith,<span> Finance Officer</span></h4>
//                                           <p>Mar 26 - Mar 27, 2023</p>
//                                       </div>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Leave Type:</h5>
//                                       <p>Annual Leave</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>No of Days:</h5>
//                                       <p>2 Days</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Remaining Leave:</h5>
//                                       <p>10 Days</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Leave Reason:</h5>
//                                       <p>Lorem ipsum dolor sit ,</p>
//                                   </div>
//                                   <div class="card-footer">
//                                       <Link to="#" class="btn apply-btn">
//                                           <i class="fa-solid fa-check"></i> Approve
//                                       </Link>
//                                       <Link to="#" class="btn reject-btn">
//                                           <i class="fa-solid fa-check"></i> Reject
//                                       </Link>
//                                   </div>
//                               </div>

//                           </div>
//                       </div>
//                       <div class="item">
//                           <div class="leave-card">
//                               <div class="card-body">
//                                   <div class="card-header">
//                                       <div class="depart-avatar">
//                                           <img src={avatar2}
//                                               class="avatar-img rounded-circle border border-white ">
//                                       </div>
//                                       <div class="leave-title ">
//                                           <h4>Mike Litorus,<span> UI/UX Designer</span></h4>
//                                           <p>Mar 26 - Mar 27, 2023</p>
//                                       </div>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Leave Type:</h5>
//                                       <p>Sick Leave</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>No of Days:</h5>
//                                       <p>2 Days</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Remaining Leave:</h5>
//                                       <p>4 Days</p>
//                                   </div>
//                                   <div class="card-detail">
//                                       <h5>Leave Reason:</h5>
//                                       <p>Lorem ipsum dolor sit ,</p>
//                                   </div>
//                                   <div class="card-footer">
//                                       <Link to="#" class="btn apply-btn">
//                                           <i class="fa-solid fa-check"></i> Approve
//                                       </Link>
//                                       <Link to="#" class="btn reject-btn">
//                                           <i class="fa-solid fa-check"></i> Reject
//                                       </Link>
//                                   </div>
//                               </div>
//                           </div>
//                           <div class="leave-inner">
//                               <div id="rejectionpopup">
//                                   <div class="leave-part">
//                                       <h2>Reason for Rejection</h2>
//                                       <div class="leave-msg">
//                                           <form action="#">
//                                               <div class="input-area">
//                                                   <textarea type="text" class="form-control"
//                                                       placeholder="Enter Season"></textarea>
//                                               </div>
//                                           </form>
//                                           <div class="leave-btn">
//                                               <Link class="btn main-btn" to="#">Save</Link>
//                                               <Link class="btn close-btn me-0" to="#"
//                                                   onclick="leaveclose()" data-bs-dismiss="modal"
//                                                   aria-label="Close">Cancel</Link>
//                                           </div>
//                                       </div>
//                                   </div>
//                               </div>
//                           </div>
//                       </div> */}
//                   </div>
//                 </div>
//                 {/* <div class="col-sm-12 col-md-6 col-lg-3 leave-popup">
//                   <div class="leave-card">
//                       <div class="card-body">
//                           <div class="card-header">
//                               <div class="depart-avatar">
//                                   <img src={avatar1}
//                                       class="avatar-img rounded-circle border border-white ">
//                               </div>
//                               <div class="leave-title ">
//                                   <h4>John Smith,<span> UI/UX Designer</span></h4>
//                                   <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Sick Leave</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                           </div>
//                           <div class="card-footer">
//                               <Link to="#" class="btn apply-btn">
//                                   <i class="fa-solid fa-check"></i> Approve
//                               </Link>
//                               <Link to="#" class="btn reject-btn" onclick="leaveopen()">
//                                   <i class="fa-solid fa-check"></i> Reject
//                               </Link>
//                           </div>
//                       </div>
//                   </div>
//                   <div class="leave-inner">
//                       <div id="rejectionpopup">
//                           <div class="leave-part">
//                               <h2>Reason for Rejection</h2>
//                               <div class="leave-msg">
//                                   <form action="#">
//                                       <div class="input-area">
//                                           <textarea type="text" class="form-control"
//                                               placeholder="Enter Season"></textarea>
//                                       </div>
//                                   </form>
//                                   <div class="leave-btn">
//                                       <Link class="btn main-btn" to="#">Save</Link>
//                                       <Link class="btn close-btn me-0" to="#"
//                                           onclick="leaveclose()" data-bs-dismiss="modal"
//                                           aria-label="Close">Cancel</Link>
//                                   </div>
//                               </div>
//                           </div>
//                       </div>
//                   </div>
//               </div>
//               <div class="col-sm-12 col-md-6 col-lg-3">
//                   <div class="leave-card">
//                       <div class="card-body">
//                           <div class="card-header">
//                               <div class="depart-avatar">
//                                   <img src={avatar5}
//                                       class="avatar-img rounded-circle border border-white ">
//                               </div>
//                               <div class="leave-title ">
//                                   <h4>Richard,<span> Frontend Designer</span></h4>
//                                   <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Medical Leave</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>1 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                           </div>
//                           <div class="card-footer">
//                               <Link to="#" class="btn apply-btn">
//                                   <i class="fa-solid fa-check"></i> Approve
//                               </Link>
//                               <Link to="#" class="btn reject-btn">
//                                   <i class="fa-solid fa-check"></i> Reject
//                               </Link>
//                           </div>
//                       </div>

//                   </div>
//               </div>
//               <div class="col-sm-12 col-md-6 col-lg-3">
//                   <div class="leave-card">
//                       <div class="card-body">
//                           <div class="card-header">
//                               <div class="depart-avatar">
//                                   <img src={avatar6}
//                                       class="avatar-img rounded-circle border border-white ">
//                               </div>
//                               <div class="leave-title ">
//                                   <h4>Smith,<span> Finance Officer</span></h4>
//                                   <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Annual Leave</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>10 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                           </div>
//                           <div class="card-footer">
//                               <Link to="#" class="btn apply-btn">
//                                   <i class="fa-solid fa-check"></i> Approve
//                               </Link>
//                               <Link to="#" class="btn reject-btn">
//                                   <i class="fa-solid fa-check"></i> Reject
//                               </Link>
//                           </div>
//                       </div>

//                   </div>
//               </div>
//               <div class="col-sm-12 col-md-6 col-lg-3">
//                   <div class="department-card">
//                       <div class="card-body">
//                           <div class="card-header">
//                               <div class="depart-avatar">
//                                   <img src={avatar2}
//                                       class="avatar-img rounded-circle border border-white ">
//                               </div>
//                               <div class="leave-title ">
//                                   <h4>Mike Litorus,<span> UI/UX Designer</span></h4>
//                                   <p>Mar 26 - Mar 27, 2023</p>
//                               </div>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Type:</h5>
//                               <p>Sick Leave</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>No of Days:</h5>
//                               <p>2 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Remaining Leave:</h5>
//                               <p>4 Days</p>
//                           </div>
//                           <div class="card-detail">
//                               <h5>Leave Reason:</h5>
//                               <p>Lorem ipsum dolor sit ,</p>
//                           </div>
//                           <div class="card-footer">
//                               <Link to="#" class="btn apply-btn">
//                                   <i class="fa-solid fa-check"></i> Approve
//                               </Link>
//                               <Link to="#" class="btn reject-btn">
//                                   <i class="fa-solid fa-check"></i> Reject
//                               </Link>
//                           </div>
//                       </div>

//                   </div>
//               </div> */}
//               </div>
//             </div>
//             {/* Leave request */}
//             {/* Leave History */}
//             <div className="page-header third-title">
//               <div className="row align-items-center">
//                 <div className="col-lg-6 col-md-6">
//                   <h3 className="page-title">Leave History</h3>
//                 </div>
//                 <div className="col-lg-6 col-md-6 ">
//                   <div className="form-group float-end search d-inline">
//                     <i className="feather-search" />
//                     <input type="text" className="form-control" placeholder="Search" />
//                   </div>
//                 </div>
//               </div>
//             </div>
//             {/* Leave History */}
//             {/* Employee List */}
//             <div className="leave-history">
//               <div className="row">
//                 <div className="col-sm-12">
//                   <div className="card-table">
//                     <div className="card-body">
//                       <div className="table-responsive">
//                         <table className="table table-center table-hover datatable">
//                           <thead className="thead-light">
//                             <tr>
//                               <th>#&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" />
//                               </th>
//                               <th>Leave Name&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                               <th>Department&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                               <th>Date&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                               <th>Leave Type&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                               <th>Status&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                               <th>Employee Name&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                               <th>Action&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                             </tr>
//                           </thead>
//                           <tbody>
//                             <tr>
//                               <td>1</td>
//                               <td>
//                                 <h2 className="table-avatar d-flex">
//                                   <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User Image" /></Link>
//                                   <Link to="#">John Smith <br />
//                                     <span>UI/UX Team Lead</span></Link>
//                                 </h2>
//                               </td>
//                               <td>
//                                 <p>Mar 12, 2022 - Mar 14, 2022</p><span>3 Days</span>
//                               </td>
//                               <td>
//                                 <p>Mar 12, 2022 - Mar 14, 2022</p><span>3 Days</span>
//                               </td>
//                               <td>
//                                 <p>Sick Leave</p>
//                               </td>
//                               <td><span className="success-status text-center">Approved</span></td>
//                               <td>
//                                 <h2 className="table-avatar d-flex">
//                                   <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User Image" /></Link>
//                                   <Link to="#">John Smith <br />
//                                     <span>DGT-365</span></Link>
//                                 </h2>
//                               </td>
//                               <td className="d-flex align-items-center">
//                                 <div className="dropdown dropdown-action">
//                                   <Link to="#" className=" btn-action-icon">View</Link>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>2</td>
//                               <td>
//                                 <h2 className="table-avatar d-flex">
//                                   <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar5} alt="User Image" /></Link>
//                                   <Link to="#">David <br />
//                                     <span>UI/UX Team Lead</span></Link>
//                                 </h2>
//                               </td>
//                               <td>
//                                 <p>Mar 20, 2022 - Mar 30, 2022</p><span>10 Days</span>
//                               </td>
//                               <td>
//                                 <p>Mar 21, 2022 - Mar 24, 2022</p><span>3 Days</span>
//                               </td>
//                               <td>
//                                 <p>Sick Leave</p>
//                               </td>
//                               <td><span className="success-status text-center">Approved</span></td>
//                               <td>
//                                 <h2 className="table-avatar d-flex">
//                                   <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar5} alt="User Image" /></Link>
//                                   <Link to="#">David<br />
//                                     <span>DGT-365</span></Link>
//                                 </h2>
//                               </td>
//                               <td className="d-flex align-items-center">
//                                 <div className="dropdown dropdown-action">
//                                   <Link to="#" className=" btn-action-icon">View</Link>
//                                 </div>
//                               </td>
//                             </tr>
//                             <tr>
//                               <td>3</td>
//                               <td>
//                                 <h2 className="table-avatar d-flex">
//                                   <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar7} alt="User Image" /></Link>
//                                   <Link to="#">Paul <br />
//                                     <span>UI/UX Team Lead</span></Link>
//                                 </h2>
//                               </td>
//                               <td>
//                                 <p>Mar 21, 2022 - Mar 22, 2022</p><span>1 Days</span>
//                               </td>
//                               <td>
//                                 <p>Mar 21, 2022 - Mar 22, 2022</p><span>1 Days</span>
//                               </td>
//                               <td>
//                                 <p>Sick Leave</p>
//                               </td>
//                               <td><span className="warning-status text-center">Rejected</span></td>
//                               <td>
//                                 <h2 className="table-avatar d-flex">
//                                   <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar7} alt="User Image" /></Link>
//                                   <Link to="#">Paul<br />
//                                     <span>DGT-365</span></Link>
//                                 </h2>
//                               </td>
//                               <td className="d-flex align-items-center">
//                                 <div className="dropdown dropdown-action">
//                                   <Link to="#" className=" btn-action-icon">View</Link>
//                                 </div>
//                               </td>
//                             </tr>
//                           </tbody>
//                         </table>
//                         <div className="pagination-wrap d-flex justify-content-between">
//                           <p>Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
//                           <ul className="d-flex">
//                             <li><Link to="#">1</Link></li>
//                             <li><Link to="#">2</Link></li>
//                             <li><Link to="#">3</Link></li>
//                             <li><Link to="#">...</Link></li>
//                             <li><Link to="#">10</Link></li>
//                             <li><Link to="#">11</Link></li>
//                             <li><Link to="#">12</Link></li>
//                           </ul>
//                           <p>Go to page&nbsp; &nbsp; <img src={line} />&nbsp;
//                             &nbsp;<img src={rightarrow} /></p>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//             {/* Employee List */}
//             {/* Footer */}
//             <footer className="footer leave_footer">
//               <div className="container">
//                 <div className="row">
//                   <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
//                     <div className="footer-left">
//                       <p>© 2023 Dreams HRMS <span>Developed by</span> </p>
//                       <img src={logotitle} />
//                     </div>
//                   </div>
//                   <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
//                     <div className="footer-right">
//                       <ul>
//                         <li>
//                           <Link to="#">Privacy Policy</Link>
//                         </li>
//                         <li>
//                           <Link to="#">Terms &amp; Conditions</Link>
//                         </li>
//                       </ul>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </footer>
//             {/* Footer */}
//           </div>
//           {/* /Page Content */}
//         </div>
//         {/* /Page Wrapper */}
//       </div>
//       {/* /Main Wrapper */}
//       {/* Modal Popup */}
//       <div className="employees-popup add-leave ">
//         <div className="modal fade" id="addleave" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="addleaveLabel" aria-hidden="true">
//           <div className="modal-dialog modal-dialog-centered">
//             <div className="modal-content">
//               <div className="modal-header">
//                 <h1 className="modal-title" id="addleaveLabel">New Leave Request</h1>
//                 <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><img src={close} /> </button>
//               </div>
//               <div className="modal-body">
//                 <div className="multistep-form">
//                   <fieldset className="form-inner" id="first">
//                     <div className="form-area">
//                       <div className="form-details ">
//                         <form action="#">
//                           <div className="row">
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Leave Type <span>*</span> </label>
//                                 <select className="form-select select">
//                                   <option selected>Select Leave Type</option>
//                                   <option value={1}>Sick Leave</option>
//                                   <option value={2}>Medical Leave</option>
//                                   <option value={3}>Other</option>
//                                 </select>
//                                 <span className="show-msg">Current Available Leave: <span>10
//                                   Days</span> </span>
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area date-select">
//                                 <label className="form-label">Start of Leave <span>*</span></label>
//                                 <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
//                                 <span className="icon"> <i className="feather-calendar" /> </span>
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area date-select">
//                                 <label className="form-label">End of Leave <span>*</span></label>
//                                 <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
//                                 <span className="icon"> <i className="feather-calendar" /> </span>
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Time Range <span>*</span></label>
//                                 <div className="row">
//                                   <div className="col-lg-4 col-md-6 col-sm-6">
//                                     <div className="form-check">
//                                       <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
//                                       <label className="form-check-label" htmlFor="flexRadioDefault1">
//                                         Full time
//                                       </label>
//                                     </div>
//                                   </div>
//                                   <div className="col-lg-4 col-md-6 col-sm-6">
//                                     <div className="form-check">
//                                       <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" defaultChecked />
//                                       <label className="form-check-label" htmlFor="flexRadioDefault2">
//                                         Morning
//                                       </label>
//                                     </div>
//                                   </div>
//                                   <div className="col-lg-4 col-md-6 col-sm-6">
//                                     <div className="form-check">
//                                       <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault3" defaultChecked />
//                                       <label className="form-check-label" htmlFor="flexRadioDefault3">
//                                         Evening
//                                       </label>
//                                     </div>
//                                   </div>
//                                 </div>
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Number of Days</label>
//                                 <input type="text" className="form-control" placeholder required />
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Leave Reason <span>*</span></label>
//                                 <textarea type="text" className="form-control textarea-cls" placeholder="Enter Reason" required defaultValue={""} />
//                               </div>
//                             </div>
//                             <div className="col-lg-12 col-md-6 col-sm-6 ">
//                               <div className="input-area">
//                                 <label className="form-label">Attachment</label>
//                                 <div className="employee-upload-img">
//                                   <p>Drop your files here or <span>Browse</span></p>
//                                   <h6>Maximum size: 50MB</h6>
//                                   <input type="file" className="form-control" />
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </form>
//                       </div>
//                     </div>
//                     <div className="add-form-btn widget-next-btn submit-btn">
//                       <div className="btn-left">
//                         <Link className="btn main-btn ">Save</Link>
//                         <Link className="btn close-btn me-0" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
//                       </div>
//                     </div>
//                   </fieldset>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>

//   )
// }

// export default Leave



import React from 'react'
import Footer from '../Footer'
import Header from '../Header'
import { Link } from 'react-router-dom'
import { avatar1, avatar2, avatar3, avatar5, avatar7, close, document, funnel, medical, money, plane } from '../imagepath'

const Leave = () => {
  return (
    <div>
  <div className="main-wrapper">
    {/* Header */}
    {/* <header className="header header-fixed header-one">
      <nav className="navbar navbar-expand-lg header-nav">
        <div className="navbar-header">
          <Link id="mobile_btn" to="#">
            <span className="bar-icon">
              <span />
              <span />
              <span />
            </span>
          </Link>
          <Link to="#" className="navbar-brand logo">
            <img src="assets/img/logo.svg" className="img-fluid" alt="Logo" />
          </Link>
        </div>
        <div className="main-menu-wrapper">
          <ul className="main-nav">
            <li>
              <Link to="#">
                <span className="me-2"><i className="fa-solid fa-gauge" /></span> Dashboard
              </Link>
            </li>
            <li className="active nav-item quick-link-item dropdown">
              <Link className="dropdown-toggle" data-bs-toggle="dropdown" to="employees.html" role="button" aria-expanded="false">
                <span className="me-2"><i className="fa-solid fa-users" /></span>Employees
              </Link>
              <ul className="dropdown-menu clearfix employees-menu">
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/employees-menu-icon.svg" alt />Employees</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/timeoff-icon.svg" alt />Leave Report</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/timesheet-icon.svg" alt className="attendance" />Attendance</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/shift-schedule.svg" alt />Shift &amp; Schedule</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/employees-menu-icon.svg" alt />Teams</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/department.svg" alt />Department</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/org-chart.svg" alt />Organization Chart</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/timesheet.svg" alt />Timesheet</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/onboarding.svg" alt />Onboarding</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/Offboarding.svg" alt />Offboarding Report</Link></li>
              </ul>
            </li>
            <li>
              <Link to="#">
                <span className="me-2"><i className="fa-solid fa-plane-departure" /></span> Time off
              </Link>
            </li>
            <li>
              <Link to="#">
                <span className="me-2"><i className="fa-solid fa-file" /></span> Policies
              </Link>
            </li>
            <li>
              <Link to="#">
                <span className="me-2"><i className="fa-solid fa-chart-pie" /></span> Reports
              </Link>
            </li>
          </ul>
          <ul className="nav header-navbar-rht darkLight-searchBox">
            <li className="nav-item search-item">
              <div className="top-nav-search">
                <form action="#">
                  <input type="text" className="form-control" placeholder="Search" />
                  <button className="btn" type="submit"><i className="feather-search" /></button>
                  <span><img src="assets/img/icons/shortcut-icon.svg" alt /></span>
                </form>
              </div>
            </li>
            <li className="nav-item quick-link-item dropdown">
              <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
                <span>Quick Links <i className="feather-zap" /></span>
              </Link>
              <ul className="dropdown-menu clearfix">
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/employees-menu-icon.svg" alt />Employees</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/timeoff-icon.svg" alt />Time Off</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/timesheet-icon.svg" alt />Timesheet</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/allpolicies-icon.svg" alt />All Policies</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/allreports-icon.svg" alt />Shift &amp; Schedule</Link></li>
                <li><Link className="dropdown-item" to="#"><img src="assets/img/icons/shift-schedule-icon.svg" alt />All Reports</Link></li>
                <li className="w-100 bottom-list-menu">
                  <ul className="sub-menu clearfix">
                    <li><Link to="#">Documentation</Link></li>
                    <li><Link to="#">Changelog v1.4.4</Link></li>
                    <li><Link to="#">Components</Link></li>
                    <li><Link to="#">Support</Link></li>
                    <li><Link to="#">Terms &amp; Conditions</Link></li>
                    <li><Link to="#">About</Link></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li className="nav-item nav-icons">
              <div className="dark-light">
                <i className="feather-moon moon" />
                <i className="feather-sun sun" />
              </div>
            </li>
            <li className="nav-item dropdown has-arrow notification-dropdown">
              <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <i className="feather-bell" />
                <span className="badge">3</span>
              </Link>
              <div className="dropdown-menu dropdown-menu-end notifications">
                <div className="topnav-dropdown-header">
                  <span className="notification-title">Notifications</span>
                  <Link to="#" className="clear-noti"> Clear All</Link>
                </div>
                <div className="noti-content">
                  <ul className="notification-list">
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar1} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">John Doe</span>added new task 
                              <span className="noti-title">Patient appointment booking</span></p>
                            <p className="noti-time"><span className="notification-time">4 mins ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar2} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Tarah Shropshire</span> changed the task name 
                              <span className="noti-title">Appointment booking with payment gateway</span></p>
                            <p className="noti-time"><span className="notification-time">6 mins ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src="assets/img/profiles/avatar-06.jpg" className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Misty Tison</span> added 
                              <span className="noti-title">Domenic Houston</span> and 
                              <span className="noti-title">Claire Mapes</span> to project 
                              <span className="noti-title">Doctor available module</span></p>
                            <p className="noti-time"><span className="notification-time">8 mins ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar5} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Rolland
                                Webber</span> completed task <span className="noti-title">Patient and Doctor video conferencing</span></p>
                            <p className="noti-time"><span className="notification-time">12 mins ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar3} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Bernardo Galaviz</span> added new task 
                              <span className="noti-title">Private chat module</span></p>
                            <p className="noti-time"><span className="notification-time">2 days ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                  </ul>
                </div>
                <div className="topnav-dropdown-footer">
                  <Link to="#">View all Notifications</Link>
                </div>
              </div>
            </li>
            <li className="nav-item nav-icons">
              <Link to="#">
                <i className="feather-settings" />
              </Link>
            </li>
            <li className="nav-item nav-icons">
              <Link to="#">
                <i className="far fa-circle-question" />
              </Link>
            </li>
            <li className="nav-item dropdown has-arrow main-drop">
              <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <span className="user-img">
                  <img src={avatar1} className="img-rounded" alt />
                </span>
              </Link>
              <div className="dropdown-menu">
                <Link className="dropdown-item" to="#">
                  <i className="feather-user-plus" /> My Profile
                </Link>
                <Link className="dropdown-item" to="#">
                  <i className="feather-settings" /> Settings
                </Link>
                <Link className="dropdown-item" to="#">
                  <i className="feather-log-out" /> Logout
                </Link>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </header> */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper leave-page time-sheet">
      {/* Page Content */}
      <div className="content container">
        {/* Page Header */}
        <div className="page-header">
          <div className="row align-items-center">
            <div className="col-lg-4 col-md-6">
              <h3 className="page-title">Leaves</h3>
            </div>
            <div className="col-lg-8 col-md-6">
              <div className="date-time-group date-time mb-0">
                <div className="col-auto selct-today-list">
                  <select className="form-select select select-today">
                    <option selected>Today</option>
                    <option value={1}>Week</option>
                    <option value={2}>Month</option>
                    <option value={3}>Year</option>
                  </select>
                </div>
                <div className="col-auto d-md-inline">
                  <div className="date-picker btn btn-group btn-sm mb-0">
                    <div className="ico left">
                      <i className="fas fa-chevron-left" />
                    </div>
                    <div className="cal-ico center">
                      <i className="feather-calendar mr-1" />
                      <span>3/28/2023 - 4/3/2023</span>
                    </div>
                    <div className="ico right">
                      <i className="fas fa-chevron-right" />
                    </div>
                  </div>
                </div>
                <div className="col-auto selct-week-list">
                  <select className="form-select select select-week">
                    <option selected>Week</option>
                    <option value={1}>Day</option>
                    <option value={2}>Month</option>
                    <option value={3}>Year</option>
                  </select>
                </div>
                <Link to="#" className="btn btn-filter">
                  <img src={funnel} alt />
                </Link>
                <Link to="#" className="btn add-employee-btn" data-bs-toggle="modal" data-bs-target="#addleave">
                  <i className="fa-solid fa-plus" /> Add Leave
                </Link>
              </div>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        {/* leave Grid */}
        <div className="leave-grid-view">
          <div className="row">
            <div className="col-sm-12 col-md-6 col-lg-3 list float-start d-flex">
              <div className="white-bg flex-fill">
                <div className="d-flex avg-working-hrs">
                  <div className="flex-grow-1">
                    <h4>Annual Leave</h4>
                    <span>13 Employees applied</span>
                  </div>
                  <i className="text-center"><img src={money} className="align-middle" alt /></i>
                </div>
                <div className="percentage">
                  <div className="depart-team">
                    <div className="depart-group">
                      <div className="depart-avatar">
                        <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <span className="avatar-title rounded-circle border border-white">35+</span>
                      </div>
                    </div>
                  </div>
                  <div className="footer-text high"><i className="fa-solid fa-arrow-right"> </i> <span className="text-success">02</span></div>
                </div>
              </div>
            </div>
            <div className="col-sm-12 col-md-6 col-lg-3 list float-start d-flex">
              <div className="white-bg flex-fill">
                <div className="d-flex working-hrs">
                  <div className="flex-grow-1">
                    <h4>Medical Leave</h4>
                    <span>17 Employees applied</span>
                  </div>
                  <i className="text-center"><img src={medical} className="align-middle" alt /></i>
                </div>
                <div className="percentage">
                  <div className="depart-team">
                    <div className="depart-group">
                      <div className="depart-avatar">
                        <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <span className="avatar-title rounded-circle border border-white">35+</span>
                      </div>
                    </div>
                  </div>
                  <div className="footer-text low"><i className="fa-solid fa-arrow-right"> </i> <span className="text-danger">02</span></div>
                </div>
              </div>
            </div>
            <div className="col-sm-12 col-md-6 col-lg-3 list float-start d-flex">
              <div className="white-bg flex-fill">
                <div className="d-flex late-login">
                  <div className="flex-grow-1">
                    <h4>Vacation Leave</h4>
                    <span>7 Employees applied</span>
                  </div>
                  <i className="text-center"><img src={plane} className="align-middle" alt /></i>
                </div>
                <div className="percentage">
                  <div className="depart-team">
                    <div className="depart-group">
                      <div className="depart-avatar">
                        <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <span className="avatar-title rounded-circle border border-white">35+</span>
                      </div>
                    </div>
                  </div>
                  <div className="footer-text high"><i className="fa-solid fa-arrow-right"> </i> <span className="text-success">02</span></div>
                </div>
              </div>
            </div>
            <div className="col-sm-12 col-md-6 col-lg-3 list float-start d-flex">
              <div className="white-bg flex-fill">
                <div className="d-flex overtime-hrs">
                  <div className="flex-grow-1">
                    <h4>Loss of Pay</h4>
                    <span>15 Employees applied</span>
                  </div>
                  <i className="text-center"><img src={document} className="align-middle" alt /></i>
                </div>
                <div className="percentage">
                  <div className="depart-team">
                    <div className="depart-group">
                      <div className="depart-avatar">
                        <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                      </div>
                      <div className="depart-avatar">
                        <span className="avatar-title rounded-circle border border-white">35+</span>
                      </div>
                    </div>
                  </div>
                  <div className="footer-text low"><i className="fa-solid fa-arrow-right" /><span className="text-danger">07</span></div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /leave Grid */}
        {/* Page Header */}
        <div className="page-header second-title">
          <div className="row align-items-center">
            <div className="col-lg-4 col-md-6">
              <h3 className="page-title">Leave History <span>25</span></h3>
            </div>
            <div className="col-lg-8 col-md-6 ">
              <div className="mynav2" />
            </div>
          </div>
        </div>
        {/* /Page Header */}
        {/* Leave request */}
        <div className="leave-request">
          <div className="row">
            <div className="col-lg-12">
              <div className="owl-carousel owl-theme featured-slider">
                <div className="item index-1">
                  <div className="leave-popup">
                    <div className="leave-card">
                      <div className="card-body">
                        <div className="card-header">
                          <div className="depart-avatar">
                            <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                          </div>
                          <div className="leave-title ">
                            <h4>John Smith,<span> UI/UX Designer</span></h4>
                            <p>Mar 26 - Mar 27, 2023</p>
                          </div>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Type:</h5>
                          <p>Sick Leave</p>
                        </div>
                        <div className="card-detail">
                          <h5>No of Days:</h5>
                          <p>2 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Remaining Leave:</h5>
                          <p>4 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Reason:</h5>
                          <p>Lorem ipsum dolor sit ,</p>
                        </div>
                        <div className="card-footer">
                          <Link to="#" className="btn apply-btn">
                            <i className="fa-solid fa-check me-2" />Approve
                          </Link>
                          <Link to="#" className="btn reject-btn call">
                            <i className="fa-solid fa-check me-2" />Reject
                          </Link>
                        </div>
                      </div>
                    </div>                                        
                  </div>
                  <div className="overlay-rejection" />                                        
                  <div className="popup-rejection">
                    <div className="popup-content" />
                    <div className="leave-inner-overlay for-call-popup">
                      <h6>Reason for Rejection</h6>
                      <form className="call-popup">
                        <div className="leave-part">                                                    
                          <div className="leave-msg">
                            <div className="input-area">
                              <textarea type="text" cols={50} rows={4} className="form-control border-0" placeholder="Enter Season" defaultValue={""} />
                            </div>
                            <div className="leave-btn text-center">
                              <button type="submit" className="btn reject-apply-btn">Save</button>
                              <button type="reset" className="btn reject-close-btn">Cancel</button>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
                <div className="item index-2">
                  <div className="leave-popup">
                    <div className="leave-card">
                      <div className="card-body">
                        <div className="card-header">
                          <div className="depart-avatar">
                            <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                          </div>
                          <div className="leave-title ">
                            <h4>John Smith,<span> UI/UX Designer</span></h4>
                            <p>Mar 26 - Mar 27, 2023</p>
                          </div>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Type:</h5>
                          <p>Sick Leave</p>
                        </div>
                        <div className="card-detail">
                          <h5>No of Days:</h5>
                          <p>2 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Remaining Leave:</h5>
                          <p>4 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Reason:</h5>
                          <p>Lorem ipsum dolor sit ,</p>
                        </div>
                        <div className="card-footer">
                          <Link to="#" className="btn apply-btn">
                            <i className="fa-solid fa-check me-2" />Approve
                          </Link>
                          <Link to="#" className="btn reject-btn call2">
                            <i className="fa-solid fa-check me-2" />Reject
                          </Link>
                        </div>
                      </div>
                    </div>                                        
                  </div>
                </div>
                <div className="item index-1">
                  <div className="leave-popup">
                    <div className="leave-card">
                      <div className="card-body">
                        <div className="card-header">
                          <div className="depart-avatar">
                            <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                          </div>
                          <div className="leave-title ">
                            <h4>John Smith,<span> UI/UX Designer</span></h4>
                            <p>Mar 26 - Mar 27, 2023</p>
                          </div>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Type:</h5>
                          <p>Sick Leave</p>
                        </div>
                        <div className="card-detail">
                          <h5>No of Days:</h5>
                          <p>2 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Remaining Leave:</h5>
                          <p>4 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Reason:</h5>
                          <p>Lorem ipsum dolor sit ,</p>
                        </div>
                        <div className="card-footer">
                          <Link to="#" className="btn apply-btn">
                            <i className="fa-solid fa-check me-2" />Approve
                          </Link>
                          <Link to="#" className="btn reject-btn call3">
                            <i className="fa-solid fa-check me-2" />Reject
                          </Link>
                        </div>
                      </div>
                    </div>                                        
                  </div>
                </div>
                <div className="item index-1">
                  <div className="leave-popup">
                    <div className="leave-card">
                      <div className="card-body">
                        <div className="card-header">
                          <div className="depart-avatar">
                            <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                          </div>
                          <div className="leave-title ">
                            <h4>John Smith,<span> UI/UX Designer</span></h4>
                            <p>Mar 26 - Mar 27, 2023</p>
                          </div>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Type:</h5>
                          <p>Sick Leave</p>
                        </div>
                        <div className="card-detail">
                          <h5>No of Days:</h5>
                          <p>2 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Remaining Leave:</h5>
                          <p>4 Days</p>
                        </div>
                        <div className="card-detail">
                          <h5>Leave Reason:</h5>
                          <p>Lorem ipsum dolor sit ,</p>
                        </div>
                        <div className="card-footer">
                          <Link to="#" className="btn apply-btn">
                            <i className="fa-solid fa-check me-2" />Approve
                          </Link>
                          <Link to="#" className="btn reject-btn call4">
                            <i className="fa-solid fa-check me-2" />Reject
                          </Link>
                        </div>
                      </div>
                    </div>                                        
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Leave request */}
        {/* Leave History */}
        <div className="page-header third-title">
          <div className="row align-items-center">
            <div className="col-lg-6 col-md-6">
              <h3 className="page-title">Leave History</h3>
            </div>
            <div className="col-lg-6 col-md-6 ">
              <div className="form-group float-end search d-inline">
                <i className="feather-search" />
                <input type="text" className="form-control" placeholder="Search" />
              </div>
            </div>
          </div>
        </div>
        {/* Leave History */}
        {/* Employee List */}
        <div className="leave-history">
          <div className="row">
            <div className="col-sm-12">
              <div className="card-table">
                <div className="card-body">
                  <div className="table-responsive">
                    <table className="table table-center table-hover datatable">
                      <thead className="thead-light">
                        <tr>
                          <th>#</th>
                          <th>Leave Name</th>
                          <th>Department</th>
                          <th>Date</th>
                          <th>Leave Type</th>
                          <th>Status</th>
                          <th>Employee Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <h2 className="table-avatar d-flex">
                              <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User Image" /></Link>
                              <Link to="#">John Smith <br />
                                <span>UI/UX Team Lead</span></Link>
                            </h2>
                          </td>
                          <td>
                            <p>Mar 12, 2022 - Mar 14, 2022</p><span>3 Days</span>
                          </td>
                          <td>
                            <p>Mar 12, 2022 - Mar 14, 2022</p><span>3 Days</span>
                          </td>
                          <td>
                            <p>Sick Leave</p>
                          </td>
                          <td><span className="success-status text-center">Approved</span></td>
                          <td>
                            <h2 className="table-avatar d-flex">
                              <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User Image" /></Link>
                              <Link to="#">John Smith <br />
                                <span>DGT-365</span></Link>
                            </h2>
                          </td>
                          <td>
                            <Link to="#" className=" btn-action-icon"><span>View</span></Link>
                          </td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>
                            <h2 className="table-avatar d-flex">
                              <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar5} alt="User Image" /></Link>
                              <Link to="#">David <br />
                                <span>UI/UX Team Lead</span></Link>
                            </h2>
                          </td>
                          <td>
                            <p>Mar 20, 2022 - Mar 30, 2022</p><span>10 Days</span>
                          </td>
                          <td>
                            <p>Mar 21, 2022 - Mar 24, 2022</p><span>3 Days</span>
                          </td>
                          <td>
                            <p>Sick Leave</p>
                          </td>
                          <td><span className="success-status text-center">Approved</span></td>
                          <td>
                            <h2 className="table-avatar d-flex">
                              <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar5} alt="User Image" /></Link>
                              <Link to="#">David<br />
                                <span>DGT-365</span></Link>
                            </h2>
                          </td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <Link to="#" className=" btn-action-icon">View</Link>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>
                            <h2 className="table-avatar d-flex">
                              <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar7} alt="User Image" /></Link>
                              <Link to="#">Paul <br />
                                <span>UI/UX Team Lead</span></Link>
                            </h2>
                          </td>
                          <td>
                            <p>Mar 21, 2022 - Mar 22, 2022</p><span>1 Days</span>
                          </td>
                          <td>
                            <p>Mar 21, 2022 - Mar 22, 2022</p><span>1 Days</span>
                          </td>
                          <td>
                            <p>Sick Leave</p>
                          </td>
                          <td><span className="warning-status text-center">Rejected</span></td>
                          <td>
                            <h2 className="table-avatar d-flex">
                              <Link to="#" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar7} alt="User Image" /></Link>
                              <Link to="#">Paul<br />
                                <span>DGT-365</span></Link>
                            </h2>
                          </td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <Link to="#" className=" btn-action-icon">View</Link>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Employee List */}
        {/* Footer */}
        {/* <footer className="footer">
          <div className="container">
            <div className="row">
              <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                <div className="footer-left">
                  <p>© 2023 Dreams HRMS</p>
                </div>
              </div>
              <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                <div className="footer-right">
                  <ul>
                    <li>
                      <Link to="#">Privacy Policy</Link>
                    </li>
                    <li>
                      <Link to="#">Terms &amp; Conditions</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </footer> */}
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Modal Popup */}
  <div className="employees-popup add-leave ">
    <div className="modal fade" id="addleave" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="addleaveLabel" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h1 className="modal-title" id="addleaveLabel">New Leave Request</h1>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><img src={close} alt='close' /> </button>
          </div>
          <div className="modal-body">
            <div className="multistep-form">
              <fieldset className="form-inner" id="first">
                <div className="form-area">
                  <div className="form-details ">
                    <form action="#">
                      <div className="row">
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Leave Type <span>*</span> </label>
                            <select className="form-select select">
                              <option selected>Select Leave Type</option>
                              <option value={1}>Sick Leave</option>
                              <option value={2}>Medical Leave</option>
                              <option value={3}>Other</option>
                            </select>
                            <span className="show-msg">Current Available Leave: <span>10
                                Days</span> </span>
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area date-select">
                            <label className="form-label">Start of Leave <span>*</span></label>
                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                            <span className="icon"> <i className="feather-calendar" /> </span>
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area date-select">
                            <label className="form-label">End of Leave <span>*</span></label>
                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                            <span className="icon"> <i className="feather-calendar" /> </span>
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Time Range <span>*</span></label>
                            <div className="row">
                              <div className="col-lg-4 col-md-6 col-sm-6">
                                <div className="form-check">
                                  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
                                  <label className="form-check-label" htmlFor="flexRadioDefault1">
                                    Full time
                                  </label>
                                </div>
                              </div>
                              <div className="col-lg-4 col-md-6 col-sm-6">
                                <div className="form-check">
                                  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2" defaultChecked />
                                  <label className="form-check-label" htmlFor="flexRadioDefault2">
                                    Morning
                                  </label>
                                </div>
                              </div>
                              <div className="col-lg-4 col-md-6 col-sm-6">
                                <div className="form-check">
                                  <input className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault3" defaultChecked />
                                  <label className="form-check-label" htmlFor="flexRadioDefault3">
                                    Evening
                                  </label>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Number of Days</label>
                            <input type="text" className="form-control" placeholder required />
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Leave Reason <span>*</span></label>
                            <textarea type="text" className="form-control textarea-cls" placeholder="Enter Reason" required defaultValue={""} />
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Attachment</label>
                            <div className="employee-upload-img">
                              <p>Drop your files here or <span>Browse</span></p>
                              <h6>Maximum size: 50MB</h6>
                              <input type="file" className="form-control" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="add-form-btn widget-next-btn submit-btn">
                  <div className="btn-left">
                    <Link className="btn main-btn ">Save</Link>
                    <Link className="btn close-btn me-0" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
                  </div>
                </div>
              </fieldset>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  )
}

export default Leave

