import React from 'react'
import { Link } from 'react-router-dom'
import { allpolicies, allreports, annual, avatar1, avatar2, avatar3, avatar5, avatar6, blue, cofee, combo, empmenuicon, events, green, leaverequest, logo, orange, purple, shiftschedule, sick, sicon, timeofficon, timesheet, vocation } from '../imagepath'

const EmployeeDashboard = () => {
  return (
    <div className="main-wrapper">
  {/* Header */}
  <header className="header header-fixed header-one">
    <nav className="navbar navbar-expand-lg header-nav">
      <div className="navbar-header">
        <Link id="mobile_btn" to="#">
          <span className="bar-icon">
            <span />
            <span />
            <span />
          </span>
        </Link>
        <Link to="#" className="navbar-brand logo">
          <img src={logo} className="img-fluid" alt="Logo" />
        </Link>
      </div>
      <div className="main-menu-wrapper">
        <ul className="main-nav">
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-gauge" /></span> Dashboard
            </Link>
          </li>
          <li className="nav-item quick-link-item dropdown">
            <Link className="dropdown-toggle" data-bs-toggle="dropdown" to="employees.html" role="button" aria-expanded="false">
              <span className="me-2"><i className="fa-solid fa-users" /></span>Employees
            </Link>
            <ul className="dropdown-menu clearfix employees-menu">                                
              <li><Link className="dropdown-item" to="leave.html"><span className="me-2 icon-img"><i className="fa-solid fa-plane-departure" /></span>Leave Report</Link></li>
              <li><Link className="dropdown-item" to="employees.html"><span className="me-2 icon-img"><i className="fa-solid fa-users" /></span>Employees</Link></li>                                
              <li><Link className="dropdown-item" to="shift-schedule.html"><span className="me-2 icon-img"><i className="fa-solid fa-calendar" /></span>Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="admin-employee-attendance.html"><span className="me-2 icon-img"><i className="fa-solid fa-clipboard-user" /></span>Attendance</Link></li>                                
              <li><Link className="dropdown-item" to="department.html"><span className="me-2 icon-img"><i className="fa-solid fa-building" /></span>Department</Link></li>
              <li><Link className="dropdown-item" to="employee-teams.html"><span className="me-2 icon-img"><i className="fa-solid fa-users" /></span>Teams</Link></li>
              <li><Link className="dropdown-item" to="timesheet.html"><span className="me-2 icon-img"><i className="fa-solid fa-file" /></span>Timesheet</Link></li>                                
              <li><Link className="dropdown-item" to="orginization-chart.html"><span className="me-2 icon-img"><i className="fa-solid fa-chart-bar" /></span>Organization Chart</Link></li>
              <li><Link className="dropdown-item" to="onboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-arrow-right-from-bracket" /></span>Onboarding</Link></li>
              <li><Link className="dropdown-item" to="offboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-arrow-right-from-bracket" /></span>Offboarding Report</Link></li>
            </ul>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-plane-departure" /></span> Time off
            </Link>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-file" /></span> Policies
            </Link>
          </li>
          <li className="active nav-item quick-link-item dropdown">
            <Link className="dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
              <span className="me-2"><i className="fa-solid fa-chart-pie" /></span> Reports
            </Link>
            <ul className="dropdown-menu clearfix">                                
              <li><Link className="dropdown-item" to="leave.html"><span className="me-2 icon-img"><i className="fa-solid fa-plane-departure" /></span>Leave Report</Link></li>                                
              <li><Link className="dropdown-item" to="attendance-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-clipboard-user" /></span>Attendance Report</Link></li>                                
              <li><Link className="dropdown-item" to="onboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-clipboard-user" /></span>Onboarding Report</Link></li>
              <li><Link className="dropdown-item" to="employee-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-users" /></span>Employee Report</Link></li>                                
              <li><Link className="dropdown-item" to="asset-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-laptop" /></span>Asset Report</Link></li>
              <li><Link className="dropdown-item" to="offboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-file" /></span>Offboarding Report</Link></li>
            </ul>
          </li>
        </ul>
        <ul className="nav header-navbar-rht darkLight-searchBox">
          <li className="nav-item search-item">
            <div className="top-nav-search">
              <form action="#">
                <input type="text" className="form-control" placeholder="Search" />
                <button className="btn" type="submit"><i className="feather-search" /></button>
                <span><img src={sicon} alt /></span>
              </form>
            </div>
          </li>
          <li className="nav-item quick-link-item dropdown">
            <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
              <span>Quick Links <i className="feather-zap" /></span>
            </Link>
            <ul className="dropdown-menu clearfix">
              <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
              <li className="w-100 bottom-list-menu">
                <ul className="sub-menu clearfix">
                  <li><Link to="#">Documentation</Link></li>
                  <li><Link to="#">Changelog v1.4.4</Link></li>
                  <li><Link to="#">Components</Link></li>
                  <li><Link to="#">Support</Link></li>
                  <li><Link to="#">Terms &amp; Conditions</Link></li>
                  <li><Link to="#">About</Link></li>
                </ul>
              </li>
            </ul>
          </li>
          <li className="nav-item nav-icons">
            <div className="dark-light">
              <i className="feather-moon moon" />
              <i className="feather-sun sun" />
            </div>
          </li>
          <li className="nav-item dropdown has-arrow notification-dropdown">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <i className="feather-bell" />
              <span className="badge">3</span>
            </Link>
            <div className="dropdown-menu dropdown-menu-end notifications">
              <div className="topnav-dropdown-header">
                <span className="notification-title">Notifications</span>
                <Link to="#" className="clear-noti"> Clear All</Link>
              </div>
              <div className="noti-content">
                <ul className="notification-list">
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar1} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">John Doe</span>added new task 
                            <span className="noti-title">Patient appointment booking</span></p>
                          <p className="noti-time"><span className="notification-time">4 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar2} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Tarah Shropshire</span> changed the task name 
                            <span className="noti-title">Appointment booking with payment gateway</span></p>
                          <p className="noti-time"><span className="notification-time">6 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar6} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Misty Tison</span> added 
                            <span className="noti-title">Domenic Houston</span> and 
                            <span className="noti-title">Claire Mapes</span> to project 
                            <span className="noti-title">Doctor available module</span></p>
                          <p className="noti-time"><span className="notification-time">8 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar5} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Rolland
                              Webber</span> completed task <span className="noti-title">Patient and Doctor video conferencing</span></p>
                          <p className="noti-time"><span className="notification-time">12 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar3} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Bernardo Galaviz</span> added new task 
                            <span className="noti-title">Private chat module</span></p>
                          <p className="noti-time"><span className="notification-time">2 days ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="topnav-dropdown-footer">
                <Link to="#">View all Notifications</Link>
              </div>
            </div>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="feather-settings" />
            </Link>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="far fa-circle-question" />
            </Link>
          </li>
          <li className="nav-item dropdown has-arrow main-drop">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <span className="user-img">
                <img src={avatar1} className="img-rounded" alt />
              </span>
            </Link>
            <div className="dropdown-menu">
              <Link className="dropdown-item" to="#">
                <i className="feather-user-plus" /> My Profile
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-settings" /> Settings
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-log-out" /> Logout
              </Link>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper dashboard employee-dashboard">
    {/* Page Content */}
    <div className="content container">
      <div className="d-sm-flex justify-content-between align-items-center title-row">
        <h2>Welcome back,Robert!</h2>
      </div>
      <div className="leave-types mb-20">
        <div className="row">
          <div className="col-sm-6 col-lg-3 d-flex">
            <div className="card annual-leave white-bg flex-fill">
              <h3 className><i className="d-inline-block text-center align-middle"><img src={annual} alt /></i>Annual Leave</h3>
              <h4>9/12</h4>
              <div className="graph">
                <span>Currently Available</span>
                <i><img src={purple} alt /></i> 
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-lg-3 d-flex">
            <div className="card sick-leave white-bg flex-fill">
              <h3 className><i className="d-inline-block text-center align-middle"><img src={sick} alt /></i>Sick Leave</h3>
              <h4>2/5</h4>
              <div className="graph">
                <span>Currently Available</span>
                <i><img src={orange} alt /></i> 
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-lg-3 d-flex">
            <div className="card vocation-leave white-bg flex-fill">
              <h3 className><i className="d-inline-block text-center align-middle"><img src={vocation} alt /></i>Vocation Leave</h3>
              <h4>2/8</h4>
              <div className="graph">
                <span>Currently Available</span>
                <i><img src={green} alt /></i> 
              </div>
            </div>
          </div>
          <div className="col-sm-6 col-lg-3 d-flex">
            <div className="card combo-off-leave white-bg flex-fill">
              <h3 className><i className="d-inline-block text-center align-middle"><img src={combo} alt /></i>Combo-Off Leave</h3>
              <h4>4/6</h4>
              <div className="graph">
                <span>Currently Available</span>
                <i><img src={blue} alt /></i> 
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Attendance Graphs Row*/}
      <div className="row mb-20">
        {/* admin chart */}
        <div className="col-12 col-sm-12 col-md-6 col-lg-6 d-flex">
          <div className="card white-bg online-attendance flex-fill">
            <div className="d-flex justify-content-between align-items-center">    
              <h3 className="text-capitalize">Online Attendance</h3>
              <div className="clock-text">
                <i className="fa fa-clock" aria-hidden="true" />
                <h5 className="d-inline">16:20</h5>
                <span>Monday,03 Mar 2023</span>
              </div>
            </div>
            <ul className="w-100 hrs clearfix">
              <li className="w-50">
                <span>Office Break</span>
                <p>1:30 pm - 2:30 pm</p>
              </li>
              <li className="w-50">
                <span>Target working hours</span>
                <p>8h/days</p>
              </li>
            </ul>
            <div className="row align-items-center">
              <div className="col-sm-12 col-md-6 col-lg-6">
                <div id="empdb-online-attendance" />
              </div>
              <div className="col-md-12 col-lg-6">
                <button type="button" className="btn gradient-btn d-block"><img src={cofee} alt />&nbsp;&nbsp;Take a Break</button>
                <button type="button" className="btn btn-transparent"><i className="fa fa-sign-out me-2" aria-hidden="true" />Check in</button>
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-sm-12 col-md-6 col-lg-6 d-flex">
          <div className="card white-bg flex-fill">
            <h3>Attendance Report</h3>
            <div id="attendance-report" />
          </div>
        </div>
      </div>
      {/* /Attendance Graphs Row*/}
      {/* Leave Request-My Team */}
      <div className="row">
        <div className="col-12 col-sm-12 col-md-6 col-lg-6 d-flex">
          <div className="card white-bg leave-request flex-fill">
            <div className="d-flex justify-content-between align-items-center position-relative">
              <h3>Leave Request</h3>
              <select className="form-select w-auto d-inline select month">
                <option selected>Month</option>
                <option value={1}>Today</option>
                <option value={2}>Week</option>
                <option value={3}>Year</option>
              </select>
            </div>
            <ul className="nav nav-pills" id="leave-request" role="tablist">
              <li className="nav-item" role="presentation">
                <button className="nav-link active" id="pills-leave-tab" data-bs-toggle="pill" data-bs-target="#pills-leave" type="button" role="tab" aria-controls="pills-leave" aria-selected="true"><i className="fa fa-sign-out" aria-hidden="true" />Leave</button>
              </li>
              <li className="nav-item" role="presentation">
                <button className="nav-link" id="pills-permission-tab" data-bs-toggle="pill" data-bs-target="#pills-permission" type="button" role="tab" aria-controls="pills-permission" aria-selected="false"><i className="feather-shield" aria-hidden="true" />Permission</button>
              </li>
              <li className="nav-item flex-grow-1 text-end"><Link className="nav-link view-all" to="#">View All</Link></li>
            </ul>
            <div className="tab-content" id="leave-request-ontent">
              <div className="tab-pane fade show active" id="pills-leave" role="tabpanel" aria-labelledby="pills-leave-tab">
                <div className="row">
                  <div className="col-12 col-sm-12 col-md-4 col-lg-4 leave-info-wrapper d-flex">
                    <div className="card leave-info flex-fill">
                      <div className="d-flex align-items-center justify-content-start">
                        <Link href className="profile"><img src={leaverequest} alt /></Link>
                        <div className="flex-grow-1">
                          <h5>Jennifer</h5>
                          <h6>UI/UX Designer</h6>
                        </div>
                      </div>
                      <ul>
                        <li className="d-flex justify-content-between align-items-center"><span>Leave Type</span><p className="d-inline-block">Casual</p></li>
                        <li className="d-flex justify-content-between align-items-center"><span>Date</span><p className="d-inline-block">05 Mar 2023</p></li>
                      </ul>
                      <div className="btn-row">
                        <button type="button" className="btn common-btn btn-pending btn-transparent">Pending</button>
                      </div>
                      <span className="blue-label">Approved By: John</span>
                    </div>
                  </div>
                  <div className="col-12 col-sm-12 col-md-4 col-lg-4 leave-info-wrapper d-flex">
                    <div className="card leave-info flex-fill">
                      <div className="d-flex align-items-center justify-content-start">
                        <Link href className="profile"><img src={leaverequest} alt /></Link>
                        <div className="flex-grow-1">
                          <h5>Jennifer</h5>
                          <h6>UI/UX Designer</h6>
                        </div>
                      </div>
                      <ul>
                        <li className="d-flex justify-content-between align-items-center"><span>Leave Type</span><p className="d-inline-block">Casual</p></li>
                        <li className="d-flex justify-content-between align-items-center"><span>Date</span><p className="d-inline-block">05 Mar 2023</p></li>
                      </ul>
                      <div className="btn-row">
                        <button type="button" className="btn common-btn btn-reject btn-transparent">Rejected</button>
                      </div>
                      <span className="blue-label">Approved By: John</span>
                    </div>
                  </div>
                  <div className="col-12 col-sm-12 col-md-4 col-lg-4 leave-info-wrapper d-flex">
                    <div className="card leave-info flex-fill mb-0">
                      <div className="d-flex align-items-center justify-content-start">
                        <Link href className="profile"><img src={leaverequest} alt /></Link>
                        <div className="flex-grow-1">
                          <h5>Jennifer</h5>
                          <h6>UI/UX Designer</h6>
                        </div>
                      </div>
                      <ul>
                        <li className="d-flex justify-content-between align-items-center"><span>Leave Type</span><p className="d-inline-block">Casual</p></li>
                        <li className="d-flex justify-content-between align-items-center"><span>Date</span><p className="d-inline-block">05 Mar 2023</p></li>
                      </ul>
                      <div className="btn-row">
                        <button type="button" className="btn common-btn btn-accept btn-transparent">Accepted</button>
                      </div>
                      <span className="blue-label">Approved By: John</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="tab-pane fade" id="pills-permission" role="tabpanel" aria-labelledby="pills-permission-tab">
                <div className="row">
                  <div className="col-12 col-sm-12 col-md-6 col-lg-6 leave-info-wrapper d-flex">
                    <div className="card leave-info flex-fill mb-0">
                      <div className="d-flex align-items-center justify-content-start">
                        <Link href className="profile"><img src={leaverequest} alt /></Link>
                        <div className="flex-grow-1">
                          <h5>Jennifer</h5>
                          <h6>UI/UX Designer</h6>
                        </div>
                      </div>
                      <ul>
                        <li className="d-flex justify-content-between align-items-center"><span>Leave Type</span><p className="d-inline-block">Casual</p></li>
                        <li className="d-flex justify-content-between align-items-center"><span>Date</span><p className="d-inline-block">05 Mar 2023</p></li>
                      </ul>
                      <div className="d-flex justify-content-between align-items-center btn-row">
                        <button type="button" className="btn common-btn btn-message btn-transparent">Message</button>
                      </div>
                      <span className="d-block blue-label">Approved By: John</span>
                    </div>
                  </div>
                  <div className="col-12 col-sm-12 col-md-6 col-lg-6 leave-info-wrapper d-flex">
                    <div className="card leave-info flex-fill mb-0">
                      <div className="d-flex align-items-center justify-content-start">
                        <Link href className="profile"><img src={leaverequest} alt /></Link>
                        <div className="flex-grow-1">
                          <h5>Jennifer</h5>
                          <h6>UI/UX Designer</h6>
                        </div>
                      </div>
                      <ul>
                        <li className="d-flex justify-content-between align-items-center"><span>Leave Type</span><p className="d-inline-block">Casual</p></li>
                        <li className="d-flex justify-content-between align-items-center"><span>Date</span><p className="d-inline-block">05 Mar 2023</p></li>
                      </ul>
                      <div className="d-flex justify-content-between align-items-center btn-row">
                        <button type="button" className="btn common-btn btn-accept btn-transparent">Accept</button>
                        <button type="button" className="btn common-btn btn-reject btn-transparent">Reject</button>
                      </div>
                      <span className="d-block blue-label">Approved By: John</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-sm-12 col-md-6 col-lg-6 d-flex">
          <div className="card white-bg my-team-members flex-fill">
            <div className="d-flex justify-content-between align-items-center mb-20 position-relative">
              <h3>My Team Members</h3>
              <select className="form-select w-auto d-inline select month">
                <option selected>Today</option>
                <option value={1}>Month</option>
                <option value={2}>Week</option>
                <option value={3}>Year</option>
              </select>
            </div>
            <ul className="ticket-raised my-team">
              <li>
                <div className="head team-info">
                  <div className="team-info-img">
                    <div className="profile">
                      <Link href><img src={leaverequest} alt /></Link>
                    </div>
                    <div className="text">
                      <h5>John Smith</h5>
                      <span>UI/UX Team Leader</span>
                    </div>
                  </div>
                  <span className="designation">Team Leader</span>
                  <span className="status-success">Present</span>
                </div>
              </li>
              <li>
                <div className="head team-info">
                  <div className="team-info-img">
                    <div className="profile">
                      <Link href><img src={leaverequest} alt /></Link>
                    </div>
                    <div className="text">
                      <h5>John Smith</h5>
                      <span>UI/UX Team Leader</span>
                    </div>
                  </div>
                  <span className="designation">Team Leader</span>
                  <span className="status-warning">Absent</span>
                </div>
              </li>
              <li>
                <div className="head team-info">
                  <div className="team-info-img">
                    <div className="profile">
                      <Link href><img src={leaverequest} alt /></Link>
                    </div>
                    <div className="text">
                      <h5>John Smith</h5>
                      <span>UI/UX Team Leader</span>
                    </div>
                  </div>
                  <span className="designation">Team Leader</span>
                  <span className="status-success">Present</span>
                </div>
              </li>
            </ul>
            <div className="d-grid">
              <button className="btn view-all mb-0" type="button">View All Members</button>
            </div>
          </div>
        </div>
      </div>
      {/* /Leave Request-My Team */}
      {/* Events Recruitment Announcement */}
      <div className="row mb-20 mt-20">
        <div className="col-12 col-sm-12 col-md-4 col-lg-4 d-flex">
          <div className="card white-bg flex-fill">
            <div className="d-flex justify-content-between align-items-center position-relative">
              <h3>Events</h3>
              <select className="form-select w-auto d-inline select month">
                <option selected>Today</option>
                <option value={1}>Today</option>
                <option value={2}>Week</option>
                <option value={3}>Year</option>
              </select>
            </div>
            <ul className="nav nav-pills" id="events" role="tablist">
              <li className="nav-item" role="presentation">
                <button className="nav-link active" id="pills-all-tab" data-bs-toggle="pill" data-bs-target="#pills-all" type="button" role="tab" aria-controls="pills-all" aria-selected="true"><i className="fa fa-calendar-o" aria-hidden="true" />All</button>
              </li>
              <li className="nav-item" role="presentation">
                <button className="nav-link" id="pills-birthday-tab" data-bs-toggle="pill" data-bs-target="#pills-birthday" type="button" role="tab" aria-controls="pills-birthday" aria-selected="false"><i className="fa fa-birthday-cake" aria-hidden="true" />Birthday</button>
              </li>
              <li className="nav-item" role="presentation">
                <button className="nav-link" id="pills-anniversary-tab" data-bs-toggle="pill" data-bs-target="#pills-anniversary" type="button" role="tab" aria-controls="pills-anniversary" aria-selected="false"><i className="fa fa-heart" aria-hidden="true" />Anniversary</button>
              </li>
            </ul>
            <div className="tab-content" id="events-content">
              <div className="tab-pane fade show active" id="pills-all" role="tabpanel" aria-labelledby="pills-all-tab">
                <ul className="events-info">
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                </ul>
                <div className="d-grid">
                  <button className="btn view-all mb-0" type="button">View All</button>
                </div>
              </div>
              <div className="tab-pane fade" id="pills-birthday" role="tabpanel" aria-labelledby="pills-birthday-tab">
                <ul className="events-info">
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                </ul>
                <div className="d-grid">
                  <button className="btn view-all mb-0" type="button">View All</button>
                </div>
              </div>
              <div className="tab-pane fade" id="pills-anniversary" role="tabpanel" aria-labelledby="pills-anniversary-tab">
                <ul className="events-info">
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                  <li className="d-flex justify-content-between">
                    <div className="d-flex justify-content-start align-items-center">
                      <Link href className="profile"><img src={events} alt /></Link>
                      <div className>
                        <h4>Bernardo</h4>
                        <span>Senior Developer</span>
                      </div>
                    </div>
                    <div className="d-inline-flex gift">
                      <i className="fa fa-gift" aria-hidden="true" />
                      <Link href>Wish Her</Link>
                    </div>
                  </li>
                </ul>
                <div className="d-grid">
                  <button className="btn view-all mb-0" type="button">View All</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-sm-12 col-md-4 col-lg-4 d-flex">
          <div className="card white-bg flex-fill">
            <div className="d-flex justify-content-between align-items-center position-relative">
              <h3>Announcement</h3>
              <select className="form-select w-auto d-inline select month">
                <option selected>Today</option>
                <option value={1}>Month</option>
                <option value={2}>Week</option>
                <option value={3}>Year</option>
              </select>
            </div>
            <div className="announcement">
              <div className="d-flex justify-content-between align-items-center announcement-list">
                <div className="text">
                  <h5>Forestry Day Activity</h5>
                  <span>5 Minutes ago</span>
                </div>
                <div className="dropdown dropdown-action">
                  <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                  <div className="dropdown-menu dropdown-menu-end">
                    <ul>
                      <li>
                        <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between align-items-center announcement-list">
                <div className="text">
                  <h5>Forestry Day Activity</h5>
                  <span>5 Minutes ago</span>
                </div>
                <div className="dropdown dropdown-action">
                  <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                  <div className="dropdown-menu dropdown-menu-end">
                    <ul>
                      <li>
                        <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between align-items-center announcement-list">
                <div className="text">
                  <h5>Forestry Day Activity</h5>
                  <span>5 Minutes ago</span>
                </div>
                <div className="dropdown dropdown-action">
                  <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                  <div className="dropdown-menu dropdown-menu-end">
                    <ul>
                      <li>
                        <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                      </li>
                      <li>
                        333      <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="d-flex justify-content-between align-items-center announcement-list">
                <div className="text">
                  <h5>Forestry Day Activity</h5>
                  <span>5 Minutes ago</span>
                </div>
                <div className="dropdown dropdown-action">
                  <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                  <div className="dropdown-menu dropdown-menu-end">
                    <ul>
                      <li>
                        <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                      </li>
                      <li>
                        <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="d-grid">
                <button className="btn view-all mb-0" type="button">View All</button>
              </div>
            </div>
          </div>
        </div>
        <div className="col-12 col-sm-12 col-md-4 col-lg-4 d-flex">
          <div className="card white-bg recruitment flex-fill">
            <div className="d-flex justify-content-between align-items-center position-relative mb-30">
              <h3>Ticket Raised</h3>
              <select className="form-select w-auto d-inline select month">
                <option selected>Today</option>
                <option value={1}>Month</option>
                <option value={2}>Week</option>
                <option value={3}>Year</option>
              </select>
            </div>
            <ul className="ticket-raised">
              <li>
                <div className="head team-info">
                  <div className="d-flex align-items-center">
                    <div className="profile">
                      <Link href><img src={leaverequest} alt /></Link>
                    </div>
                    <div className="text">
                      <h5>John Smith</h5>
                      <span>UI/UX Team Leader</span>
                    </div>
                  </div>
                  <span className="blue-bg-info">Pending</span>
                </div>
                <div className="row mt-15">
                  <div className="col-6">
                    <h4>Issue</h4>
                    <span>Laptop Not Working</span>
                  </div>
                  <div className="col-6 text-end">
                    <h4>Date Raised</h4>
                    <span>14 Apr 2023</span>
                  </div>
                </div>
              </li>
              <li>
                <div className="head team-info">
                  <div className="team-info-img">
                    <div className="profile">
                      <Link href><img src={leaverequest} alt /></Link>
                    </div>
                    <div className="text">
                      <h5>John Smith</h5>
                      <span>UI/UX Team Leader</span>
                    </div>
                  </div>
                  <span className="blue-bg-info">Pending</span>
                </div>
                <div className="row mt-15">
                  <div className="col-6">
                    <h4>Issue</h4>
                    <span>Laptop Not Working</span>
                  </div>
                  <div className="col-6 text-end">
                    <h4>Date Raised</h4>
                    <span>14 Apr 2023</span>
                  </div>
                </div>
              </li>
            </ul>
            <div className="d-grid">
              <button className="btn view-all mb-0" type="button">View All</button>
            </div>
          </div>
        </div>
      </div>
      {/* /Events Recruitment Announcement */}
      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="row">
            <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
              <div className="footer-left">
                <p>© 2023 Dreams HRMS</p>
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
              <div className="footer-right">
                <ul>
                  <li>
                    <Link to="#">Privacy Policy</Link>
                  </li>
                  <li>
                    <Link to="#">Terms &amp; Conditions</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default EmployeeDashboard
