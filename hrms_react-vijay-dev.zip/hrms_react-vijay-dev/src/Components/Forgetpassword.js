import React, { useEffect, useState } from "react";
import login_banner from "./assets/img/login-banner.png";
import login_logo from "./assets/img/login-logo.svg";
// import google from "../assets/img/icons/google.svg";
import arrow_right from "./assets/img/arrow_right.svg";
import { useNavigate } from "react-router-dom";
import Waving_Hand from "./assets/img/Waving_Hand.svg";
import CheckMailModal from "./Modal/CheckMailModal";
import TermconModal from "./Modal/TermconModal";
import PrivacyModal from "../Components/Modal/PrivacyModal";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASEURL } from "./apiPath/baseUrl";
import { postData, getDecryptedData } from "./services/apiUrl";
import cogoToast from "cogo-toast";
import { useDispatch } from "react-redux";
import { loading } from "./Employee/ReduxReducer/EmployeeReducer";

function Forgetpassword() {
  const [show, setShow] = useState(false);
  const [showterm, setShowterm] = useState(false);
  const [showprev, setShowprev] = useState(false);
  const [forgotData, setForgotData] = useState();
  const [mailData,setMaildata]=useState();
  const Dispatch = useDispatch();

  const formik = useFormik({
    initialValues: {
      email: "",
    },
    validationSchema: Yup.object({
      email: Yup.string().email("Invalid email format").required("Required!"),
    }),

    onSubmit: (values) => {
      setForgotData(values);
      const forgotPassword = async () => {
        const preparData = {
          email: values.email,
        };
        Dispatch(loading(true));
        setMaildata(preparData)
        postData("forgot-password", preparData, sucessCallBack);    
      };
      forgotPassword();
    },
  });

  const sucessCallBack = (data, res) => {
    console.log(data,"dta");
    Dispatch(loading(false));
    if (data?.code == 200) {
      setShow(true);
    } else {
      cogoToast.error(data?.error);
    }
  };

  const navigate = useNavigate();
  const handleModal = () => {
    setShow(true);
  };
  useEffect(() => {
    // const url =
    //   "7a3d889901d015727f2652563010efac2629f4f9b7bbe9bcaeb028bce4a3f72a851720c8fc21c2ebc481cc778ede19d08e7147b74e5226ca84bd2f2aa7a333eee932079108bbbab28d89fa2027ee0e43f4b49d9f0fad5980db3c1bf9f1d9704a55726de983afdae6b9e5ce5ac868abd24297b5fb78b05f2b4a";
    // getDecryptedData(url, (data) => {
    //  console.log(data,"responce");
    // });
  });

  return (
    <div class="main-wrapper">
      <div class="row">
        <div class="col-lg-4 col-md-5 col-sm-12 login-wrap-bg">
          <div class="login-wrapper">
            <div class="loginbox">
              <div class="logo-img d-flex align-items-center justify-content-between">
                <img src={login_logo} class="img-fluid" alt="Logo" />
                <div class="sign-group">
                  <a
                    class="btn sign-up d-flex"
                    onClick={() => navigate("/register")}
                    style={{ color: "white" }}
                  >
                    Sign Up
                    <span>
                      <img class="arrow-icon mx-1" src={arrow_right} />
                    </span>
                  </a>
                </div>
              </div>
              <h2>Forgetpassword</h2>
              <p>
                No Worry <img src={Waving_Hand} aria-label="sheep" />, we'll
                send you reset instruction
              </p>
              <form onSubmit={formik.handleSubmit}>
                <div class="form-group">
                  <label class="label">Email Address</label>
                  <input
                    type="email"
                    class="form-control"
                    name="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                  />
                </div>
                {formik.errors.email && formik.touched.email && (
                  <p style={{ color: "red", display: "flex" }}>
                    {formik.errors.email}
                  </p>
                )}

                <button type="submit" class="form-group btn login-submit w-100">
                  Reset Password
                </button>
                <a
                  class="form-group btn forgot-submit w-100"
                  onClick={() => navigate("/")}
                >
                  Back to Login
                </a>

                <div class="form-group">
                  <div class="terms-policy">
                    <ul>
                      <li>
                        <a onClick={() => setShowterm(true)} href="#">
                          Terms & Conditions
                        </a>
                      </li>
                      <li>
                        <a onClick={() => setShowprev(true)} href="#">
                          Privacy Policy
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div class="col-lg-8 col-md-7 col-sm-12 login-bg">
          <div class="welcome-login">
            <h2>Smarter . Simpler . Automated .</h2>
            <p>
              With the world's best staff management solutions, users can
              improve retention as well as productivity.
            </p>
          </div>
          <div class="banner-img">
            <img src={login_banner} class="img-fluid" alt="Login Banner" />
          </div>
          <div class="copyright">
            <div class="row">
              <div class="col-md-6">
                <div class="privacy-policy">
                  <p>Copyrights @ Dreams Hrms 2023</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="copyright-text">
                  <p class="mb-0">
                    Design and Developed by <span>Dreamguy’s</span>
                  </p>
                </div>
              </div>
              <TermconModal showterm={showterm} setShowterm={setShowterm} />
              <PrivacyModal showprev={showprev} setShowprev={setShowprev} />
            </div>
          </div>
        </div>
      </div>
      <CheckMailModal mailData ={mailData} show={show} setShow={setShow} />
    </div>
  );
}
export default Forgetpassword;
