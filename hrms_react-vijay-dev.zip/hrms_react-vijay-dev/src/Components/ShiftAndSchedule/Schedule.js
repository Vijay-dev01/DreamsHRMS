// import React from 'react'
// import logo from "../../../src/Components/assets/img/logo.svg"   
// import shortcut_icon from "../../../src/Components/assets/img/icons/shortcut-icon.svg"  
// import emp_menu_icon from "../../../src/Components/assets/img/icons/employees-menu-icon.svg"  
// import time_off_icon from "../../../src/Components/assets/img/icons/timeoff-icon.svg"
// import timesheet_icon from "../../../src/Components/assets/img/icons/timesheet-icon.svg" 
// import allpolicy_icon from "../../../src/Components/assets/img/icons/allpolicies-icon.svg"   
// import shift_schedule_icon from "../../../src/Components/assets/img/icons/shift-schedule-icon.svg"
// import report_icon from "../../../src/Components/assets/img/icons/shift-schedule-icon.svg"

// import allreport_icon from "../../../src/Components/assets/img/icons/allreports-icon.svg"   
// import Line from "../../../src/Components/assets/img/icons/Line.svg" 
// import bar from '../assets/img/icons/bar-icon.svg';
// import funnel_icon from '../assets/img/icons/assets/img/icons/funnel-icon.svg'
// import search_icon from '../assets/img/icons/assets/img/icons/search-icon.svg'
// import avatar1 from "../assets/img/profiles/avatar-01.jpg";
// import avatar2 from "../assets/img/profiles/avatar-02.jpg";
// import avatar5 from "../assets/img/profiles/avatar-02.jpg";
// import avatar6 from "../assets/img/profiles/avatar-06.jpg";
// import avatar3 from "../assets/img/profiles/avatar-03.jpg";


// export default function Schedule() {
//   return (
// <div>
//   {/* Main Wrapper */}
//   <div className="main-wrapper">
//     {/* Header */}
//     <header className="header header-fixed header-one">
//       <nav className="navbar navbar-expand-lg header-nav">
//         <div className="navbar-header">
//           <a id="mobile_btn" href="javascript:void(0);">
//             <span className="bar-icon">
//               <span />
//               <span />
//               <span />
//             </span>
//           </a>
//           <a href="javascript:void(0);" className="navbar-brand logo">
//             <img src={logo} className="img-fluid" alt="Logo" />
//           </a>
//         </div>
//         <div className="main-menu-wrapper">
//           <ul className="main-nav">
//             <li>
//               <a href="javascript:void(0);">
//                 <span className="me-2"><i className="fa-solid fa-gauge" /></span> Dashboard
//               </a>
//             </li>
//             <li className="active">
//               <a>
//                 <span className="me-2"><i className="fa-solid fa-users" /></span> Employees
//               </a>
//             </li>
//             <li>
//               <a href="javascript:void(0);">
//                 <span className="me-2"><i className="fa-solid fa-plane-departure" /></span> Time off
//               </a>
//             </li>
//             <li>
//               <a href="javascript:void(0);">
//                 <span className="me-2"><i className="fa-solid fa-file" /></span> Policies
//               </a>
//             </li>
//             <li>
//               <a href="javascript:void(0);">
//                 <span className="me-2"><i className="fa-solid fa-chart-pie" /></span> Reports
//               </a>
//             </li>
//           </ul>
//           <ul className="nav header-navbar-rht darkLight-searchBox">
//             <li className="nav-item search-item">
//               <div className="top-nav-search">
//                 <form action="#">
//                   <input type="text" className="form-control" placeholder="Search" />
//                   <button className="btn" type="submit"><i className="feather-search" /></button>
//                   <span><img src={shortcut_icon} alt /></span>
//                 </form>
//               </div>
//             </li>
//             <li className="nav-item quick-link-item dropdown">
//               <a className="btn dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">
//                 <span>Quick Links <i className="feather-zap" /></span>
//               </a>
//               <ul className="dropdown-menu clearfix">
//                 <li><a className="dropdown-item" href="#"><img src={emp_menu_icon} alt />Employees</a></li>
//                 <li><a className="dropdown-item" href="#"><img src={time_off_icon} alt />Time Off</a></li>
//                 <li><a className="dropdown-item" href="#"><img src={timesheet_icon}alt />Timesheet</a></li>
//                 <li><a className="dropdown-item" href="#"><img src={allpolicy_icon}alt />All Policies</a></li>
//                 <li><a className="dropdown-item" href="#"><img src={allreport_icon} alt />Shift &amp; Schedule</a></li>
//                 <li><a className="dropdown-item" href="#"><img src={shift_schedule_icon} alt />All Reports</a></li>
//                 <li className="w-100 bottom-list-menu">
//                   <ul className="sub-menu clearfix">
//                     <li><a href="#">Documentation</a></li>
//                     <li><a href="#">Changelog v1.4.4</a></li>
//                     <li><a href="#">Components</a></li>
//                     <li><a href="#">Support</a></li>
//                     <li><a href="#">Terms &amp; Conditions</a></li>
//                     <li><a href="#">About</a></li>
//                   </ul>
//                 </li>
//               </ul>
//             </li>
//             <li className="nav-item nav-icons">
//               <div className="dark-light">
//                 <i className="feather-moon moon" />
//                 <i className="feather-sun sun" />
//               </div>
//             </li>
//             <li className="nav-item dropdown has-arrow notification-dropdown">
//               <a href="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
//                 <i className="feather-bell" />
//                 <span className="badge">3</span>
//               </a>
//               <div className="dropdown-menu dropdown-menu-end notifications">
//                 <div className="topnav-dropdown-header">
//                   <span className="notification-title">Notifications</span>
//                   <a href="javascript:void(0)" className="clear-noti"> Clear All</a>
//                 </div>
//                 <div className="noti-content">
//                   <ul className="notification-list">
//                     <li className="notification-message">
//                       <a href="javascript:void(0)">
//                         <div className="media d-flex">
//                           <span className="avatar flex-shrink-0">
//                             <img alt src={avatar1} className="rounded-circle" />
//                           </span>
//                           <div className="media-body flex-grow-1">
//                             <p className="noti-details"><span className="noti-title">John Doe</span>added new task 
//                               <span className="noti-title">Patient appointment booking</span></p>
//                             <p className="noti-time"><span className="notification-time">4 mins ago</span></p>
//                           </div>
//                         </div>
//                       </a>
//                     </li>
//                     <li className="notification-message">
//                       <a href="javascript:void(0)">
//                         <div className="media d-flex">
//                           <span className="avatar flex-shrink-0">
//                             <img alt src={avatar2} className="rounded-circle" />
//                           </span>
//                           <div className="media-body flex-grow-1">
//                             <p className="noti-details"><span className="noti-title">Tarah Shropshire</span> changed the task name 
//                               <span className="noti-title">Appointment booking with payment gateway</span></p>
//                             <p className="noti-time"><span className="notification-time">6 mins ago</span></p>
//                           </div>
//                         </div>
//                       </a>
//                     </li>
//                     <li className="notification-message">
//                       <a href="javascript:void(0)">
//                         <div className="media d-flex">
//                           <span className="avatar flex-shrink-0">
//                             <img alt src={avatar6}className="rounded-circle" />
//                           </span>
//                           <div className="media-body flex-grow-1">
//                             <p className="noti-details"><span className="noti-title">Misty Tison</span> added 
//                               <span className="noti-title">Domenic Houston</span> and 
//                               <span className="noti-title">Claire Mapes</span> to project 
//                               <span className="noti-title">Doctor available module</span></p>
//                             <p className="noti-time"><span className="notification-time">8 mins ago</span></p>
//                           </div>
//                         </div>
//                       </a>
//                     </li>
//                     <li className="notification-message">
//                       <a href="javascript:void(0)">
//                         <div className="media d-flex">
//                           <span className="avatar flex-shrink-0">
//                             <img alt src={avatar5} className="rounded-circle" />
//                           </span>
//                           <div className="media-body flex-grow-1">
//                             <p className="noti-details"><span className="noti-title">Rolland
//                                 Webber</span> completed task <span className="noti-title">Patient and Doctor video conferencing</span></p>
//                             <p className="noti-time"><span className="notification-time">12 mins ago</span></p>
//                           </div>
//                         </div>
//                       </a>
//                     </li>
//                     <li className="notification-message">
//                       <a href="javascript:void(0)">
//                         <div className="media d-flex">
//                           <span className="avatar flex-shrink-0">
//                             <img alt src={avatar3} className="rounded-circle" />
//                           </span>
//                           <div className="media-body flex-grow-1">
//                             <p className="noti-details"><span className="noti-title">Bernardo Galaviz</span> added new task 
//                               <span className="noti-title">Private chat module</span></p>
//                             <p className="noti-time"><span className="notification-time">2 days ago</span></p>
//                           </div>
//                         </div>
//                       </a>
//                     </li>
//                   </ul>
//                 </div>
//                 <div className="topnav-dropdown-footer">
//                   <a href="javascript:void(0)">View all Notifications</a>
//                 </div>
//               </div>
//             </li>
//             <li className="nav-item nav-icons">
//               <a href="javascript:void(0);">
//                 <i className="feather-settings" />
//               </a>
//             </li>
//             <li className="nav-item nav-icons">
//               <a href="javascript:void(0);">
//                 <i className="far fa-circle-question" />
//               </a>
//             </li>
//             <li className="nav-item dropdown has-arrow main-drop">
//               <a href="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
//                 <span className="user-img">
//                   <img src={avatar1} className="img-rounded" alt />
//                 </span>
//               </a>
//               <div className="dropdown-menu">
//                 <a className="dropdown-item" href="javascript:void(0);">
//                   <i className="feather-user-plus" /> My Profile
//                 </a>
//                 <a className="dropdown-item" href="javascript:void(0);">
//                   <i className="feather-settings" /> Settings
//                 </a>
//                 <a className="dropdown-item" href="javascript:void(0);">
//                   <i className="feather-log-out" /> Logout
//                 </a>
//               </div>
//             </li>
//           </ul>
//         </div>
//       </nav>
//     </header>
//     {/* /Header */}
//     {/* Page Wrapper */}
//     <div className="page-wrapper schedule-page">
//       {/* Page Content */}
//       <div className="content container">
//         {/* Page Header */}
//         <div className="page-header">
//           <div className="row align-items-center">
//             <div className="col-lg-12">
//               <h3 className="page-title">Leaves</h3>
//             </div>
//           </div>
//           <div className="row align-items-center">
//             <div className="col-lg-6 col-md-6 page-header-btns schedule-btn">
//               <div className="date-time-group date-time mb-0">
//                 <div className="col-auto selct-today-list">
//                   <select className="form-select select select-today">
//                     <option selected>Today</option>
//                     <option value={1}>Week</option>
//                     <option value={2}>Month</option>
//                     <option value={3}>Year</option>
//                   </select>
//                 </div>
//                 <div className="col-auto d-md-inline schedule-date-range">
//                   <div className="date-picker btn btn-group btn-sm mb-0">
//                     <div className="ico left">
//                       <i className="fas fa-chevron-left" />
//                     </div>
//                     <div className="cal-ico center">
//                       <i className="feather-calendar mr-1" />
//                       <span>3/28/2023 - 4/3/2023</span>
//                     </div>
//                     <div className="ico right">
//                       <i className="fas fa-chevron-right" />
//                     </div>
//                   </div>
//                 </div>
//                 <div className="col-auto selct-week-list">
//                   <select className="form-select select select-week">
//                     <option selected>Week</option>
//                     <option value={1}>Day</option>
//                     <option value={2}>Month</option>
//                     <option value={3}>Year</option>
//                   </select>
//                 </div>
//               </div>
//             </div>
//             <div className="col-lg-6 col-md-6 page-header-btns right-btn-part">
//               <div className="col-auto selct-week-list">
//                 <select className="form-select select select-week">
//                   <option selected>Employee View</option>
//                   <option value={1}>Employee 1</option>
//                   <option value={2}>Employee 2</option>
//                   <option value={3}>Employee 3</option>
//                 </select>
//               </div>
//               <a href="javascript:void(0);" className="btn popup-toggle">
//                 <img src="assets/img/icons/funnel-icon.svg" alt />
//               </a>
//               <a href="javascript:void(0);" className="btn new-employee-btn outline-btn"><span>
//                   <i className="feather-flag" /> Positions</span>
//               </a>
//               <a href="javascript:void(0);" className="btn new-employee-btn" data-bs-toggle="modal" data-bs-target="#newschedule">
//                 <i className="fa-solid fa-plus" /> New Schedule
//               </a>
//             </div>
//           </div>                    
//         </div>
//         {/* /Page Header */}
//         {/* Employee Grid */}
//         <div className="employee-list schedule-list">
//           <div className="row">
//             <div className="col-sm-12">
//               <div className="card-table">
//                 <div className="card-body">
//                   <div className="table-responsive">
//                     <table className="table table-center table-hover">
//                       <thead className="thead-light">
//                         <tr>
//                           <th>Employee Name&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
//                           <th>Sun, Mar12</th>
//                           <th>Mon, Mar13</th>
//                           <th>Tue, Mar14</th>
//                           <th>Wed, Mar15</th>
//                           <th>Thu, Mar16</th>
//                           <th>Fri, Mar17</th>
//                           <th>Sat, Mar18</th>
//                         </tr>
//                       </thead>
//                       <tbody>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-02.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Richard Miles <br />
//                                 <span>BD Manager</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                             <div className="shift-btn mid-sht-cht">
//                               <p className="title">Mid Shift Time</p>
//                               <p className="timing">2:30AM - 8:30PM</p>
//                             </div>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="empty-btn">
//                               <a href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#scheduledetail">
//                                 <i className="fa-solid fa-plus" />
//                               </a>
//                             </div>
//                           </td>
//                           <td>
//                           </td>
//                           <td />
//                           <td>
//                             <div className="shift-btn reg-sft-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-03.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Richard Miles <br />
//                                 <span>BD Manager</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn mid-sht-cht">
//                               <p className="title">Mid Shift Time</p>
//                               <p className="timing">2:30AM - 8:30PM</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td />
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn a-sft-cht">
//                               <p className="title">Shift A</p>
//                               <p className="timing">10AM - 7PM</p>
//                             </div>
//                           </td>
//                           <td />
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-04.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Bernardo Galaviz <br />
//                                 <span>UI/UX Team Leader</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                             <div className="shift-btn tst-sht-cht">
//                               <p className="title">Test Shift</p>
//                               <p className="timing">7AM - 4PM</p>
//                             </div>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn a-sft-cht">
//                               <p className="title">Shift A</p>
//                               <p className="timing">10AM - 7PM</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td>
//                           </td>
//                           <td />
//                           <td>
//                             <div className="shift-btn tst-sht-cht">
//                               <p className="title">Test Shift</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-02.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Mike Litorus <br />
//                                 <span>UI/UX Team Leader</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn sft-b-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td>
//                           </td>
//                           <td />
//                           <td />
//                           <td>
//                             <div className="shift-btn sft-b-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-05.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Lesley Grauer <br />
//                                 <span>BD Manager</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                             <div className="shift-btn sft-b-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn tst-sht-cht">
//                               <p className="title">Test Shift</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn reg-sft-cht">
//                               <p className="title">Regular Shift</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td />
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-02.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Loren Gatlin <br />
//                                 <span>UI/UX Team Leader</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn mrg-sft-cht">
//                               <p className="title">Morning Shift</p>
//                               <p className="timing">6PM - 2PM</p>
//                             </div>
//                           </td>
//                           <td>
//                             <div className="shift-btn mid-sht-cht">
//                               <p className="title">Mid Shift Time</p>
//                               <p className="timing">2:30AM - 8:30M</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td>
//                             <div className="shift-btn a-sft-cht">
//                               <p className="title">Shift A</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td>
//                             <div className="shift-btn sft-b-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-04.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Wilmer Deluna <br />
//                                 <span>BD Manager</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn tst-sht-cht">
//                               <p className="title">Test Shift</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td />
//                           <td>
//                           </td>
//                           <td>
//                             <div className="shift-btn sft-b-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td />
//                         </tr>
//                         <tr>
//                           <td>
//                             <h2 className="table-avatar d-flex">
//                               <a href="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src="assets/img/profiles/avatar-01.jpg" alt="User Image" /></a>
//                               <a href="profile.html">Richard Lee <br />
//                                 <span>BD Manager</span></a>
//                             </h2>
//                           </td>
//                           <td>
//                             <div className="shift-btn sft-b-cht">
//                               <p className="title">Shift B</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td>
//                           </td>
//                           <td />
//                           <td>
//                             <div className="shift-btn tst-sht-cht">
//                               <p className="title">Test Shift</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                           <td />
//                           <td />
//                           <td>
//                             <div className="shift-btn reg-sft-cht">
//                               <p className="title">Regular Shift</p>
//                               <p className="timing">2PM - 9PM</p>
//                             </div>
//                           </td>
//                         </tr>
//                       </tbody>
//                     </table>
//                     <div className="pagination-wrap d-flex justify-content-between">
//                       <p>Rows Per page&nbsp;&nbsp;<span>6</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
//                       <ul className="d-flex">
//                         <li><a href="#">1</a></li>
//                         <li><a href="#">2</a></li>
//                         <li><a href="#">3</a></li>
//                         <li><a href="#">...</a></li>
//                         <li><a href="#">10</a></li>
//                         <li><a href="#">11</a></li>
//                         <li><a href="#">12</a></li>
//                       </ul>
//                       <p>Go to page&nbsp; &nbsp; <img src={line} />&nbsp;
//                         &nbsp;<img src="assets/img/icons/right-arrow.svg" /></p>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//         {/* /Employee Grid */}
//         {/* Footer */}
//         <footer className="footer">
//           <div className="container">
//             <div className="row">
//               <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
//                 <div className="footer-left">
//                   <p>© 2023 Dreams HRMS</p>
//                 </div>
//               </div>
//               <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
//                 <div className="footer-right">
//                   <ul>
//                     <li>
//                       <a href="javascript:void(0);">Privacy Policy</a>
//                     </li>
//                     <li>
//                       <a href="javascript:void(0);">Terms &amp; Conditions</a>
//                     </li>
//                   </ul>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </footer>
//         {/* Footer */}
//         <div className="toggle-sidebar schedule-filter">
//           <div className="sidebar-layout-filter">
//             <div className="sidebar-header">
//               <h5>Filter</h5>
//               <a href="#" className="sidebar-closes"><i className="fa-regular fa-circle-xmark" /></a>
//             </div>
//             <div className="sidebar-body">
//               <form action="#" autoComplete="off">
//                 <div className="form-custom">
//                   <input type="text" className="form-control" id="member_search1" placeholder="Search here" />
//                   <span><img src="assets/img/icons/search.svg" alt="img" /></span>
//                 </div>
//                 <div className="accordion" id="accordionMain1">
//                   <div className="card-header-new" id="headingOne">
//                     <h6 className="filter-title">
//                       <a href="javascript:void(0);" className="w-100" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
//                         Customer
//                         <span className="float-end"><i className="fa-solid fa-chevron-down" /></span>
//                       </a>
//                     </h6>
//                   </div>
//                   <div id="collapseOne" className="collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample1">
//                     <div className="card-body-chat">
//                       <div className="row">
//                         <div className="col-md-12">
//                           <div id="checkBoxes1">
//                             <div className="selectBox-cont">
//                               <div className="individual">
//                                 <label className="custom_check">
//                                   <input type="checkbox" name="username" />
//                                   <span className="checkmark" />
//                                 </label>
//                                 <div className="check-img">
//                                   <img src="assets/img/profiles/avatar-01.jpg" className="avatar avatar-img rounded-circle" />
//                                 </div>
//                                 <div className="check-content">
//                                   <h4> Brian Johnson </h4>
//                                   <p className="filter-designation">Senior Designer</p>
//                                 </div>
//                               </div>
//                               <div className="individual">
//                                 <label className="custom_check">
//                                   <input type="checkbox" name="username" />
//                                   <span className="checkmark" />
//                                 </label>
//                                 <div className="check-img">
//                                   <img src="assets/img/profiles/avatar-02.jpg" className="avatar avatar-img rounded-circle" />
//                                 </div>
//                                 <div className="check-content">
//                                   <h4> David </h4>
//                                   <p className="filter-designation">Senior Designer</p>
//                                 </div>
//                               </div>
//                               <div className="individual">
//                                 <label className="custom_check">
//                                   <input type="checkbox" name="username" />
//                                   <span className="checkmark" />
//                                 </label>
//                                 <div className="check-img">
//                                   <img src="assets/img/profiles/avatar-05.jpg" className="avatar avatar-img rounded-circle" />
//                                 </div>
//                                 <div className="check-content">
//                                   <h4> Sam </h4>
//                                   <p className="filter-designation">Senior Designer</p>
//                                 </div>
//                               </div>
//                               <div className="individual">
//                                 <label className="custom_check">
//                                   <input type="checkbox" name="username" />
//                                   <span className="checkmark" />
//                                 </label>
//                                 <div className="check-img">
//                                   <img src="assets/img/profiles/avatar-06.jpg" className="avatar avatar-img rounded-circle" />
//                                 </div>
//                                 <div className="check-content">
//                                   <h4> Brandan </h4>
//                                   <p className="filter-designation">Senior Designer</p>
//                                 </div>
//                               </div>
//                               <div className="view-content">
//                                 <div className="view-all">
//                                   <a href="javascript:void(0);" className="viewall-button-One">
//                                     <span className="me-2">View All</span>
//                                     <span><i className="fa fa-angles-right" /></span>
//                                   </a>
//                                 </div>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="accordion" id="accordionMain3">
//                   <div className="card-header-new" id="headingThree">
//                     <h6 className="filter-title">
//                       <a href="javascript:void(0);" className="w-100 collapsed" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">Team
//                         <span className="float-end"><i className="fa-solid fa-chevron-down" /></span>
//                       </a>
//                     </h6>
//                   </div>
//                   <div id="collapseThree" className="collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExample3">
//                     <div className="card-body-chat">
//                       <div id="checkBoxes2">
//                         <div className="selectBox-cont">
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="bystatus" />
//                             <span className="checkmark" /> Designing Team
//                           </label>
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="bystatus" />
//                             <span className="checkmark" /> Frontend Development Team
//                           </label>
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="bystatus" />
//                             <span className="checkmark" /> Business Development Team
//                           </label>
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="bystatus" />
//                             <span className="checkmark" /> Development Team / PHP
//                           </label>
//                           <div className="view-content">
//                             <div className="view-all">
//                               <a href="javascript:void(0);" className="viewall-button-Two">
//                                 <span className="me-2">View All</span>
//                                 <span><i className="fa fa-angles-right" /></span>
//                               </a>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="accordion accordion-last" id="accordionMain4">
//                   <div className="card-header-new" id="headingFour">
//                     <h6 className="filter-title">
//                       <a href="javascript:void(0);" className="w-100 collapsed" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
//                         Position
//                         <span className="float-end"><i className="fa-solid fa-chevron-down" /></span>
//                       </a>
//                     </h6>
//                   </div>
//                   <div id="collapseFour" className="collapse" aria-labelledby="headingFour" data-bs-parent="#accordionExample4" style={{}}>
//                     <div className="card-body-chat">
//                       <div id="checkBoxes3">
//                         <div className="selectBox-cont">
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="category" />
//                             <span className="checkmark" /> PHP Developer
//                           </label>
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="category" />
//                             <span className="checkmark" /> UI Designer
//                           </label>
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="category" />
//                             <span className="checkmark" /> Frontend Developer
//                           </label>
//                           <label className="custom_check w-100">
//                             <input type="checkbox" name="category" />
//                             <span className="checkmark" /> ReactJs Developer
//                           </label>
//                           <div className="view-content">
//                             <div className="view-all">
//                               <a href="javascript:void(0);" className="viewall-button-Two">
//                                 <span className="me-2">View All</span>
//                                 <span><i className="fa fa-angles-right" /></span>
//                               </a>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//                 <div className="footer-btn">
//                   <a href="javascript:void(0);" className="btn reset-btn">
//                     <i className="fa fa-arrow-rotate-right" /> Reset
//                   </a>
//                   <a href="javascript:void(0);" className="btn main-btn">
//                     <i className="fa-solid fa-check" /> Apply
//                   </a>
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </div>
//       {/* /Page Content */}
//     </div>
//     {/* /Page Wrapper */}
//   </div>
//   {/* /Main Wrapper */}
//   {/* Modal Popup */}
//   <div className="employees-popup schedule-popup">
//     <div className="modal fade" id="scheduledetail" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="scheduledetailLabel" aria-hidden="true">
//       <div className="modal-dialog modal-dialog-centered">
//         <div className="modal-content">
//           <div className="modal-header">
//             <h1 className="modal-title" id="scheduledetailLabel"> 
//               <img src="assets/img/profiles/avatar-01.jpg" className="avatar avatar-img rounded-circle" /> John Smith - Tuesday, March 15, 2023
//             </h1>
//             <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
//               <img src="assets/img/icons/close.svg" /> 
//             </button>
//           </div>
//           <div className="modal-body">
//             <div className="multistep-form">
//               <fieldset className="form-inner" id="first">
//                 <div className="form-area">
//                   <div className="form-details ">
//                     <form action="#">
//                       <div className="row">
//                         <div className="col-lg-6 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Team <span>*</span></label>
//                             <input type="text" className="form-control " placeholder="Design" readOnly />
//                           </div>
//                         </div>
//                         <div className="col-lg-6 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Position <span>*</span></label>
//                             <input type="text" className="form-control" placeholder="Ui Designer" readOnly />
//                           </div>
//                         </div>
//                         <div className="col-lg-12 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Select Shift <span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected>Select Parent Department</option>
//                               <option value={1}>One</option>
//                               <option value={2}>Two</option>
//                               <option value={3}>Three</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="col-lg-4 col-md-6 col-sm-12">
//                           <div className="input-area date-select time">
//                             <label className="form-label">Start Time<span>*</span></label>
//                             <input type="text" className="form-control timepicker" placeholder="Select Time" />
//                             <span className="icon"> <i className="feather-clock" /> </span>
//                           </div>
//                         </div>
//                         <div className="col-lg-4 col-md-6 col-sm-12">
//                           <div className="input-area date-select time">
//                             <label className="form-label">End Time<span>*</span></label>
//                             <input type="text" className="form-control timepicker" placeholder="Select Time" />
//                             <span className="icon"> <i className="feather-clock" /> </span>
//                           </div>
//                         </div>
//                         <div className="col-lg-4 col-md-6 col-sm-12">
//                           <div className="input-area date-select time">
//                             <label className="form-label">Break Time<span>*</span></label>
//                             <input type="text" className="form-control timepicker" placeholder="Select Time" />
//                             <span className="icon"> <i className="feather-clock" /> </span>
//                           </div>
//                         </div>
//                         <div className="col-lg-12 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Repeat <span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected>Does not repeat</option>
//                               <option value={1}>Daily</option>
//                               <option value={2}>Weekly on Monday</option>
//                               <option value={3}>Every 4rd Monday</option>
//                               <option value={4}>Every weekday (Monday to Friday)</option>
//                               <option value={5}>Custom...</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="col-lg-12 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">During <span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected>2 Weeks</option>
//                               <option value={1}>1 Month</option>
//                               <option value={2}>2 Months</option>
//                               <option value={3}>3 Months</option>
//                               <option value={4}>6 Months</option>
//                               <option value={5}>12 Months</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="col-lg-4 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Every</label>
//                             <input type="text" className="form-control" placeholder={10} />
//                           </div>
//                         </div>
//                         <div className="col-lg-8 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Select repeat every </label>
//                             <select className="form-select select">
//                               <option selected>10 Days</option>
//                               <option value={1}>10 Weeks</option>
//                               <option value={2}>10 Months</option>
//                               <option value={3}>10 Years</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="col-lg-8 col-md-6 col-sm-6 ">
//                           <div className="input-area">
//                             <label className="form-label">Repeat on</label>
//                             <div className="selectdays">
//                               <ul>
//                                 <li>
//                                   <a href="javascript:void(0);"> M</a>
//                                 </li>
//                                 <li>
//                                   <a href="javascript:void(0);"> T</a>
//                                 </li>
//                                 <li>
//                                   <a href="javascript:void(0);"> W</a>
//                                 </li>
//                                 <li>
//                                   <a href="javascript:void(0);"> T</a>
//                                 </li>
//                                 <li>
//                                   <a href="javascript:void(0);"> F</a>
//                                 </li>
//                                 <li>
//                                   <a href="javascript:void(0);"> S</a>
//                                 </li>
//                                 <li>
//                                   <a href="javascript:void(0);"> S</a>
//                                 </li>
//                               </ul>
//                             </div>
//                           </div>
//                         </div>
//                       </div>
//                     </form>
//                   </div>
//                 </div>
//                 <div className="add-form-btn widget-next-btn submit-btn">
//                   <div className="btn-left">
//                     <a className="btn main-btn"><i className="fa-solid fa-check" /> Publish</a>
//                   </div>
//                 </div>
//               </fieldset>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   </div>
//   {/* Modal */}
//   {/* Modal */}
//   <div className="employees-popup new-schedule">
//     <div className="modal fade" id="newschedule" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="newscheduleLabel" aria-hidden="true">
//       <div className="modal-dialog modal-dialog-centered">
//         <div className="modal-content p-0">
//           <div className="modal-header modal-schedule mb-0">
//             <h6 id="newscheduleLabel">
//               <img src="assets/img/profiles/avatar-01.jpg" className="schedule-img rounded-circle me-2" alt />John Smith - Tuesday, March 15, 2023
//             </h6>
//             <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
//               <img src="assets/img/icons/close.svg" /> 
//             </button>
//           </div>
//           <div className="modal-body">
//             <div className="multistep-form">
//               <fieldset className="form-inner" id="first">
//                 <div className="form-area">
//                   <div className="form-details ">
//                     <form action="#">
//                       <div className="row">
//                         <div className="col-lg-6 col-md-6 col-sm-12">
//                           <div className="input-area">
//                             <label className="form-label">Team <span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected>Select Team</option>
//                               <option value={1}>Ui Team</option>
//                               <option value={2}>Web Team</option>
//                               <option value={3}>IOS Team</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="col-lg-6 col-md-6 col-sm-6 ">
//                           <div className="input-area">
//                             <label className="form-label">Position <span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected>Select Position</option>
//                               <option value={1}>Senior</option>
//                               <option value={2}>Junior</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="col-lg-12 col-md-6 col-sm-6 ">
//                           <div className="input-area">
//                             <label className="form-label">Shift Templates<span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected>Select Shift</option>
//                               <option value={1}>Morning Shift</option>
//                               <option value={2}>Night Shift</option>
//                               <option value={3}>Mid Shift</option>
//                             </select>
//                           </div>
//                         </div>
//                         <div className="assign-form">
//                           <div className="row">
//                             <div className="col-lg-4 col-md-6 col-sm-12">
//                               <div className="input-area date-select time">
//                                 <label className="form-label">Start Time<span>*</span></label>
//                                 <input type="text" className="form-control timepicker" placeholder="Select Shift" />
//                                 <span className="icon"> <i className="feather-clock" /></span>
//                               </div>
//                             </div>
//                             <div className="col-lg-4 col-md-6 col-sm-12">
//                               <div className="input-area date-select time">
//                                 <label className="form-label">End Time<span>*</span></label>
//                                 <input type="text" className="form-control timepicker" placeholder="Select Shift" />
//                                 <span className="icon"> <i className="feather-clock" /></span>
//                               </div>
//                             </div>
//                             <div className="col-lg-4 col-md-6 col-sm-12">
//                               <div className="input-area date-select time">
//                                 <label className="form-label">Break Time<span>*</span></label>
//                                 <input type="text" className="form-control timepicker" placeholder="Select Shift" />
//                                 <span className="icon"> <i className="feather-clock" /></span>
//                               </div>
//                             </div>
//                           </div>
//                         </div>
//                         <div className="col-lg-12 col-md-6 col-sm-6 ">
//                           <div className="input-area">
//                             <label className="form-label">Repeat <span>*</span> </label>
//                             <select className="form-select select">
//                               <option selected className="text-info">Does not repeat</option>
//                               <option value={1}>Senior</option>
//                               <option value={2}>Junior</option>
//                             </select>
//                           </div>
//                         </div>
//                       </div>
//                     </form>
//                   </div>
//                 </div>
//                 <div className="add-form-btn widget-next-btn submit-btn">
//                   <div className="btn-left">
//                     <a className="btn main-btn"><i className="fa-solid fa-check"> </i> Assign Schedule</a>
//                   </div>
//                 </div>
//               </fieldset>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   </div>
//   {/* Modal*/}
// </div>

//   )
// }
