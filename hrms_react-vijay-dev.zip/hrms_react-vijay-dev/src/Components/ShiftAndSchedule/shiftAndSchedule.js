import React from 'react'
import funnelicon from '../../../src/Components/assets/img/icons/funnel-icon.svg'
import bararrowicon from  '../../../src/Components/assets/img/icons/bar-arrow.svg'
import search_icon from  '../../../src/Components/assets/img/icons/search-icon.svg'
import gridicon from '../../../src/Components/assets/img/icons/grid-icon.svg'
import dashboardicon from '../../../src/Components/assets/img/icons/dashboard-icon.svg'
import employeeicon from '../../../src/Components/assets/img/icons/employees-icon.svg'
import timeofficon from '../../../src/Components/assets/img/icons/time-off-icon.svg'
import policyicon from  '../../../src/Components/assets/img/icons/policies-icon.svg'
import reporticon from '../../../src/Components/assets/img/icons/reports-icon.svg'
import shortcuticon from     '../../../src/Components/assets/img/icons/shortcut-icon.svg'                       
import timesheeticon from     '../../../src/Components/assets/img/icons/timesheet-icon.svg'   
import allpoliciesicon from     '../../../src/Components/assets/img/icons/allpolicies-icon.svg'   
import empmenu_icon from     '../../../src/Components/assets/img/icons/employees-menu-icon.svg'  
import allreport_icon from     '../../../src/Components/assets/img/icons/allreports-icon.svg'  
import shift_schedule_icon from     '../../../src/Components/assets/img/icons/shift-schedule-icon.svg' 
import ticket_icon from "../../../src/Components/assets/img/icons/ticket.svg"  
import clock_icon from "../../../src/Components/assets/img/icons/clock.svg"   
import timing_icon from "../../../src/Components/assets/img/icons/timing.svg"   
import break_icon from "../../../src/Components/assets/img/icons/break.svg" 
import avatar1 from "../../Components/assets/img/profiles/avatar-01.jpg"  
import logo from "../../Components/assets/img/logo.svg"
import avatar2 from "../../Components/assets/img/profiles/avatar-02.jpg"
import avatar5 from "../../Components/assets/img/profiles/avatar-05.jpg"
import avatar6 from "../../Components/assets/img/profiles/avatar-06.jpg"
import avatar3 from "../../Components/assets/img/profiles/avatar-03.jpg"
import avatar7 from "../../Components/assets/img/profiles/avatar-07.jpg"
import avatar8 from "../../Components/assets/img/profiles/avatar-08.jpg"
import avatar10 from "../../Components/assets/img/profiles/avatar-10.jpg"

import FontAwesome from 'react-fontawesome';

export default function ShiftAndSchedule() {
  return (
<>
<div>
<div>
  {/* Main Wrapper */}
  <div className="main-wrapper">
    {/* Header */}
    <header className="header header-fixed header-one">
      <nav className="navbar navbar-expand-lg header-nav">
        <div className="navbar-header">
          <a id="mobile_btn" href="javascript:void(0);">
            <span className="bar-icon">
              <span />
              <span />
              <span />
            </span>
          </a>
          <a href="javascript:void(0);" className="navbar-brand logo">
            <img src={logo} className="img-fluid" alt="Logo" />
          </a>
        </div>
        <div className="main-menu-wrapper">
          <ul className="main-nav">
            <li>
              <a href="javascript:void(0);">
                <span className="me-2"><i className="fa-solid fa-gauge" /></span> Dashboard
              </a>
            </li>
            <li className="active">
              <a href="employees.html">
                <span className="me-2"><i className="fa-solid fa-users" /></span> Employees
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <span className="me-2"><i className="fa-solid fa-plane-departure" /></span> Time off
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <span className="me-2"><i className="fa-solid fa-file" /></span> Policies
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <span className="me-2"><i className="fa-solid fa-chart-pie" /></span> Reports
              </a>
            </li>
          </ul>
          <ul className="nav header-navbar-rht darkLight-searchBox">
            <li className="nav-item search-item">
              <div className="top-nav-search">
                <form action="#">
                  <input type="text" className="form-control" placeholder="Search" />
                  <button className="btn" type="submit"><i className="feather-search" /></button>
                  <span><img src={shortcuticon} alt /></span>
                </form>
              </div>
            </li>
            <li className="nav-item quick-link-item dropdown">
              <a className="btn dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">
                <span>Quick Links <i className="feather-zap" /></span>
              </a>
              <ul className="dropdown-menu clearfix">
                <li><a className="dropdown-item" href="#"><img src={empmenu_icon} alt />Employees</a></li>
                <li><a className="dropdown-item" href="#"><img src={timeofficon} alt />Time Off</a></li>
                <li><a className="dropdown-item" href="#"><img src={timesheeticon} alt />Timesheet</a></li>
                <li><a className="dropdown-item" href="#"><img src={allpoliciesicon} alt />All Policies</a></li>
                <li><a className="dropdown-item" href="#"><img src={shift_schedule_icon} alt />Shift &amp; Schedule</a></li>
                <li><a className="dropdown-item" href="#"><img src={allreport_icon}alt />All Reports</a></li>
                <li className="w-100 bottom-list-menu">
                  <ul className="sub-menu clearfix">
                    <li><a href="#">Documentation</a></li>
                    <li><a href="#">Changelog v1.4.4</a></li>
                    <li><a href="#">Components</a></li>
                    <li><a href="#">Support</a></li>
                    <li><a href="#">Terms &amp; Conditions</a></li>
                    <li><a href="#">About</a></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li className="nav-item nav-icons">
              <div className="dark-light">
                <i className="feather-moon moon" />
                <i className="feather-sun sun" />
              </div>
            </li>
            <li className="nav-item dropdown has-arrow notification-dropdown">
              <a href="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <i className="feather-bell" />
                <span className="badge">3</span>
              </a>
              <div className="dropdown-menu dropdown-menu-end notifications">
                <div className="topnav-dropdown-header">
                  <span className="notification-title">Notifications</span>
                  <a href="javascript:void(0)" className="clear-noti"> Clear All</a>
                </div>
                <div className="noti-content">
                  <ul className="notification-list">
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar1} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">John Doe</span>added new task 
                              <span className="noti-title">Patient appointment booking</span></p>
                            <p className="noti-time"><span className="notification-time">4 mins ago</span></p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar2} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Tarah Shropshire</span> changed the task name 
                              <span className="noti-title">Appointment booking with payment gateway</span></p>
                            <p className="noti-time"><span className="notification-time">6 mins ago</span></p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar6} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Misty Tison</span> added 
                              <span className="noti-title">Domenic Houston</span> and 
                              <span className="noti-title">Claire Mapes</span> to project 
                              <span className="noti-title">Doctor available module</span></p>
                            <p className="noti-time"><span className="notification-time">8 mins ago</span></p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar5} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Rolland
                                Webber</span> completed task <span className="noti-title">Patient and Doctor video conferencing</span></p>
                            <p className="noti-time"><span className="notification-time">12 mins ago</span></p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt src={avatar3} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Bernardo Galaviz</span> added new task 
                              <span className="noti-title">Private chat module</span></p>
                            <p className="noti-time"><span className="notification-time">2 days ago</span></p>
                          </div>
                        </div>
                      </a>
                    </li>
                  </ul>
                </div>
                <div className="topnav-dropdown-footer">
                  <a href="javascript:void(0)">View all Notifications</a>
                </div>
              </div>
            </li>
            <li className="nav-item nav-icons">
              <a href="javascript:void(0);">
                <i className="feather-settings" />
              </a>
            </li>
            <li className="nav-item nav-icons">
              <a href="javascript:void(0);">
                <i className="far fa-circle-question" />
              </a>
            </li>
            <li className="nav-item dropdown has-arrow main-drop">
              <a href="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <span className="user-img">
                  <img src={avatar1} className="img-rounded" alt />
                </span>
              </a>
              <div className="dropdown-menu">
                <a className="dropdown-item" href="javascript:void(0);">
                  <i className="feather-user-plus" /> My Profile
                </a>
                <a className="dropdown-item" href="javascript:void(0);">
                  <i className="feather-settings" /> Settings
                </a>
                <a className="dropdown-item" href="javascript:void(0);">
                  <i className="feather-log-out" /> Logout
                </a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper shift-page">
      {/* Page Content */}
      <div className="content container">
        {/* Page Header */}
        <div className="page-header">
          <div className="row align-items-center">
            <div className="col-lg-6 col-md-6">
              <h3 className="page-title">Shift List</h3>
            </div>
            <div className="col-lg-6 col-md-6 page-header-btns page-header-position-btns">
              <a href="javascript:void(0);" className="btn ">
                <img src={funnelicon} alt />
              </a>
              <a href="javascript:void(0);" className="btn ">
                <img src={bararrowicon} alt />
              </a>
              <a href="javascript:void(0);" className="btn ">
                <img src={search_icon} alt />
              </a>
              <a href="javascript:void(0);" className="btn new-employee-btn" data-bs-toggle="modal" data-bs-target="#add-shift">
                <i className="fa-solid fa-plus" /> New Shift
              </a>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        {/* Shift List */}
        <div className="employee-list shift-list">
          <div className="row">
            <div className="col-sm-12">
              <div className="card-table">
                <div className="card-body">
                  <div className="table-responsive">
                    <table className="table table-center table-hover datatable">
                      <thead className="thead-light">
                        <tr>
                          <th>#</th>
                          <th>Color</th>
                          <th>Shift Name</th>
                          <th>Start Time</th>
                          <th>End Time</th>
                          <th>Break Time</th>
                          <th>Note</th>
                          <th>Action&nbsp;&nbsp;</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>
                            <span className="mrg-sft table-bg" />
                          </td>
                          <td>Morning Shift</td>
                          <td>06:00:00 AM</td>
                          <td>02:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td>
                            <span className="tst-sht table-bg" />
                          </td>
                          <td>Test Shift</td>
                          <td>10:00:00 AM</td>
                          <td>07:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>
                            <span className="mid-sht table-bg" />
                          </td>
                          <td>Mid Shift Time</td>
                          <td>02:00:00 PM</td>
                          <td>09:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>4</td>
                          <td>
                            <span className="reg-sft table-bg" />
                          </td>
                          <td>Regular Shift</td>
                          <td>09:00:00 AM</td>
                          <td>06:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>5</td>
                          <td>
                            <span className="a-sft table-bg" />
                          </td>
                          <td>Shift A</td>
                          <td>10:00:00 AM</td>
                          <td>07:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>6</td>
                          <td>
                            <span className="nit-sft table-bg" />
                          </td>
                          <td>Night Shift</td>
                          <td>09:00:00 AM</td>
                          <td>06:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>7</td>
                          <td>
                            <span className="sft-b table-bg" />
                          </td>
                          <td>Shift B</td>
                          <td>10:00:00 AM</td>
                          <td>07:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>8</td>
                          <td>
                            <span className="sft-c table-bg" />
                          </td>
                          <td>Shift C</td>
                          <td>10:00:00 AM</td>
                          <td>07:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>9</td>
                          <td>
                            <span className="sft-d table-bg" />
                          </td>
                          <td>Shift D</td>
                          <td>10:00:00 AM</td>
                          <td>07:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>10</td>
                          <td>
                            <span className="sft-e table-bg" />
                          </td>
                          <td>Shift E</td>
                          <td>10:00:00 AM</td>
                          <td>07:00:00 PM</td>
                          <td>60 Mins</td>
                          <td>Development Team</td>
                          <td className="d-flex align-items-center">
                            <div className="dropdown dropdown-action">
                              <a href="#" className=" btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></a>
                              <div className="dropdown-menu dropdown-menu-end">
                                <ul>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-edit me-2" />Edit</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</a>
                                  </li>
                                  <li>
                                    <a className="dropdown-item" href="javascript:void(0);"><i className="far fa-eye me-2" />View</a>
                                  </li>
                                </ul>
                              </div>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /Shift List */}
        {/* Footer */}
        <footer className="footer">
          <div className="container">
            <div className="row">
              <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                <div className="footer-left">
                  <p>© 2023 Dreams HRMS</p>
                </div>
              </div>
              <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                <div className="footer-right">
                  <ul>
                    <li>
                      <a href="javascript:void(0);">Privacy Policy</a>
                    </li>
                    <li>
                      <a href="javascript:void(0);">Terms &amp; Conditions</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </footer>
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  <div className="employees-popup add-shift " id="employee-offboarding">
    <div className="modal fade modal-lg" id="add-shift" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="staticBackdrop1Label" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h1 className="modal-title" id="staticBackdrop1Label">Add Shift</h1>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span><i className="far fa-solid fa-close" /></span>
            </button>
          </div>
          <div className="modal-body">
            <div className="multistep-form">
              <fieldset className="form-inner" id="first">
                <div className="form-area">
                  <div className="form-details">
                    <form action="#">
                      <div className="row">
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Shift Name <span>*</span></label>
                            <input type="text" className="form-control" placeholder="Enter Shift Name" required />
                          </div>
                        </div>
                        <div className="col-lg-6 col-md-6 col-sm-6 ">
                          <div className="input-area date-select">
                            <label className="form-label">Date <span>*</span></label>
                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                            <span className="icon"> <i className="feather-calendar" /> </span>
                          </div>
                        </div>
                        <div className="col-lg-6 col-md-6 col-sm-6 ">
                          <div className="input-area date-select time">
                            <label className="form-label">Select Shift<span>*</span></label>
                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                            <span className="icon"> <i className="feather-clock" /> </span>
                          </div>
                        </div>
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Choose Color <span>*</span></label>
                            <div className="select-color">
                              <div className="multi-color">
                                <ul>
                                  <li>
                                    <a href="javascript:void(0);" className="mrg-sft" />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="tst-sht" />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="mid-sht" />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="reg-sft " />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="a-sft" />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="nit-sft" />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="sft-b" />
                                  </li>
                                  <li>
                                    <a href="javascript:void(0);" className="sft-c" />
                                  </li>
                                </ul>
                              </div>
                              <div className="choose-color">
                                <p className="text-color">More Colors 
                                  <input type="color" className="sft-e  form-control form-control-color" />
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <ul className="nav nav-tabs shift-schedule-tab" id="myTab" role="tablist">
                        <li className="nav-item mb-0" role="presentation">
                          <button className="nav-link active" id="resignation-tab" data-bs-toggle="tab" data-bs-target="#resignation" type="button" role="tab" aria-controls="resignation" aria-selected="true">                          
                            <div className="schedule-type">
                              <div className="schedule-img">
                                <img src= {ticket_icon}/>
                              </div>
                              <div className="schedule-content">
                                <h3>Duration Based</h3>
                                <p>Lorem ipsum dolor elit</p>
                              </div>
                              <span />
                            </div>
                          </button>
                        </li>
                        <li className="nav-item mb-0" role="presentation">
                          <button className="nav-link" id="termination-tab" data-bs-toggle="tab" data-bs-target="#termination" type="button" role="tab" aria-controls="termination" aria-selected="false">                          
                            <div className="schedule-type">
                              <div className="schedule-img">
                                <img src={clock_icon}/>
                              </div>
                              <div className="schedule-content">
                                <h3>Duration Based</h3>
                                <p>Lorem ipsum dolor elit</p>
                              </div>
                              <span />
                            </div>
                          </button>
                        </li>
                      </ul>
                      <div className="tab-content" id="myTabContent">
                        <div className="tab-pane fade show active" id="resignation" role="tabpanel" aria-labelledby="resignation-tab">	
                          <div className="row">
                            <div className="workingtime">
                              <h5>Working Time</h5>
                              <div className="accordion" id="accordionPanelsStayOpenExample">
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_1" className="check" />
                                        <label htmlFor="status_1" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Monday</p>
                                      <div className="timing">
                                        <img src={timing_icon} /> 09:30 -
                                        18:30 &nbsp;&nbsp;&nbsp; 
                                        <img src={break_icon}/> 09:30 -
                                        18:30
                                      </div>
                                      <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                                      </button>
                                    </div>
                                  </h2>
                                  <div id="panelsStayOpen-collapseOne" className="accordion-collapse collapse show">
                                    <div className="accordion-body">
                                      <div className="row">
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select">
                                            <label className="form-label">Date
                                              <span>*</span></label>
                                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                                            <span className="icon"> <i className="feather-calendar" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select time">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                                            <span className="icon"> <i className="feather-clock" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-2 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select paste">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control" />
                                            <a href="javascript:void(0);">
                                              <span className="icon"> <i className="feather-copy" />
                                              </span>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_2" className="check" />
                                        <label htmlFor="status_2" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Tuesday</p>
                                      <div className="timing">
                                        <img src={timing_icon}/> 09:30 -
                                        18:30 &nbsp;&nbsp;&nbsp; 
                                        <img src={break_icon}/> 09:30 -
                                        18:30
                                      </div>
                                      <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
                                      </button>
                                    </div>
                                  </h2>
                                  <div id="panelsStayOpen-collapseTwo" className="accordion-collapse collapse">
                                    <div className="accordion-body">
                                      <div className="row">
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select">
                                            <label className="form-label">Date
                                              <span>*</span></label>
                                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                                            <span className="icon"> <i className="feather-calendar" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select time">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                                            <span className="icon"> <i className="feather-clock" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-2 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select paste">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control" />
                                            <a href="javascript:void(0);">
                                              <span className="icon"> <i className="feather-copy" />
                                              </span>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_3" className="check" />
                                        <label htmlFor="status_3" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Wednesday</p>
                                      <div className="timing">
                                        <img src={timing_icon}/> 09:30 -
                                        18:30 &nbsp;&nbsp;&nbsp; 
                                        <img src={break_icon}/> 09:30 -
                                        18:30
                                      </div>
                                      <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
                                      </button>
                                    </div>
                                  </h2>
                                  <div id="panelsStayOpen-collapseThree" className="accordion-collapse collapse">
                                    <div className="accordion-body">
                                      <div className="row">
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select">
                                            <label className="form-label">Date
                                              <span>*</span></label>
                                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                                            <span className="icon"> <i className="feather-calendar" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select time">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                                            <span className="icon"> <i className="feather-clock" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-2 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select paste">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control" />
                                            <a href="javascript:void(0);">
                                              <span className="icon"> <i className="feather-copy" />
                                              </span>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_4" className="check" />
                                        <label htmlFor="status_4" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Saturday</p>
                                    </div>
                                  </h2>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="tab-pane fade" id="termination" role="tabpanel" aria-labelledby="termination-tab">
                          <div className="row">
                            <div className="workingtime">
                              <h5>Working Time</h5>
                              <div className="accordion" id="accordionPanelsStayOpenExample">
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_7" className="check" />
                                        <label htmlFor="status_7" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Monday</p>
                                      <div className="timing">
                                        <img src={timing_icon} /> 09:30 -
                                        18:30 &nbsp;&nbsp;&nbsp; 
                                        <img src={break_icon} /> 09:30 -
                                        18:30
                                      </div>
                                      <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true" aria-controls="panelsStayOpen-collapseOne">
                                      </button>
                                    </div>
                                  </h2>
                                  <div id="panelsStayOpen-collapseOne" className="accordion-collapse collapse show">
                                    <div className="accordion-body">
                                      <div className="row">
                                        <div className="col-lg-10 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select time">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                                            <span className="icon"> <i className="feather-clock" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-2 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select paste">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control" />
                                            <a href="javascript:void(0);">
                                              <span className="icon"> <i className="feather-copy" />
                                              </span>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_8" className="check" />
                                        <label htmlFor="status_8" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Tuesday</p>
                                      <div className="timing">
                                        <img src={timing_icon} /> 09:30 -
                                        18:30 &nbsp;&nbsp;&nbsp; 
                                        <img src={break_icon}/> 09:30 -
                                        18:30
                                      </div>
                                      <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
                                      </button>
                                    </div>
                                  </h2>
                                  <div id="panelsStayOpen-collapseTwo" className="accordion-collapse collapse">
                                    <div className="accordion-body">
                                      <div className="row">
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select">
                                            <label className="form-label">Date
                                              <span>*</span></label>
                                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                                            <span className="icon"> <i className="feather-calendar" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select time">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                                            <span className="icon"> <i className="feather-clock" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-2 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select paste">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control" />
                                            <a href="javascript:void(0);">
                                              <span className="icon"> <i className="feather-copy" />
                                              </span>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_9" className="check" />
                                        <label htmlFor="status_9" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Wednesday</p>
                                      <div className="timing">
                                        <img src={timing_icon}/> 09:30 -
                                        18:30 &nbsp;&nbsp;&nbsp; 
                                        <img src={break_icon}/> 09:30 -
                                        18:30
                                      </div>
                                      <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="true" aria-controls="panelsStayOpen-collapseThree">
                                      </button>
                                    </div>
                                  </h2>
                                  <div id="panelsStayOpen-collapseThree" className="accordion-collapse collapse">
                                    <div className="accordion-body">
                                      <div className="row">
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select">
                                            <label className="form-label">Date
                                              <span>*</span></label>
                                            <input type="text" className="form-control datetimepicker" placeholder="Select Date" />
                                            <span className="icon"> <i className="feather-calendar" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-5 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select time">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control timepicker" placeholder="Select Shift" />
                                            <span className="icon"> <i className="feather-clock" />
                                            </span>
                                          </div>
                                        </div>
                                        <div className="col-lg-2 col-md-6 col-sm-6 ">
                                          <div className="input-area date-select paste">
                                            <label className="form-label">Select
                                              Shift<span>*</span></label>
                                            <input type="text" className="form-control" />
                                            <a href="javascript:void(0);">
                                              <span className="icon"> <i className="feather-copy" />
                                              </span>
                                            </a>
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                <div className="accordion-item">
                                  <h2 className="accordion-header">
                                    <div className="form-check form-switch">
                                      <div className="status-toggle ">
                                        <input type="checkbox" id="status_10" className="check" />
                                        <label htmlFor="status_10" className="checktoggle">checkbox</label>
                                      </div>
                                      <p>Saturday</p>
                                    </div>
                                  </h2>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="add-form-btn widget-next-btn submit-btn">
                  <div className="btn-left">
                    <a className="btn main-btn"><i className="fa-solid fa-check me-2"> </i> Save Templates</a>
                  </div>
                </div>
              </fieldset>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Modal Popup */}
  {/* Modal */}
  {/* Modal Popup */}
  <div className="employees-popup add-position">
    <div className="modal fade" id="delete_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h1 className="modal-title" id="addroleLabel">Delete Shift List</h1>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <span><i className="far fa-solid fa-close" /></span>
            </button>
          </div>
          <div className="modal-body">
            <div className="multistep-form">
              <fieldset className="form-inner" id="first">
                <div className="form-area">
                  <div className="form-details ">
                    <form action="#">
                      <div className="row">
                        <div className="col-lg-12 text-center">
                          <div className="input-area">
                            <span className="delete-area text-danger display-6"><i className="far fa-solid fa-trash-alt" /></span>
                            <p className="mt-2">Are you sure you want to delete your Shift List</p>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="btns-groups mt-0 modal-btn-group text-center">
                  <button type="submit" className="btn gradient-btn me-3" data-bs-dismiss="modal"><span><i className="fa-solid fa-check" /></span>Save Changes</button>
                  <button type="reset" className="btn cancel-btn" data-bs-dismiss="modal">Cancel</button>
                </div>
              </fieldset>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* /Modal Popup */}
</div>

</div>

</>



  )
}
