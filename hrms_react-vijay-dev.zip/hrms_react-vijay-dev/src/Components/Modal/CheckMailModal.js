import React from "react";
import { Button } from "react-bootstrap";
import Modal from "react-bootstrap/Modal";
import { useNavigate } from "react-router-dom";
import mail from "../assets/img/mail.svg";
import union from "../assets/img/union.svg";
import backArrow from "../assets/img/backArrow.svg";
import "../Modal/Modal.css";

function CheckMailModal({ show, setShow, mailData }) {
  console.log(mailData, "mail");
  console.log(show);
  const navigate = useNavigate();

  return (
    <div className="p-4">
      <Modal show={show} size="m">
        <Modal.Body className=" d-flex align-items-center justify-content-center flex-column ">
          <div className="d-flex align-items-end justify-content-end w-100 ">
            <div onClick={() => setShow(false)} className="close-btn">
              <img
                src={union}
                alt=""
                style={{ width: "14.73px", height: "14.73px" }}
              />
            </div>
          </div>
          <div
            style={{ flexDirection: "column" }}
            className=" d-flex align-items-center justify-content-center"
          >
            <img className="pt-2" src={mail} alt="" />

            <div className=" d-flex align-items-center justify-content-center flex-column my-3">
              <h3 className="pt-2">Check Your Mail</h3>
              <p className="pt-2">
                We send a Password reset link to{" "}
                <span style={{ color: "#0F233C", fontWeight: "600" }}>
                  {mailData?.email}
                </span>
              </p>
            </div>

            <div className=" d-flex align-items-center justify-content-center flex-column w-100">
              <a
                onClick={() => setShow(false)}
                class="form-group btn login-submit w-100 pt-2"
              >
                Close
              </a>
              <button
                style={{ color: "rgba(0, 0, 0, 0.4)", border: "1px solid" }}
                class="form-group btn forgot-submit w-100 pt-2"
                onClick={() => navigate("/")}
              >
                <span>
                  <img
                    src={backArrow}
                    style={{ paddingRight: "5%" }}
                    alt=""
                  ></img>
                </span>{" "}
                Back to Login
              </button>
              <p className="pt-2">
                dont receive the email?{" "}
                <span style={{ color: "#00AEEB" }}>Click to resend</span>{" "}
              </p>
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default CheckMailModal;
