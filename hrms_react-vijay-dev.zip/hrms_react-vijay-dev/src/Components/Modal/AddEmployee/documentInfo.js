import React from 'react'

export default function documentInfo() {
  return (
    <div>documentInfo</div>
  )
}
