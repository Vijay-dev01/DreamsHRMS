import React, { useState } from "react";
import { Button, Col, Modal, Row } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import "bootstrap/dist/css/bootstrap.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import "../Modal.css";
import profileimg from "../../assets/img/profileimg.svg";
export default function PersonalinfoModal({ showmodal }) {
  return (
    <div>
      <Modal
        style={{ padding: "1.5rem" }}
        show={showmodal}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Row>
          <h5>Personal Information</h5>
          <p>Basic Information</p>
          <p>Profile Picture</p>
          <div style={{ padding: "0%" }}>
            <Col>
              <img src={profileimg}></img>
            </Col>
            <Col >
              <Button style={{background:"#00AEEB",marginRight:"20px"}}>Upload New Picture</Button>
              <Button style={{color:"#EF444E",background:"none",border: "solid 1px #E5E7EB"}}>Delete</Button>
              <p className="pt-2" style={{fontWidth:"400",fontSize:"12px"}}>Image Should be minimum 152 * 152 Supported File format JPG,PNG,SVG</p>
            </Col>
          </div>
        </Row>
        <Row>
          <Col>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>First Name</Form.Label>
                <Form.Control type="text" placeholder="Enter Emp First Name" />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Gender</Form.Label>
                <Form.Select size="lg">
                  <option> select Gender </option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Date Of Birth</Form.Label>
                <Form.Control type="date" placeholder="DDMMYY" />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>City</Form.Label>
                <Form.Select size="lg">
                  <option> select city</option>
                </Form.Select>
              </Form.Group>
            </Form>
          </Col>
          <Col>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Last Name</Form.Label>
                <Form.Control type="email" placeholder="Enter Emp Lastname" />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Martial Status</Form.Label>
                <Form.Select size="lg">
                  <option> select Gender </option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>District</Form.Label>
                <Form.Select size="lg">
                  <option> select District </option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Personal Email</Form.Label>
                <Form.Control type="email" placeholder="Enter Personal Email" />
              </Form.Group>
            </Form>
          </Col>
          <Col>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Nationality</Form.Label>
                <Form.Select size="lg">
                  <option> select Nationality</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>State</Form.Label>

                <Form.Select size="lg">
                  <option> select state</option>
                </Form.Select>
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Blood Group</Form.Label>
                <Form.Select size="lg">
                  <option> select Nationality</option>
                </Form.Select>
              </Form.Group>
            </Form>
          </Col>
        </Row>
        <Row>
          <Col>
            <h5 style={{ color: "#00AEEB" }}>Emergency Information</h5>
          </Col>
          <Col className="d-flex justify-content-end">
            <div
              className="d-flex align-items-center"
              style={{
                border: "1px solid #00AEEB",
                background: "#FFFFFF",
                borderRadius: "5px",
              }}
            >
              <span style={{ paddingRight: "0.5rem", color: "#00C1C5" }}>
                <i class="bi bi-plus"></i>
              </span>
              <span
                style={{
                  paddingRight: "0.5rem",
                  color: "#00C1C5",
                  fontSize: "14px",
                }}
              >
                Add More
              </span>
            </div>
          </Col>
        </Row>
        <Row>
          <Col>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" />
              </Form.Group>
              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="password" placeholder="Password" />
              </Form.Group>
            </Form>
          </Col>
          <Col>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" />
              </Form.Group>

              <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Password</Form.Label>
                <Form.Control type="date" placeholder="data" />
              </Form.Group>
            </Form>
          </Col>
          <Col>
            <Form>
              <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Email address</Form.Label>
                <Form.Control type="email" placeholder="Enter email" />
              </Form.Group>
            </Form>
          </Col>
        </Row>
        <Row>
          <Col>
            <Button
              style={{
                background:
                  "linear-gradient(176.58deg, #40BE54 -13.04%, #00AEEB 123.56%)",
                borderRadius: "8px",
                border: "none",
              }}
            >
              Save&Next
            </Button>
            <span style={{ paddingLeft: "1rem" }}>Cancel</span>
          </Col>
        </Row>
      </Modal>
    </div>
  );
}
