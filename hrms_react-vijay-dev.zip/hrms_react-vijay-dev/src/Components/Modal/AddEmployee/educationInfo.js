import React from 'react'

export default function educationInfo() {
  return (
    <div>educationInfo</div>
  )
}
