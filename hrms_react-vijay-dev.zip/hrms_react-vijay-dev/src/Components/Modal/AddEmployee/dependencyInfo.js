import React from 'react'

export default function dependencyInfo() {
  return (
    <div>dependencyInfo</div>
  )
}
