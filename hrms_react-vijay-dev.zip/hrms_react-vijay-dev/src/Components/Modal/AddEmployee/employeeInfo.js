import React from 'react'

export default function employeeInfo() {
  return (
    <div>employeeInfo</div>
  )
}
