import React from "react";

import Modal from "react-bootstrap/Modal";
import { useNavigate } from "react-router-dom";
import tick from "../assets/img/tick.svg";
import union from "../assets/img/union.svg";
import "../Modal/Modal.css";

function PasswordresetModal({ show,setShow }) {
 
  const navigate = useNavigate();
  return (
    <div className="p-4">
      <Modal
        show={show}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Body className=" d-flex align-items-center justify-content-center flex-column ">
          <div className="d-flex align-items-end justify-content-end w-100 ">
            <div className="close-btn" onClick={()=>setShow(false)} >
              <img
          
                src={union}
                alt=""
                style={{ width: "14.73px", height: "14.73px" }}
              />
            </div>
          </div>
          <div
            style={{ flexDirection: "column" }}
            className=" d-flex align-items-center justify-content-center"
          >
            <img className="pt-2" src={tick} alt="" />
            <div className=" d-flex align-items-center justify-content-center flex-column my-3 pt-2">
              <h3 className="pt-2"> Password Reset Successful</h3>
              <p className="pt-2">
                Your password have been Successfully Reset, click below to log
                in magically
              </p>
            </div>

            <div
              style={{ width: "88%" }}
              className=" d-flex align-items-center justify-content-center flex-column pt-2"
            >
              <button class="form-group btn login-submit w-100 pt-2">
                Continue
              </button>
              {/* <a
              class="form-group btn forgot-submit w-100 pt-2"
              onClick={() => navigate("/")}
            >
              Back to Login
            </a>
            <p className="pt-2">dont receive the email? Click to resend </p> */}
            </div>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default PasswordresetModal;
