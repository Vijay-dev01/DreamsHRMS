import React from "react";
import Modal from "react-bootstrap/Modal";
import "../Modal/Modal.css";
import union from "../assets/img/union.svg";
import terms from "../assets/img/terms.svg";
import "../../Components/Modal/termsconModal.css";
import { Col, Row } from "react-bootstrap";
function TermconModal({ showterm,setShowterm }) {
 
  return (
    <div>
      <Modal size="lg" show={showterm}>
        <Modal.Body>
          <Row className=" d-flex align-items-center justify-content-space-between">
            <Col  style={{justifyContent:"space-around"}} className="d-flex ">
              <img src={terms} alt="terms" className="" />
              <h2>Terms and Conditions</h2>
            </Col>
            <Col className="d-flex justify-content-end">
              <div onClick={()=>setShowterm(false)} className="close-btn mx-5">
                <img
                  src={union}
                  alt=""
                  style={{ width: "14.73px", height: "14.73px" }}
                />
              </div>
            </Col>
          </Row>
          <div className="pt-4">
            <h5>Terms of Services</h5>
            <p className="TermconModal-p">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur.
            </p>
            <p className="TermconModal-p">
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem
              accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
              quae ab illo inventore veritatis et quasi architecto beatae vitae
              dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
              aspernatur aut odit aut fugit, sed quia consequuntur magni dolores
              eos qui ratione voluptatem sequi nesciunt.
            </p>
            <p className="TermconModal-p">
              ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
              nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat. Duis aute irure dolor in reprehenderit in voluptate
              velit esse cillum dolore eu fugiat nulla pariatur.
            </p>
          </div>
          <div className="pt-2">
            <h5>Authorized Users</h5>
            <p className="TermconModal-p">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur.
            </p>
          </div>
          <div className="my-4">
            <button className="term-button">I accept</button>
            <button onClick={()=>setShowterm(false)} className="decline-button mx-4">I decline</button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default TermconModal;
