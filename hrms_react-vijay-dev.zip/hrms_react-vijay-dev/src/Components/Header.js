import React from 'react'
import { Link } from 'react-router-dom'
import { allpolicies, allreports, avatar1, avatar2, avatar3, avatar4, avatar5, avatar6, empmenuicon, logo, shiftschedule, sicon, timeofficon, timesheet } from './imagepath'

const Header = () => {
  return (
   <div>
  <header className="header header-fixed header-one">
    <nav className="navbar navbar-expand-lg header-nav">
      <div className="navbar-header">
        <Link id="mobile_btn" to="#">
          <span className="bar-icon">
            <span />
            <span />
            <span />
          </span>
        </Link>
        <Link to="#" className="navbar-brand logo">
          <img src={logo} className="img-fluid" alt="Logo" />
        </Link>
      </div>
      <div className="main-menu-wrapper">
        <ul className="main-nav">
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-gauge" /></span> Dashboard
            </Link>
          </li>
          <li className="active">
            <Link to="employees.html">
              <span className="me-2"><i className="fa-solid fa-users" /></span> Employees
            </Link>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-plane-departure" /></span> Time off
            </Link>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-file" /></span> Policies
            </Link>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-chart-pie" /></span> Reports
            </Link>
          </li>
        </ul>
        <ul className="nav header-navbar-rht darkLight-searchBox">
          <li className="nav-item search-item">
            <div className="top-nav-search">
              <form action="#">
                <input type="text" className="form-control" placeholder="Search" />
                <button className="btn" type="submit"><i className="feather-search" /></button>
                <span><img src={sicon} alt /></span>
              </form>
            </div>
          </li>
          <li className="nav-item quick-link-item dropdown">
            <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
              <span>Quick Links <i className="feather-zap" /></span>
            </Link>
            <ul className="dropdown-menu clearfix">
              <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
              <li className="w-100 bottom-list-menu">
                <ul className="sub-menu clearfix">
                  <li><Link to="#">Documentation</Link></li>
                  <li><Link to="#">Changelog v1.4.4</Link></li>
                  <li><Link to="#">Components</Link></li>
                  <li><Link to="#">Support</Link></li>
                  <li><Link to="#">Terms &amp; Conditions</Link></li>
                  <li><Link to="#">About</Link></li>
                </ul>
              </li>
            </ul>
          </li>
          <li className="nav-item nav-icons">
            <div className="dark-light">
              <i className="feather-moon moon" />
              <i className="feather-sun sun" />
            </div>
          </li>
          <li className="nav-item dropdown has-arrow notification-dropdown">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <i className="feather-bell" />
              <span className="badge">3</span>
            </Link>
            <div className="dropdown-menu dropdown-menu-end notifications">
              <div className="topnav-dropdown-header">
                <span className="notification-title">Notifications</span>
                <Link to="#" className="clear-noti"> Clear All</Link>
              </div>
              <div className="noti-content">
                <ul className="notification-list">
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar1} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">John Doe</span>added new task 
                            <span className="noti-title">Patient appointment booking</span></p>
                          <p className="noti-time"><span className="notification-time">4 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar2} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Tarah Shropshire</span> changed the task name 
                            <span className="noti-title">Appointment booking with payment gateway</span></p>
                          <p className="noti-time"><span className="notification-time">6 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar6} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Misty Tison</span> added 
                            <span className="noti-title">Domenic Houston</span> and 
                            <span className="noti-title">Claire Mapes</span> to project 
                            <span className="noti-title">Doctor available module</span></p>
                          <p className="noti-time"><span className="notification-time">8 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar5} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Rolland
                              Webber</span> completed task <span className="noti-title">Patient and Doctor video conferencing</span></p>
                          <p className="noti-time"><span className="notification-time">12 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar3} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Bernardo Galaviz</span> added new task 
                            <span className="noti-title">Private chat module</span></p>
                          <p className="noti-time"><span className="notification-time">2 days ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="topnav-dropdown-footer">
                <Link to="#">View all Notifications</Link>
              </div>
            </div>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="feather-settings" />
            </Link>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="far fa-circle-question" />
            </Link>
          </li>
          <li className="nav-item dropdown has-arrow main-drop">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <span className="user-img">
                <img src={avatar1} className="img-rounded" alt />
              </span>
            </Link>
            <div className="dropdown-menu">
              <Link className="dropdown-item" to="#">
                <i className="feather-user-plus" /> My Profile
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-settings" /> Settings
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-log-out" /> Logout
              </Link>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </header>
</div>

  )
}

export default Header
