
// export const BASEURL = "https://tenant1.ms1.dreamshrms.com/api/login"



// "https://api.dreamshrms.com/api/"
/* "https://newhrms.dreamguystech.com/" */