import React, { useState } from 'react'
import Header from '../Header'
import { checksqure, copy, noteicon, pencil, pencildarticon, uploadicon } from '../imagepath'
import Footer from '../Footer'

const Offboardingsetting = () => {
  const [showButton, setShowButton] = useState(false);

  const handleClick = () => {
    setShowButton(true);
  };

  return (
    <div>
  {/* Main Wrapper */}
  <div className="main-wrapper">
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper onboarding onboarding-setting">
      {/* Page Content */}
      <div className="content container">
        <div className="d-lg-flex justify-content-between align-items-center search-filter">
          <h2>Offboarding Setting</h2>
          <div className="mixed-buttons">
            <button type="text" className="btn btn-transparent"><i className="fa fa-search" aria-hidden="true" /></button>
            <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-template"><i className="fa fa-plus" aria-hidden="true" />Add Templates</button>
          </div>
        </div>
        <h3>Offboarding Templates</h3>
        {/* Onboarding Settings Tab */}
        <div className="accordion accordion-flush" id="onboarding-setting">
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingOne">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne" onClick={handleClick}>
                <div className="d-block head">
                  <div className="text">
                    <h4>Offboarding Technical Checklist</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div> 
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                {showButton &&<button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>}
                </div>
              </div>
            </div>
            <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingTwo">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                <div className="d-block head">
                  <div className="text">
                    <h4>Offboarding Interpersonal Checklist</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingThree">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                <div className="d-block head">
                  <div className="text">
                    <h4>Offboarding 3</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseThree" className="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingFour">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                <div className="d-block head">
                  <div className="text">
                    <h4>Offboarding 4</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseFour" className="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingFive">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
                <div className="d-block head">
                  <div className="text">
                    <h4>Offboarding 5</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseFive" className="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        {/* /Onboarding Settings Tab */}
        
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Template Modal */}
  <div className="modal fade onboarding-modal settings" id="add-template" tabIndex={-1} aria-labelledby="add-template" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Templates</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Template Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Template Name" />
            </div>
            <div className="form-group note field-icon">
              <label htmlFor="description">Description</label>
              <textarea className="form-control" id="description" placeholder="Note" rows={3} defaultValue={""} />
              <img className="icon" src={noteicon} alt="User img"/>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Add Template Modal */}
  {/* Add Task */}
  <div className="modal fade onboarding-modal settings" id="add-task" tabIndex={-1} aria-labelledby="add-task" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Task</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Task Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Primary Address" />
            </div>
            <div className="form-group">
              <label>Task Type <span>*</span></label>
              <select className="select">
                <option>Select Task Type</option>
                <option>Option1</option>
                <option>Option2</option>
              </select>
            </div>
            <div className="form-group">
              <label>Task Role <span>*</span></label>
              <select className="select">
                <option>Select Task Role</option>
                <option>Option1</option>
                <option>Option2</option>
              </select>
            </div>
            <div className="row">
              <label className="bold">Due Date <span>*</span></label>
              <div className="col">
                <div className="form-group">
                  <label>Day </label>
                  <select className="select">
                    <option>Select Assign</option>
                    <option>Option1</option>
                    <option>Option2</option>
                  </select>
                </div>
              </div>
              <div className="col">
                <div className="form-group">
                  <label>Join Date <span>*</span></label>
                  <select className="select">
                    <option>Before</option>
                    <option>Option1</option>
                    <option>Option2</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="form-group mb-0">
              <label className="add-course-label">Description</label>
              <div id="editor" />
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /End Modal */}
  {/* Kit Info Modal */}
  <div className="modal fade onboarding-modal settings" id="kit-info" tabIndex={-1} aria-labelledby="kit-info" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Company Welcome Kit Details</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <ul>
            <li className="d-flex justify-content-between align-items-top"><span>Task Type:</span><p><i className="fa fa-check-square" aria-hidden="true" /> Checkbox</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Document Size:</span><p>2MB</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Task Name:</span><p>Company Welcome Kit</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Assignee:</span><p>Hr-in-charge</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Due Date:</span><p>2 day before join date</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Description:</span><p>Lorem ipsum dolor consectetur adipiscing ut et eiusmod dolore magna aliqua. </p></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  {/* /Kit Info Modal */}
</div>


  )
}

export default Offboardingsetting
