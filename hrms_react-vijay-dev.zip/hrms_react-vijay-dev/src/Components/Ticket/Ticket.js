import React, { useState } from 'react'
import Header from '../Header'
import Footer from '../Footer'
import { Link } from 'react-router-dom'
import { avatar1, avatar10, avatar2, avatar3, avatar4, avatar5, avatar6, avatar7, avatar8, avatar9, avatard } from '../imagepath'

const Ticket = () => {
    const [show, setShow] = useState(false);

    const toggleShow = () => {
        console.log('click')
        setShow(true)
    }

    const toggleClose = () => {
        console.log('click')
        setShow(false)
    }
    console.log(show);

  return (
    <div>
  <div className="main-wrapper">
    {/* Header */}
   <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper assets">
      {/* Page Content */}
      <div className="content container">
        <div className="page-header">
          <div className="row align-items-center">
            <div className="col-lg-4 col-md-6">
              <h3 className="page-title">Raised Tickets</h3>
            </div>
            <div className="col-lg-8 col-md-6 page-header-btns page-header-position-btns">
              <Link to="#" className="btn ">
                <span><i className="fa-solid fa-rotate-right" /></span>
              </Link>
              <Link to="#" className="btn ">
                <span><i className="fa-solid fa-magnifying-glass" /></span>
              </Link>
              <Link to="#" className="btn ">
                <span><i className="fa-solid fa-download" /></span>
              </Link>
              <Link to="#" className="btn popup-toggle"  onClick={toggleShow}>
                <span><i className="fa-solid fa-filter"/></span>
              </Link>
              <Link to="#" className="btn ">
                <span><i className="fa-solid fa-print" /></span>
              </Link>
              <Link to="#" className="btn upload-document-btn" data-bs-toggle="modal" data-bs-target="#addfolder">
                <span className="me-2"><i className="fa-solid fa-ticket" /></span>My Tickets
              </Link>
              <Link to="#" className="btn new-employee-btn" data-bs-toggle="modal" data-bs-target="#upload-doc">
                <span><i className="fa-solid fa-ticket" /></span>Raised Tickets
              </Link>
            </div>
          </div>
        </div>
        {/* Table Start */}
        <div className="col-sm-12">
          <div className="card-table">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-center table-hover datatable checklist">
                  <thead className="thead-light">
                    <tr>
                      <th>#</th>
                      <th>Ticket Number</th>
                      <th>Subject</th>
                      <th>Assignee</th>
                      <th>Date</th>
                      <th>Priority</th>
                      <th>Status</th>
                      <th>Approved By</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>0289</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Laptop change - Reg</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar1} alt="User " /></Link>
                          <Link to="#">John Smith <span>HR</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><span className="badge bg-danger-light">Urgent</span></td>
                      <td><span className="badge bg-danger-light">Open</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                          <Link to="#">Jonathon <span>DGT-365</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>2</p></td>
                      <td><p>0290</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Need Access</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                          <Link to="#">John Walker <span>Finance</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><span className="badge bg-danger-light">Very high</span></td>
                      <td><span className="badge bg-success-light">Resolved</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar3} alt="User " /></Link>
                          <Link to="#">Jonathon <span>DGT-366</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>3</p></td>
                      <td><p>0291</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Git Access</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar3} alt="User" /></Link>
                          <Link to="#">Bernardo <span>IT</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><span className="badge bg-warning-light">High</span></td>
                      <td><span className="badge bg-warning-light">Pending</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar4} alt="User " /></Link>
                          <Link to="#">Jonathon <span>DGT-367</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>4</p></td>
                      <td><p>0292</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Laptop Issue</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar5} alt="User " /></Link>
                          <Link to="#">Mike Litorus <span>Mike Litorus</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><span className="badge bg-warning-light">Medium</span></td>
                      <td><span className="badge bg-gray-light">Closed</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar6} alt="User" /></Link>
                          <Link to="#">Jonathon <span>DGT-368</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>5</p></td>
                      <td><p>0293</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Head Phone Change</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar4} alt="User" /></Link>
                          <Link to="#">John Smith <span>HR</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><span className="badge bg-info-light">Low</span></td>
                      <td><span className="badge bg-danger-light">Open</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar5} alt="User " /></Link>
                          <Link to="#">Matthew <span>DGT-369</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>6</p></td>
                      <td><p>0294</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Need Mouse</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar6} alt="User " /></Link>
                          <Link to="#">John Walker <span>Finance</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>											
                      <td><span className="badge bg-danger-light">Urgent</span></td>
                      <td><span className="badge bg-info-light">InProgress</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar7} alt="User " /></Link>
                          <Link to="#">Matthew <span>DGT-370</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>7</p></td>
                      <td><p>0295</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Need Access</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar7} alt="User " /></Link>
                          <Link to="#">Bernardo  <span>IT</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>11 Apr 2023</p>
                        <span>Thursday</span>
                      </td>											
                      <td><span className="badge bg-warning-light">High</span></td>
                      <td><span className="badge bg-success-light">Resolved</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar8} alt="User " /></Link>
                          <Link to="#">Matthew <span>DGT-371</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>8</p></td>
                      <td><p>0296</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Git Access</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar8} alt="User " /></Link>
                          <Link to="#">Mike Litorus  <span>Admin</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>11 Apr 2023</p>
                        <span>Thursday</span>
                      </td>											
                      <td><span className="badge bg-info-light">Low</span></td>
                      <td><span className="badge bg-warning-light">Pending</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar9} alt="User" /></Link>
                          <Link to="#">Diana <span>DGT-371</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>9</p></td>
                      <td><p>0297</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Laptop Issue</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar9} alt="User" /></Link>
                          <Link to="#">John Smith  <span>HR</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>11 Apr 2023</p>
                        <span>Thursday</span>
                      </td>											
                      <td><span className="badge bg-warning-light">High</span></td>
                      <td><span className="badge bg-danger-light">Open</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar10} alt="User " /></Link>
                          <Link to="#">Wendy <span>DGT-372</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                    <tr>
                      <td><p>10</p></td>
                      <td><p>0298</p></td>
                      <td>
                        <div className="assets">
                          <Link to="#" className="text-info">Laptop change</Link>
                        </div>
                      </td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar3} alt="User" /></Link>
                          <Link to="#">John Walker  <span>Finance</span></Link>
                        </h2>
                      </td>
                      <td>
                        <p>10 Apr 2023</p>
                        <span>Monday</span>
                      </td>											
                      <td><span className="badge bg-info-light">Low</span></td>
                      <td><span className="badge bg-success-light">Resolved</span></td>
                      <td>
                        <h2 className="table-avatar">
                          <Link to="#" className="avatar avatar-sm me-2"><img className="avatar-img rounded-circle" src={avatar10} alt="User" /></Link>
                          <Link to="#">Tammy <span>DGT-373</span></Link>
                        </h2>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action">
                          <Link to="#" className="btn-action-icon" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                              <li>
                              </li></ul>
                          </div>
                        </div></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        {/* /Table End */}
        {/* Footer */}
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Raised Tickets */}
  <div className={show ? "toggle-sidebar raised-tickets open-sidebar" : "toggle-sidebar raised-tickets"} style={{ display: show ? 'block' : 'none'}}>
    <div className="d-flex align-items-center justify-content-between head">
      <h5>Assets Deatils</h5>
      <i className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes" aria-hidden="true" onClick={toggleClose}/>
    </div>
    <table className="w-100">
      <tbody><tr>
          <td><span>Ticket Number</span></td>
          <td className="ticket-info">0298</td>
        </tr>
        <tr>
          <td><span>Name</span></td>
          <td className="ticket-info">Jonathon</td>
        </tr>
        <tr>
          <td><span>Email</span></td>
          <td className="ticket-info">jonathon@example.com</td>
        </tr>
        <tr>
          <td><span>Created On</span></td>
          <td className="ticket-info">13 Apr 2023</td>
        </tr>
        <tr>
          <td><span>Subject</span></td>
          <td className="ticket-info">Laptop Change</td>
        </tr>
        <tr>
          <td><span>Purchase Date</span></td>
          <td className="ticket-info">10 April 2023</td>
        </tr>
        <tr>
          <td><span>Warranty Expiration Date</span></td>
          <td className="ticket-info">10 April 2025</td>
        </tr>
        <tr>
          <td><span>Asset Status</span></td>
          <td className="ticket-info">Deployed</td>
        </tr>
        <tr>
          <td><span>Supplier</span></td>
          <td className="ticket-info">Amazon</td>
        </tr>
        <tr>
          <td><span>Purchase Amount</span></td>
          <td className="ticket-info">$320.00</td>
        </tr>
      </tbody></table>
    <h6>Assignee Details</h6>
    <table className="w-100">
      <tbody><tr>
          <td><span>Assigned To</span></td>
          <td className="ticket-info">John Smith</td>
        </tr>
        <tr>
          <td><span>Priority</span></td>
          <td className="ticket-info"><span className="badge bg-danger-light">Very high</span></td>
        </tr>
        <tr>
          <td><span>Status</span></td>
          <td className="ticket-info"><span className="badge bg-warning-light">Pending</span></td>
        </tr>
        <tr>
          <td><span>Stage</span></td>
          <td className="ticket-info">Assigned</td>
        </tr>
        <tr>
          <td><span>Responded By</span></td>
          <td className="ticket-info">John Smith</td>
        </tr>
      </tbody></table>
    <h6>Activity</h6>
    <ul className="activity">
      <li>
        <span className="d-block">Yesterday</span>
        <div className="ticket-img">
          <div className="group-avatar">
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                <img src={avatard} alt="" />
              </Link>
            </span>	
          </div>												
          <p>Lorem ipsum dolor sit consectetur adipiscing elit sed do</p>
        </div>
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="ticket-img">
          <div className="group-avatar">
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                <img src={avatard} alt="" />
              </Link>
            </span>	
          </div>												
          <p>Lorem ipsum dolor sit consectetur adipiscing elit sed do</p>
        </div>
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="ticket-img">
          <div className="group-avatar">
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                <img src={avatard} alt="" />
              </Link>
            </span>	
          </div>												
          <p>Lorem ipsum dolor sit consectetur adipiscing elit sed do</p>
        </div>
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="ticket-img">
          <div className="group-avatar">
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                <img src={avatard} alt="" />
              </Link>
            </span>	
          </div>												
          <p>Lorem ipsum dolor sit consectetur adipiscing elit sed do</p>
        </div>
      </li>
    </ul>
    <div className="discuss-footer">
      <input type="text" className="form-control" placeholder="Type a message" />			
      <button type="button" className="btn msg-btn"><i className="feather-send" /></button>
    </div>
  </div>
</div>

  )
}

export default Ticket
