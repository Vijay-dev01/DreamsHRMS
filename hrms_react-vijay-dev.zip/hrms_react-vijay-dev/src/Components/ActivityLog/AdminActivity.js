import React from 'react'
import { Link } from 'react-router-dom'
import { activity1, activity10, activity11, activity2, activity3, activity4, activity5, activity6, activity7, activity8, activity9, activityprofile, allpolicies, allreports, avatar1, avatar2, avatar3, avatar5, avatar6, empmenuicon, logo, shiftschedule, sicon, timeofficon, timesheet } from '../imagepath'

const AdminActivity = () => {
  return (
   <div className="main-wrapper">
  {/* Header */}
  <header className="header header-fixed header-one">
    <nav className="navbar navbar-expand-lg header-nav">
      <div className="navbar-header">
        <Link id="mobile_btn" to="#">
          <span className="bar-icon">
            <span />
            <span />
            <span />
          </span>
        </Link>
        <Link to="#" className="navbar-brand logo">
          <img src={logo} className="img-fluid" alt="Logo" />
        </Link>
      </div>
      <div className="main-menu-wrapper">
        <ul className="main-nav">
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-gauge" /></span> Dashboard
            </Link>
          </li>
          <li className="nav-item quick-link-item dropdown">
            <Link className="dropdown-toggle" data-bs-toggle="dropdown" to="employees.html" role="button" aria-expanded="false">
              <span className="me-2"><i className="fa-solid fa-users" /></span>Employees
            </Link>
            <ul className="dropdown-menu clearfix employees-menu">                                
              <li><Link className="dropdown-item" to="leave.html"><span className="me-2 icon-img"><i className="fa-solid fa-plane-departure" /></span>Leave Report</Link></li>
              <li><Link className="dropdown-item" to="employees.html"><span className="me-2 icon-img"><i className="fa-solid fa-users" /></span>Employees</Link></li>                                
              <li><Link className="dropdown-item" to="shift-schedule.html"><span className="me-2 icon-img"><i className="fa-solid fa-calendar" /></span>Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="admin-employee-attendance.html"><span className="me-2 icon-img"><i className="fa-solid fa-clipboard-user" /></span>Attendance</Link></li>                                
              <li><Link className="dropdown-item" to="department.html"><span className="me-2 icon-img"><i className="fa-solid fa-building" /></span>Department</Link></li>
              <li><Link className="dropdown-item" to="employee-teams.html"><span className="me-2 icon-img"><i className="fa-solid fa-users" /></span>Teams</Link></li>
              <li><Link className="dropdown-item" to="timesheet.html"><span className="me-2 icon-img"><i className="fa-solid fa-file" /></span>Timesheet</Link></li>                                
              <li><Link className="dropdown-item" to="orginization-chart.html"><span className="me-2 icon-img"><i className="fa-solid fa-chart-bar" /></span>Organization Chart</Link></li>
              <li><Link className="dropdown-item" to="onboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-arrow-right-from-bracket" /></span>Onboarding</Link></li>
              <li><Link className="dropdown-item" to="offboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-arrow-right-from-bracket" /></span>Offboarding Report</Link></li>
            </ul>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-plane-departure" /></span> Time off
            </Link>
          </li>
          <li>
            <Link to="#">
              <span className="me-2"><i className="fa-solid fa-file" /></span> Policies
            </Link>
          </li>
          <li className="active nav-item quick-link-item dropdown">
            <Link className="dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
              <span className="me-2"><i className="fa-solid fa-chart-pie" /></span> Reports
            </Link>
            <ul className="dropdown-menu clearfix">                                
              <li><Link className="dropdown-item" to="leave.html"><span className="me-2 icon-img"><i className="fa-solid fa-plane-departure" /></span>Leave Report</Link></li>                                
              <li><Link className="dropdown-item" to="attendance-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-clipboard-user" /></span>Attendance Report</Link></li>                                
              <li><Link className="dropdown-item" to="onboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-clipboard-user" /></span>Onboarding Report</Link></li>
              <li><Link className="dropdown-item" to="employee-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-users" /></span>Employee Report</Link></li>                                
              <li><Link className="dropdown-item" to="asset-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-laptop" /></span>Asset Report</Link></li>
              <li><Link className="dropdown-item" to="offboarding-report.html"><span className="me-2 icon-img"><i className="fa-solid fa-file" /></span>Offboarding Report</Link></li>
            </ul>
          </li>
        </ul>
        <ul className="nav header-navbar-rht darkLight-searchBox">
          <li className="nav-item search-item">
            <div className="top-nav-search">
              <form action="#">
                <input type="text" className="form-control" placeholder="Search" />
                <button className="btn" type="submit"><i className="feather-search" /></button>
                <span><img src={sicon} alt /></span>
              </form>
            </div>
          </li>
          <li className="nav-item quick-link-item dropdown">
            <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
              <span>Quick Links <i className="feather-zap" /></span>
            </Link>
            <ul className="dropdown-menu clearfix">
              <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
              <li className="w-100 bottom-list-menu">
                <ul className="sub-menu clearfix">
                  <li><Link to="#">Documentation</Link></li>
                  <li><Link to="#">Changelog v1.4.4</Link></li>
                  <li><Link to="#">Components</Link></li>
                  <li><Link to="#">Support</Link></li>
                  <li><Link to="#">Terms &amp; Conditions</Link></li>
                  <li><Link to="#">About</Link></li>
                </ul>
              </li>
            </ul>
          </li>
          <li className="nav-item nav-icons">
            <div className="dark-light">
              <i className="feather-moon moon" />
              <i className="feather-sun sun" />
            </div>
          </li>
          <li className="nav-item dropdown has-arrow notification-dropdown">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <i className="feather-bell" />
              <span className="badge">3</span>
            </Link>
            <div className="dropdown-menu dropdown-menu-end notifications">
              <div className="topnav-dropdown-header">
                <span className="notification-title">Notifications</span>
                <Link to="#" className="clear-noti"> Clear All</Link>
              </div>
              <div className="noti-content">
                <ul className="notification-list">
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar1} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">John Doe</span>added new task 
                            <span className="noti-title">Patient appointment booking</span></p>
                          <p className="noti-time"><span className="notification-time">4 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar2} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Tarah Shropshire</span> changed the task name 
                            <span className="noti-title">Appointment booking with payment gateway</span></p>
                          <p className="noti-time"><span className="notification-time">6 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar6} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Misty Tison</span> added 
                            <span className="noti-title">Domenic Houston</span> and 
                            <span className="noti-title">Claire Mapes</span> to project 
                            <span className="noti-title">Doctor available module</span></p>
                          <p className="noti-time"><span className="notification-time">8 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar5} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Rolland
                              Webber</span> completed task <span className="noti-title">Patient and Doctor video conferencing</span></p>
                          <p className="noti-time"><span className="notification-time">12 mins ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar3} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Bernardo Galaviz</span> added new task 
                            <span className="noti-title">Private chat module</span></p>
                          <p className="noti-time"><span className="notification-time">2 days ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="topnav-dropdown-footer">
                <Link to="#">View all Notifications</Link>
              </div>
            </div>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="feather-settings" />
            </Link>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="far fa-circle-question" />
            </Link>
          </li>
          <li className="nav-item dropdown has-arrow main-drop">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
              <span className="user-img">
                <img src={avatar1} className="img-rounded" alt />
              </span>
            </Link>
            <div className="dropdown-menu">
              <Link className="dropdown-item" to="#">
                <i className="feather-user-plus" /> My Profile
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-settings" /> Settings
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-log-out" /> Logout
              </Link>
            </div>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper admin-activity">
    {/* Page Content */}
    <div className="content container">
      <div className="d-lg-flex justify-content-between align-items-center">
        <h2>Activity Log</h2>
        <div className="d-lg-flex align-items-center justify-content-end date-time">
          <div className="btn btn-group btn-sm">
            <select className="form-select w-auto d-inline select today">
              <option selected>Today</option>
              <option value={1}>Week</option>
              <option value={2}>Month</option>
              <option value={3}>Year</option>
            </select>
            <select className="form-select w-auto d-inline select week">
              <option selected>week</option>
              <option value={1}>Today</option>
              <option value={2}>Month</option>
              <option value={3}>Year</option>
            </select>
            <select className="form-select w-auto d-inline select month">
              <option selected>Month</option>
              <option value={1}>Today</option>
              <option value={2}>Week</option>
              <option value={3}>Year</option>
            </select>
          </div>
          <div className="col-auto d-inline">
            <div className="date-picker btn btn-group btn-sm">
              <div className="ico left">
                <i className="fas fa-chevron-left" />
              </div>
              <div className="cal-ico center">
                <i className="feather-calendar mr-1" />
                <span>3/28/2023 - 4/3/2023</span>
              </div>
              <div className="ico right">
                <i className="fas fa-chevron-right" />
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Activity Wrapper*/}
      <div className="activity-wrapper">
        <div className="date">
          <span className="record-date">07 April 2023</span>
          <ul className="activity-logs">
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity1} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity2} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-lg-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity3} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                    <div className="d-flex justify-content-start align-items-center btn-row">
                      <button type="button" className="btn btn-transparent">Decline</button>
                      <button type="button" className="btn btn-primary">Approve</button>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="date">
          <span className="record-date">07 April 2023</span>
          <ul className="activity-logs">
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity4} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity3} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                    <div className="d-flex justify-content-start align-items-center status-row">
                      <span className="success status">Cleaning</span>
                      <span className="pending status">Car Repair</span>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity5} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="date">
          <span className="record-date">07 April 2023</span>
          <ul className="activity-logs">
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity6} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity7} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity8} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="date">
          <span className="record-date">07 April 2023</span>
          <ul className="activity-logs">
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity6} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity7} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity8} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="date">
          <span className="record-date">07 April 2023</span>
          <ul className="activity-logs">
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity6} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity7} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity8} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div className="date">
          <span className="record-date">07 April 2023</span>
          <ul className="activity-logs">
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity9} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity10} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
            <li className="d-flex justify-content-start align-items-center">
              <div className="activity-icon">
                <i className="d-flex align-items-center justify-content-center"><img src={activity11} alt /></i>
              </div>
              <span className="horizontal-border" />
              <div className="white-bg flex-grow-1">
                <div className="row">
                  <div className="col-12 col-sm-6 col-md-8 col-lg-8 no-padding-right left-text">
                    <div className="d-sm-flex justify-content-start align-items-center">
                      <Link to="#"><img src={activityprofile} className="img-rounded" alt /></Link>
                      <p>Amanda <span className="dull-text">Changed the delivery date of</span> Design project <span className="dull-text">to Sep 25</span></p>
                    </div>
                  </div>
                  <div className="col-12 col-sm-6 col-md-4 col-lg-4 right-text d-md-flex align-items-center justify-content-end">
                    <span className="dull-text align-items-center">2 Mins ago <i className="fa-sharp fa-solid fa-circle" /> Design Team</span>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
      {/* /Activity Wrapper*/} 
      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="row">
            <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
              <div className="footer-left">
                <p>© 2023 Dreams HRMS</p>
              </div>
            </div>
            <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
              <div className="footer-right">
                <ul>
                  <li>
                    <Link to="#">Privacy Policy</Link>
                  </li>
                  <li>
                    <Link to="#">Terms &amp; Conditions</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default AdminActivity
