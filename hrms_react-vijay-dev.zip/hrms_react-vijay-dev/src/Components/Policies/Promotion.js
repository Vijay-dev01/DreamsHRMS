import React from 'react'
import Header from '../Header'
import { Link } from 'react-router-dom'
import { avatar2, funnel, sortascending } from '../imagepath'
import Footer from '../Footer'
import Select from 'react-select';
import makeAnimated from 'react-select/animated';
import 'bootstrap/dist/css/bootstrap.min.css';
const animatedComponents = makeAnimated();
const Countries = [
  { label: "HR", value: 355 },
  { label: "UI/UX", value: 54 },
  { label: "Marketing", value: 43 },
  { label: "Development", value: 61 },
];

const Promotion = () => {
  return (
    <div>
    <div className="main-wrapper">
      {/* Header */}
     <Header />
      {/* /Header */}
      {/* Page Wrapper */}
      <div className="page-wrapper policies">
        {/* Page Content */}
        <div className="content container">
          <div className="d-lg-flex justify-content-between align-items-center search-filter">
            <div className="d-lg-flex justify-content-start align-items-center policy-bg">
              <h2>Promotion</h2>
            </div>
            <div className="mixed-buttons">
              <button type="text" className="btn btn-transparent"><img src={funnel} alt="" /></button>
              <button type="text" className="btn btn-transparent"><img src={sortascending} alt="" /></button>
              <button type="text" className="btn btn-transparent"><i className="fa fa-search" aria-hidden="true" /></button>
              <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-promotion"><i className="fa fa-plus" aria-hidden="true" />Add Promotion</button>
            </div>
          </div>
          {/* Table Start */}
          <div className="col-sm-12">
            <div className="card-table">
              <div className="card-body">
                <div className="table-responsive">
                  <table className="table table-center table-hover datatable checklist">
                    <thead className="thead-light">
                      <tr>
                        <th>#&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Promoted Employee&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Department&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Promotion From&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Promotion To&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Promotion Date&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Action&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User" /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User" /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td><p>1</p></td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User " /></Link>
                            <Link to="profile.html">John Smith <br />
                              <span>DGT-365</span></Link>
                          </h2>
                        </td>
                        <td><p>Human Resources</p></td>
                        <td><p>W</p></td>
                        <td><p>A</p></td>
                        <td>
                          <p>30 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="pagination-wrap d-flex justify-content-between">
                    <p>Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
                    <ul className="d-flex">
                      <li className="active"><Link to="#">1</Link></li>
                      <li><Link to="#">2</Link></li>
                      <li><Link to="#">3</Link></li>
                      <li><Link to="#">...</Link></li>
                      <li><Link to="#">10</Link></li>
                      <li><Link to="#">11</Link></li>
                      <li><Link to="#">12</Link></li>
                    </ul>
                    <p>Go to page&nbsp;&nbsp;<i className="fa fa-long-arrow-right" aria-hidden="true" /></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Table End */}
          {/* Footer */}
          <Footer />
          {/* Footer */}
        </div>
        {/* /Page Content */}
      </div>
      {/* /Page Wrapper */}
    </div>
    {/* /Main Wrapper */}
    {/* Add Template Modal */}
    <div className="modal fade onboarding-modal" id="add-promotion" tabIndex={-1} aria-labelledby="add-promotion" aria-hidden="true">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Add Promotion</h5>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
          </div>
          <div className="modal-body">
            <form>
              <div className="form-group">
                <label>Promotion For <span>*</span></label>
                <div id="multi-tags">
                  <div id="promotion-for">
                    {/* <select multiple name="native-select" placeholder="Select Employee" data-search="false" data-silent-initial-value-set="true">
                              </select> */}
                              <Select options={Countries} components={animatedComponents}
              isMulti />
                  </div>
                </div>
              </div>
              <div className="form-group">
                <label>Department <span>*</span></label>
                <select className="container p-2 rounded">
                  <option>Select Department</option>
                  <option>Option1</option>
                  <option>Option2</option>
                </select>
              </div>
              <div className="form-group">
                <label>Promotion From <span>*</span></label>
                <select className="container p-2 rounded">
                  <option>Select Grade</option>
                  <option>Option1</option>
                  <option>Option2</option>
                </select>
              </div>
              <div className="form-group">
                <label>Promotion To <span>*</span></label>
                <select className="container p-2 rounded">
                  <option>Select Grade</option>
                  <option>Option1</option>
                  <option>Option2</option>
                </select>
              </div>
              <div className="form-group">
                <label>Promotion Date <span>*</span></label>
                <select className="container p-2 rounded">
                  <option>Select Date</option>
                  <option>Option1</option>
                  <option>Option2</option>
                </select>
              </div>
              <div className="form-group">
                <label htmlFor="startDate">Start</label>
                <input id="startDate" className="form-control" type="date" />
                <span id="startDateSelected" />
              </div>
              <div className="buttons">
                <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Submit</button>
                <button type="button" className="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  )
}

export default Promotion
