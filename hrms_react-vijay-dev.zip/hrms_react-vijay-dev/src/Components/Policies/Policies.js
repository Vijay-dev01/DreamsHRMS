import React from 'react';
import Header from '../Header'
import { Link } from 'react-router-dom'
import { drag1, funnel, noteicon, sortascending } from '../imagepath'
import Footer from '../Footer'
import Select from 'react-select';
import makeAnimated from 'react-select/animated';
import 'bootstrap/dist/css/bootstrap.min.css';
const animatedComponents = makeAnimated();
const Countries = [
  { label: "HR", value: 355 },
  { label: "UI/UX", value: 54 },
  { label: "Marketing", value: 43 },
  { label: "Development", value: 61 },
];
const Policies = () => {
  return (
  <div>
  <div className="main-wrapper">
    {/* Header */}
  <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper policies">
      {/* Page Content */}
      <div className="content container">
        <div className="d-lg-flex justify-content-between align-items-center search-filter">
          <div className="d-lg-flex justify-content-start align-items-center policy-bg">
            <h2>Policies</h2>
            <Link to="policy-detail.html" className="policy-bg">RK <span>(25)</span></Link>
          </div>
          <div className="mixed-buttons">
            <button type="text" className="btn btn-transparent"><img src={funnel} alt="funnel" /></button>
            <button type="text" className="btn btn-transparent"><img src={sortascending} alt="sort" /></button>
            <button type="text" className="btn btn-transparent"><i className="fa fa-search" aria-hidden="true" /></button>
            <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-policies"><i className="fa fa-plus" aria-hidden="true" />Add Policies</button>
          </div>
        </div>
        {/* Table Start */}
        <div className="col-sm-12">
          <div className="card-table">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-center table-hover datatable checklist">
                  <thead className="thead-light">
                    <tr>
                      <th>#&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      <th>Policy Name&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      <th>Department&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      <th>Description&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      <th>Created On&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      <th>Expiry Date&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      <th>Action&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>2</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>3</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>4</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>5</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>6</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>7</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>8</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>9</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>10</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>11</p></td>
                      <td><p>DGT/Department Chart 2023</p></td>
                      <td><p>All Departments</p></td>
                      <td><p>At vero eos accusamus et odio</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td>
                        <p>30 Sep 2023</p>
                        <span>Saturday</span>
                      </td>
                      <td>
                        <div className="action-icons d-flex justify-content-start align-items-center">
                          <Link to="#" className="text-center">
                            <i className="fa fa-pencil" aria-hidden="true" />
                          </Link>
                          <Link to="#" className="text-center">
                            <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                          </Link>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <div className="pagination-wrap d-flex justify-content-between">
                  <p>Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
                  <ul className="d-flex">
                    <li className="active"><Link to="#">1</Link></li>
                    <li><Link to="#">2</Link></li>
                    <li><Link to="#">3</Link></li>
                    <li><Link to="#">...</Link></li>
                    <li><Link to="#">10</Link></li>
                    <li><Link to="#">11</Link></li>
                    <li><Link to="#">12</Link></li>
                  </ul>
                  <p>Go to page&nbsp;&nbsp;<i className="fa fa-long-arrow-right" aria-hidden="true" /></p>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /Table End */}
        {/* Footer */}
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Template Modal */}
  <div className="modal fade onboarding-modal" id="add-policies" tabIndex={-1} aria-labelledby="add-policies" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Policies</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Policy Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Policy Name" />
            </div>
            <div className="form-group note field-icon">
              <label htmlFor="description">Description</label>
              <textarea className="form-control" id="description" placeholder="Enter Description" rows={3} defaultValue={""} />
              <img className="icon" src={noteicon} alt="noteicon" />
            </div>
            {/* <div class="form-group">
          <label>Department <span>*</span></label>
          <select class="select">
              <option>Select Department</option>
              <option>Option1</option>
              <option>Option2</option>
          </select>
      </div> */}
            <div className="form-group">
              <label>Department <span>*</span></label>
              {/* <select multiple name="native-select" placeholder="Select Department" data-search="false" data-silent-initial-value-set="true" id="policy-department">
                <option value={1}>HR</option>
                <option value={2}>UI/UX </option>
                <option value={3}>Marketing</option>
                <option value={4}>Development</option>
              </select> */}
               <Select options={Countries} components={animatedComponents}
              isMulti />
            </div>
            <div className="form-group">
              <label className="label">Company Image <span>*</span></label>
              <div className="drag-drop text-center">
                <div className="upload">
                  <Link to="#"><img src={drag1} alt='drag' /></Link>
                  <p>Drag &amp; drop your files here or choose file <Link to="#">browse</Link></p>
                  <span>Maximum size: 50MB</span>
                </div>
                <input type="file" multiple />
              </div>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Create</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>


  )
}

export default Policies
