'use strict';

$(document).ready(function() {

	function generateData(baseval, count, yrange) {
		var i = 0;
		var series = [];
		while (i < count) {
			var x = Math.floor(Math.random() * (750 - 1 + 1)) + 1;;
			var y = Math.floor(Math.random() * (yrange.max - yrange.min + 1)) + yrange.min;
			var z = Math.floor(Math.random() * (75 - 15 + 1)) + 15;

			series.push([x, y, z]);
			baseval += 86400000;
			i++;
		}
		return series;
	}

// attendance Chart

if($('#attendance-chart').length > 0 ){
var donutChart = {
    chart: {
        height: 350,
        type: 'donut',
        toolbar: {
          show: false,
        },
        plotOptions: {
          pie: {
            dataLabels: {
              name: {
                show: false
              },
              value: {
                show: false
              }
            }
          }
        }
    },
     colors: ['#00AEEB', '#FFCD1C', '#E5E7EB'],
    series: [100, 40, 60],
    responsive: [{
        breakpoint: 480,
        options: {
            chart: {
                width: 200
            },
            legend: {
                position: 'bottom'
            }
        }
    }]
}

var donut = new ApexCharts(
    document.querySelector("#attendance-chart"),
    donutChart
);

donut.render();
}

if($('#half-radius-chart').length > 0 ){
    var options = {
        series: [75],
        chart: {
        type: 'radialBar',
        offsetY: -20,
        sparkline: {
          enabled: true
        }
      },
      plotOptions: {
        radialBar: {
          startAngle: -90,
          endAngle: 90,
          track: {
            background: "#e7e7e7",
            strokeWidth: '97%',
            margin: 5, // margin is in pixels
            dropShadow: {
              enabled: true,
              top: 2,
              left: 0,
              color: '#999',
              opacity: 1,
              blur: 2
            }
          },
          dataLabels: {
            name: {
              show: false
            },
            value: {
              offsetY: -2,
              fontSize: '22px'
            }
          }
        }
      },
      grid: {
        padding: {
          top: -10
        }
      },
      fill: {
        type: 'gradient',
        gradient: {
          shade: 'light',
          shadeIntensity: 0.4,
          inverseColors: false,
          opacityFrom: 1,
          opacityTo: 1,
          stops: [0, 50, 53, 91]
        },
      },
      labels: ['Average Results'],
      };

      var chart = new ApexCharts(document.querySelector("#half-radius-chart"), options);
      chart.render();
  }

  // Leave Chart Admin Dashboard
  if($('#dashboard-admin-Leave').length > 0 ){
  var sColStacked = {
      chart: {
          height: 275,
          type: 'bar',
          stacked: true,
          toolbar: {
            show: false,
          }
      },
      colors: ['#40C63C', '#FF4747', '#00AEEB'],
      responsive: [{
          breakpoint: 480,
          options: {
              legend: {
                  position: 'bottom',
                  offsetX: -10,
                  offsetY: 0
              }
          }
      }],
      plotOptions: {
          bar: {
              horizontal: false,
          },
      },
      series: [{
          name: 'Vacation',
          data: [44, 55, 41, 67, 22, 30, 15, 20, 12, 30, 20, 10]
      },{
          name: 'Medical',
          data: [13, 23, 20, 8, 13, 30, 15, 10, 12, 20, 20, 10]
      },{
          name: 'Annual',
          data: [11, 20, 15, 15, 21, 30, 15, 20, 15, 20, 20, 10]
      }],
      xaxis: {
          categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        },
      legend: {
          position: 'bottom',
          // offsetY: 40
      },
      fill: {
          opacity: 1
      },
  }

  var chart = new ApexCharts(
      document.querySelector("#dashboard-admin-Leave"),
      sColStacked
  );

  chart.render();
  }
  //Working Format Admin Dashboard
  if($('#admin-working-format').length > 0 ){
  var donutChart = {
      chart: {
          height: 320,
          type: 'donut',
          toolbar: {
            show: false,
          },
          plotOptions: {
            pie: {
              dataLabels: {
                name: {
                  show: true
                },
                value: {
                  show: false
                }
              }
            }
          }
      },
      colors: ['#00AEEB', '#40C63C', '#FFC107'],
      series: [100, 40, 60],
      labels: ['On Site', 'Remote', 'Hybrid'],
      responsive: [{
          breakpoint: 480,
          options: {
              chart: {
                  width: 200
              },
              
          }
      }],
      legend: {
          position: 'bottom'
      }
  }

  var donut = new ApexCharts(
      document.querySelector("#admin-working-format"),
      donutChart
  );

  donut.render();
  }

  //Employee Report Admin Dashboard
  if($('#employee-report').length > 0 ){
    var options = {
      series: [{
        name: "Employees",
        data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
    },{
        name: 'Interns',
        data: [50, 41, 25, 41, 79, 82, 69, 100, 148]
      }],
      chart: {
      height: 273,
      type: 'line',
      zoom: {
        enabled: false
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'straight'
    },
    title: {
      text: '',
      align: 'left'
    },
    grid: {
      row: {
        colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        opacity: 0.5
      },
    },
    xaxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
    }
    };

    var chart = new ApexCharts(document.querySelector("#employee-report"), options);
    chart.render();
  }

  //Leave Report Admin Dashboard
  if($('#hr-leave-report').length > 0 ){
    var options = {
          series: [{
          name: 'Annual',
          data: [44, 55, 57, 56, 61, 58, 63, 60, 66]
        }, {
          name: 'Vacation',
          data: [76, 85, 101, 98, 87, 105, 91, 114, 94]
        }, {
          name: 'Medical',
          data: [35, 41, 36, 26, 45, 48, 52, 53, 41]
        }],
          chart: {
          type: 'bar',
          height: 350
        },
        colors: ['#00AEEB', '#40C63C', '#FF4747'],
        plotOptions: {
          bar: {
            horizontal: false,
            columnWidth: '55%',
            // endingShape: 'rounded'
          },
        },
        dataLabels: {
          enabled: false
        },
        stroke: {
          show: true,
          width: 2,
          colors: ['transparent']
        },
        xaxis: {
          categories: ['Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
        },
        yaxis: {
          title: {
            text: '$ (thousands)'
          }
        },
        fill: {
          opacity: 1
        },
        tooltip: {
          y: {
            formatter: function (val) {
              return "$ " + val + " thousands"
            }
          }
        }
        };

        var chart = new ApexCharts(document.querySelector("#hr-leave-report"), options);
        chart.render(); 

  }

  //Job Summary HR Dashboard
  if($('#job-vacancy-summary').length > 0 ){
  var donutChart = {
      chart: {
          height: 350,
          type: 'donut',
          toolbar: {
            show: false,
          },
          plotOptions: {
            pie: {
              dataLabels: {
                name: {
                  show: true
                },
                value: {
                  show: true
                }
              }
            }
          }
      },
      colors: ['#334399', '#FACE70', '#4CC6A1', '#00AEEB'],
      series: [40, 30, 60, 70],
      labels: ['Graphic ', 'UI/UX', 'Product', 'Visual'],
      responsive: [{
          breakpoint: 480,
          options: {
              chart: {
                  width: 200
              },
          }
      }],
      legend: {
          position: 'bottom',
      }
  }

  var donut = new ApexCharts(
      document.querySelector("#job-vacancy-summary"),
      donutChart
  );

  donut.render();
  }

  //Employee DB Online Attendance
  if($('#empdb-online-attendance').length > 0 ){
  var donutChart = {
      chart: {
          height: 320,
          type: 'donut',
          toolbar: {
            show: false,
          },
          plotOptions: {
            pie: {
              dataLabels: {
                name: {
                  show: true
                },
                value: {
                  show: false
                }
              }
            }
          }
      },
      colors: ['#00AEEB', '#35BB6A', '#FFCD1C', '#FF4747'],
      series: [70, 40, 60, 30],
      labels: ['Working Hours', 'Break', 'Remaining Hours', 'Late Entey'],
      responsive: [{
          breakpoint: 480,
          options: {
              chart: {
                  width: 200
              },
              
          }
      }],
      legend: {
          position: 'bottom'
      }
  }

  var donut = new ApexCharts(
      document.querySelector("#empdb-online-attendance"),
      donutChart
  );

  donut.render();
  }
	
  //attendance Report Admin Dashboard
  if($('#attendance-report').length > 0 ){
    var options = {
      series: [{
        name: "Employees",
        data: [10, 41, 60, 71, 100, 120, 130, 150, 190]
    },{
        name: "Employees",
        data: [13, 14, 30, 35, 49, 52, 69, 71, 150]
    },{
        name: "Employees",
        data: [10, 20, 25, 35, 49, 82, 79, 91, 160]
    },{
        name: 'Interns',
        data: [10, 21, 33, 45, 50, 60, 75, 80, 85]
      }],
      chart: {
      height: 350,
      type: 'line',
      zoom: {
        enabled: false
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'straight'
    },
    title: {
      text: '',
      align: 'left'
    },
    grid: {
      row: {
        colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        opacity: 0.5
      },
    },
    xaxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
    }
    };

    var chart = new ApexCharts(document.querySelector("#attendance-report"), options);
    chart.render();
  }
  
});