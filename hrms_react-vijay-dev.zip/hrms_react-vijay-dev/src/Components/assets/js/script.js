/*
Author       : Dreamguys
Template Name: Dreams-HRMS - Bootstrap Template
Version      : 1.0
*/

(function($) {
	"use strict";
	
	var $slimScrolls = $('.slimscroll');
	var $wrapper = $('.main-wrapper');

	if ($(window).width() > 767) {
		if($('.theiaStickySidebar').length > 0) {
			$('.theiaStickySidebar').theiaStickySidebar({
			  // Settings
			  additionalMarginTop: 30
			});
		}
	}
	
	// Sidebar

	if($(window).width() <= 991){
	var Sidemenu = function() {
		this.$menuItem = $('.main-nav a');
	};

	function init() {
		var $this = Sidemenu;
	}
	$(document).resize(function(){
		init();
	});

	// Sidebar Initiate
	}
	
	// Mobile menu sidebar overlay
	
	$('body').append('<div class="sidebar-overlay"></div>');
	$(document).on('click', '#mobile_btn', function(e) {
		$('main-wrapper').toggleClass('slide-nav');
		$('.sidebar-overlay').toggleClass('opened');
		$('html').toggleClass('menu-opened');
		e.preventDefault();
		return false;
	});
	
	$(document).on('click', '.sidebar-overlay', function() {
		$('html').removeClass('menu-opened');
		$(this).removeClass('opened');
		$('main-wrapper').removeClass('slide-nav');
	});
	
	$(document).on('click', '#menu_close', function() {
		$('html').removeClass('menu-opened');
		$('.sidebar-overlay').removeClass('opened');
		$('main-wrapper').removeClass('slide-nav');
	});
	
	// Content div min height set
	
	function resizeInnerDiv() {
		var height = $(window).height();	
		var header_height = $(".header").height();
		var footer_height = $(".footer").height();
		var setheight = height - header_height;
		var trueheight = setheight - footer_height;
		$(".content").css("min-height", trueheight);
	}
	
	if($('.content').length > 0 ){
		resizeInnerDiv();
	}

	$(window).resize(function(){
		if($('.content').length > 0 ){
			resizeInnerDiv();
		}
	});

	// Header Fixed
	
	if($('.header-fixed').length > 0) {
		$(document).ready(function(){
		  $(window).scroll(function(){
			var scroll = $(window).scrollTop();
			  if (scroll > 35) {
				$(".header-fixed").css("background" , "#FFFFFF");
				$(".header-three.header-fixed").css("width" , "100%");
				$(".header-three.header-fixed").css("margin" , "0");
			  }

			  else{
				  $(".header-fixed").css("background" , "transparent");  	
				  $(".header-three.header-fixed").css("width" , "calc(100% - 80px)");
				  $(".header-three.header-fixed").css("margin-left" , "80px");
			  }
		  })
		})
	}
	
	// Small Sidebar
    
    $(document).on('click', '#toggle_btn', function () {
        if ($('body').hasClass('mini-sidebar')) {
            $('body').removeClass('mini-sidebar');
            $('.subdrop + ul').slideDown();
        } else {
            $('body').addClass('mini-sidebar');
            $('.subdrop + ul').slideUp();
        }
        return false;
    });
    
    
    $(document).on('mouseover', function (e) {
        e.stopPropagation();
        if ($('body').hasClass('mini-sidebar') && $('#toggle_btn').is(':visible')) {
            var targ = $(e.target).closest('.sidebar').length;
            if (targ) {
                $('body').addClass('expand-menu');
                $('.subdrop + ul').slideDown();
            } else {
                $('body').removeClass('expand-menu');
                $('.subdrop + ul').slideUp();
            }
            return false;
        }
    });
	
	// Sidebar Menu
	
	var Sidemenu = function() {
		this.$menuItems = $('#sidebar-menu a');
	};
	
	function initi() {
		var $this = Sidemenu;
		$('#sidebar-menu a').on('click', function(e) {
			if($(this).parent().hasClass('submenu')) {
				e.preventDefault();
			}
			if(!$(this).hasClass('subdrop')) {
				$('ul', $(this).parents('ul:first')).slideUp(350);
				$('a', $(this).parents('ul:first')).removeClass('subdrop');
				$(this).next('ul').slideDown(350);
				$(this).addClass('subdrop');
			} else if($(this).hasClass('subdrop')) {
				$(this).removeClass('subdrop');
				$(this).next('ul').slideUp(350);
			}
		});
		$('#sidebar-menu ul li.submenu a.active').parents('li:last').children('a:first').addClass('active').trigger('click');
	}
	
	// Sidebar Initiate
	initi();

	// Select 2
	
	if ($('.select').length > 0) {
		$('.select').select2({
			minimumResultsForSearch: -1,
			width: '100%'
		});
	}
	
	if ($('.category-select').length > 0) {
		$(".category-select").select2({
			placeholder: "Choose Category",
			allowClear: false
		});
	}
	
	if ($('.loc-select').length > 0) {
		$(".loc-select").select2({
			placeholder: "Choose Location",
			allowClear: false
		});
	}
	
	if ($('.region select').length > 0) {
		$(".region select").select2({
			placeholder: "Region",
			allowClear: false
		});
	}

	// Featured Slider
	if ($('.owl-carousel.featured-slider').length > 0) {
		$('.owl-carousel.featured-slider').owlCarousel({
			loop: true,
			margin: 24,
			nav: true,
			dots: false,
			smartSpeed: 2000,
			navText: ["<i class='fa-solid fa-angle-left'></i>", "<i class='fa-solid fa-angle-right'></i>"],
			navContainer: '.mynav2',
			responsive: {
				0: {
					items: 1
				},

				550: {
					items: 4
				},
				700: {
					items: 4
				},
				1000: {
					items: 4
				}
			}
		})
	}

	// Dependency Slider
	if ($('.owl-carousel.dependency-slider').length > 0) {
		$('.owl-carousel.dependency-slider').owlCarousel({
			loop: true,
			margin: 24,
			nav: true,
			dots: false,
			smartSpeed: 2000,
			navText: ["<i class='fa-solid fa-angle-left'></i>", "<i class='fa-solid fa-angle-right'></i>"],
			navContainer: '.dependency-nav',
			responsive: {
				0: {
					items: 1
				},

				550: {
					items: 2
				},
				700: {
					items: 1
				},
				1000: {
					items: 3
				}
			}
		})
	}

	// Eductaion Documents Slider
	if ($('.owl-carousel.eductaion-documents').length > 0) {
		$('.owl-carousel.eductaion-documents').owlCarousel({
			loop: true,
			margin: 24,
			nav: true,
			dots: false,
			smartSpeed: 2000,
			navText: ["<i class='fa-solid fa-angle-left'></i>", "<i class='fa-solid fa-angle-right'></i>"],
			navContainer: '.dependency-nav',
			responsive: {
				0: {
					items: 1
				},

				550: {
					items: 2
				},
				700: {
					items: 1
				},
				1000: {
					items: 3
				}
			}
		})
	}
	
	// Datetimepicker Date	

	if($('.datetimepicker').length > 0 ){
		$('.datetimepicker').datetimepicker({			
			format: 'DD-MM-YYYY',
			icons: {
				up: "fas fa-angle-up",
				down: "fas fa-angle-down",
				next: 'fas fa-angle-right',
				previous: 'fas fa-angle-left'
			}
		});
	}

	// timepicker
	if($('.timepicker').length > 0) {
		$('.timepicker').datetimepicker({
			format: "hh:mm:ss",
			icons: {
				up: "fa fa-angle-up",
				down: "fa fa-angle-down",
				next: 'fa fa-angle-right',
				previous: 'fa fa-angle-left'
			}
		});
	}

	// Datatable
	if($('.datatable').length > 0) {
		$('.datatable').DataTable({
			"bFilter": false,  
			"ordering": true,
			"bInfo": true,
			"bLengthChange": false,
			
			"language": {
				search: ' ',
				sLengthMenu: '_MENU_',
				paginate: {
					next: 'Next <i class=" fa fa-angle-double-right ms-2"></i>',
					previous: '<i class="fa fa-angle-double-left me-2"></i> Previous'
				},
			 },
			initComplete: (settings, json)=>{
				$('.dataTables_filter').appendTo('#tableSearch');
				$('.dataTables_filter').appendTo('.search-input');
			},	
		});
	}

	// Datatable Report
	if($('.datatable-report').length > 0) {
		$('.datatable-report').DataTable({
			"bFilter": false,  
			"ordering": false,
			"bInfo": false,
			"bLengthChange": false,
			
			"language": {
				search: ' ',
				sLengthMenu: '_MENU_',
				paginate: {
					next: 'Next <i class=" fa fa-angle-double-right ms-2"></i>',
					previous: '<i class="fa fa-angle-double-left me-2"></i> Previous'
				},
			 },
			initComplete: (settings, json)=>{
				$('.dataTables_filter').appendTo('#tableSearch');
				$('.dataTables_filter').appendTo('.search-input');
			},	
		});
	}
		
	// Country Code Selection
	
	if($('#mobile_code').length > 0) {
		$( '#mobile_code' ).intlTelInput( {
			initialCountry: "in",
			separateDialCode: true,	
		});
	}

	// Toggle Password

    if($('.toggle-password').length > 0) {
		$(document).on('click', '.toggle-password', function() {
			$(this).toggleClass("feather-eye-off");
			var input = $(".pass-input");
			if (input.attr("type") == "password") {
				input.attr("type", "text");
			} else {
				input.attr("type", "password");
			}
		});
	}


		// Wizard

		$(document).ready(function () {
			let progressVal = 0;
			let businessType = 0;
		  
			$(".next_btn").click(function () {
				$(this).parent().parent().parent().next().fadeIn('slow');
				$(this).parent().parent().parent().css({
					'display': 'none'
				});
				progressVal = progressVal + 1;
				$('.progress-active').removeClass('progress-active').addClass('progress-activated').next().addClass('progress-active');
			});
	
			$(".prev_btn").click(function () {
				$(this).parent().parent().parent().prev().fadeIn('slow');
				$(this).parent().parent().parent().css({
					'display': 'none'
				});
				progressVal = progressVal - 1;
				$('.progress-active').removeClass('progress-active').prev().removeClass('progress-activated').addClass('progress-active'); 
			});
	  });


		//Register page left side block height depends on right side block

		$(".register-sign-up").height($(".login-bg").height()-88);
		
		//popup display on focus

		$(".register-password-set .password input[type=password]").focus(function(event){
		  $(".popover-bg").fadeTo('slow', 1);
		}).blur(function(event){
		  $(".popover-bg").fadeTo('slow', 0);
		});

		// Date Range Picker
		if($('.date-picker').length > 0) {
			var start = moment().subtract(6, 'days');
			var end = moment();

			function datepicker_range(start, end) {
				$('.date-picker span').html(start.format('M/D/YYYY') + ' - ' + end.format('M/D/YYYY'));
			}

			$('.date-picker').daterangepicker({
				startDate: start,
				endDate: end,
				ranges: {
					'Today': [moment(), moment()],
					'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
					'Last 7 Days': [moment().subtract(6, 'days'), moment()],
					'Last 30 Days': [moment().subtract(29, 'days'), moment()],
					'This Month': [moment().startOf('month'), moment().endOf('month')],
					'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
				}
			}, datepicker_range);

			datepicker_range(start, end);
		}

		//sliding content
		$(".documents .document-wrap h3, .slide-left-right i.round").click(function(){
		    $(".document-slide").animate({
		      	width: "toggle"
		    });
		});

		//common Sidebar Toggle Fun
		if($('.popup-toggle').length > 0) {
			$(".popup-toggle").click(function(){
				$(".toggle-sidebar").addClass("open-sidebar");
			});
			$(".sidebar-closes").click(function(){
				$(".toggle-sidebar").removeClass("open-sidebar");
			});
		}
		
		//Admin Assets Filter Sidebar Toggle Fun
		if($('.filter-popup-toggle').length > 0) {
			$(".filter-popup-toggle").click(function(){
				$(".filter-toggle-sidebar").addClass("filter-open-sidebar");
			});
			$(".filter-sidebar-closes").click(function(){
				$(".filter-toggle-sidebar").removeClass("filter-open-sidebar");
			});
		}

		if($('.popup-toggle').length > 0) {
			$(".popup-toggle").click(function(){
				$(".privileges-sidebar").addClass("open-sidebar");
			  });
			  $(".sidebar-closes").click(function(){
				$(".privileges-sidebar").removeClass("open-sidebar");
			  });
		}

		//Team Slide Function
		$(".tree li").click(function(){
		    $(this).find('ul').slideToggle(500);
		});

		var tglHandle = $(".toggle-sidebar .head");
        
	    tglHandle.click(function() {
	        $(this).next('ul').slideToggle("slow");
	        $(this).next('i').toggleClass("fa-angle-up");
	    });

	    //Table row toggle on checklist
	    var tglHandle = $(".checklist tr.parent-row");
	    tglHandle.click(function() {
	        $(this).next('tr').slideToggle('2000',"swing", function () {
        // Animation complete.
		    });
		});

		//Bootstrap accordian collapse hide button
		$('.collapse').on('shown.bs.collapse', function () {
	        $(this).parent().addClass('active');
	    });
	    $('.collapse').on('hidden.bs.collapse', function () {
	        $(this).parent().removeClass('active');
	    });

		// Circle Progress Bar
		function animateElements() {
			$('.circle-bar1').each(function () {
				var elementPos = $(this).offset().top;
				var topOfWindow = $(window).scrollTop();
				var percent = $(this).find('.circle-graph1').attr('data-percent');
				var animate = $(this).data('animate');
				if (elementPos < topOfWindow + $(window).height() - 30 && !animate) {
					$(this).data('animate', true);
					$(this).find('.circle-graph1').circleProgress({
						value: percent / 100,
						size : 400,
						thickness: 60,
						fill: {
							color: '#00AEEB'
						}
					});
				}
			});
			
		}	
		
		if($('.circle-bar').length > 0) {
			animateElements();
		}
		$(window).scroll(animateElements);

    	//Tooltip
    	var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
		var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  			return new bootstrap.Tooltip(tooltipTriggerEl)
		})

		//Multiselct checkbox
		$('#select-employees').change(function(e) {
		  	if (e.currentTarget.checked) {
		  	$('.employee-row').find('input[type="checkbox"]').prop('checked', true);
		} else {
		    	$('.employee-row').find('input[type="checkbox"]').prop('checked', false);
		  	}
		});
		$('#select-department').change(function(e) {
		  	if (e.currentTarget.checked) {
		  	$('.department-row').find('input[type="checkbox"]').prop('checked', true);
		} else {
		    	$('.department-row').find('input[type="checkbox"]').prop('checked', false);
		  	}
		});
		$('#select-position').change(function(e) {
		  	if (e.currentTarget.checked) {
		  	$('.position-row').find('input[type="checkbox"]').prop('checked', true);
		} else {
		    	$('.position-row').find('input[type="checkbox"]').prop('checked', false);
		  	}
		});

		// MultiSearch Image    
        
	    if($('.multi-search-select-image').length > 0) {
	        $('.multi-search-select-image').multiselect({
	            enableClickableOptGroups: true,
	            enableFiltering: false,
	            widthSynchronizationMode: 'always',
	            buttonWidth: '100%',
	            enableHTML: true,
	            optionLabel: function(element) {
	                if ($(element).attr('data-img')=='')
	                {
	                    return '<span class="name-avatars">'+$(element).attr('data-foo')+'</span>'+$(element).text();
	                }
	                else {
	                    return '<img class="multi-drop-img" src="'+$(element).attr('data-img')+'">'+$(element).text();
	                } 
	            }

	        });
	        $('button[class="multiselect-option dropdown-item"]').removeAttr("title"); 
	    }

	    // File Manager

	    if ($('.owl-carousel.file-manager-slider').length > 0) {
	        $('.owl-carousel.file-manager-slider').owlCarousel({
	            loop: true,
	            margin: 24,
	            nav: true,
	            dots: false,
	            smartSpeed: 2000,
	            navText: ["<i class='fa-solid fa-angle-left'></i>", "<i class='fa-solid fa-angle-right'></i>"],
	            navContainer: '.mynav2',
	            responsive: {
	                0: {
	                    items: 1
	                },

	                550: {
	                    items: 1
	                },
	                700: {
	                    items: 1
	                },
	                1000: {
	                    items: 3
	                }
	            }
	        })
	    }

	    // File Manager Favourite Folders

	    if ($('.owl-carousel.favourite-folders').length > 0) {
	        $('.owl-carousel.favourite-folders').owlCarousel({
	            loop: true,
	            margin: 24,
	            nav: true,
	            dots: false,
	            smartSpeed: 2000,
	            navText: ["<i class='fa-solid fa-angle-left'></i>", "<i class='fa-solid fa-angle-right'></i>"],
	            navContainer: '.mynav3',
	            responsive: {
	                0: {
	                    items: 1
	                },

	                550: {
	                    items: 1
	                },
	                700: {
	                    items: 1
	                },
	                1000: {
	                    items: 3
	                }
	            }
	        })
	    }

	    // Tooltip
	    
	    if($('[data-bs-toggle="tooltip"]').length > 0) {
	        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
	        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
	          return new bootstrap.Tooltip(tooltipTriggerEl)
	        })
	    }
		//width controll for head ellipse text
		var TotalWidth = $('.document-wrap .head').width();
		var LeftImg = $('.document-wrap .document-icon').width();
		var RightImg = $('.document-wrap .star-ellips').width();
		var RequiredWidth = TotalWidth - (LeftImg + RightImg)-4;
		$(".document-wrap .text").css({
		    "width": RequiredWidth
		});
		var AttendanceTotalWidth = $('.header-total-w').width();
		var AttendanceRightImg = $('.daily-attendance i').width();
		// var RightImg = $('.document-wrap .star-ellips').width();
		var AttendanceRequiredWidth = AttendanceTotalWidth - (AttendanceRightImg-4);
		$("h5.header-working-hrs").css({
		    "width": AttendanceRequiredWidth
		});
		
		//For Employee Admin Attendance HeadText Width Control
		$("span.header-working-hrs").css({
		    "width": AttendanceRequiredWidth
		});
		
	//For Employee Admin Attendance HeadText Width Control
	$("span.header-working-hrs").css({
		"width": AttendanceRequiredWidth
	});
	

	// Tooltip

	if($('[data-bs-toggle="tooltip"]').length > 0) {
		var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
		var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
		return new bootstrap.Tooltip(tooltipTriggerEl)
		})
	}

	// Terminated Employe multi select
	if($('#terminationtype-select').length > 0) {
		VirtualSelect.init({
			ele: '#terminationtype-select',
			allowNewOption: true,
		});
		VirtualSelect.init({ ele: 'select' });
	}

	 //Virtual Select for Policies Department
	 if($('#policy-department').length > 0) {
		VirtualSelect.init({ ele: '#policy-department' });
	}

	// Rejection open popup

	$(function() {
		var p = new Popup({
			popup: '.popup-rejection',
			content: '.popup-content',
			overlay: '.overlay-rejection',
		});
		
		$('.call').click(function() {
			var form = $('.for-call-popup');
			p.open(form.html());
		});
	});
	
	function Popup(Obj) {
		this.popup = $(Obj.popup);
		this.content = $(Obj.content);
		this.overlay = $(Obj.overlay);
	
		var pop = this;
	
		this.open = (function(content) {
			pop.content.html(content);
			pop.popup.addClass('rejection-open').fadeIn(1000);
			pop.overlay.addClass('rejection-open');
		});
	
		this.close = (function() {
			pop.popup.removeClass('rejection-open');
			pop.overlay.removeClass('rejection-open');
		});
	
		this.overlay.click(function(e) {
			if (!pop.popup.is(e.target) && pop.popup.has(e.target).length === 0) {
				pop.close();
			}
		});
	}
		
	//Virtual Select for Image
	function sampleLabelRenderer(data) {
		let prefix = '';
		prefix = `<img src="assets/img/profiles/team1.png" alt="" width="37" />`;
		return `${prefix}${data.label}`;
	}

	//Virtual Select for Termination Type
	if($('#terminationtype-select').length > 0) {
		VirtualSelect.init({
			ele: '#terminationtype-select',
			allowNewOption: true,
		});
		VirtualSelect.init({ ele: 'select' });
	}
	//Virtual Select for Policies Department
	if($('#policy-department').length > 0) {
		VirtualSelect.init({ ele: '#policy-department' });
	}
	//Virtual Select for Promotion Type
	if($('#promotion-for').length > 0) {
		VirtualSelect.init({
			ele: '#promotion-for',
			options: [
				{ label: 'John Smith', value: '1', description: 'DGT-365' },
				{ label: 'John Smith', value: '2', description: 'DGT-365' },
				{ label: 'John Smith', value: '3', description: 'DGT-365' },
			],
			hasOptionDescription: true,
			multiple: true,
			labelRenderer: sampleLabelRenderer,
		});
	}

})(jQuery);

