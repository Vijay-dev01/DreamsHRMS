import React, { useEffect, useState, useRef } from "react";
import login_banner from "./assets/img/login-banner.png";
import login_logo from "./assets/img/login-logo.svg";
import google from "./assets/img/icons/google.svg";
import "./assets/css/style.css";
import Waving_Hand from "./assets/img/Waving_Hand.svg";
import arrow_right from "./assets/img/arrow_right.svg";
import { useNavigate } from "react-router-dom";
import { BASEURL } from "./apiPath/baseUrl";
import axios from "axios";
import TermconModal from "./Modal/TermconModal";
import PrivacyModal from "../Components/Modal/PrivacyModal";
import { useFormik } from "formik";
import * as Yup from "yup";
import { DataEncrpt, getDecryptedData, postData } from "./services/apiUrl";
import { useParams } from "react-router-dom";
import localStorage from "redux-persist/es/storage";
import cogoToast from "cogo-toast";
import { DomainName } from "../Components/Employee/ReduxReducer/EmployeeReducer";
import { useDispatch } from "react-redux";
function Register() {
  const inputElement = useRef();
  const Dispatch = useDispatch();
  const formik = useFormik({
    initialValues: {
      first_name: "",
      last_name: "",
      email: "",
      job_title: "",
      domain_name: "",
      phone_number: "",
      employee_count: "",
      country_id: "",
    },
    validationSchema: Yup.object({
      first_name: Yup.string()
        .min(5, "Mininum 2 characters")
        .max(15, "Maximum 15 characters")
        .required("Required!"),
      last_name: Yup.string().required("Required!"),
      email: Yup.string().email("Invalid email format").required("Required!"),

      job_title: Yup.string().required("Required!"),
      domain_name: Yup.string().required("Required!"),
      phone_number: Yup.number()
        .typeError("That doesn't look like a phone number")
        .positive("A phone number can't start with a minus")
        .integer("A phone number can't include a decimal point")
        .min(10)
        .required("A phone number is required"),
      employee_count: Yup.string().required("Required!"),
      country_id: Yup.string().required("Required!"),
    }),
    onSubmit: (values) => {
      console.log(values, "123456789");
      setData(values);
      focusInput();
      const getregister = async () => {
        const preparData = {
          first_name: values.first_name,
          last_name: values.last_name,
          email: values.email,
          job_title: values.job_title,
          domain_name: values.domain_name,
          phone_number: values.phone_number,
          employee_count: values.employee_count,
          country_id: values.country_id,
        };
        console.log(preparData, "preparData");
        postData("company-register", preparData, sucessCallBack);
      
      };
      getregister();
    },
  });

  const sucessCallBack = (data, res) => {
    console.log(data, "dtaaaa");
    // Dispatch(loading(false));
    if (res?.status === true) {
      cogoToast.success(data?.message);
      navigate(`/signup`);
      Dispatch(DomainName(data.DomainName ? data.DomainName : ""));
    } else {
      cogoToast.error(data?.error);
    }
  };


  const navigate = useNavigate();



  const [showterm, setShowterm] = useState(false);
  const [showprev, setShowprev] = useState(false);
  const [data, setData] = useState();


  const focusInput = () => {
    inputElement.current.focus();
    // register();
  };


  useEffect(() => {
    focusInput();
  }, []);

  return (
    <div class="main-wrapper">
      <div class="row">
        <div class="col-lg-4 col-md-5 col-sm-12 login-wrap-bg">
          <div class="login-wrapper">
            <div class="signupbox">
              <div class="logo-img d-flex align-items-center justify-content-between">
                <img src={login_logo} class="img-fluid" alt="Logo" />
                <div class="sign-group">
                  <a
                    onClick={() => navigate("/")}
                    class="btn sign-up d-flex"
                    style={{ color: "white", backgroundColor: "#0F233C" }}
                  >
                    Sign in
                    <span>
                      <img
                        class="arrow-icon mx-1"
                        style={{ marginTop: "3px" }}
                        src={arrow_right}
                      />
                    </span>
                  </a>
                </div>
              </div>
              <h2>Sign up</h2>
              <p>
                Hey <img src={Waving_Hand} aria-label="sheep" />, Enter the
                details to create you account
              </p>
              <form onSubmit={formik.handleSubmit} style={{ padding: "10px" }}>
                <div class="form-group">
                  <label class="label">First Name</label>
                  <input
                    type="text"
                    class="form-control"
                    ref={inputElement}
                    // name="register"
                    // value={register.firstName}
                    // onChange={handleChange}
                    name="first_name"
                    value={formik.values.first_name}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.first_name && formik.touched.first_name && (
                    <p className="d-flex  text-danger">
                      {formik.errors.first_name}
                    </p>
                  )}
                </div>
                <div class="form-group">
                  <label class="label">Last Name</label>
                  <input
                    ref={inputElement}
                    type="text"
                    class="form-control"
                    name="last_name"
                    value={formik.values.last_name}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.last_name && formik.touched.last_name && (
                    <p className="d-flex  text-danger">
                      {formik.errors.last_name}
                    </p>
                  )}
                </div>

                <div class="form-group">
                  <label class="label">Email Address</label>
                  <input
                    ref={inputElement}
                    type="email"
                    class="form-control"
                    // name="register"
                    // value={register.email}
                    // onChange={handleChange}
                    name="email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.email && formik.touched.email && (
                    <p className="d-flex  text-danger">{formik.errors.email}</p>
                  )}
                </div>
                <div class="form-group">
                  <label class="label">Job Title</label>
                  <input
                    ref={inputElement}
                    type="text"
                    class="form-control"
                    // name="register"
                    // value={register.job_title}
                    // onChange={handleChange}

                    name="job_title"
                    value={formik.values.job_title}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.job_title && formik.touched.job_title && (
                    <p className="d-flex  text-danger">
                      {formik.errors.job_title}
                    </p>
                  )}
                </div>
                <div class="form-group">
                  <label class="label">Company Name</label>
                  <input
                    ref={inputElement}
                    type="text"
                    class="form-control"
                    // name="register"
                    // value={register.domain_name}
                    // onChange={handleChange}
                    name="domain_name"
                    value={formik.values.domain_name}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.domain_name && formik.touched.domain_name && (
                    <p className="d-flex  text-danger">
                      {formik.errors.domain_name}
                    </p>
                  )}
                </div>
                <div class="form-group">
                  <label class="label">Phone number</label>
                  <input
                    ref={inputElement}
                    type="text"
                    class="form-control"
                    // name="register"
                    // value={register.phoneNUmber}
                    // onChange={handleChange}
                    name="phone_number"
                    value={formik.values.phone_number}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.phone_number &&
                    formik.touched.phone_number && (
                      <p className="d-flex  text-danger">
                        {formik.errors.phone_number}
                      </p>
                    )}
                </div>
                <div class="form-group">
                <label>Employee Count</label>
                  <select
                    class="form-select"
                    // name="register"
                    // value={register.employee_count}
                    // onChange={handleChange}
                    name="employee_count"
                    value={formik.values.employee_count}
                    onChange={formik.handleChange}
                  >
                    <option>Employee Count</option>
                    <option>50-100</option>
                    <option>100-200</option>
                  </select>
                  {formik.errors.employee_count &&
                    formik.touched.employee_count && (
                      <p className="d-flex  text-danger">
                        {formik.errors.employee_count}
                      </p>
                    )}
                </div>
                <div className="form-group">
<label>Country Id</label>
                  <select
                    class="form-select"
                    // value={register.country_id}
                    // onChange={handleChange}
                    name="country_id"
                    value={formik.values.country_id}
                    onChange={formik.handleChange}
                  >
                    <option>country_id</option>
                    <option>India</option>
                    <option>Other</option>
                  </select>
                  {formik.errors.country_id && formik.touched.country_id && (
                    <p className="d-flex  text-danger">
                      {formik.errors.country_id}
                    </p>
                  )}
                </div>
                {/* <div class="form-group">
                  <label class="form-control-label">Password</label>
                  <div class="pass-group" id="passwordInput">
                    <input
                      type="password"
                      class="form-control pass-input"
                      placeholder="Enter your password"
                    />
                    <span class="toggle-password feather-eye"></span>
                    <span class="pass-checked">
                      <i class="feather-check"></i>
                    </span>
                  </div>
                  <div class="form-password">
                    <div class="password-strength" id="passwordStrength">
                      <span id="poor"></span>
                      <span id="weak"></span>
                      <span id="strong"></span>
                      <span id="heavy"></span>
                    </div>
                    <div id="passwordInfo"></div>
                  </div>
                </div> */}
                <div class="form-group">
                  <div class="status-toggle d-flex align-items-center">
                    <input
                      ref={inputElement}
                      id="rating_1"
                      class="check"
                      type="checkbox"
                    />
                    <label
                      for="rating_1"
                      class="checktoggle checkbox-bg mb-0"
                    ></label>
                    <span>
                      By Signing up to create an account I accept Company’s
                      <span class="text-decoration-underline">
                        Terms & Privacy
                      </span>
                    </span>
                  </div>
                </div>
                <button
                  type="submit"
                  class="form-group btn login-submit w-100"
                  // onClick={registerDetails}
                >
                  Get Started
                </button>
                <div class="form-group">
                  <div class="ogin-or" style={{display:"flex",justifyContent:"center"}}>
                    <span class="or-line"></span>
                    <span class="span-or">Or</span>
                  </div>
                </div>
                <div class="form-group social-login">
                  <a
                    href="#"
                    class="d-flex align-items-center justify-content-center form-group btn google-login w-100"
                  >
                    <span>
                      <img src={google} class="img-fluid" alt="Logo" />
                    </span>
                    Sign up with Google
                  </a>
                </div>
                <div class="form-group">
                  <div class="terms-policy">
                    <ul>
                      <li>
                        <a onClick={() => setShowterm(true)} href="#">
                          Terms & Conditions
                        </a>
                      </li>
                      <li>
                        <a onClick={() => setShowprev(true)} href="#">
                          Privacy Policy
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div
          class="col-lg-8 col-md-7 col-sm-12 login-bg"
          style={{ position: "fixed" }}
        >
          <div class="welcome-login">
            <h2>Smarter . Simpler . Automated .</h2>
            <p>
              With the world's best staff management solutions, users can
              improve retention as well as productivity.
            </p>
          </div>
          <div class="banner-img">
            <img src={login_banner} class="img-fluid" alt="Login Banner" />
          </div>
          <div class="copyright">
            <div class="row">
              <div class="col-md-6">
                <div class="privacy-policy">
                  <p>Copyrights @ Dreams Hrms 2023</p>
                </div>
              </div>
              <div class="col-md-6">
                <div class="copyright-text">
                  <p class="mb-0">
                    Design and Developed by <span>Dreamguy’s</span>
                  </p>
                </div>
              </div>
              <TermconModal showterm={showterm} setShowterm={setShowterm} />
              <PrivacyModal showprev={showprev} setShowprev={setShowprev} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Register;
