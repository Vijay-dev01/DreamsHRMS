import React, { useState } from 'react'
import logo from './assets/img/logo.svg'
import avatar1 from './assets/img/profiles/avatar-01.jpg'
import avatar2 from './assets/img/profiles/avatar-02.jpg'
import avatar5 from './assets/img/profiles/avatar-02.jpg'
import avatar6 from './assets/img/profiles/avatar-06.jpg'
import avatar14 from './assets/img/profiles/avatar-14.jpg'
import gearicon from './assets/img/icons/gear-icon.svg'
import clockicon from './assets/img/icons/clock-icon.svg'
import cloudicon from './assets/img/icons/cloud-icon.svg'
import downloadicon from './assets/img/icons/download-icon.svg'
import printericon from './assets/img/icons/printer-icon.svg'
import funnelicon from './assets/img/icons/funnel-icon.svg'
import baricon from  './assets/img/icons/bar-icon.svg'
import gridicon from './assets/img/icons/grid-icon.svg'
import dashboardicon from './assets/img/icons/dashboard-icon.svg'
import employeeicon from './assets/img/icons/employees-icon.svg'
import timeofficon from './assets/img/icons/time-off-icon.svg'
import policyicon from  './assets/img/icons/policies-icon.svg'
import reporticon from './assets/img/icons/reports-icon.svg'
import shortcuticon from './assets/img/icons/shortcut-icon.svg'
import PersonalinfoModal from './Modal/AddEmployee/personalinfo'




function Dashboard() {
	const [showmodal,setShowmodal] = useState(false)
  return (
    <div class="main-wrapper">

			<header class="header header-fixed header-one">
				<nav class="navbar navbar-expand-lg header-nav">
					<div class="navbar-header">
						<a id="mobile_btn" href="javascript:void(0);">
							<span class="bar-icon">
								<span></span>
								<span></span>
								<span></span>
							</span>
						</a>
						<a href="javascript:void(0);" class="navbar-brand logo">
							<img src={logo} class="img-fluid" alt="Logo"/>
						</a>
					</div>
					<div class="main-menu-wrapper">
						<div class="menu-header">
							<a href="index.html" class="menu-logo">
								<img src={logo} class="img-fluid" alt="Logo"/>
							</a>
							<a id="menu_close" class="menu-close" href="javascript:void(0);">
								<i class="fas fa-times"></i>
							</a>
						</div>
						<ul class="main-nav">
							<li>
								<a href="javascript:void(0);">
									<img src={dashboardicon} alt=""/> Dashboard
								</a>
							</li>
							<li class="active">
								<a href="employees.html">
									<img src={employeeicon}alt=""/> Employees
								</a>
							</li>
							<li>
								<a href="javascript:void(0);">
									<img src={timeofficon} alt="" /> Time off
								</a>
							</li>
							<li>
								<a href="javascript:void(0);">
									<img src={policyicon} alt="" /> Policies
								</a>
							</li>
							<li>
								<a href="javascript:void(0);">
									<img src={reporticon} alt="" /> Reports
								</a>
							</li>
						</ul>
						<ul class="nav header-navbar-rht">
							<li class="nav-item search-item">
								<div class="top-nav-search">
									<form action="#">
										<input type="text" class="form-control" placeholder="Search" />
										<button class="btn" type="submit"><i class="feather-search"></i></button>
										<span><img src={shortcuticon} alt="" /></span>
									</form>
								</div>
							</li>
							<li class="nav-item quick-link-item">
								<a class="btn" href="javascript:void(0);">
									<span>Quick Links <i class="feather-zap"></i></span>
								</a>
							</li>
							<li class="nav-item nav-icons">
								<a href="javascript:void(0);">
									<i class="feather-sun"></i>
								</a>
							</li>
							<li class="nav-item dropdown has-arrow notification-dropdown">
	                            <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
	                                <i class="feather-bell"></i>
	                            </a>
	                            <div class="dropdown-menu dropdown-menu-end notifications">
									<div class="topnav-dropdown-header">
										<span class="notification-title">Notifications</span>
										<a href="javascript:void(0)" class="clear-noti"> Clear All</a>
									</div>
									<div class="noti-content">
										<ul class="notification-list">
											<li class="notification-message">
												<a href="javascript:void(0)">
													<div class="media d-flex">
														<span class="avatar flex-shrink-0">
															<img alt="" src={avatar1} class="rounded-circle" />
														</span>
														<div class="media-body flex-grow-1">
															<p class="noti-details"><span class="noti-title">John Doe</span> added new task <span class="noti-title">Patient appointment booking</span></p>
															<p class="noti-time"><span class="notification-time">4 mins ago</span></p>
														</div>
													</div>
												</a>
											</li>
											<li class="notification-message">
												<a href="javascript:void(0)">
													<div class="media d-flex">
														<span class="avatar flex-shrink-0">
															<img alt="" src={avatar2} class="rounded-circle"/>
														</span>
														<div class="media-body flex-grow-1">
															<p class="noti-details"><span class="noti-title">Tarah Shropshire</span> changed the task name <span class="noti-title">Appointment booking with payment gateway</span></p>
															<p class="noti-time"><span class="notification-time">6 mins ago</span></p>
														</div>
													</div>
												</a>
											</li>
											<li class="notification-message">
												<a href="javascript:void(0)">
													<div class="media d-flex">
														<span class="avatar flex-shrink-0">
															<img alt="" src={avatar6} class="rounded-circle"/>
														</span>
														<div class="media-body flex-grow-1">
															<p class="noti-details"><span class="noti-title">Misty Tison</span> added <span class="noti-title">Domenic Houston</span> and <span class="noti-title">Claire Mapes</span> to project <span class="noti-title">Doctor available module</span></p>
															<p class="noti-time"><span class="notification-time">8 mins ago</span></p>
														</div>
													</div>
												</a>
											</li>
											<li class="notification-message">
												<a href="javascript:void(0)">
													<div class="media d-flex">
														<span class="avatar flex-shrink-0">
															<img alt="" src={avatar5} class="rounded-circle"/>
														</span>
														<div class="media-body flex-grow-1">
															<p class="noti-details"><span class="noti-title">Rolland Webber</span> completed task <span class="noti-title">Patient and Doctor video conferencing</span></p>
															<p class="noti-time"><span class="notification-time">12 mins ago</span></p>
														</div>
													</div>
												</a>
											</li>
											<li class="notification-message">
												<a href="javascript:void(0)">
													<div class="media d-flex">
														<span class="avatar flex-shrink-0">
															<img alt="" src={avatar6} class="rounded-circle"/>
														</span>
														<div class="media-body flex-grow-1">
															<p class="noti-details"><span class="noti-title">Bernardo Galaviz</span> added new task <span class="noti-title">Private chat module</span></p>
															<p class="noti-time"><span class="notification-time">2 days ago</span></p>
														</div>
													</div>
												</a>
											</li>
										</ul>
									</div>
									<div class="topnav-dropdown-footer">
										<a href="javascript:void(0)">View all Notifications</a>
									</div>
								</div>
	                        </li>
							<li class="nav-item nav-icons">
								<a href="javascript:void(0);">
									<i class="feather-settings"></i>
								</a>
							</li>
							<li class="nav-item nav-icons">
								<a href="javascript:void(0);">
									<i class="far fa-circle-question"></i>
								</a>
							</li>
							<li class="nav-item dropdown has-arrow main-drop">
								<a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
									<span class="user-img">
										<img src={avatar14} class="img-rounded" alt="" />
									</span>
								</a>
								<div class="dropdown-menu">
									<a class="dropdown-item" href="javascript:void(0);">
										<i class="feather-user-plus"></i> My Profile
									</a>
									<a class="dropdown-item" href="javascript:void(0);">
										<i class="feather-settings"></i> Settings
									</a>
									<a class="dropdown-item" href="javascript:void(0);">
										<i class="feather-log-out"></i> Logout
									</a>
								</div>
							</li>
						</ul>
					</div>
				</nav>
			</header>
			
			
			<div class="page-wrapper">

                <div class="content container">

                	
					<div class="page-header">
						<div class="row align-items-center">
							<div class="col-lg-6 col-md-6">
								<h3 class="page-title">Employees <span>(215)</span> 
									<a href="javascript:void(0);">Archived (13)</a>
								</h3>
							</div>
							<div class="col-lg-6 col-md-6 page-header-btns">
								<a href="javascript:void(0);" class="btn import-btn">
									<img src={cloudicon} alt="" /> Import
								</a>
								<a href="javascript:void(0);" class="btn">
									<img src={gearicon} alt="" />
								</a>
								<a onClick={()=>setShowmodal(true)}  /* href="javascript:void(0);" */ class="btn new-employee-btn">
									<i class="fa-solid fa-plus"></i> New Employee
								</a>
							</div>
						</div>
					</div>
					
					<div class="search-filter">
						<div class="row align-items-center">
							<div class="col-lg-6 col-md-6">  
								<div class="form-group">
									<i class="feather-search"></i>
									<input type="text" class="form-control" placeholder="Name, email, etc.,"/>
								</div>
							</div>
							<div class="col-lg-6 col-md-6">
								<ul class="nav search-btns-info">
									<li>
										<a href="javascript:void(0);" class="btn">
											<img src={clockicon} alt="" />
										</a>
									</li>
									<li>
										<a href="javascript:void(0);" class="btn">
											<img src={downloadicon} alt="" />
										</a>
									</li>
									<li>
										<a href="javascript:void(0);" class="btn">
											<img src={printericon} alt="" />
										</a>
									</li>
									<li>
										<a href="javascript:void(0);" class="btn">as
											<img src={funnelicon} alt="" />
										</a>
									</li>
									<li>
										<a href="javascript:void(0);" class="btn">
											<img src={baricon} alt="" />
										</a>
									</li>
									<li>
										<a href="javascript:void(0);" class="btn">
											<img src={gridicon} alt="" />
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
				
					<div class="employee-grid">
						<div class="row">

					
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar1} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">John Walker</a>
											</h4>
											<h6>UI Designer</h6>
											<p>DGT 00201</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> Design Team</p>
											<p><i class="feather-calendar"></i> 17th March 2023</p>
											<p><i class="feather-mail"></i> johnwalker@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 987 6543 210</p>
										</div>
									</div>
								</div>
							</div>
						
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar2} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">Bernardo Galaviz</a>
											</h4>
											<h6>Web Developer</h6>
											<p>DGT 00202</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> Web Development Team</p>
											<p><i class="feather-calendar"></i> 19th March 2023</p>
											<p><i class="feather-mail"></i> bernardo@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 587 2643 765</p>
										</div>
									</div>
								</div>
							</div>
						
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar14} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">Loren Gatlin</a>
											</h4>
											<h6>UI Designer</h6>
											<p>DGT 00203</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> Design Team</p>
											<p><i class="feather-calendar"></i> 22nd March 2023</p>
											<p><i class="feather-mail"></i> lorengatlin@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 785 2563 789</p>
										</div>
									</div>
								</div>
							</div>
					
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar5} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">Richard Miles</a>
											</h4>
											<h6>BD Manager</h6>
											<p>DGT 00204</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> Business Team</p>
											<p><i class="feather-calendar"></i> 05th April 2023</p>
											<p><i class="feather-mail"></i> richardmiles@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 896 0326 752</p>
										</div>
									</div>
								</div>
							</div>
				
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar6} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">Lesley Grauer</a>
											</h4>
											<h6>SEO Analyst</h6>
											<p>DGT 00205</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> SEO Team</p>
											<p><i class="feather-calendar"></i> 10th April 2023</p>
											<p><i class="feather-mail"></i> lesleygrauer@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +8 657 0326 752</p>
										</div>
									</div>
								</div>
							</div>
					
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar6} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">John Doe</a>
											</h4>
											<h6>Test Engineer</h6>
											<p>DGT 00206</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> QA Team</p>
											<p><i class="feather-calendar"></i> 25th April 2023</p>
											<p><i class="feather-mail"></i> johndoe@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 897 5897 345</p>
										</div>
									</div>
								</div>
							</div>
						
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar14} alt="" />
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">Wilmer Deluna</a>
											</h4>
											<h6>UI Designer</h6>
											<p>DGT 00207</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> Design Team</p>
											<p><i class="feather-calendar"></i> 01st May 2023</p>
											<p><i class="feather-mail"></i> wilmer@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 300 7859 214</p>
										</div>
									</div>
								</div>
							</div>
						
							<div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
								<div class="card employee-card">
									<div class="card-body">
										<div class="employee-img">
											<a href="javascript:void(0);">
												<img src={avatar1} alt=""/>
											</a>
										</div>
										<div class="dropdown profile-action">
											<a href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
												<i class="fa-solid fa-ellipsis-vertical"></i>
											</a>
											<div class="dropdown-menu dropdown-menu-end">
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-solid fa-pencil"></i> Edit
												</a>
												<a class="dropdown-item" href="javascript:void(0);">
													<i class="fa-regular fa-trash-can"></i> Delete
												</a>
											</div>
										</div>
										<div class="employee-details">
											<h4 class="user-name text-ellipsis">
												<a href="javascript:void(0);">Mike Litorus</a>
											</h4>
											<h6>Web Developer</h6>
											<p>DGT 00208</p>
										</div>
										<div class="employee-info">
											<p><i class="feather-server"></i> Web Development Team</p>
											<p><i class="feather-calendar"></i> 13th May 2023</p>
											<p><i class="feather-mail"></i> mike@dgthrms.com</p>
											<p><i class="feather-phone-call"></i> +1 258 8456 457</p>
										</div>
									</div>
								</div>
							</div>
						

						</div>
					</div>
				

                </div>
    

			</div>
		
<PersonalinfoModal showmodal={showmodal}/>
        </div>

  )
}

export default Dashboard