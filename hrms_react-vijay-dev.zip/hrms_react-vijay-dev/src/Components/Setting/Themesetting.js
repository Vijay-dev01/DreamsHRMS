import React from 'react'
import Header from '../Header'
import { dark, light } from '../imagepath'
import { Link } from 'react-router-dom'
import Footer from '../Footer'

const Themesetting = () => {
  return (
    <div className="main-wrapper">
  {/* Header */}
  <Header />
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper">
    {/* Page Content */}
    <div className="content container">				
      {/* Page Header */}
      <div className="page-header settings-header">
        <h3 className="page-title">Theme Settings </h3>
        <p>Change how Untitled UI looks and feels in your browser.</p>
      </div>
      {/* /Page Header */}
      {/* Interface Theme */}
      <div className="settings-details theme-settings">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Interface Theme</h6>
              <p>Select or customize your UI theme.</p>
            </div>
          </div>
          <div className="col-lg-8">
            <ul className="dark-light">
              <li>
                <div className="theme-img">
                  <img className="moon" src={light} alt="Light " />
                  <p>Light</p>
                </div>
              </li>
              <li>
                <div className="theme-img">
                  <img className="sun" src={dark} alt="Light " />
                  <p>Dark</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {/* Interface Theme */}
      {/* Transparent Sidebar */}
      <div className="settings-details">
        <div className="row align-items-center">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Transparent Sidebar</h6>
              <p>Make the desktop sidebar transparent</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="status-toggle ">
              <input type="checkbox" id="status_2" className="check" />
              <label htmlFor="status_2" className="checktoggle">checkbox</label>
            </div>
          </div>
        </div>
      </div>
      {/* Transparent Sidebar */}
      {/* Accent Color */}
      <div className="settings-details shift-list add-shift">
        <div className="row align-items-center">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Accent Color</h6>
              <p>Select your application accent color</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="form-area">
              <div className="form-details">
                <div className="input-area">
                  <div className="select-color">
                    <div className="multi-color">
                      <ul>
                        <li>
                          <Link to="#" className="mrg-sft" />
                        </li>
                        <li>
                          <Link to="#" className="tst-sht" />
                        </li>
                        <li>
                          <Link to="#" className="mid-sht" />
                        </li>
                        <li>
                          <Link to="#" className="reg-sft " />
                        </li>
                        <li>
                          <Link to="#" className="a-sft" />
                        </li>
                        <li>
                          <Link to="#" className="nit-sft" />
                        </li>
                        <li>
                          <Link to="#" className="sft-b" />
                        </li>
                        <li>
                          <Link to="#" className="sft-c" />
                        </li>
                      </ul>
                    </div>
                    <div className="choose-color">
                      <p className="text-color">More Colors 
                        <input type="color" className="sft-e  form-control form-control-color" />
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Accent Color */}
      {/* Select Font */}
      <div className="settings-details">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Font Style</h6>
              <p>Choose your font style</p>
            </div>
          </div>
          <div className="col-lg-8">
            <select className="select">
              <option value={1}>Select Font</option>
              <option value={2}>Font 1</option>
              <option value={2}>Font 2</option>
            </select>
          </div>
        </div>
      </div>
      {/* Select Font */}
      <div className="btns-groups">
        <button type="submit" className="btn gradient-btn me-3"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
        <button type="submit" className="btn cancel-btn">Cancel</button>
      </div>
      {/* Footer */}
     <Footer />
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default Themesetting
