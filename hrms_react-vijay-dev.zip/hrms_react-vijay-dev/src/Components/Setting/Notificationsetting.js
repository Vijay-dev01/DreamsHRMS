import React from 'react'
import Header from '../Header'
import { Link } from 'react-router-dom'
import Footer from '../Footer'
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';

const Countries = [
  { label: "Chennai", value: 355 },
  { label: "Bengalure", value: 54 },
  { label: "Coimbatore", value: 43 }

];

const Notificationsetting = () => {
  return (
   <div className="main-wrapper">
  {/* Header */}
  <Header />
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper">
    {/* Page Content */}
    <div className="content container">				
      {/* Page Header */}
      <div className="page-header settings-header">
        <h3 className="page-title">Notifications Settings</h3>
        <p>We may still send you important notifications about your account outside of your notification settings.</p>
      </div>
      {/* /Page Header */}
      {/* Notification */}
      <div className="notification-header">
        <div className="row align-center">
          <div className="col-lg-5">
            <h3>Which Branch would you like to receive notifications for? *</h3>
          </div>
          <div className="col-lg-7">
            <div className="input-area">
              {/* <select className="select">
                <option value="selected">Select Branch</option>
                <option value="Chennai">Chennai</option>
                <option value="Coimbatore"> Coimbatore</option>
                <option value="Bangalore">Bangalore</option>
              </select> */}
               <div className="container">
                    <div className="row">
                      <div className="col-md-3"></div>
                      <div className="col-md-6">
                        <Select options={Countries} placeholder="Select Branch" />
                      </div>
                      <div className="col-md-4"></div>
                    </div>
                  </div>
            </div>
          </div>
        </div>
      </div>
      {/* /Notification */}
      {/* Page Header */}
      <div className="page-header notification-header settings-details">
        <div className="content-page-header settings-details-head">
          <h6>Teams</h6>
          <div className="listing-btn page-header-btns">
            <ul>
              <li>
                <Link to="#" className="btn team-list">
                  <span><i className="feather-mail me-2" /></span>Email
                </Link>
                <Link to="#" className="btn team-list">
                  <span><i className="feather-bell me-2" /></span>Push
                </Link>
                <Link to="#" className="btn team-list">
                  <span><i className="feather-file-text me-2" /></span>Text
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>
      {/* /Page Header */}
      {/* Shifts & Schedule Notifications */}
      <div className="settings-details notification-header">
        <div className="row">
          <div className="col-lg-4 col-sm-12 col-12">
            <div className="settings-details-head">
              <h6>Shifts &amp; Schedule Notifications</h6>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
            </div>
          </div>
          <div className="col-lg-8 col-sm-12 col-12">
            <div className="table-responsive">
              <table className="table table-center">
                <tbody>
                  <tr className="notifi-list">
                    <td className="p-0">
                      Schedule publication and updates
                    </td>
                    <td className="pt-0">
                      <div className="status-toggle">
                        <input id="rating_1" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td className="pt-0">
                      <div className="status-toggle">
                        <input id="rating_2" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_2" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td className="pt-0">
                      <div className="status-toggle">
                        <input id="rating_3" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_3" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Shift trade and cover request updates
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_4" className="check" type="checkbox" />
                        <label htmlFor="rating_4" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_5" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_5" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_6" className="check" type="checkbox" />
                        <label htmlFor="rating_6" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Time off request responses
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_7" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_7" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_8" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_8" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_9" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_9" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      <div className="notifi-input d-flex align-items-center">Send me a reminder<span className="me-2 ms-2"><input type="text" className="form-control" /></span>hour(s) before my shift</div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_10" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_10" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_11" className="check" type="checkbox" />
                        <label htmlFor="rating_11" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_12" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_12" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Clock in/out confirmation
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_13" className="check" type="checkbox" />
                        <label htmlFor="rating_13" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_14" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_14" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_15" className="check" type="checkbox" />
                        <label htmlFor="rating_15" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list border-0">
                    <td>
                      Break end confirmation
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_16" className="check" type="checkbox" />
                        <label htmlFor="rating_16" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_17" className="check" type="checkbox" />
                        <label htmlFor="rating_17" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_18" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_18" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      {/* Shifts & Schedule Notifications */}
      {/* Manager Alerts */}
      <div className="settings-details notification-header">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Manager Alerts</h6>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="table-responsive">
              <table className="table table-center">
                <tbody>
                  <tr className="notifi-list">
                    <td className="p-0">
                      Overtime notifications
                    </td>
                    <td className="pt-0">
                      <div className="status-toggle">
                        <input id="rating_19" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_19" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td className="pt-0">
                      <div className="status-toggle">
                        <input id="rating_20" className="check" type="checkbox" />
                        <label htmlFor="rating_20" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td className="pt-0">
                      <div className="status-toggle">
                        <input id="rating_21" className="check" type="checkbox" />
                        <label htmlFor="rating_21" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Employee trade, cover, and time off requests
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_22" className="check" type="checkbox" />
                        <label htmlFor="rating_22" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_23" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_23" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_24" className="check" type="checkbox" />
                        <label htmlFor="rating_24" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Employee availability requests
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_25" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_25" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_26" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_26" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_27" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_27" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Daily Email summaries
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_28" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_28" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_29" className="check" type="checkbox" />
                        <label htmlFor="rating_29" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_30" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_30" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list">
                    <td>
                      Weekly Email summaries
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_31" className="check" type="checkbox" />
                        <label htmlFor="rating_31" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_32" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_32" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_33" className="check" type="checkbox" />
                        <label htmlFor="rating_33" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                  <tr className="notifi-list border-0">
                    <td>
                      Daily Hiring summaries
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_34" className="check" type="checkbox" />
                        <label htmlFor="rating_34" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_35" className="check" type="checkbox" />
                        <label htmlFor="rating_35" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                    <td>
                      <div className="status-toggle">
                        <input id="rating_36" className="check" type="checkbox" defaultChecked />
                        <label htmlFor="rating_36" className="checktoggle checkbox-bg">checkbox</label>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      {/* Manager Alerts */}
      {/* Buttons */}
      <div className="btns-groups m-0">
        <button type="submit" className="btn gradient-btn me-3"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
        <button type="submit" className="btn cancel-btn">Cancel</button>
      </div>
      {/* /Buttons */}
      {/* Footer */}
        <Footer />
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default Notificationsetting
