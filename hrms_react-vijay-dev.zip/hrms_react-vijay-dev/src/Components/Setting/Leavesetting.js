import React from 'react'
import Header from '../Header'
import { Link } from 'react-router-dom'
import Footer from '../Footer'

const Leavesetting = () => {
  return (
   <div>
  <div className="main-wrapper">
    {/* Header */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper collab-setting">
      {/* Page Content */}
      <div className="content container">
        <div className="d-lg-flex justify-content-between align-items-center search-filter">
          <h3>Leave Setting</h3>
          <div className="mixed-buttons">
            <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-leave"><i className="fa fa-plus" aria-hidden="true" />Add Templates</button>
          </div>
        </div>
        {/* Leave Setting */}
        <div className="accordion accordion-flush" id="onboarding-setting">
          {/* Accordion Item */}
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingOne">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                <div className="d-block head">
                  <div className="text">
                    <h4>Annual</h4>
                    <p>Adjust employee's leave balance to an updated Days immediately</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <div className="status-toggle">
                  <input id="rating_1" className="check" type="checkbox" defaultChecked />
                  <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                </div>
              </div>
            </div>
            <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <table className="table table-center leave-table">
                  <thead className="thead-light">
                    <tr>
                      <th>Days</th>
                      <th>Carry forward</th>
                      <th>Earned leave</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="parent-row">
                      <td>
                        <input type="text" className="form-control" placeholder="Enter Holiday Name" /></td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="rdo1" defaultChecked className="radio-input" name="radio-group" />
                            <label htmlFor="rdo1" className="radio-label mb-0"> <span className="radio-border" />Yes</label>
                          </div>												
                          <div className="radio-custom">
                            <input type="radio" id="rdo2" className="radio-input" name="radio-group" />
                            <label htmlFor="rdo2" className="radio-label mb-0"> <span className="radio-border" />No</label>
                          </div>													
                          <div className="custom-max">
                            <input type="numer" className="form-control" placeholder="Enter Days" />
                            <span>Max</span>
                          </div>	
                        </form>
                      </td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="radio1" name="radio-group" defaultChecked />
                            <label htmlFor="radio1" className="radio-label mb-0"><span className="radio-border">Yes</span></label>
                          </div>
                          <div className="radio-custom">
                            <input type="radio" id="radio2" name="radio-group" />
                            <label htmlFor="radio2" className="radio-label mb-0"><span className="radio-border">No</span></label>
                          </div>
                        </form>
                      </td>
                      <td><Link to="#"><span className="edit-leave"><i className="fa-solid fa-pen" /></span></Link></td>
                    </tr>
                  </tbody>
                </table>
                <div className="d-lg-flex justify-content-between align-items-center search-filter mt-3 mb-0">
                  <h4>Custom policy</h4>
                  <div className="mixed-buttons">
                    <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-custom-policy"><i className="fa fa-plus" aria-hidden="true" />Add custom policy</button>
                  </div>
                </div>	
              </div>
            </div>
          </div>
          {/* /Accordion Item */}
          {/* Accordion Item */}
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingTwo">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                <div className="d-block head">
                  <div className="text">
                    <h4>Sick</h4>
                    <p>Adjust employee's leave balance to an updated Days immediately</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <div className="status-toggle">
                  <input id="rating_1" className="check" type="checkbox" defaultChecked />
                  <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                </div>
              </div>
            </div>
            <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <table className="table table-center leave-table">
                  <thead className="thead-light">
                    <tr>
                      <th>Days</th>
                      <th>Carry forward</th>
                      <th>Earned leave</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="parent-row">
                      <td>
                        <input type="text" className="form-control" placeholder="Enter Holiday Name" /></td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="rdo1" defaultChecked className="radio-input" name="radio-group" />
                            <label htmlFor="rdo1" className="radio-label mb-0"> <span className="radio-border" />Yes</label>
                          </div>												
                          <div className="radio-custom">
                            <input type="radio" id="rdo2" className="radio-input" name="radio-group" />
                            <label htmlFor="rdo2" className="radio-label mb-0"> <span className="radio-border" />No</label>
                          </div>													
                          <div className="custom-max">
                            <input type="numer" className="form-control" placeholder="Enter Days" />
                            <span>Max</span>
                          </div>	
                        </form>
                      </td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="radio1" name="radio-group" defaultChecked />
                            <label htmlFor="radio1" className="radio-label mb-0"><span className="radio-border">Yes</span></label>
                          </div>
                          <div className="radio-custom">
                            <input type="radio" id="radio2" name="radio-group" />
                            <label htmlFor="radio2" className="radio-label mb-0"><span className="radio-border">No</span></label>
                          </div>
                        </form>
                      </td>
                      <td><Link to="#"><span className="edit-leave"><i className="fa-solid fa-pen" /></span></Link></td>
                    </tr>
                  </tbody>
                </table>
                <div className="d-lg-flex justify-content-between align-items-center search-filter mt-3 mb-0">
                  <h4>Custom policy</h4>
                  <div className="mixed-buttons">
                    <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-custom-policy"><i className="fa fa-plus" aria-hidden="true" />Add custom policy</button>
                  </div>
                </div>	
              </div>
            </div>
          </div>
          {/* /Accordion Item */}
          {/* Accordion Item */}
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingThree">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                <div className="d-block head">
                  <div className="text">
                    <h4>Hospitalisation</h4>
                    <p>Adjust employee's leave balance to an updated Days immediately</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <div className="status-toggle">
                  <input id="rating_1" className="check" type="checkbox" defaultChecked />
                  <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                </div>
              </div>
            </div>
            <div id="flush-collapseThree" className="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <table className="table table-center leave-table">
                  <thead className="thead-light">
                    <tr>
                      <th>Days</th>
                      <th>Carry forward</th>
                      <th>Earned leave</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="parent-row">
                      <td>
                        <input type="text" className="form-control" placeholder="Enter Holiday Name" /></td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="rdo1" defaultChecked className="radio-input" name="radio-group" />
                            <label htmlFor="rdo1" className="radio-label mb-0"> <span className="radio-border" />Yes</label>
                          </div>												
                          <div className="radio-custom">
                            <input type="radio" id="rdo2" className="radio-input" name="radio-group" />
                            <label htmlFor="rdo2" className="radio-label mb-0"> <span className="radio-border" />No</label>
                          </div>													
                          <div className="custom-max">
                            <input type="numer" className="form-control" placeholder="Enter Days" />
                            <span>Max</span>
                          </div>	
                        </form>
                      </td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="radio1" name="radio-group" defaultChecked />
                            <label htmlFor="radio1" className="radio-label mb-0"><span className="radio-border">Yes</span></label>
                          </div>
                          <div className="radio-custom">
                            <input type="radio" id="radio2" name="radio-group" />
                            <label htmlFor="radio2" className="radio-label mb-0"><span className="radio-border">No</span></label>
                          </div>
                        </form>
                      </td>
                      <td><Link to="#"><span className="edit-leave"><i className="fa-solid fa-pen" /></span></Link></td>
                    </tr>
                  </tbody>
                </table>
                <div className="d-lg-flex justify-content-between align-items-center search-filter mt-3 mb-0">
                  <h4>Custom policy</h4>
                  <div className="mixed-buttons">
                    <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-custom-policy"><i className="fa fa-plus" aria-hidden="true" />Add custom policy</button>
                  </div>
                </div>	
              </div>
            </div>
          </div>
          {/* /Accordion Item */}
          {/* Accordion Item */}
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingFour">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                <div className="d-block head">
                  <div className="text">
                    <h4>MaternityAssigned to female only</h4>
                    <p>Adjust employee's leave balance to an updated Days immediately</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <div className="status-toggle">
                  <input id="rating_1" className="check" type="checkbox" defaultChecked />
                  <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                </div>
              </div>
            </div>
            <div id="flush-collapseFour" className="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <table className="table table-center leave-table">
                  <thead className="thead-light">
                    <tr>
                      <th>Days</th>
                      <th>Carry forward</th>
                      <th>Earned leave</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="parent-row">
                      <td>
                        <input type="text" className="form-control" placeholder="Enter Holiday Name" /></td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="rdo1" defaultChecked className="radio-input" name="radio-group" />
                            <label htmlFor="rdo1" className="radio-label mb-0"> <span className="radio-border" />Yes</label>
                          </div>												
                          <div className="radio-custom">
                            <input type="radio" id="rdo2" className="radio-input" name="radio-group" />
                            <label htmlFor="rdo2" className="radio-label mb-0"> <span className="radio-border" />No</label>
                          </div>													
                          <div className="custom-max">
                            <input type="numer" className="form-control" placeholder="Enter Days" />
                            <span>Max</span>
                          </div>	
                        </form>
                      </td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="radio1" name="radio-group" defaultChecked />
                            <label htmlFor="radio1" className="radio-label mb-0"><span className="radio-border">Yes</span></label>
                          </div>
                          <div className="radio-custom">
                            <input type="radio" id="radio2" name="radio-group" />
                            <label htmlFor="radio2" className="radio-label mb-0"><span className="radio-border">No</span></label>
                          </div>
                        </form>
                      </td>
                      <td><Link to="#"><span className="edit-leave"><i className="fa-solid fa-pen" /></span></Link></td>
                    </tr>
                  </tbody>
                </table>
                <div className="d-lg-flex justify-content-between align-items-center search-filter mt-3 mb-0">
                  <h4>Custom policy</h4>
                  <div className="mixed-buttons">
                    <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-custom-policy"><i className="fa fa-plus" aria-hidden="true" />Add custom policy</button>
                  </div>
                </div>	
              </div>
            </div>
          </div>
          {/* /Accordion Item */}
          {/* Accordion Item */}
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingFive">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
                <div className="d-block head">
                  <div className="text">
                    <h4>PaternityAssigned to male only</h4>
                    <p>Adjust employee's leave balance to an updated Days immediately</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <div className="status-toggle">
                  <input id="rating_1" className="check" type="checkbox" defaultChecked />
                  <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                </div>
              </div>
            </div>
            <div id="flush-collapseFive" className="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <table className="table table-center leave-table">
                  <thead className="thead-light">
                    <tr>
                      <th>Days</th>
                      <th>Carry forward</th>
                      <th>Earned leave</th>
                      <th />
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="parent-row">
                      <td>
                        <input type="text" className="form-control" placeholder="Enter Holiday Name" /></td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="rdo1" defaultChecked className="radio-input" name="radio-group" />
                            <label htmlFor="rdo1" className="radio-label mb-0"> <span className="radio-border" />Yes</label>
                          </div>												
                          <div className="radio-custom">
                            <input type="radio" id="rdo2" className="radio-input" name="radio-group" />
                            <label htmlFor="rdo2" className="radio-label mb-0"> <span className="radio-border" />No</label>
                          </div>													
                          <div className="custom-max">
                            <input type="numer" className="form-control" placeholder="Enter Days" />
                            <span>Max</span>
                          </div>	
                        </form>
                      </td>
                      <td>
                        <form action="#" className="leave-option-group">
                          <div className="radio-custom">
                            <input type="radio" id="radio1" name="radio-group" defaultChecked />
                            <label htmlFor="radio1" className="radio-label mb-0"><span className="radio-border">Yes</span></label>
                          </div>
                          <div className="radio-custom">
                            <input type="radio" id="radio2" name="radio-group" />
                            <label htmlFor="radio2" className="radio-label mb-0"><span className="radio-border">No</span></label>
                          </div>
                        </form>
                      </td>
                      <td><Link to="#"><span className="edit-leave"><i className="fa-solid fa-pen" /></span></Link></td>
                    </tr>
                  </tbody>
                </table>
                <div className="d-lg-flex justify-content-between align-items-center search-filter mt-3 mb-0">
                  <h4>Custom policy</h4>
                  <div className="mixed-buttons">
                    <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-custom-policy"><i className="fa fa-plus" aria-hidden="true" />Add custom policy</button>
                  </div>
                </div>	
              </div>
            </div>
          </div>
          {/* /Accordion Item */}
          {/* Accordion Item */}
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingSix">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseSix" aria-expanded="false" aria-controls="flush-collapseSix">
                <div className="d-block head">
                  <div className="text">
                    <h4>Compensation Apply</h4>
                    <p>Adjust employee's leave balance to an updated Days immediately</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <div className="status-toggle">
                  <input id="rating_1" className="check" type="checkbox" defaultChecked />
                  <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                </div>
              </div>
            </div>
            <div id="flush-collapseSix" className="accordion-collapse collapse" aria-labelledby="flush-headingSix" data-bs-parent="#onboarding-setting">
              <div className="accordion-body table-responsive">
                <div className="table-responsive">
                  <div className="row dt-row">
                    <div className="col-sm-12">
                      <table className="table table-center leave-table">
                        <thead className="thead-light">
                          <tr>
                            <th>Days</th>
                            <th>Carry forward</th>
                            <th>Earned leave</th>
                            <th />
                          </tr>
                        </thead>
                        <tbody>
                          <tr className="parent-row">
                            <td>
                              <input type="text" className="form-control" placeholder="Enter Holiday Name" /></td>
                            <td>
                              <form action="#" className="leave-option-group">
                                <div className="radio-custom">
                                  <input type="radio" id="rdo1" defaultChecked className="radio-input" name="radio-group" />
                                  <label htmlFor="rdo1" className="radio-label mb-0"> <span className="radio-border" />Yes</label>
                                </div>												
                                <div className="radio-custom">
                                  <input type="radio" id="rdo2" className="radio-input" name="radio-group" />
                                  <label htmlFor="rdo2" className="radio-label mb-0"> <span className="radio-border" />No</label>
                                </div>													
                                <div className="custom-max">
                                  <input type="numer" className="form-control" placeholder="Enter Days" />
                                  <span>Max</span>
                                </div>	
                              </form>
                            </td>
                            <td>
                              <form action="#" className="leave-option-group">
                                <div className="radio-custom">
                                  <input type="radio" id="radio1" name="radio-group" defaultChecked />
                                  <label htmlFor="radio1" className="radio-label mb-0"><span className="radio-border">Yes</span></label>
                                </div>
                                <div className="radio-custom">
                                  <input type="radio" id="radio2" name="radio-group" />
                                  <label htmlFor="radio2" className="radio-label mb-0"><span className="radio-border">No</span></label>
                                </div>
                              </form>
                            </td>
                            <td><Link to="#"><span className="edit-leave"><i className="fa-solid fa-pen" /></span></Link></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <div className="d-lg-flex justify-content-between align-items-center search-filter mt-3 mb-0">
                  <h4>Custom policy</h4>
                  <div className="mixed-buttons">
                    <button type="text" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#add-custom-policy"><i className="fa fa-plus" aria-hidden="true" />Add custom policy</button>
                  </div>
                </div>	
              </div>
            </div>
          </div>
          {/* /Accordion Item */}
        </div>
        {/* /Leave Setting */}				
      </div>
      {/* /Page Content */}
      {/* Footer */}
        <Footer />
      {/* Footer */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* New Leave Type Modal */}
  <div className="modal fade onboarding-modal settings" id="add-leave" tabIndex={-1} aria-labelledby="add-leave" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">New Leave Type</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Leave Type Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Template Name" />
            </div>
            <div className="form-group note">
              <label htmlFor="description">Days <span>*</span></label>
              <input type="numer" className="form-control" placeholder="Enter Template Name" />
            </div>
            <div className="btns-groups modal-btn-group">
              <button type="submit" className="btn gradient-btn me-3" data-bs-dismiss="modal"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
              <button type="submit" className="btn cancel-btn" data-bs-dismiss="modal">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /New Leave Type Modal */}
  {/* Add Custom Policy */}
  <div className="modal fade" id="add-custom-policy" tabIndex={-1} aria-labelledby="add-custom-policy" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Custom Policy</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Policy Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Policy Name" />
            </div>
            <div className="form-group">
              <label className="label">Days <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Days" />
            </div>
            <div className="form-group">
              <label>Days * <span>*</span></label>
              <select className="select">
                <option>Select Task Type</option>
                <option>Option1</option>
                <option>Option2</option>
              </select>
            </div>
            <div className="form-group">
              <label>Add employee <span>*</span></label>
              <select className="multi-search-select-image" multiple>
                <option data-img="assets/img/profiles/avatar-01.jpg" data-foo>Adam Williams</option>
                <option data-img="assets/img/profiles/avatar-02.jpg" data-foo>Karina Clark</option>
                <option data-img data-foo="K">Karina Clark</option>
              </select>
            </div>
            <div className="row">
              <div className="col">
                <div className="form-group">
                  <label>Position <span>*</span></label>
                  <select className="select">
                    <option>Designer</option>
                    <option>Developer</option>
                    <option>HR</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

  )
}

export default Leavesetting
