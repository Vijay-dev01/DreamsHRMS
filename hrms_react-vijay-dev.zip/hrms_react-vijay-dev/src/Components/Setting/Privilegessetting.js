import React from 'react'
import Header from '../Header'
import { Link } from 'react-router-dom'
import Footer from '../Footer'
import { close } from '../imagepath'

const Privilegessetting = () => {
  return (
    <div>
  <div className="main-wrapper">
    {/* Header */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper privileges-page">
      {/* Page Content */}
      <div className="content container">
        {/* Page Header */}
        <div className="page-header privileges-header">
          <div className="row align-items-center">
            <div className="col-lg-6 col-md-6">
              <h3 className="privileges-title">Roles &amp; Privileges Settings</h3>
              <p className="privileges-descrip">Check the Permissions you wish to grant all Team Members in each Role, and then click Save.</p>
            </div>
            <div className="col-lg-6 col-md-6 page-header-btns page-header-position-btns">
              <Link to="#" className="btn new-employee-btn" data-bs-toggle="modal" data-bs-target="#addrole">
                <i className="fa-solid fa-plus" /> Add Role
              </Link>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        {/* Privileges */}
        <div className="employee-list department-position">
          <div className="row">
            <div className="col-sm-12">
              <div className="card-table">
                <div className="card-body">
                  <div className="table-responsive">
                    <table className="table table-center table-hover datatable">
                      <thead className="thead-light">
                        <tr>
                          <th>#</th>
                          <th>Role Name</th>
                          <th>Modules Access</th>
                          <th>Created On</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td className="depart-name">Admin</td>
                          <td className="depart-name">Full Permissions</td>
                          <td className="depart-name">30 March 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>2</td>
                          <td className="depart-name">Manager</td>
                          <td className="depart-name">Full Permissions</td>
                          <td className="depart-name">30 March 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td className="depart-name">Custom Permissions</td>
                          <td className="depart-name">Full Permissions</td>
                          <td className="depart-name">30 March 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>4</td>
                          <td className="depart-name">HR</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">01 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>5</td>
                          <td className="depart-name">Supervisor</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">04 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>6</td>
                          <td className="depart-name">Client</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">05 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>7</td>
                          <td className="depart-name">An Accountant</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">06 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>8</td>
                          <td className="depart-name">Executive Secretary</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">07 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>9</td>
                          <td className="depart-name">Product Owner</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">08 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>10</td>
                          <td className="depart-name">Project Manager</td>
                          <td>Custom Permissions</td>
                          <td className="depart-name">10 April 2023<br /><span>Thursday</span></td>
                          <td>
                            <div className="action">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="#"><i className="far fa-solid fa-key" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item popup-toggle" to="#"><i className="fa-regular fa-circle-user" /></Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-solid fa-trash-alt me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /Privileges */}				
        {/* Footer */}
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Privileges Slide */}
  <div className="privileges-sidebar">
    <div className="d-flex align-items-center justify-content-between head">
      <h5>Admin - Modules Privileges</h5>
      <i className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes" aria-hidden="true" />
    </div>
    <div className="employee-list department-position">
      <div className="row">
        <div className="col-sm-12">
          <div className="card-table">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-center table-hover">
                  <thead className="thead-light">
                    <tr>
                      <th>#</th>
                      <th>Module</th>
                      <th>Create</th>
                      <th>View</th>
                      <th>Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td className="depart-name">All Employees</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td className="depart-name">Activity Feed</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td className="depart-name">All Job Types</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td className="depart-name">Annual Incentive Plans</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>5</td>
                      <td className="depart-name">Appraisal</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>6</td>
                      <td className="depart-name">Aptitude Results</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>7</td>
                      <td className="depart-name">Assets</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>8</td>
                      <td className="depart-name">Attendance</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>9</td>
                      <td className="depart-name">Balance Sheet</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>10</td>
                      <td className="depart-name">Budget Expenses</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>11</td>
                      <td className="depart-name">Budget Expenses</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                    <tr>
                      <td>12</td>
                      <td className="depart-name">Budget Expenses</td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                      <td>
                        <label className="custom_check w-100">
                          <input type="checkbox" name="wednesday" />
                          <span className="checkmark"><i className="fa-solid fa-check" /></span>
                        </label>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* Privileges Slide */}
  {/* Delete Items Modal */}
  <div className="modal custom-modal fade" id="delete_modal" role="dialog">
    <div className="modal-dialog modal-dialog-centered modal-md">
      <div className="modal-content">
        <div className="modal-body">
          <div className="form-header text-center">
            <h3>Delete Roles &amp; Privileges</h3>
            <p>Are you sure want to delete?</p>
          </div>
          <div className="modal-btn delete-action text-center">
            <div className="btns-groups modal-btn-group">
              <button type="submit" className="btn gradient-btn me-3" data-bs-dismiss="modal"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
              <button type="submit" className="btn cancel-btn" data-bs-dismiss="modal">Cancel</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* /Delete Items Modal */}
  {/* Modal Popup */}
  <div className="employees-popup add-position">
    <div className="modal fade" id="addrole" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="addroleLabel" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-header">
            <h1 className="modal-title" id="addroleLabel">Add Role</h1>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
              <img src={close} alt="" /> 
            </button>
          </div>
          <div className="modal-body">
            <div className="multistep-form">
              <fieldset className="form-inner" id="first">
                <div className="form-area">
                  <div className="form-details ">
                    <form action="#">
                      <div className="row">
                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                          <div className="input-area">
                            <label className="form-label">Role Name <span>*</span></label>
                            <input type="text" className="form-control" placeholder="Enter Role Name" required />
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="btns-groups mt-0 modal-btn-group">
                  <button type="submit" className="btn gradient-btn me-3" data-bs-dismiss="modal"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
                  <button type="submit" className="btn cancel-btn" data-bs-dismiss="modal">Cancel</button>
                </div>
              </fieldset>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  )
}

export default Privilegessetting
