import React from 'react'
import Header from '../../Header'
import Footer from '../../Footer'

const ResignationNotice = () => {
  return (
   <div className="main-wrapper">
  {/* Header */}
  <Header />
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper">
    {/* Page Content */}
    <div className="content container">		
      {/* Approval Setting */}
      <div className="employee-info">
        <div className="row align-items-center">
          <div className="col-xl-4 col-lg-5 col-sm-12 col-12">	
            <div className="page-header settings-header">
              <h3 className="page-title">Approval Setting</h3>
              <p>We may still send you important Approval Settings about your account outside of your notification settings.</p>
            </div>	
          </div>
          <div className="col-xl-8 col-lg-7 col-sm-12 col-12">
            <div className="secure-items profile-items p-0">
              <ul>
                <li><a href="/approval-setting">Expense Approval</a></li>
                <li><a href="/Leave-approval-setting">Leave Approval</a></li>
                <li><a href="/offer-approval-setting">Offer Approval</a></li>
                <li className="active"><a href="/resignation-notice">Resignation Notice</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* /Approval Setting */}
      {/* Page Header */}
      <div className="default-expense settings-details">
        <div className="row">
          <div className="col-xl-4 col-lg-5 col-sm-12 col-12">							
            <div className="settings-details-head">
              <h6>Resignation Notice</h6>
              <p>Sed perspiciatis unde omnis iste natus error voluptatem accusantium doloremque laudantium, </p>
            </div>
          </div>
          <div className="col-xl-8 col-lg-7 col-sm-12 col-12">
            <div className="default-approval">
              <div className="option-head">
                <h6>Resignation Notice Approvers</h6>
                <div className="col-lg-12">											
                  <div className="form-group">
                    <label>Email Notification </label>
                    <div className="row option-group-plus css-equal-heights">
                      <div className="col-lg-9">
                        <select className="container p-2 rounded">
                          <option selected>Select Member</option>
                          <option value={1}>Member 1</option>
                          <option value={2}>Member 2</option>
                          <option value={3}>Member 3</option>
                        </select>
                      </div>
                    </div>												
                  </div>	
                  <div className="form-group">
                    <label>Notice Days</label>
                    <div className="row option-group-plus css-equal-heights">
                      <div className="col-lg-9">
                        <select className="container p-2 rounded">
                          <option selected>Select Notice Days</option>
                          <option value={1}>Notice Days 1</option>
                          <option value={2}>Notice Days 2</option>
                          <option value={3}>Notice Days 3</option>
                        </select>
                      </div>
                    </div>												
                  </div>								
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* /Page Header */}
      {/* Buttons */}
      <div className="btns-groups m-0">
        <button type="submit" className="btn gradient-btn me-3"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
        <button type="submit" className="btn cancel-btn">Cancel</button>
      </div>
      {/* /Buttons */}
    </div>
    {/* /Page Content */}
    {/* Footer */}
    <Footer />
    {/* Footer */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default ResignationNotice
