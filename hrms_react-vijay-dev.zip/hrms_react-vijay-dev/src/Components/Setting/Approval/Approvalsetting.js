import React from 'react'
import Header from '../../Header'
import { Link } from 'react-router-dom'
import Footer from '../../Footer'

const Approvalsetting = () => {
  return (
    <div className="main-wrapper">
  {/* Header */}
  <Header />
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper">
    {/* Page Content */}
    <div className="content container">		
      {/* Approval Setting */}
      <div className="employee-info">
        <div className="row align-items-center">
          <div className="col-xl-4 col-lg-5 col-sm-12 col-12">	
            <div className="page-header settings-header">
              <h3 className="page-title">Approval Setting</h3>
              <p>We may still send you important Approval Settings about your account outside of your notification settings.</p>
            </div>	
          </div>
          <div className="col-xl-8 col-lg-7 col-sm-12 col-12">
            <div className="secure-items profile-items p-0">
              <ul>
                <li className="active"><Link to="/approval-setting">Expense Approval</Link></li>
                <li><Link to="/Leave-approval-setting">Leave Approval</Link></li>
                <li><Link to="/offer-approval-setting">Offer Approval</Link></li>
                <li><Link to="/resignation-notice">Resignation Notice</Link></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      {/* /Approval Setting */}
      {/* Page Header */}
      <div className="default-expense settings-details">
        <div className="row">
          <div className="col-xl-4 col-lg-5 col-sm-12 col-12">							
            <div className="settings-details-head">
              <h6>Expense Approval Settings</h6>
              <p>Sed perspiciatis unde omnis iste natus error voluptatem accusantium doloremque laudantium, </p>
            </div>
          </div>
          <div className="col-xl-8 col-lg-7 col-sm-12 col-12">
            <div className="default-approval">
              <div className="option-head">
                <h6>Default Expense Approval</h6>
                <div className="option-group">
                  <div className="default-option">
                    <label className="custom_radio mb-0 active">
                      <input type="radio" name="payment" />
                      <span className="checkmark" /> Simultaneous Approval
                    </label>
                  </div>
                  <div className="default-option">
                    <label className="custom_radio mb-0">
                      <input type="radio" name="payment" />
                      <span className="checkmark" /> Simultaneous Approval
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="default-approval">
              <div className="option-head">
                <h6>Expense Approvers</h6>
                <div className="col-lg-12">											
                  <div className="form-group">
                    <label>Approver 1</label>
                    <div className="row option-group-plus css-equal-heights">
                      <div className="col-lg-9">	
                        <select className="container p-2 rounded">
                          <option selected>Select Approver </option>
                          <option value={1}>Approver 1</option>
                          <option value={2}>Approver 2</option>
                          <option value={3}>Approver 3</option>
                        </select>
                      </div>
                      <div className="col-lg-3">	    
                        <Link className="btn option-plus-btn" to="#">
                          <span><i className="feather-plus-circle me-2" />Add Approver</span>
                        </Link>
                      </div>
                    </div>												
                  </div>									
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* /Page Header */}
      {/* Buttons */}
      <div className="btns-groups m-0">
        <button type="submit" className="btn gradient-btn me-3"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
        <button type="submit" className="btn cancel-btn">Cancel</button>
      </div>
      {/* /Buttons */}				
    </div>
    {/* /Page Content */}
    {/* Footer */}
   <Footer />
    {/* Footer */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default Approvalsetting
