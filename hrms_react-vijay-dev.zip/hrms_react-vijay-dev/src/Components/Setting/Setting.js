import React from 'react'
import Header from '../Header'
import { Link } from 'react-router-dom'
import { close } from '../imagepath'
import Footer from '../Footer'
import Select from 'react-select';
import 'bootstrap/dist/css/bootstrap.min.css';

const Countries = [
  { label: "Chennai", value: 355 },
  { label: "Bengalure", value: 54 },
  { label: "Coimbatore", value: 43 }

];

const Setting = () => {
  return (
    <div className="main-wrapper">
      {/* Header */}
      <Header />
      {/* /Header */}
      {/* Page Wrapper */}
      <div className="page-wrapper">
        {/* Page Content */}
        <div className="content container">
          {/* Page Header */}
          <div className="page-header settings-header">
            <h3 className="page-title">Settings</h3>
            <p>Manage your account settings and preferences.</p>
          </div>
          {/* /Page Header */}
          {/* Notification */}
          <div className="notification-header">
            <div className="row align-center">
              <div className="col-lg-5">
                <h3>Which Branch would you like to receive notifications for? *</h3>
              </div>
              <div className="col-lg-7">
                <div className="input-area">
                  {/* <select className="select">
                <option value="selected">Select Branch</option>
                <option value="Chennai">Chennai</option>
                <option value="Coimbatore"> Coimbatore</option>
                <option value="Bangalore">Bangalore</option>
              </select> */}
                  <div className="container">
                    <div className="row">
                      <div className="col-md-3"></div>
                      <div className="col-md-6">
                        <Select options={Countries} placeholder="Select Branch" />
                      </div>
                      <div className="col-md-4"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Notification */}
          {/* Settings */}
          <div className="settings-info">
            <div className="row">
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/company-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-file" />
                        </span>
                        <div className="dash-content">
                          <h6>Company Settings</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/company-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/system-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-solid fa-laptop" />
                        </span>
                        <div className="dash-content">
                          <h6>System Settings</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/system-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/notification-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-bell" />
                        </span>
                        <div className="dash-content">
                          <h6>Notifications</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/notification-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/privileges-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-flag" />
                        </span>
                        <div className="dash-content">
                          <h6>Roles &amp; Privileges</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/privileges-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/Leave-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-clock" />
                        </span>
                        <div className="dash-content">
                          <h6>Leave Setting</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/Leave-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/admin-dashboard-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-solid fa-border-all" />
                        </span>
                        <div className="dash-content">
                          <h6>Dashboard Settings</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/admin-dashboard-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/approval-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-thumbs-up" />
                        </span>
                        <div className="dash-content">
                          <h6>Approval Setting</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="/approval-setting" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="/theme-setting">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-file" />
                        </span>
                        <div className="dash-content">
                          <h6>Theme Settings</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="theme-settings.html" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4 col-sm-6 col-12 d-flex">
                <div className="card flex-fill">
                  <div className="card-body">
                    <Link to="#" data-bs-toggle="modal" data-bs-target="#delete_modal">
                      <div className="dash-widget-header">
                        <span className="dash-widget-icon">
                          <i className="fa-regular fa-trash-can" />
                        </span>
                        <div className="dash-content">
                          <h6>Delete Account</h6>
                          <p>Lorem ipsum dolor adipiscing</p>
                        </div>
                      </div>
                    </Link>
                    <div className="dash-widget-btn">
                      <Link to="#" data-bs-toggle="modal" data-bs-target="#delete_modal" className="text-light-success"><span><i className="fa-solid fa-arrow-right-long" /></span></Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Settings */}
          {/* Modal Popup */}
          <div className="employees-popup add-position">
            <div className="modal fade" id="delete_modal" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="addroleLabel" aria-hidden="true">
              <div className="modal-dialog modal-dialog-centered">
                <div className="modal-content">
                  <div className="modal-header">
                    <h1 className="modal-title" id="addroleLabel">Delete Organization</h1>
                    <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close">
                      <img src={close} alt="" />
                    </button>
                  </div>
                  <div className="modal-body">
                    <div className="multistep-form">
                      <fieldset className="form-inner" id="first">
                        <div className="form-area">
                          <div className="form-details ">
                            <form action="#">
                              <div className="row">
                                <div className="col-lg-12 text-center">
                                  <div className="input-area">
                                    <span className="delete-area text-danger display-6"><i className="far fa-solid fa-trash-alt" /></span>
                                    <p className="mt-2">Are you sure you want to delete your <span className="font-weight-bold">Dreamshrms</span> Business organization?</p>
                                  </div>
                                </div>
                              </div>
                            </form>
                          </div>
                        </div>
                        <div className="btns-groups mt-0 modal-btn-group text-center">
                          <button type="submit" className="btn gradient-btn me-3" data-bs-dismiss="modal"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
                          <button type="reset" className="btn cancel-btn" data-bs-dismiss="modal">Cancel</button>
                        </div>
                      </fieldset>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Modal Popup */}
          {/* Footer */}
          <Footer />
          {/* /Footer */}
        </div>
        {/* /Page Content */}
      </div>
      {/* /Page Wrapper */}
    </div>

  )
}

export default Setting
