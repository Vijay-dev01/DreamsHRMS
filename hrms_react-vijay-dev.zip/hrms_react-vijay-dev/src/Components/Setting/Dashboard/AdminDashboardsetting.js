import React from 'react'
import Footer from '../../Footer'
import Header from '../../Header'
import { Link } from 'react-router-dom'

const AdminDashboardsetting = () => {
  return (
    <div className="main-wrapper">
    {/* Header */}
   <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper">
      {/* Page Content */}
      <div className="content container">				
        {/* Page Header */}
        <div className="employee-info">
          <div className="row align-items-center">
            <div className="col-xl-4 col-lg-5 col-sm-12 col-12">	
              <div className="settings-header">
                <h3 className="page-title">Dashboard Settings</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
              </div>	
            </div>
            <div className="col-xl-8 col-lg-7 col-sm-12 col-12">
              <div className="secure-items profile-items p-0">
                <ul>
                  <li className="active"><Link to="/admin-dashboard-setting">Admin</Link></li>
                  <li><Link to="/hr-dashboard-setting">HR</Link></li>
                  <li><Link to="/employee-dashboard-setting">Employee</Link></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        {/* /Page Header */}
        {/* Select Role */}
        <div className="settings-details notification-header admin-table-settings">
          <div className="row">
            <div className="col-lg-4 col-sm-12 col-12">
              <div className="settings-details-head">
                <div className="input-area">
                  <label>Select Role</label>
                  <select className="container p-1 rounded">
                    <option value="selected">Select Role</option>
                    <option value="Admin">Admin</option>
                    <option value="HR"> HR</option>
                    <option value="Employee">Employee</option>
                  </select>
                </div>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
              </div>
            </div>
            <div className="col-lg-8 col-sm-12 col-12">
              <div className="table-responsive">
                <table className="table table-center dashboard-table">
                  <tbody>
                    <tr className="notifi-list">
                      <td className="p-0">
                        Leave Report
                      </td>
                      <td className="pt-0">
                        <div className="status-toggle">
                          <input id="rating_1" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Leave Request
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_2" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_2" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Job Vacancy Summary
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_3" className="check" type="checkbox" />
                          <label htmlFor="rating_3" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Online Attendance
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_4" className="check" type="checkbox" />
                          <label htmlFor="rating_4" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list border-0">
                      <td>
                        Attendance Report
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_5" className="check" type="checkbox" />
                          <label htmlFor="rating_5" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list border-0">
                      <td>
                        Ticket Raised
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_6" className="check" type="checkbox" />
                          <label htmlFor="rating_6" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Events
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_7" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_7" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Recruitment
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_8" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_8" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        My Team members
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_9" className="check" type="checkbox" />
                          <label htmlFor="rating_9" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Announcement
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_10" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_10" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Working Format
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_11" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_11" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                    <tr className="notifi-list">
                      <td>
                        Employee Report
                      </td>
                      <td>
                        <div className="status-toggle">
                          <input id="rating_12" className="check" type="checkbox" defaultChecked />
                          <label htmlFor="rating_12" className="checktoggle checkbox-bg">checkbox</label>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        {/* Select Role */}
        {/* Buttons */}
        <div className="btns-groups m-0">
          <button type="submit" className="btn gradient-btn me-3"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
          <button type="submit" className="btn cancel-btn">Cancel</button>
        </div>
        {/* /Buttons */}
        {/* Footer */}
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  )
}

export default AdminDashboardsetting
