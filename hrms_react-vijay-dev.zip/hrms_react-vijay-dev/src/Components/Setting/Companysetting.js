import React from 'react'
import Header from '../Header'
import { avatar2, dropicon } from '../imagepath'
import { Link } from 'react-router-dom'
import Footer from '../Footer'

const Companysetting = () => {
  return (
   
<div className="main-wrapper">
  {/* Header */}
  <Header />
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper">
    {/* Page Content */}
    <div className="content container">				
      {/* Page Header */}
      <div className="page-header settings-header">
        <h3 className="page-title">Company Setting</h3>
        <p>Manage your account settings and preferences.</p>
      </div>
      {/* /Page Header */}
      {/* Company Address Details */}
      <div className="settings-details">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Company Setting</h6>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                do eiusmod tempor incididunt</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Company Name <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Enter Company Name" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Legal Name <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Enter Legal Name" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Company Website <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Enter Company Website" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Company Registration <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Enter Company Registration" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Company Setting */}
      {/* Company Logo settings */}
      <div className="settings-details">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Company Logo</h6>
              <p>Upload your company logo and then choose where you want it to display.</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area service-upload">
                  <span><img src={dropicon} alt="upload" /></span>
                  <div className="service-upload-content">
                    <h6 className="drop-browse align-center"><span className="text-info ms-1">Click to Replace</span>or Drag and Drop</h6>
                    <p className="text-muted">SVG, PNG, JPG (Max 800*400px)</p>	
                    <input type="file" multiple id="image_sign" />
                    <div id="frames" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Company Logo Setting */}
      {/* Company Address Details */}
      <div className="settings-details">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Company Address Details</h6>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="row">
              <div className="col-lg-12 col-md-12 col-sm-12 col-12">
                <div className="input-area">
                  <label className="form-label">Company Address <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Enter Company Address" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Country</label>
                  <select className="container p-1 rounded">
                    <option value="Afghanistan">Afghanistan</option>
                    <option value="Albania">Albania</option>
                    <option value="Algeria">Algeria</option>
                    <option value="American Samoa">American Samoa</option>
                    <option value="Andorra">Andorra</option>
                    <option value="India">India</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">State/Province</label>
                  <select className="container p-1 rounded">
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Telangana">Telangana</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">City</label>
                  <select className="container p-1 rounded">
                    <option value="Coimbatore">Coimbatore</option>
                    <option value="Chennai">Chennai</option>
                    <option value="Namakkal">Namakkal</option>
                    <option value="Salem">Salem</option>
                    <option value="Palakkad">Palakkad</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Phone Number</label>
                  <input type="number" className="form-control" placeholder="Enter Phone Number" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Mobile Number</label>
                  <input type="number" className="form-control" placeholder="Enter Mobile Number" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 col-12">
                <div className="input-area">
                  <label className="form-label">Fax</label>
                  <input type="number" className="form-control" placeholder="Enter Fax" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Company Address Details */}
      {/* Working Days */}
      <div className="settings-details">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Working Days</h6>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="table-responsive working-table">
              <table className="table table-center">
                <thead className="thead-light">
                  <tr>
                    <th>Day</th>
                    <th>Select Hours</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Monday</span>
                        <input type="checkbox" name="monday" />
                        <span className="checkmark" />
                      </label>
                    </td>
                    <td className="hours-info">
                      <div className="input-area  w-100">
                        <select className="select w-100">
                          <option selected>Custom Hours</option>
                          <option value={1}>1 Hours</option>
                          <option value={2}>2 Hours</option>
                          <option value={3}>3 Hours</option>
                          <option value={4}>4 Hours</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td className="custom-hours-time">8 Hours</td>
                  </tr>
                  <tr>
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Tuesday</span>
                        <input type="checkbox" name="tuesday" />
                        <span className="checkmark" />
                      </label>
                    </td>
                    <td className="hours-info">
                      <div className="input-area  w-100">
                        <select className="select w-100">
                          <option selected>Custom Hours</option>
                          <option value={1}>1 Hours</option>
                          <option value={2}>2 Hours</option>
                          <option value={3}>3 Hours</option>
                          <option value={4}>4 Hours</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td className="custom-hours-time">8 Hours</td>
                  </tr>
                  <tr>
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Wednesday</span>
                        <input type="checkbox" name="wednesday" />
                        <span className="checkmark" />
                      </label>
                    </td>
                    <td className="hours-info">
                      <div className="input-area  w-100">
                        <select className="select w-100">
                          <option selected>Custom Hours</option>
                          <option value={1}>1 Hours</option>
                          <option value={2}>2 Hours</option>
                          <option value={3}>3 Hours</option>
                          <option value={4}>4 Hours</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td className="custom-hours-time">8 Hours</td>
                  </tr>
                  <tr>
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Thursday</span>
                        <input type="checkbox" name="thursday" />
                        <span className="checkmark" />
                      </label>
                    </td>
                    <td className="hours-info">
                      <div className="input-area  w-100">
                        <select className="select w-100">
                          <option selected>Custom Hours</option>
                          <option value={1}>1 Hours</option>
                          <option value={2}>2 Hours</option>
                          <option value={3}>3 Hours</option>
                          <option value={4}>4 Hours</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td className="custom-hours-time">8 Hours</td>
                  </tr>
                  <tr>
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Friday</span>
                        <input type="checkbox" name="friday" />
                        <span className="checkmark" />
                      </label>
                    </td>
                    <td className="hours-info">
                      <div className="input-area  w-100">
                        <select className="select w-100">
                          <option selected>Custom Hours</option>
                          <option value={1}>1 Hours</option>
                          <option value={2}>2 Hours</option>
                          <option value={3}>3 Hours</option>
                          <option value={4}>4 Hours</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td className="custom-hours-time">8 Hours</td>
                  </tr>
                  <tr>
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Saturday</span>
                        <input type="checkbox" name="saturday" />
                        <span className="checkmark" />
                      </label>
                    </td>
                    <td className="hours-info">
                      <div className="input-area  w-100">
                        <select className="select w-100">
                          <option selected>Custom Hours</option>
                          <option value={1}>1 Hours</option>
                          <option value={2}>2 Hours</option>
                          <option value={3}>3 Hours</option>
                          <option value={4}>4 Hours</option>
                        </select>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="custom-hours d-flex">
                        <div className="input-area">
                          <select className="select">
                            <option selected>09</option>
                            <option value={9}>09</option>
                            <option value={10}>10</option>
                            <option value={11}>11</option>
                            <option value={12}>12</option>
                          </select>
                        </div>
                        <span className="hours-collan">:</span>
                        <div className="input-area">
                          <select className="select">
                            <option selected>00</option>
                            <option value={5}>05</option>
                            <option value={10}>10</option>
                            <option value={15}>15</option>
                            <option value={20}>20</option>
                          </select>
                        </div>
                      </div>
                    </td>
                    <td className="custom-hours-time">8 Hours</td>
                  </tr>
                  <tr className="non-working-group">
                    <td className="custom-day">
                      <label className="custom_check w-100">
                        <span>Sunday</span>
                        <input type="checkbox" name="sunday" />
                        <span className="checkmark" />
                      </label>
                    </td>											
                    <td className="custom-non-working">Non-Working Day</td>
                    <td>
                      <div className="non-working-list">
                        <span className="non-working-badge" />
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      {/* Working Days */}
      {/* Account Owner */}
      <div className="settings-details">
        <div className="row">
          <div className="col-lg-4">
            <div className="settings-details-head">
              <h6>Account Owner</h6>
              <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt</p>
            </div>
          </div>
          <div className="col-lg-8">
            <div className="employee-time-off-list">
              <div className="row">			
                <div className="col-sm-12">
                  <div className="card-table">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table className="table table-center table-hover">
                          <thead className="thead-light">
                            <tr>
                              <th>Employee Name</th>
                              <th>Mail ID</th>
                              <th>Phone Number</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>
                                <h2 className="table-avatar d-flex">
                                  <Link to="profile.html" className="avatar avatar-md me-2"><img className="avatar-img rounded-circle" src={avatar2} alt="User Image" /></Link>
                                  <Link to="profile.html">Richard Miles
                                    <span>BD Manager</span>
                                  </Link>
                                </h2>
                              </td>
                              <td><Link to="prfile.html">johnsmith@dgthrms.com</Link></td>
                              <td>+91 9876533422</td>
                              <td>Active</td>
                              <td><Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-edit me-2" /></Link></td>
                            </tr>															
                          </tbody>
                        </table>			
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="btns-groups">
            <button type="submit" className="btn gradient-btn me-2"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
            <button type="submit" className="btn cancel-btn">Cancel</button>
          </div>
        </div>
      </div>
      {/* Account Owner */}
      {/* Footer */}
      <Footer />
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default Companysetting
