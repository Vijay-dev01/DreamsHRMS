import React from 'react'
import { Link } from 'react-router-dom'
import Header from '../Header'
import { flogo } from '../imagepath'
import Footer from '../Footer'

const Systemsetting = () => {
  return (
   <div className="main-wrapper">
  {/* Header */}
  <Header />
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper">
    {/* Page Content */}
    <div className="content container">				
      {/* Page Header */}
      <div className="page-header settings-header">
        <h3 className="page-title">System Setting</h3>
        <p>Your company's time zone will be set as default for all new locations. However, you can select a different time zone for each individual location if necessary.</p>
      </div>
      {/* /Page Header */}
      {/* System Setting */}
      <div className="settings-info">
        <div className="row">
          <div className="col-lg-6 col-md-6 col-sm-6 col-12">
            <div className="input-area">
              <label className="form-label">Select Time Zone</label>
              <select className="container p-2 rounded">
                <option value="Alpha Time">Alpha Time Zone	UTC +4:30</option>
                <option value="India Time">India Time Zone UTC +5:30</option>
                <option value="Australian Time">Australian Central Time Zone UTC +10:30</option>
              </select>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6 col-12">
            <div className="input-area">
              <label className="form-label">Short Date Format</label>
              <select className="container p-2 rounded">
                <option value="MM/DD/YY">MM/DD/YY</option>
                <option value="DD/MM/YY">DD/MM/YY</option>
                <option value="YY/MM/DD">YY/MM/DD</option>
              </select>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6 col-12">
            <div className="input-area">
              <label className="form-label">First Day of the Week</label>
              <select className="container p-2 rounded">
                <option value="selected">Select Day</option>
                <option value="Day 1">Day 1</option>
                <option value="Day 2">Day 2</option>
                <option value="Day 3">Day 3</option>
              </select>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6 col-12">
            <div className="input-area">
              <label className="form-label">Time format</label>
              <select className="container p-2 rounded">
                <option value="selected">Select Time format</option>
                <option value="YYYY-MM-DD HH:MI:SS">YYYY-MM-DD HH:MI:SS</option>
                <option value="YYYY-MM-DD HH:MI:SS"> YYYY-MM-DD HH:MI:SS</option>
                <option value="YYYY-MM-DD hh:mm:ss[.nnnnnnn]">YYYY-MM-DD hh:mm:ss[.nnnnnnn]</option>
              </select>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6 col-12">
            <div className="input-area">
              <label className="form-label">Language</label>
              <select className="container p-2 rounded">
                <option value="selected">Select Language</option>
                <option value="English">English</option>
                <option value="Hindi"> Hindi</option>
                <option value="Tamil">Tamil</option>
              </select>
            </div>
          </div>
          <div className="col-lg-6 col-md-6 col-sm-6 col-12">
            <div className="input-area">
              <label className="form-label">Currency</label>
              <select className="container p-2 rounded">
                <option value="selected">Select Currency</option>
                <option value="Dollars">Dollars</option>
                <option value="Rupees"> Rupees</option>
                <option value="Cents">Cents</option>
              </select>
            </div>
          </div>
        </div>
      </div>
      {/* Company Setting */}
      {/* Company Logo settings */}
      <div className="settings-info">
        <div className="settings-list">
          <div className="check-mark-status d-flex align-center justify-content-between">
            <div>
              <h6 className="label-text">Apply Preferred Time Zone?</h6>
              <p>Enable your Team Members to view all times in their preferred Time Zone (set on the Team Member’s profile). Default is your Organization’s time zone, above.</p>
            </div>
            <div className="status-toggle">
              <input id="rating_1" className="check" type="checkbox" defaultChecked />
              <label htmlFor="rating_1" className="checktoggle checkbox-bg">checkbox</label>
            </div>
          </div>
        </div> 
        <div className="settings-list">
          <div className="check-mark-status d-flex align-center justify-content-between">
            <div>
              <h6 className="label-text">Format Durations as Numbers</h6>
              <p>Display durations in number format like 5.5hrs? If disabled, durations will be displayed in time format like 5h 30m.</p>
            </div>
            <div className="status-toggle">
              <input id="rating_2" className="check" type="checkbox" defaultChecked />
              <label htmlFor="rating_2" className="checktoggle checkbox-bg">checkbox</label>
            </div>
          </div>
        </div>
        <div className="btns-groups">
          <button type="submit" className="btn gradient-btn me-3"><span className="me-2"><i className="fa-solid fa-check" /></span>Save Changes</button>
          <button type="submit" className="btn cancel-btn">Cancel</button>
        </div>
      </div>
      {/* System Setting */}
      {/* Footer */}
        <Footer />
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
</div>

  )
}

export default Systemsetting
