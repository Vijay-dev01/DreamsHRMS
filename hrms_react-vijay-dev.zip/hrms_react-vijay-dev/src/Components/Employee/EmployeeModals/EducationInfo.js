import React, { useEffect, useState } from "react";

import {
  FieldArray,
  Formik,
  useFormik,
  Field,
  Form,
  ErrorMessage,
} from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASEURL } from "../../apiPath/baseUrl";
import { postData, getDecryptedData } from "../../services/apiUrl";
import { Select } from "@mui/material";
// import { Formik, Field, Form, ErrorMessage, FieldArray } from "formik";

// user_id:1
// college_name:Abc
// degree:1
// specialization:test specializtion
// gpa:88
// start_year:
// end_year:
// created_by:1

export default function EducationInfo({ addnew, setAddnew }) {
  const [data, setData] = useState();
  const [educationShow, setEducationShow] = useState(false);
  // const formik = useFormik({
  //   initialValues: {
  //     degree: "",
  //     specialization: "",
  //     gpa: "",
  //     start_year: "",
  //     end_year: "",
  //     college_name: "",
  //   },
  //   validationSchema: Yup.object({
  //     // degree: Yup.string().required("Required!"),
  //     // gpa: Yup.string().required("Required!"),
  //   }),

  //   onSubmit: (values) => {
  //     setAddnew("field-5");
  //     console.log(values, "123456789");
  //     setData(values);
  //     const EducationalInfo = async () => {
  //       const educationalinfodata = {
  //         degree: values.degree,
  //         specialization: values.specialization,
  //         end_year: values.end_year,
  //         gpa: values.gpa,
  //         start_year: values.start_year,
  //         college_name: values.college_name,
  //       };
  //       console.log(educationalinfodata, "educationinfo");
  //       postData("EducationalInfo", educationalinfodata, (data, res) => {
  //         console.log(data, "personalinfo");
  //       });
  //     };
  //     EducationalInfo();
  //   },
  // });

  useEffect(() => {
    // addeducation();
  });
  const initialValues = {
    Education: [
      {
        degree: "",
        specialization: "",
        end_year: "",
        gpa: "",
        start_year: "",
        college_name: "",
      },
    ],
  };
  const validateSchema = Yup.object().shape({
    Education: Yup.array().of(
      Yup.object({
        degree: Yup.string().required("Required!"),
        gpa: Yup.string().required("Required!"),
      })
    ),
  });
  const sucessCallBack = (data, res) => {
   
    if (data?.status == true) {
       setAddnew("field-5");
    }
  };

  const add_education = (id) => {
    console.log(id.Education, "addd");
    postData("AddEducationalInfo", id.Education, sucessCallBack);
  };
  return (
    <fieldset
      className={`${addnew == "field-4" ? "d-black" : "d-none"}`}
      id="field4"
    >
      {" "}
      <Formik
        initialValues={initialValues}
        validateSchema={validateSchema}
        onSubmit={async (values) => {
          add_education(values);
        }}
      >
        {({ values }) => (
          <Form>
            <FieldArray name="Education">
              {({ push }) => (
                <>
                  {values.Education.length > 0 &&
                    values.Education.map((friend, index) => (
                      <div className="form-area">
                        {index < 2 ? (
                          <>
                            {" "}
                            <h2>Educational Information</h2>
                            <div className="form-details ">
                              {index < 1 ? (
                                <div className="title-btn">
                                  <h4>Education Qualification</h4>
                                  <a
                                    type="submit"
                                    onClick={() =>
                                      push({
                                        degree: "  ",
                                        specialization: "",
                                        end_year: "    ",
                                        gpa: "",
                                        start_year: "",
                                        college_name: "",
                                      })
                                    }
                                  >
                                    <i className="fa-solid fa-plus" /> Add More
                                  </a>
                                </div>
                              ) : (
                                ""
                              )}

                              <form>
                                <div className="row" key={index}>
                                  <div
                                    className="col-lg-4 col-md-6 col-sm-6 "
                                    htmlFor={`Education.${index}.degree`}
                                  >
                                    <div className="input-area">
                                      <label className="form-label">
                                        Degree Name
                                        <span>*</span>
                                      </label>
                                      <Field
                                        name={`Education.${index}.degree`}
                                        className="form-control"
                                        placeholder="Enter Name of Institution"
                                      />
                                      {/* <option>Select Degree Name</option>
                                        <option>2</option>
                                        <option>3</option> */}
                                      <div style={{ color: "red" }}>
                                        <ErrorMessage
                                          name={`Education.${index}.degree`}
                                          className="field-error"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    className="col-lg-4 col-md-6 col-sm-6 "
                                    htmlFor={`Education.${index}.specialization`}
                                  >
                                    <div className="input-area">
                                      <label className="form-label">
                                        Specialization
                                      </label>
                                      <select
                                        name={`Education.${index}.specialization`}
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter your Academic course"
                                      >
                                        <option>Select Specialization</option>
                                        <option>1</option>
                                        <option>2</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div
                                    className="col-lg-4 col-md-6 col-sm-6 "
                                    htmlFor={`Education.${index}.college_name`}
                                  >
                                    <div className="input-area">
                                      <label className="form-label">
                                        University Name
                                      </label>
                                      <input
                                        name={`Education.${index}.college_name`}
                                        type="text"
                                        className="form-control"
                                        placeholder="Enterunivercity Name"
                                      />
                                    </div>
                                  </div>
                                  <div
                                    className="col-lg-4 col-md-6 col-sm-6 "
                                    htmlFor={`Education.${index}.gpa`}
                                  >
                                    <div className="input-area">
                                      <label className="form-label">
                                        GPA
                                        <span>*</span>
                                      </label>
                                      <Field
                                        type="text"
                                        name={`Education.${index}.gpa`}
                                        className="form-control"
                                        placeholder="Enter GPA"
                                      />
                                      <div style={{ color: "red" }}>
                                        <ErrorMessage
                                          name={`Education.${index}.gpa`}
                                          className="field-error"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div
                                    className="col-lg-4 col-md-6 col-sm-6 "
                                    htmlFor={`Education.${index}.start_year`}
                                  >
                                    <div className="input-area date-select">
                                      <label className="form-label">
                                        Start Year
                                      </label>
                                      <Field
                                        name={`Education.${index}.start_year`}
                                        type="date"
                                        className="form-control datetimepicker"
                                        placeholder="DDMMYY"
                                      />
                                    </div>
                                  </div>
                                  <div
                                    className="col-lg-4 col-md-6 col-sm-6 "
                                    htmlFor={`Education.${index}.end_year`}
                                  >
                                    <div className="input-area date-select">
                                      <label className="form-label">
                                        End Date
                                      </label>
                                      <Field
                                        name={`Education.${index}.end_year`}
                                        type="date"
                                        className="form-control datetimepicker"
                                        placeholder="DDMMYY"
                                      />
                                    </div>
                                  </div>
                                </div>
                              </form>
                            </div>
                          </>
                        ) : (
                          ""
                        )}
                      </div>
                    ))}
                </>
              )}
            </FieldArray>
            <div className="add-form-btn widget-next-btn submit-btn">
              <div className="btn-left">
                <button
                  type="submit"
                  className="btn  main-btn next_btn"
                  // onClick={() => focusInput()}
                >
                  Save &amp; Next
                </button>
                <a className="btn close-btn me-0">Cancel</a>
              </div>
              <div className="btn-right">
                <button
                  type="submit"
                  onClick={() => setAddnew("field-2")}
                  className="btn close-btn prev_btn back-btn me-0"
                >
                  <i className="feather-chevron-left" /> Back
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </fieldset>
  );
}
