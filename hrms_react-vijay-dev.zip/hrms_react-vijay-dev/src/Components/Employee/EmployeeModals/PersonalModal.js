import React, { useEffect, useRef, useState } from "react";
import * as Yup from "yup";
import parse from "date-fns/parse";
import avatar1 from "../../assets/img/profiles/avatar-01.jpg";
import { getDecryptedData, postData } from "../../services/apiUrl";
import { Formik, Field, Form, ErrorMessage, FieldArray } from "formik";

export default function PersonalModal({ addnew, setAddnew }) {
  const [data, setData] = useState();
  const inputElement = useRef();
  const [personaldata, setPersonaldata] = useState(false);
  const initialValues = {
    personal: [
      {
        first_name: "",
        last_name: "",
        dob: "",
        email: "",
        relation_first_name: "",
        relation_last_name: "",
        relation_email_address: "",
        phone_number: "",
        relationship: "",
      },
    ],
  };

  const validateSchema = Yup.object().shape({
    personal: Yup.array().of(
      Yup.object().shape({
        dob: Yup.string().required("Required!"),
        first_name:  Yup.string().required("Required!"),
        last_name: Yup.string().required("Required!") ,
        relation_first_name: Yup.string().required("Required!"),
        relation_last_name: Yup.string().required("Required!"),
        relation_email_address: Yup.string().required("Required!"),
        phone_number: Yup.string().required("Required!"),
        relationship: Yup.string().required("Required!"),
      })
    ),
  });


  const add_Employee = (values) => {
    const newArray = JSON.parse(JSON.stringify(values.personal));
    let res = newArray.forEach(
      (
        { relation_first_name, relation_last_name, phone_number, relationship },
        idx,
        arr
      ) =>
        (arr[idx] = {
          relation_first_name,
          relation_last_name,
          phone_number,
          relationship,
        })
    );
    const payload = [
      {
        first_name: values.personal[0].first_name,
        last_name: values.personal[0].last_name,
        dob: values.personal[0].dob,
        email: values.personal[0].email,
        emergency: newArray,
      },
    ];
    console.log(payload, "payload");
    postData("add-employee", payload, sucessCallBack);
  };

  const sucessCallBack = (data, res) => {
    if (data?.status == true) {
      setAddnew("field-2");
    }
  };

  return (
    <fieldset
      className={`${addnew == "field" ? "d-black" : "d-none"} `}
      id="field1"
    >
      <Formik
        initialValues={initialValues}
        validationSchema={validateSchema}
        onSubmit={async (values) => {
          add_Employee(values);
        }}
      >
        {({ values }) => (
          <Form>
            <FieldArray name="personal">
              {({ push }) => (
                <>
                  {values.personal.length > 0 &&
                    values.personal.map((data, index) => (
                      <div className="form-area">
                        {index < 1 ? (
                          <>
                            {" "}
                            <h2>Personal Information</h2>
                            <div className="form-details">
                              <h4>Basic Information</h4>
                              <div className="profile_pic">
                                <h5>Profile picture</h5>
                                <div class="d-flex justify-content-start align-items-center profile-wrap">
                                  <div class="profile-pic">
                                    <a href="#">
                                      <img
                                        style={{ borderRadius: "12px" }}
                                        src={avatar1}
                                        width="80"
                                        height="80"
                                        alt=""
                                      />
                                    </a>
                                  </div>
                                  <div
                                    class="profile-info"
                                    style={{ marginLeft: "14px" }}
                                  >
                                    <button class="btn btn-primary">
                                      Upload new picture
                                    </button>

                                    <button class="btn btn-transparant">
                                      Delete
                                    </button>
                                    <p>
                                      Image Should be minimum 152 * 152
                                      Supported File format JPG,PNG,SVG
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <div className="row">
                                <div
                                  className="col-lg-4 col-md-6 col-sm-6 "
                                  htmlFor={`personal.${index}.first_name`}
                                >
                                  <div className="input-area">
                                    <label className="form-label">
                                      First Name <span>*</span>
                                    </label>
                                    <Field
                                      type="text"
                                      name={`personal.${index}.first_name`}
                                      className="form-control"
                                      placeholder="Enter Emp First Name"
                                    />
                                    <div style={{ color: "red" }}>
                                      <ErrorMessage
                                        name={`personal.${index}.first_name`}
                                        className="field-error"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div
                                  className="col-lg-4 col-md-6 col-sm-6 "
                                  htmlFor={`personal.${index}.last_name`}
                                >
                                  <div className="input-area">
                                    <label className="form-label">
                                      Last Name <span>*</span>
                                    </label>
                                    <Field
                                      type="text"
                                      name={`personal.${index}.last_name`}
                                      className="form-control"
                                      placeholder="Enter Emp Last Name"
                                    />
                                    <div style={{ color: "red" }}>
                                      <ErrorMessage
                                        name={`personal.${index}.last_name`}
                                        className="field-error"
                                      />
                                    </div>
                                  </div>
                                </div>
                                <div
                                  className="col-lg-4 col-md-6 col-sm-6 "
                                  htmlFor={`personal.${index}.email`}
                                >
                                  <div className="input-area">
                                    <label className="form-label">
                                      Email Address
                                    </label>
                                    <Field
                                      className="form-control"
                                      type="text"
                                      name={`personal.${index}.email`}
                                    />
                                  </div>
                                </div>

                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">Gender</label>
                                    <select
                                      className="form-select select"
                                      type="text"
                                      name="gender"
                                    >
                                      <option selected>
                                        Open this select menu
                                      </option>
                                      <option value={1}>male</option>
                                      <option value={2}>female</option>
                                      <option value={3}>other</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Marital Status{" "}
                                    </label>
                                    <select
                                      className="form-select select"
                                      name="Martialstatus"
                                    >
                                      <option selected>
                                        Select Marital Status
                                      </option>
                                      <option value={1}>Single</option>
                                      <option value={2}>Married</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Nationality{" "}
                                    </label>
                                    <select
                                      className="form-select select"
                                      name="nationality"
                                    >
                                      <option selected>
                                        Select Nationality
                                      </option>
                                      <option value={1}>Indian</option>
                                      <option value={2}>Others</option>
                                    </select>
                                  </div>
                                </div>
                                <div
                                  className="col-lg-4 col-md-6 col-sm-6 "
                                  htmlFor={`personal.${index}.dob`}
                                >
                                  <div className="input-area date-select">
                                    <label className="form-label">
                                      Date of Birth <span>*</span>
                                    </label>
                                    <Field
                                      type="date"
                                      data-date-format="YYYY MMMM DD"
                                      name={`personal.${index}.dob`}
                                      className="form-control datetimepicker"
                                      placeholder="DDMMYY"
                                    />{" "}
                                    <div style={{ color: "red" }}>
                                      <ErrorMessage
                                        name={`personal.${index}.dob`}
                                        className="field-error"
                                      />
                                    </div>
                                    <span className="icon">
                                      {" "}
                                      {/* <i className="feather-calendar" />{" "} */}
                                    </span>
                                  </div>
                                </div>

                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">State</label>
                                    <select
                                      className="form-select select"
                                      name="state"
                                    >
                                      <option selected>Select State</option>
                                      <option value={1}>Tamil Nadu</option>
                                      <option value={2}>Kerala</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">City</label>
                                    <select
                                      className="form-select select"
                                      name="city"
                                    >
                                      <option selected>Select city</option>
                                      <option value={1}>Mumbai</option>
                                      <option value={2}>Chennai</option>
                                    </select>
                                  </div>
                                </div>

                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Personal Email
                                    </label>
                                    <input
                                      type="email"
                                      name="personal_email"
                                      className="form-control"
                                      placeholder="personal Email"
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Blood Group
                                    </label>
                                    <select
                                      className="form-select select"
                                      type="text"
                                      name="blood_group"
                                    >
                                      <option selected>
                                        Open this select menu
                                      </option>
                                      <option value={1}>o+</option>
                                      <option value={2}>o-</option>
                                      <option value={3}>AB+</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        ) : (
                          ""
                        )}

                        {index < 2 ? (
                          <>
                            <div className="row" key={index}>
                              {index < 1 ? (
                                <div className="form-details">
                                  <div className="title-btn">
                                    <h4>Emergency Information</h4>
                                    <a
                                      onClick={() =>
                                        push({
                                          relation_first_name: "",
                                          relation_last_name: "",
                                          relation_email_address: "",
                                          phone_number: "",
                                          relationship: "",
                                        })
                                      }
                                    >
                                      <i className="fa-solid fa-plus" />{" "}
                                      {personaldata ? "close" : "Add More"}
                                    </a>
                                  </div>
                                </div>
                              ) : (
                                ""
                              )}

                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`personal.${index}.relation_first_name`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    First Name <span>*</span>{" "}
                                  </label>
                                  <Field
                                    type="text"
                                    name={`personal.${index}.relation_first_name`}
                                    className="form-control"
                                    placeholder="Enter Full Name"
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`personal.${index}.relation_first_name`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`personal.${index}.relation_last_name`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Last Name <span>*</span>
                                  </label>
                                  <Field
                                    type="text"
                                    className="form-control"
                                    name={`personal.${index}.relation_last_name`}
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`personal.${index}.relation_last_name`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>

                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`personal.${index}.relationship`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Relationship <span>*</span>
                                  </label>
                                  <Field
                                    type="select"
                                    className="form-control"
                                    // name="relationship"
                                    name={`personal.${index}.relationship`}
                                    placeholder="enter relationship"
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`personal.${index}.relationship`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`personal.${index}.phone_number`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Phone Number<span>*</span>
                                  </label>
                                  <Field
                                    type="text"
                                    // name="phone_number"
                                    name={`personal.${index}.phone_number`}
                                    className="form-control"
                                    placeholder="Enter Phone Number"
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`personal.${index}.phone_number`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`personal.${index}.relation_email_address`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Email Address<span>*</span>
                                  </label>
                                  <Field
                                    type="text"
                                    name={`personal.${index}.relation_email_address`}
                                    // name="relation_relation_email_address"
                                    className="form-control"
                                    placeholder="personal Email"
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`personal.${index}.relation_email_address`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        ) : (
                          ""
                        )}
                      </div>
                    ))}
              
                </>
              )}
            </FieldArray>
            <div className="add-form-btn widget-next-btn submit-btn">
                    <div className="btn-left">
                      <button type="submit"  
                      className="btn  main-btn next_btn">
                        Save &amp; Next
                      </button>
                      <a className="btn close-btn me-0">Cancel</a>
                    </div>
                  </div>
          </Form>
        )}
      </Formik>
    </fieldset>
  );
}
