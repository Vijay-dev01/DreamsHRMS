import React, { useEffect, useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASEURL } from "../../apiPath/baseUrl";
import { postData } from "../../services/apiUrl";

export default function DocumentModal({ addnew, setAddnew }) {
  const [data, setData] = useState();
  const [close, setclose] = useState("");
  console.log(close, "modal");
  const formik = useFormik({
    initialValues: {
      ID_proof: "",
      Address_proof: "",
      Letter_of_Indent: "",
      Experience_certificate: "",
      Degress_certificate: "",
      Course_completion: "",
    },
    validationSchema: Yup.object({
      ID_proof: Yup.string().required("Required!"),
      Address_proof: Yup.string().required("Required!"),
      Letter_of_Indent: Yup.string().required("Required!"),
      Experience_certificate: Yup.string().required("Required!"),
      Degress_certificate: Yup.string().required("Required!"),
      Course_completion: Yup.string().required("Required!"),
    }),

    onSubmit: (values) => {
      setData(values);
      setclose("modal");
      // setAddnew("field")
      const personalDocument =()=>{
        const Document = {
          ID_proof: values.ID_proof,
          Address_proof: values.Address_proof,
          Letter_of_Indent: values.Letter_of_Indent,
          Experience_certificate: values.Experience_certificate,
          Degress_certificate: values.Degress_certificate,
          Course_completion:values.Course_completion
        }
        postData("document", Document, (data, res) => {
          console.log(data, "document");
        });
      }
      personalDocument();
    },
  });
  // const personalDocument = async () => {
  //   try {
  //     const response = axios.post(`${BASEURL}document` + data);
  //     console.log("response", response);
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };


  useEffect(() => {
    // personalDocument();
  });
  function handleChange(event) {
    console.log(`Selected file - ${event.target.files[0].name}`);
  }
  return (
    <fieldset
      className={`${addnew == "field-5" ? "d-black" : "d-none"}`}
      id="field5"
    >
      <div className="form-area">
        <h2>Documents</h2>
        <div className="form-details">
          <form onSubmit={formik.handleSubmit}>
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6 ">
                <div className="input-area file-choose">
                  <label className="form-label">
                    ID Proof<span>*</span>
                  </label>
                  <input
                    className="form-control file-input"
                    type="file"
                    id="formFile"
                    name="ID_proof"
                    value={formik.values.ID_proof}
                    onChange={formik.handleChange}
                  />
                  <input
                    type="hidden"
                    name="MAX_FILE_SIZE"
                    defaultValue={10485760}
                  />

                  <span className="choose-file">
                    Choose file
                    <span className="choose-btn">Choose file</span>
                  </span>
                  <div className="upload-message">
                    <div>
                      <h5>
                        <i className="fa-solid fa-check" /> PAN-001.jpg
                        <span>uploaded successfully!!!</span>
                      </h5>
                    </div>
                    <div className="download-icon">
                      <i className="feather-download" />
                      <i className="feather-trash" />
                    </div>
                  </div>
                  {formik.errors.ID_proof && formik.touched.ID_proof && (
                    <p style={{ color: "red" }}>{formik.errors.ID_proof}</p>
                  )}
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 ">
                <div className="input-area file-choose">
                  <label className="form-label">
                    Address Proof<span>*</span>
                  </label>
                  <input
                    className="form-control file-input"
                    type="file"
                    id="formFile"
                    name="Address_proof"
                    value={formik.values.Address_proof}
                    onChange={formik.handleChange}
                  />
                  <input
                    type="hidden"
                    name="MAX_FILE_SIZE"
                    defaultValue={10485760}
                  />
                  <span className="choose-file">
                    Choose file
                    <span className="choose-btn">Choose File</span>
                  </span>
                </div>
                {formik.errors.Address_proof &&
                  formik.touched.Address_proof && (
                    <p style={{ color: "red" }}>
                      {formik.errors.Address_proof}
                    </p>
                  )}
              </div>
      
              <div className="col-lg-6 col-md-6 col-sm-6 ">
                <div className="input-area file-choose">
                  <label className="form-label">
                    Letter of Indent<span>*</span>
                  </label>
                  <input
                    className="form-control file-input"
                    type="file"
                    id="formFile"
                    name="Letter_of_Indent"
                    value={formik.values.Letter_of_Indent}
                    onChange={formik.handleChange}
                  />

                  <input
                    type="hidden"
                    name="MAX_FILE_SIZE"
                    defaultValue={10485760}
                  />
                  <span className="choose-file">
                    Choose file
                    <span className="choose-btn">Choose File</span>
                  </span>

                  <div className="upload-message">
                    <div>
                      <h5>
                        <i className="fa-solid fa-check" /> PAN-001.jpg
                        <span>uploaded successfully!!!</span>
                      </h5>
                    </div>
                    <div className="download-icon">
                      <i className="feather-download" />
                      <i className="feather-trash" />
                    </div>
                  </div>
                  {formik.errors.Letter_of_Indent &&
                    formik.touched.Letter_of_Indent && (
                      <p style={{ color: "red" }}>
                        {formik.errors.Letter_of_Indent}
                      </p>
                    )}
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 ">
                <div className="input-area file-choose">
                  <label className="form-label">
                    Experience Certificate<span>*</span>
                  </label>
                  <input
                    className="form-control file-input"
                    type="file"
                    id="formFile"
                    name="Experience_certificate"
                    value={formik.values.Experience_certificate}
                    onChange={formik.handleChange}
                  />

                  <input
                    type="hidden"
                    name="MAX_FILE_SIZE"
                    defaultValue={10485760}
                  />

                  <span className="choose-file">
                    Choose file
                    <span className="choose-btn">Choose File</span>
                  </span>
                </div>
                {formik.errors.Experience_certificate &&
                  formik.touched.Experience_certificate && (
                    <p style={{ color: "red" }}>
                      {formik.errors.Experience_certificate}
                    </p>
                  )}
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 ">
                <div className="input-area file-choose">
                  <label className="form-label">
                    Certificate/Diploma/Degress Certificate
                    <span>*</span>
                  </label>
                  <input
                    className="form-control file-input"
                    type="file"
                    id="formFile"
                    name="Degress_certificate"
                    value={formik.values.Degress_certificate}
                    onChange={formik.handleChange}
                  />
                  <input
                    type="hidden"
                    name="MAX_FILE_SIZE"
                    defaultValue={10485760}
                  />

                  <span className="choose-file">
                    Choose file
                    <span className="choose-btn">Choose File</span>
                  </span>
                </div>
                {formik.errors.Degress_certificate &&
                  formik.touched.Degress_certificate && (
                    <p style={{ color: "red" }}>
                      {formik.errors.Degress_certificate}
                    </p>
                  )}
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6 ">
                <div className="input-area file-choose">
                  <label className="form-label">
                    Course Completion Copy
                    <span>*</span>
                  </label>
                  <input
                    className="form-control file-input"
                    type="file"
                    id="formFile"
                    name="Course_completion"
                    value={formik.values.Course_completion}
                    onChange={formik.handleChange}
                  />
                  <input type="hidden" defaultValue={10485760} />
                  <span className="choose-file">
                    Choose file
                    <span className="choose-btn">Choose File</span>
                  </span>
                </div>

                {formik.errors.Course_completion &&
                  formik.touched.Course_completion && (
                    <p style={{ color: "red" }}>
                      {formik.errors.Course_completion}
                    </p>
                  )}
              </div>
            </div>
            <div className="add-form-btn widget-next-btn submit-btn">
              <div className="btn-left">
                <button
                  // onClick={() => handlesave("field","field5")}
                  type="submit"
                  className="btn  main-btn "
                  data-bs-dismiss={`${close}`}
                  // aria-label="Close"
                >
                  Save &amp; Next
                </button>
                <a className="btn close-btn me-0">Cancel</a>
              </div>
              <div className="btn-right">
                <a onClick={()=>setAddnew("field-4")} className="btn close-btn prev_btn back-btn me-0">
                  <i className="feather-chevron-left"  /> Back
                </a>
              </div>
            </div>
          </form>
        </div>
      </div>
    </fieldset>
  );
}
