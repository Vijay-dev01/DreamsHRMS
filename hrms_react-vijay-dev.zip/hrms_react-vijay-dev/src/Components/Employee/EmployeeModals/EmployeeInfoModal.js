import React, { useEffect, useRef, useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { BASEURL } from "../../apiPath/baseUrl";
import { DataEncrpt, postData, getDecryptedData } from "../../services/apiUrl";

export default function EmployeeInfoModal({ addnew, setAddnew }) {
  const [data, setData] = useState();
  const inputElement = useRef();
  //   Employee personal info: request
  // employee_id:DE155
  // effective_date:2023-04-04
  // shift_id:1
  // shift_time:05:00:00
  // department_id:1
  // position_name:Test
  // grade:A
  const formik = useFormik({
    initialValues: {
      employee_id: "",
      effective_date: "",
      employement_type: "",
      shift_id: "",
      shift_time: "",
      status: "",
      probation_period: "",
      probation_start_date: "",
      probation_end_date: "",
      position_name: "",
      line_manager: "",
      grade: "",
      department_id: "1",
    },
    validationSchema: Yup.object({
      employee_id: Yup.string().required("Required!"),
      effective_date: Yup.string().required("Required!"),
      shift_id: Yup.string().required("Required!"),
      shift_time: Yup.string().required("Required!"),
      position_name: Yup.string().required("Required!"),
      grade: Yup.string().required("Required!"),
      department_id: Yup.string().required("Required!"),
    }),
    onSubmit: (values) => {
      console.log(values, "123456789");
      setData(values);
      const employeeinfo = async () => {
        const employeeinfodata = {
          employee_id: values.employee_id,
          effective_date: values.effective_date,
          shift_id: values.shift_id,
          shift_time: values.shift_time,
          // probation_period:values.probation_period,
          // probation_start_date: values.probation_start_date,
          position_name: values.position_name,
          department_id: values.department_id,
          grade: values.grade,
        };

        /*      employee_id:DE155
        effective_date:2023-04-04
        shift_id:1
        shift_time:05:00:00
        department_id:1
        position_name:Test
        grade:A
 */
        console.log(employeeinfodata, "employeeinfodata");
        postData("employee_info", employeeinfodata, sucessCallBack);
      };
      employeeinfo();
    },
  });
  const sucessCallBack = (data, res) => {
    if (data.status == true) {
       
      setAddnew("field-3");
    }
  };

  console.log(addnew, "field");
  return (
    <fieldset
      className={`${addnew == "field-2" ? "d-black" : "d-none"} `}
      id="field2"
    >
      <div className="form-area">
        <h2>Employee Informations</h2>
        <div className="form-details ">
          <h4>Basic Information</h4>
          <form action="#" onSubmit={formik.handleSubmit}>
            <div className="row">
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">
                    Employee ID<span>*</span>
                  </label>
                  <input
                    ref={inputElement}
                    type="text"
                    //   onChange={(e) => handleemployee(e)}
                    name="employee_id"
                    className="form-control"
                    placeholder="Enter Emp ID"
                    value={formik.values.employee_id}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.employee_id && formik.touched.employee_id && (
                    <p style={{ color: "red" }}>{formik.errors.employee_id}</p>
                  )}
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area date-select">
                  <label className="form-label">
                    Effective Date <span>*</span>
                  </label>
                  <input
                    ref={inputElement}
                    type="date"
                    data-date-format="YYYY MMMM DD"
                    //   onChange={(e) => handleemployee(e)}
                    name="effective_date"
                    className="form-control datetimepicker"
                    placeholder="DDMMYY"
                    value={formik.values.effective_date}
                    onChange={formik.handleChange}
                  />
                  {formik.errors.effective_date &&
                    formik.touched.effective_date && (
                      <p style={{ color: "red" }}>
                        {formik.errors.effective_date}
                      </p>
                    )}
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">Employment Type</label>
                  <select
                    className="form-select select"
                    name="employement_type"
                    //   onChange={(e) => handleemployee(e)}
                    value={formik.values.employement_type}
                    onChange={formik.handleChange}
                    ref={inputElement}
                  >
                    <option selected>Select Employment Type</option>
                    <option value={1}>One</option>
                    <option value={2}>Two</option>
                    <option value={3}>Three</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">
                    Shift
                    <span>*</span>
                  </label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="shift_id"
                    //   onChange={(e) => handleemployee(e)}
                    value={formik.values.shift_id}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select Shift</option>
                    <option value={1}>1 Month</option>
                    <option value={2}>2 Month</option>
                  </select>

                  {formik.errors.shift_id && formik.touched.shift_id && (
                    <p style={{ color: "red" }}>{formik.errors.shift_id}</p>
                  )}
                </div>
              </div>

              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">
                    Shift Time
                    <span>*</span>
                  </label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="shift_time"
                    //   onChange={(e) => handleemployee(e)}
                    value={formik.values.shift_time}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select Shift Time</option>
                    <option value={1}>1 Month</option>
                    <option value={2}>2 Month</option>
                  </select>

                  {formik.errors.shift_time && formik.touched.shift_time && (
                    <p style={{ color: "red" }}>{formik.errors.shift_time}</p>
                  )}
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">status</label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="status"
                    //   onChange={(e) => handleemployee(e)}
                    value={formik.values.status}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select status</option>
                    <option value={1}>1 </option>
                    <option value={2}>2 </option>
                  </select>
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">Probation Period</label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="probation_period"
                    //   onChange={(e) => handleemployee(e)}
                    value={formik.values.probation_period}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select Probation Period</option>
                    <option value={1}>1 Month</option>
                    <option value={2}>2 Month</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area date-select">
                  <label className="form-label">Probation Start Date</label>
                  <input
                    ref={inputElement}
                    type="date"
                    data-date-format="YYYY MMMM DD"
                    //   onChange={(e) => handleemployee(e)}
                    className="form-control datetimepicker"
                    placeholder="DDMMYY"
                    name="probation_start_date"
                    value={formik.values.probation_start_date}
                    onChange={formik.handleChange}
                  />
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area date-select">
                  <label className="form-label">Probation End Date</label>
                  <input
                    ref={inputElement}
                    type="date"
                    data-date-format="YYYY MMMM DD"
                    //   onChange={(e) => handleemployee(e)}
                    className="form-control datetimepicker"
                    placeholder="DDMMYY"
                    name="probation_end_date"
                    value={formik.values.probation_end_date}
                    onChange={formik.handleChange}
                  />
                </div>
              </div>
              <div className="title-btn">
                <h4>JOB Information</h4>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">
                    Department<span>*</span>
                  </label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="department_id"
                    value={formik.values.department_id}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select Department</option>
                    <option value={1}>HR Department</option>
                    <option value={2}>Designing Department</option>
                  </select>
                  {formik.errors.department_id &&
                    formik.touched.department_id && (
                      <p style={{ color: "red" }}>
                        {formik.errors.department_id}
                      </p>
                    )}
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">
                    Position Type<span>*</span>
                  </label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="position_name"
                    value={formik.values.position_name}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select Position Type</option>
                    <option value={1}>Senior</option>
                    <option value={2}>Junior</option>
                  </select>
                  {formik.errors.position_name &&
                    formik.touched.position_name && (
                      <p style={{ color: "red" }}>
                        {formik.errors.position_name}
                      </p>
                    )}
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">Line Manager</label>
                  <select
                    className="form-select select"
                    name="line_manager"
                    value={formik.values.line_manager}
                    onChange={formik.handleChange}
                    ref={inputElement}
                  >
                    <option selected>Select Line Manager</option>
                    <option value={1}>1</option>
                    <option value={2}>2</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-4 col-md-6 col-sm-6 ">
                <div className="input-area">
                  <label className="form-label">
                    Grade<span>*</span>
                  </label>
                  <select
                    ref={inputElement}
                    className="form-select select"
                    name="grade"
                    value={formik.values.grade}
                    onChange={formik.handleChange}
                  >
                    <option selected>Select Employment Type</option>
                    <option value={1}>Senior</option>
                    <option value={2}>Junior</option>
                  </select>
                  {formik.errors.grade && formik.touched.grade && (
                    <p style={{ color: "red" }}>{formik.errors.grade}</p>
                  )}
                </div>
              </div>
            </div>
            <div className="add-form-btn widget-next-btn submit-btn">
              <div className="btn-left">
                <button
                  type="submit"
                  className="btn  main-btn next_btn"
                  // onClick={() => focusInput()}
                >
                  Save &amp; Next
                </button>
                <a className="btn close-btn me-0">Cancel</a>
              </div>
              <div className="btn-right">
                <a
                  onClick={() => setAddnew("field")}
                  className="btn close-btn prev_btn back-btn me-0"
                >
                  <i className="feather-chevron-left" /> Back
                </a>
              </div>
            </div>
          </form>
        </div>
      </div>
      {/* <div className="add-form-btn widget-next-btn submit-btn">
        <div className="btn-left">
          <button  type="submit"
            // onClick={() => setAddnew("field-3")}
            className="btn  main-btn next_btn"
          >
            Save &amp; Next
          </button>
          <a className="btn close-btn me-0">Cancel</a>
        </div>
        <div className="btn-right">
          <a className="btn close-btn prev_btn back-btn me-0">
            <i className="feather-chevron-left" /> Back
          </a>
        </div>
      </div> */}
    </fieldset>
  );
}
