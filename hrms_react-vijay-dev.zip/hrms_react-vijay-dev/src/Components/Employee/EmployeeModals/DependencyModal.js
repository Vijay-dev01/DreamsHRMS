import React, { useEffect, useState } from "react";
import * as Yup from "yup";
import { DataEncrpt, getDecryptedData, postData } from "../../services/apiUrl";
import { Formik, Field, Form, ErrorMessage, FieldArray } from "formik";
import cogoToast from "cogo-toast";

function DependencyModal({ addnew, setAddnew }) {
  const [data, setData] = useState([]);
  console.log(data, "data");
  const [addmore, setAddmore] = useState(false);
  const initialValues = {
    Emergency: [
      {
        first_name: "",
        last_name: "",
        email_address: "",
        phone_number: "",
      },
    ],
  };

  const validateSchema = Yup.object().shape({
    Emergency: Yup.array()
      .of(
        Yup.object().shape({
          first_name: Yup.string().required("Name is required"),
          last_name: Yup.string().required("Last Name is required"),
          phone_number: Yup.string().required("Phone number is required"),
          email_address: Yup.string()
            .email("Invalid email")
            .required("Please enter email"),
        })
      )
      .min(1, "Need at least a friend"),
  });

  const sucessCallBack = (data, res) => {
    console.log(res, "depentent");
    // Dispatch(loading(false));
    if (data?.status == true) {
      cogoToast.success(data?.success);
      setAddnew("field-4");
    } else {
      cogoToast.error(data?.error);
    }
  };
  const add_depentent = (id) => {
    postData("dependents-add", id.Emergency, sucessCallBack);
  };

  return (
    <fieldset
      className={`${addnew == "field-3" ? "d-black" : "d-none"} `}
      id="field3"
    >
      <Formik
        initialValues={initialValues}
        validationSchema={validateSchema}
        onSubmit={async (values) => {
          add_depentent(values);
        }}
      >
        {({ values }) => (
          <Form>
            <FieldArray name="Emergency">
              {({ push }) => (
                <>
                  {values.Emergency.length > 0 &&
                    values.Emergency.map((friend, index) => (
                      <div className="form-area">
                        {index < 2 ? (
                          <div className="row" key={index}>
                            <div className="form-details ">
                              {index < 1 ? (
                                <div className="title-btn">
                                  <h4>Basic Information</h4>
                                  <a
                                    onClick={() => {
                                      push({
                                        first_name: "",
                                        last_name: "",
                                        email_address: "",
                                        phone_number: "",
                                        gender: "",
                                        relationship: "",
                                      });
                                    }}
                                  >
                                    <i className="fa-solid fa-plus" />{" "}
                                    {addmore ? "close" : "Add More"}
                                  </a>
                                  {index < 1 ? "" : ""}
                                </div>
                              ) : (
                                ""
                              )}
                            </div>
                            <div className="row" key={index}>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`Emergency.${index}.first_name`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    First Name <span>*</span>
                                  </label>
                                  <Field
                                    type="text"
                                    className="form-control"
                                    placeholder="Enter Full Name"
                                    name={`Emergency.${index}.first_name`}
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`Emergency.${index}.first_name`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`Emergency.${index}.last_name`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Last Name <span>*</span>
                                  </label>
                                  <Field
                                    type="text"
                                    placeholder="Enter Full Name"
                                    className="form-select select"
                                    name={`Emergency.${index}.last_name`}
                                    // value={formik.values.last_name}
                                    // onChange={formik.handleChange}
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`Emergency.${index}.last_name`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`Emergency.${index}.gender`}
                              >
                                <div className="input-area">
                                  <label className="form-label">Gender</label>
                                  <select
                                    className="form-select select"
                                    name={`Emergency.${index}.gender`}
                                  >
                                    <option selected>Select gender</option>
                                    <option value={1}>Men</option>
                                    <option value={2}>Female</option>
                                    <option value={3}>Other</option>
                                  </select>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`Emergency.${index}.relationship`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Relationship
                                  </label>
                                  <select
                                    name={`Emergency.${index}.relationship`}
                                    className="form-select select"
                                    // value={formik.values.relationship}
                                    // onChange={formik.handleChange}
                                  >
                                    <option selected>
                                      Select relationship
                                    </option>
                                    <option>Single</option>
                                    <option>Married</option>
                                  </select>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                // htmlFor={`Emergency.${index}.phone_number`}
                              >
                                <div className="input-area date-select">
                                  <label className="form-label">
                                    Phone Number
                                    <span>*</span>
                                  </label>
                                  <Field
                                    type="tel"
                                    className="form-control datetimepicker"
                                    placeholder="phone number"
                                    name={`Emergency.${index}.phone_number`}
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`Emergency.${index}.phone_number`}
                                      className="field-error"
                                    />
                                  </div>
                                  <span className="icon">
                                    {" "}
                                    {/* <i className="feather-calendar" />{" "} */}
                                  </span>
                                </div>
                              </div>
                              <div
                                className="col-lg-4 col-md-6 col-sm-6 "
                                htmlFor={`Emergency.${index}.email_address`}
                              >
                                <div className="input-area">
                                  <label className="form-label">
                                    Email <span>*</span>{" "}
                                  </label>
                                  <Field
                                    type="email"
                                    className="form-select select"
                                    placeholder="Enter Your Email"
                                    name={`Emergency.${index}.email_address`}
                                  />
                                  <div style={{ color: "red" }}>
                                    <ErrorMessage
                                      name={`Emergency.${index}.email_address`}
                                      className="field-error"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ) : (
                          ""
                        )}
                      </div>
                    ))}
                </>
              )}
            </FieldArray>
            <div className="add-form-btn widget-next-btn submit-btn">
              <div className="btn-left">
                <button
                  type="submit"
                  className="btn  main-btn next_btn"
                  // onClick={() => focusInput()}
                >
                  Save &amp; Next
                </button>
                <a className="btn close-btn me-0">Cancel</a>
              </div>
              <div className="btn-right">
                <button
                  type="submit"
                  onClick={() => setAddnew("field-2")}
                  className="btn close-btn prev_btn back-btn me-0"
                >
                  <i className="feather-chevron-left" /> Back
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </fieldset>
  );
}

export default DependencyModal;
