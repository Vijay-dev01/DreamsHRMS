import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { allpolicies, allreports, avatar1, avatar2, avatar3, avatar5, avatar6, bar, checklist, clock, cloud, csv, down, empicon, empmenuicon, icon, logo, picon, printer, ricon, shiftschedule, sicon, ticon, timeofficon, timesheet } from '../imagepath'

const EmpImport = () => {
    // const [share, setShare] = useState(false);
    const [modal, setModal] = useState(false);
    const [nav, setNav] = useState(false);
    const [pro, setPro] = useState(false);

    const proShow = () => {
        console.log('click')
        setPro(true)
    }

    const proClose = () => {
        console.log('click')
        setPro(false)
    }
    console.log(modal);

    const navShow = () => {
        console.log('click')
        setNav(true)
    }

    const navClose = () => {
        console.log('click')
        setNav(false)
    }
    console.log(modal);

    const modalShow = () => {
        console.log('click')
        setModal(true)
    }

    const modalClose = () => {
        console.log('click')
        setModal(false)
    }
    console.log(modal);

    // const shareShow = () => {
    //     console.log('click')
    //     setShare(true)
    // }

    // const shareClose = () => {
    //     console.log('click')
    //     setShare(false)
    // }
    // console.log(share);

    const Profile = () => {
        return (
            <div className={ pro ? "dropdown-menu show" : "dropdown-menu"} style={{ display: pro ? 'block' : 'none' }} >
            <Link className="dropdown-item" to="#">
              <i className="feather-user-plus" /> My Profile
            </Link>
            <Link className="dropdown-item" to="#">
              <i className="feather-settings" /> Settings
            </Link>
            <Link className="dropdown-item" to="#">
              <i className="feather-log-out" /> Logout
            </Link>
          </div>
        )
    }

    const Notificationtab = () => {
        return (
            <div className={ nav ? "dropdown-menu dropdown-menu-end notifications show" : "dropdown-menu dropdown-menu-end notifications"} style={{ display: nav ? 'block' : 'none' }}>
            <div className="topnav-dropdown-header">
              <span className="notification-title">Notifications</span>
              <Link to="#" className="clear-noti"> Clear All</Link>
            </div>
            <div className="noti-content">
              <ul className="notification-list">
                <li className="notification-message">
                  <Link to="#">
                    <div className="media d-flex">
                      <span className="avatar flex-shrink-0">
                        <img alt src={avatar1} className="rounded-circle" />
                      </span>
                      <div className="media-body flex-grow-1">
                        <p className="noti-details"><span className="noti-title">John Doe</span>
                          added new task <span className="noti-title">Patient appointment
                            booking</span></p>
                        <p className="noti-time"><span className="notification-time">4 mins
                            ago</span></p>
                      </div>
                    </div>
                  </Link>
                </li>
                <li className="notification-message">
                  <Link to="#">
                    <div className="media d-flex">
                      <span className="avatar flex-shrink-0">
                        <img alt src={avatar2} className="rounded-circle" />
                      </span>
                      <div className="media-body flex-grow-1">
                        <p className="noti-details"><span className="noti-title">Tarah
                            Shropshire</span> changed the task name <span className="noti-title">Appointment booking with payment
                            gateway</span></p>
                        <p className="noti-time"><span className="notification-time">6 mins
                            ago</span></p>
                      </div>
                    </div>
                  </Link>
                </li>
                <li className="notification-message">
                  <Link to="#">
                    <div className="media d-flex">
                      <span className="avatar flex-shrink-0">
                        <img alt src={avatar6} className="rounded-circle" />
                      </span>
                      <div className="media-body flex-grow-1">
                        <p className="noti-details"><span className="noti-title">Misty
                            Tison</span> added <span className="noti-title">Domenic
                            Houston</span> and <span className="noti-title">Claire
                            Mapes</span> to project <span className="noti-title">Doctor
                            available module</span></p>
                        <p className="noti-time"><span className="notification-time">8 mins
                            ago</span></p>
                      </div>
                    </div>
                  </Link>
                </li>
                <li className="notification-message">
                  <Link to="#">
                    <div className="media d-flex">
                      <span className="avatar flex-shrink-0">
                        <img alt src={avatar5} className="rounded-circle" />
                      </span>
                      <div className="media-body flex-grow-1">
                        <p className="noti-details"><span className="noti-title">Rolland
                            Webber</span> completed task <span className="noti-title">Patient and Doctor video
                            conferencing</span></p>
                        <p className="noti-time"><span className="notification-time">12 mins
                            ago</span></p>
                      </div>
                    </div>
                  </Link>
                </li>
                <li className="notification-message">
                  <Link to="#">
                    <div className="media d-flex">
                      <span className="avatar flex-shrink-0">
                        <img alt src={avatar3} className="rounded-circle" />
                      </span>
                      <div className="media-body flex-grow-1">
                        <p className="noti-details"><span className="noti-title">Bernardo
                            Galaviz</span> added new task <span className="noti-title">Private chat module</span></p>
                        <p className="noti-time"><span className="notification-time">2 days
                            ago</span></p>
                      </div>
                    </div>
                  </Link>
                </li>
              </ul>
            </div>
            <div className="topnav-dropdown-footer">
              <Link to="#">View all Notifications</Link>
            </div>
          </div>
        )
    }


    const Employeetab = () => {
        return (
            
            <div onClick={modalClose}>
            <ul className={modal ? "dropdown-menu clearfix show" : "dropdown-menu clearfix"} style={{ display: modal ? 'block' : 'none' }}>
              <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
              <li className="w-100 bottom-list-menu">
                <ul className="sub-menu clearfix">
                  <li><Link to="#">Documentation</Link></li>
                  <li><Link to="#">Changelog v1.4.4</Link></li>
                  <li><Link to="#">Components</Link></li>
                  <li><Link to="#">Support</Link></li>
                  <li><Link to="#">Terms &amp; Conditions</Link></li>
                  <li><Link to="#">About</Link></li>
                </ul>
              </li>
            </ul>
            </div>
        )
    }

    const Share = () => {
        return (
            <div className= "modal fade" id="employee-import" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="employee-import" aria-hidden="true">
    <div className="modal-dialog modal-dialog-centered">
      <div className="modal-content">
        <div className="modal-header d-flex justify-content-between align-items-center">
          <div>
            <h5 className="modal-title">Import Employees</h5>
            <span>Upload a CSV to import Employee data to your CMS.</span>
          </div>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" > <i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          <Link to="#" className="btn btn-light"><img src={checklist} className="img-rounded" alt />Employee Template.xlsx</Link>
          <span className="d-block">Choose upload file</span>
          <div className="drag-drop text-center">
            <div className="upload">
              <Link to="#"><img src={csv} /></Link>
              <p>Drop your CSV, .xlx or xlsx files here or <Link to="#">Browse</Link></p>
              <span>Maximum size: 4MB</span>
            </div>
            <input type="file" multiple />
          </div>
          <div className="buttons d-flex justify-content-between">
            <div>
              <Link to="employee-import-list.html" className="btn btn-transparant flex-shrink-1"><i className="fa fa-eye" aria-hidden="true" />View Details</Link>
            </div>
            <div>
              <button type="button" className="btn gradient-btn"><i className="fa fa-upload" aria-hidden="true" />Import</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal" >Cancel</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
        )
    }

  return (
    <div class="main-wrapper">
  {/* Header */}
  <header className="header header-fixed header-one">
    <nav className="navbar navbar-expand-lg header-nav">
      <div className="navbar-header">
        <Link id="mobile_btn" to="#">
          <span className="bar-icon">
            <span />
            <span />
            <span />
          </span>
        </Link>
        <Link to="#" className="navbar-brand logo">
          <img src={logo} className="img-fluid" alt="Logo" />
        </Link>
      </div>
      <div className="main-menu-wrapper">
        <ul className="main-nav">
          <li>
            <Link to="#">
              <img src={icon} alt /> Dashboard
            </Link>
          </li>
          <li className="active">
            <Link to="employees.html">
              <img src={empicon} alt /> Employees
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={ticon} alt /> Time off
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={picon} alt /> Policies
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={ricon} alt /> Reports
            </Link>
          </li>
        </ul>
        <ul className="nav header-navbar-rht">
          <li className="nav-item search-item">
            <div className="top-nav-search">
              <form action="#">
                <input type="text" className="form-control" placeholder="Search" />
                <button className="btn" type="submit"><i className="feather-search" /></button>
                <span><img src={sicon} alt /></span>
              </form>
            </div>
          </li>
          <li className="nav-item quick-link-item dropdown">
            <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false" onClick={modalShow}>
              <span>Quick Links <i className="feather-zap" /></span>
            </Link>
            {<Employeetab/>}
            {/* <ul className="dropdown-menu clearfix">
              <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
              <li className="w-100 bottom-list-menu">
                <ul className="sub-menu clearfix">
                  <li><Link to="#">Documentation</Link></li>
                  <li><Link to="#">Changelog v1.4.4</Link></li>
                  <li><Link to="#">Components</Link></li>
                  <li><Link to="#">Support</Link></li>
                  <li><Link to="#">Terms &amp; Conditions</Link></li>
                  <li><Link to="#">About</Link></li>
                </ul>
              </li>
            </ul> */}
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="feather-sun" />
            </Link>
          </li>
          <li className="nav-item dropdown has-arrow notification-dropdown">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown" onClick={navShow}>
              <i className="feather-bell" />
              <span className="badge">3</span>
            </Link>
            {<Notificationtab/>}
            {/* <div className="dropdown-menu dropdown-menu-end notifications">
              <div className="topnav-dropdown-header">
                <span className="notification-title">Notifications</span>
                <Link to="#" className="clear-noti"> Clear All</Link>
              </div>
              <div className="noti-content">
                <ul className="notification-list">
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar1} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">John Doe</span>
                            added new task <span className="noti-title">Patient appointment
                              booking</span></p>
                          <p className="noti-time"><span className="notification-time">4 mins
                              ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar2} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Tarah
                              Shropshire</span> changed the task name <span className="noti-title">Appointment booking with payment
                              gateway</span></p>
                          <p className="noti-time"><span className="notification-time">6 mins
                              ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar6} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Misty
                              Tison</span> added <span className="noti-title">Domenic
                              Houston</span> and <span className="noti-title">Claire
                              Mapes</span> to project <span className="noti-title">Doctor
                              available module</span></p>
                          <p className="noti-time"><span className="notification-time">8 mins
                              ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar5} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Rolland
                              Webber</span> completed task <span className="noti-title">Patient and Doctor video
                              conferencing</span></p>
                          <p className="noti-time"><span className="notification-time">12 mins
                              ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                  <li className="notification-message">
                    <Link to="#">
                      <div className="media d-flex">
                        <span className="avatar flex-shrink-0">
                          <img alt src={avatar3} className="rounded-circle" />
                        </span>
                        <div className="media-body flex-grow-1">
                          <p className="noti-details"><span className="noti-title">Bernardo
                              Galaviz</span> added new task <span className="noti-title">Private chat module</span></p>
                          <p className="noti-time"><span className="notification-time">2 days
                              ago</span></p>
                        </div>
                      </div>
                    </Link>
                  </li>
                </ul>
              </div>
              <div className="topnav-dropdown-footer">
                <Link to="#">View all Notifications</Link>
              </div>
            </div> */}
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="feather-settings" />
            </Link>
          </li>
          <li className="nav-item nav-icons">
            <Link to="#">
              <i className="far fa-circle-question" />
            </Link>
          </li>
          <li className="nav-item dropdown has-arrow main-drop">
            <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown" onClick={proShow}>
              <span className="user-img">
                <img src={avatar1} className="img-rounded" alt />
              </span>
            </Link>
            {<Profile/>}
            {/* <div className="dropdown-menu">
              <Link className="dropdown-item" to="#">
                <i className="feather-user-plus" /> My Profile
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-settings" /> Settings
              </Link>
              <Link className="dropdown-item" to="#">
                <i className="feather-log-out" /> Logout
              </Link>
            </div> */}
          </li>
        </ul>
      </div>
    </nav>
  </header>
  {/* /Header */}
  {/* Page Wrapper */}
  <div className="page-wrapper employee-import-list">
    {/* Page Content */}
    <div className="content container">
      {/* Page Header */}
      <div className="page-header">
        {/* Search Filter */}
        <div className="search-filter">
          <div className="d-flex justify-content-between align-items-center">
            <div className="page-title">
              <h3>Import Details</h3>
            </div>
            <div className>
              <ul className="nav search-btns-info">
                <li>
                  <Link to="#" className="btn import-btn" data-bs-toggle="modal" data-bs-target="#employee-import" >
                    <img src={cloud} alt /> Import
                  </Link>
                  {<Share/>}
                </li>
                <li>
                  <Link to="#" className="btn">
                    <img src={clock} alt />
                  </Link>
                </li>
                <li>
                  <Link to="#" className="btn">
                    <img src={down} alt />
                  </Link>
                </li>
                <li>
                  <Link to="#" className="btn">
                    <img src={printer} alt />
                  </Link>
                </li>
                <li>
                  <Link to="#" className="btn active">
                    <img src={bar} alt />
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </div>
        {/* /Search Filter */}
      </div>
      {/* /Page Header */}
      {/* Employee List */}
      <div className="employee-list">
        <div className="row">
          <div className="col-sm-12">
            <div className="card-table">
              <div className="card-body">
                <div className="table-responsive">
                  <table className="table table-center table-hover datatable">
                    <thead className="thead-light">
                      <tr>
                        <th>Employee ID&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Employee Name&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Department&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Joining Date&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Employment Type&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Mail ID&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Phone Number&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Action&nbsp;&nbsp;<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="s-no">DGT 00201</td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="#" className="avatar avatar-md me-2 profile">
                              <img className="avatar-img square-circle" src={avatar2} alt="User Image"  />
                              <i className="fa-sharp fa-solid fa-circle success" />
                            </Link>
                            <Link to="#">Richard Miles <br />
                              <span>BD Manager</span></Link>
                          </h2>
                        </td>
                        <td>
                          <p>Business Team</p>
                        </td>
                        <td>
                          <p>3 March 2023</p>
                        </td>
                        <td>
                          <p>Full Time</p>
                        </td>
                        <td>
                          <p>
                            <Link to="mailto:johnsmith@dgthrms.com" className="mail-to">johnsmith@dgthrms.com</Link>
                          </p>
                        </td>
                        <td>
                          <p>+1 989-438-3131</p>
                        </td>
                        <td className="d-flex align-items-center">
                          <div className="dropdown dropdown-action">
                            <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                            <div className="dropdown-menu dropdown-menu-end">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="s-no">DGT 00201</td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="#" className="avatar avatar-md me-2 profile">
                              <img className="avatar-img square-circle" src={avatar2} alt="User Image" />
                              <i className="fa-sharp fa-solid fa-circle warning" />
                            </Link>
                            <Link to="#">Richard Miles <br />
                              <span>BD Manager</span></Link>
                          </h2>
                        </td>
                        <td>
                          <p>Business Team</p>
                        </td>
                        <td>
                          <p>3 March 2023</p>
                        </td>
                        <td>
                          <p>Full Time</p>
                        </td>
                        <td>
                          <p>
                            <Link to="mailto:johnsmith@dgthrms.com" className="mail-to">johnsmith@dgthrms.com</Link>
                          </p>
                        </td>
                        <td>
                          <p>+1 989-438-3131</p>
                        </td>
                        <td className="d-flex align-items-center">
                          <div className="dropdown dropdown-action">
                            <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                            <div className="dropdown-menu dropdown-menu-end">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="s-no">DGT 00201</td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="#" className="avatar avatar-md me-2 profile">
                              <img className="avatar-img square-circle" src={avatar2} alt="User Image" />
                              <i className="fa-sharp fa-solid fa-circle success" />
                            </Link>
                            <Link to="#">Richard Miles <br />
                              <span>BD Manager</span></Link>
                          </h2>
                        </td>
                        <td>
                          <p>Business Team</p>
                        </td>
                        <td>
                          <p>3 March 2023</p>
                        </td>
                        <td>
                          <p>Full Time</p>
                        </td>
                        <td>
                          <p>
                            <Link to="mailto:johnsmith@dgthrms.com" className="mail-to">johnsmith@dgthrms.com</Link>
                          </p>
                        </td>
                        <td>
                          <p>+1 989-438-3131</p>
                        </td>
                        <td className="d-flex align-items-center">
                          <div className="dropdown dropdown-action">
                            <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                            <div className="dropdown-menu dropdown-menu-end">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="s-no">DGT 00201</td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="#" className="avatar avatar-md me-2 profile">
                              <img className="avatar-img square-circle" src={avatar2} alt="User Image" />
                              <i className="fa-sharp fa-solid fa-circle warning" />
                            </Link>
                            <Link to="#">Richard Miles <br />
                              <span>BD Manager</span></Link>
                          </h2>
                        </td>
                        <td>
                          <p>Business Team</p>
                        </td>
                        <td>
                          <p>3 March 2023</p>
                        </td>
                        <td>
                          <p>Full Time</p>
                        </td>
                        <td>
                          <p>
                            <Link to="mailto:johnsmith@dgthrms.com" className="mail-to">johnsmith@dgthrms.com</Link>
                          </p>
                        </td>
                        <td>
                          <p>+1 989-438-3131</p>
                        </td>
                        <td className="d-flex align-items-center">
                          <div className="dropdown dropdown-action">
                            <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                            <div className="dropdown-menu dropdown-menu-end">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="s-no">DGT 00201</td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="#" className="avatar avatar-md me-2 profile">
                              <img className="avatar-img square-circle" src={avatar2} alt="User Image" />
                              <i className="fa-sharp fa-solid fa-circle success" />
                            </Link>
                            <Link to="#">Richard Miles <br />
                              <span>BD Manager</span></Link>
                          </h2>
                        </td>
                        <td>
                          <p>Business Team</p>
                        </td>
                        <td>
                          <p>3 March 2023</p>
                        </td>
                        <td>
                          <p>Full Time</p>
                        </td>
                        <td>
                          <p>
                            <Link to="mailto:johnsmith@dgthrms.com" className="mail-to">johnsmith@dgthrms.com</Link>
                          </p>
                        </td>
                        <td>
                          <p>+1 989-438-3131</p>
                        </td>
                        <td className="d-flex align-items-center">
                          <div className="dropdown dropdown-action">
                            <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                            <div className="dropdown-menu dropdown-menu-end">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td className="s-no">DGT 00201</td>
                        <td>
                          <h2 className="table-avatar d-flex">
                            <Link to="#" className="avatar avatar-md me-2 profile">
                              <img className="avatar-img square-circle" src={avatar2} alt="User Image" />
                              <i className="fa-sharp fa-solid fa-circle warning" />
                            </Link>
                            <Link to="#">Richard Miles <br />
                              <span>BD Manager</span></Link>
                          </h2>
                        </td>
                        <td>
                          <p>Business Team</p>
                        </td>
                        <td>
                          <p>3 March 2023</p>
                        </td>
                        <td>
                          <p>Full Time</p>
                        </td>
                        <td>
                          <p>
                            <Link to="mailto:johnsmith@dgthrms.com" className="mail-to">johnsmith@dgthrms.com</Link>
                          </p>
                        </td>
                        <td>
                          <p>+1 989-438-3131</p>
                        </td>
                        <td className="d-flex align-items-center">
                          <div className="dropdown dropdown-action">
                            <Link to="#" className=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                            <div className="dropdown-menu dropdown-menu-end">
                              <ul>
                                <li>
                                  <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="invoice-details.html"><i className="far fa-eye me-2" />View</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="active-customers.html"><i className="far fa-bell me-2" />Active</Link>
                                </li>
                                <li>
                                  <Link className="dropdown-item" to="deactive-customers.html"><i className="far fa-bell-slash me-2" /></Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="pagination-wrap d-flex justify-content-between">
                    <p>Rows Per page&nbsp;&nbsp;<span>6</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
                    <ul className="d-flex">
                      <li><Link to="#">1</Link></li>
                      <li><Link to="#">2</Link></li>
                      <li><Link to="#">3</Link></li>
                      <li><Link to="#">...</Link></li>
                      <li><Link to="#">10</Link></li>
                      <li><Link to="#">11</Link></li>
                      <li><Link to="#">12</Link></li>
                    </ul>
                    <p>Go to page&nbsp;&nbsp;<i className="fa fa-long-arrow-right" aria-hidden="true" /></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Employee List */}
      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <div className="row">
            <div className="d-flex justify-content-between align-items-center no-padding">
              <div className="footer-left">
                <p>© 2023 Dreams HRMS</p>
              </div>
              <div className="footer-right">
                <ul>
                  <li>
                    <Link to="#">Privacy Policy</Link>
                  </li>
                  <li>
                    <Link to="#">Terms &amp; Conditions</Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>
      {/* Footer */}
    </div>
    {/* /Page Content */}
  </div>
  {/* /Page Wrapper */}
  {/* /Main Wrapper */}
  {/* Employee Import Modal */}
  {/* <div className="modal fade" id="employee-import" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="employee-import" aria-hidden="true">
    <div className="modal-dialog modal-dialog-centered">
      <div className="modal-content">
        <div className="modal-header d-flex justify-content-between align-items-center">
          <div>
            <h5 className="modal-title">Import Employees</h5>
            <span>Upload a CSV to import Employee data to your CMS.</span>
          </div>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"> <i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
          <Link to="#" className="btn btn-light"><img src={checklist} className="img-rounded" alt />Employee Template.xlsx</Link>
          <span className="d-block">Choose upload file</span>
          <div className="drag-drop text-center">
            <div className="upload">
              <Link to="#"><img src={csv} /></Link>
              <p>Drop your CSV, .xlx or xlsx files here or <Link to="#">Browse</Link></p>
              <span>Maximum size: 4MB</span>
            </div>
            <input type="file" multiple />
          </div>
          <div className="buttons d-flex justify-content-between">
            <div>
              <Link to="employee-import-list.html" className="btn btn-transparant flex-shrink-1"><i className="fa fa-eye" aria-hidden="true" />View Details</Link>
            </div>
            <div>
              <button type="button" className="btn gradient-btn"><i className="fa fa-upload" aria-hidden="true" />Import</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div> */}
</div>

  )
}

export default EmpImport
