import React, { useEffect, useMemo, useRef, useState } from "react";
import logo from "../assets/img/logo.svg";
import dashboardicon from "../assets/img/icons/dashboard-icon.svg";
import employeeicon from "../assets/img/icons/employees-icon.svg";
import timeofficon from "../assets/img/icons/time-off-icon.svg";
import policyicon from "../assets/img/icons/policies-icon.svg";
import reporticon from "../assets/img/icons/reports-icon.svg";
import shortcuticon from "../assets/img/icons/shortcut-icon.svg";
import avatar1 from "../assets/img/profiles/avatar-01.jpg";
import avatar2 from "../assets/img/profiles/avatar-02.jpg";
import avatar5 from "../assets/img/profiles/avatar-02.jpg";
import avatar6 from "../assets/img/profiles/avatar-06.jpg";
import avatar3 from "../assets/img/profiles/avatar-03.jpg";
import avatar7 from "../assets/img/profiles/avatar-07.jpg";
import avatar8 from "../assets/img/profiles/avatar-08.jpg";
import avatar10 from "../assets/img/profiles/avatar-10.jpg";
import avatar14 from "../assets/img/profiles/avatar-14.jpg";
import gridicon from "../assets/img/icons/grid-icon.svg";
import gearicon from "../assets/img/icons/gear-icon.svg";
import clockicon from "../assets/img/icons/clock-icon.svg";
import cloudicon from "../assets/img/icons/cloud-icon.svg";
import downloadicon from "../assets/img/icons/download-icon.svg";
import printericon from "../assets/img/icons/printer-icon.svg";
import funnelicon from "../assets/img/icons/funnel-icon.svg";
import baricon from "../assets/img/icons/bar-icon.svg";
import add_step1 from "../assets/img/icons/add_step1.svg";
import add_step2 from "../assets/img/icons/add_step2.svg";
import add_step3 from "../assets/img/icons/add_step3.svg";
import add_step4 from "../assets/img/icons/add_step4.svg";
import add_step5 from "../assets/img/icons/add_step5.svg";
import avataricon from "../assets/img/icons/avatar-icon.png";
import footerlogo from "../assets/img/footer-logo.png";
import noteicon from "../assets/img/icons/note-icon.svg";
import axios from "axios";
import { BASEURL } from "../apiPath/baseUrl";
import { Modal } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min.js";
import DependencyModal from "./EmployeeModals/DependencyModal";
import EmployeeInfoModal from "./EmployeeModals/EmployeeInfoModal";
import EducationInfo from "./EmployeeModals/EducationInfo";
import DocumentModal from "./EmployeeModals/DocumentModal";
import PersonalModal from "./EmployeeModals/PersonalModal";
import Auth from "../Auth/auth";
import { postData } from "../services/apiUrl";
import { Link } from "react-router-dom";
import * as XLSX from 'xlsx';
import {useReactToPrint} from 'react-to-print';
import {Multiselect} from 'multiselect-react-dropdown';
import {Creatable} from 'react-select/creatable';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useNavigate } from "react-router-dom";

function Employee() {
  const { token, logout } = Auth();
  const [employeeDetails, setEmployeeDetails] = useState();
  const [employeeCount, setEmployeeCount] = useState();
  const [resignEmployeeId, setResignEmployeeId] = useState();
  const [employeefilter, setEmployeeFilter] = useState([]);
  const [addnew, setAddnew] = useState("field");
  const navigate = useNavigate();
  const [show, setShow] = useState(false);
  const initialValues = {resigningEmployee: "",noticeDate: "",resignationDate:"",leaveReason:""};
  const [formValues, setFormValues] = useState(initialValues);
  const [formErrors, setFormErrors] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);

  const roles =[
	{label:'admin',value:1},
	{label:'admin2',value:2},
	{label:'admin3',value:3},
	{label:'admin4',value:4},
  ]

  //Resignation Offboarding
  const [resdate, setResdate] = useState("");
  const [noticedate, setNoticeDate] = useState("");
  const [selectedNoticeDate, setSelectedNoticeDate] = useState("");
  const [selectedResignationDate, setSelectedResignationDate] = useState("");
  const [resemp, setResEmp] = useState("");
  const [leavereason, setLeaveReason] = useState("");

  //Termination OffBoarding
  const [termEmp, setTermEmp] = useState("");
  const [termType, setTermType] = useState("");
  const [termDate, setTermDate] = useState("");
  const [lastDate, setLastDate] = useState("");
  const [termLeaveReason, setTermLeaveReason] = useState("");

useEffect(() => {
  }, [resemp,resdate,noticedate,leavereason]);

useEffect(() => {
}, [termEmp,termType,termDate,lastDate,termLeaveReason]);

useEffect(()=>{
    if(Object.keys(formErrors).length === 0 && isSubmit){
    }
  },[formErrors,isSubmit]);

const validate = (values) => {
    const errors ={resigningEmployee: "",noticeDate: "",resignationDate:"",leaveReason:""};
	console.log("noticeDate",values.noticeDate)
	if (!values.resigningEmployee){
		errors.resigningEmployee= "ResigningEmployee is required";
	  }
	  if (!values.noticeDate){
		errors.noticeDate= "ResigningEmployee is required";
	  }
	  if (!values.resignationDate){
		errors.resignationDate= "ResigningEmployee is required";
	  }
	  if (!values.leaveReason){
		errors.leaveReason= "ResigningEmployee is required";
	  }
    return errors;
  };

//Resignation Offboarding Submit
  const resignationSubmit = (event) => {
	event.preventDefault();
	setFormErrors(validate(formValues));
	if (formValues.leaveReason.length === 0){
		return false;
	  }
	setIsSubmit(true);
	const preparData ={
		resigning_employee:resemp,
		notice_date:selectedNoticeDate,
		resign_date:selectedResignationDate,
		leave_reason:leavereason
	}
	console.log("preparData",preparData)
    postData("employee_offboarding", preparData, (data, res) => {
		toast("Workingggggg")
		
		console.log("data12345",data)
    });
  };

  //Termination OffBoarding Submit
  const terminationSubmit = () => {
	const preparData ={
		termination_employee:termEmp,
		termination_type:termType,
		termination_date:termDate,
		last_date:lastDate,
		leave_reason:termLeaveReason
	}
	console.log("preparData",preparData)
    postData("employeeoffboarding_termination", preparData, (data, res) => {
		toast("Workingggggg")
		
		console.log("data12345",data)
    });
  };

  //Resignation Offboarding
  function handleResigningEmp(e) {
	setResEmp(e.target.value);
	// console.log("resdate123*************",resemp)
}

  function handleNoticeDate(e) {
	const input = e.target.value;
	const [year, month, day] =  input.split('-')
	console.log("helooooooooo123",`${day}-${month}-${year}`)
	const selectedDate = `${day}-${month}-${year}`
	setNoticeDate(input);
	setSelectedNoticeDate(selectedDate);
	console.log("resdate456*************",selectedDate)
}

  function handleResignationDate(e) {
	const input = e.target.value;
	const [year, month, day] =  input.split('-')
	console.log("helooooooooo234",`${day}-${month}-${year}`)
	const selectedDate = `${day}-${month}-${year}`
	setResdate(input);
	setSelectedResignationDate(selectedDate);
	console.log("resdate789*************",resdate)
}
function handleLeaveReason(e) {
	setLeaveReason(e.target.value);
	console.log("resdate999*************",leavereason)
}

//Termination OffBoarding
function handleTerminatedEmployee(e) {
	setTermEmp(e.target.value);
	console.log("resdate*************",termEmp)
}

  function handleTerminatedType(e) {
	setTermType(e.target.value);
	console.log("resdate*************",termType)
}

  function handleTerminatedDate(e) {
	setTermDate(e.target.value);
	console.log("resdate*************",termDate)
}
function handleLastDate(e) {
	setLastDate(e.target.value);
	console.log("resdate*************",lastDate)
}
function handleTermLeaveReason(e) {
	setTermLeaveReason(e.target.value);
	console.log("resdate*************",termLeaveReason)
}

	//Print Function
	const componentRef = useRef();
    const employeePrint = useReactToPrint({
	content: () => componentRef.current,
	documentTitle: "Employee-List"
  });

  //Excel Download Function
  const employeeDownload = () => {
	var wb = XLSX.utils.book_new(),
	ws = XLSX.utils.json_to_sheet(employeeDetails);

	XLSX.utils.book_append_sheet(wb, ws, "Employee Sheet")

	XLSX.writeFile(wb, "EmployeeList.xlsx")
  };	

   const employeeList = () => {
    // const employeedata = {
    //   user_id: "1",
    // };
    postData("employee-list","",(data, res) => {
      console.log(data.data, "data99999");
	  setEmployeeDetails(data.data.emp_list)
	  setEmployeeCount(data.data.emp_count)
    });
  };

  useEffect(() => {
	// console.log("resignEmployeeId",resignEmployeeId.id)
  }, [employeeDetails,employeeCount,resignEmployeeId]);

  useEffect(() => {
 
    employeeList();
  }, []);

  // console.log(response.data,"ddddd");\
  // const filter= async () => {
  //   try {
  //     const response = await axios.post(`https://api.dreamshrms.com//api/employee-filter-list`);
  //     setEmployeeFilter(response.data);
  //     console.log("response", response.data);
  //   } catch (err) {
  //    console.error(err,"errorrr");
  //   }
  // };

  const handleClick = () => {
    setShow(show);
  };

  
  const Offboardingemp = (data) =>{
	console.log("123456789",data.id)
	setResignEmployeeId(data)
  }

  const employeeProfile = (data) =>{
	localStorage.setItem("EmployeeId",data.id)
	navigate('/employeeHeader');
  }

  // const handleChange = (e) => {
  //   setDependency({ ...dependency, [e.target.name]: e.target.value });
  // };

  // const handlepersonal = (e) => {
  //   debugger
  //   setPersonal({ ...personal, [e.target.name]: e.target.value });
  // };
  // const handleeducate = (e) => {
  //   setEducation({ ...education, [e.target.name]: e.target.value });
  // };
  // const handleemployee=(e=>{
  //   setEmployeebasinfo({...employeebasinfo, [e.target.name]: e.target.value});
  // })

  // const handlesave = (id,type) => {

  //     let getMandatoryFieldValue = document.querySelectorAll(`#${type} .input-area`)

  // let changemandatoryfieldvalue=Array.prototype.slice.call(getMandatoryFieldValue)

  //    let setValue= false;
  //    for(let i=0;i<changemandatoryfieldvalue.length;i++){
  //     let getChildren=changemandatoryfieldvalue[i].children;
  //     let changegetchildren = Array.prototype.slice.call(getChildren)
  //     changegetchildren.forEach((element) => {

  //       if(element.tagName === 'LABEL' && element.innerText.includes("*")){

  //         if(element.nextElementSibling.innerText !== ""){
  //         setMandatory(true);

  //         }else{
  //           setMandatory(false);
  //         }

  //       }
  //     })

  const logoutUser = () => {
    if (token != undefined) {
      logout();
    }
  };
  return (
    <div className="main-wrapper">
    <header className="header header-fixed header-one">
      <nav className="navbar navbar-expand-lg header-nav">
        <div className="navbar-header">
          <a id="mobile_btn" href="javascript:void(0);">
            <span className="bar-icon">
              <span></span>
              <span></span>
              <span></span>
            </span>
          </a>
          <a href="javascript:void(0);" className="navbar-brand logo">
            <img src={logo} className="img-fluid" alt="Logo" />
          </a>
        </div>
        <div className="main-menu-wrapper">
          <ul className="main-nav">
            <li>
              <a href="javascript:void(0);">
                <img src={dashboardicon} alt="" /> Dashboard
              </a>
            </li>
            <li className="active">
              <a href="employees.html">
                <img src={employeeicon} alt="" /> Employees
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <img src={timeofficon} alt="" /> Time off
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <img src={policyicon} alt="" /> Policies
              </a>
            </li>
            <li>
              <a href="javascript:void(0);">
                <img src={reporticon} alt="" /> Reports
              </a>
            </li>
          </ul>
          <ul className="nav header-navbar-rht">
            <li className="nav-item search-item">
              <div className="top-nav-search">
                <form action="#">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search"
                  />
                  <button className="btn" type="submit">
                    <i className="feather-search"></i>
                  </button>
                  <span>
                    <img src={shortcuticon} alt="" />
                  </span>
                </form>
              </div>
            </li>
            <li className="nav-item quick-link-item">
              <a className="btn" href="javascript:void(0);">
                <span>
                  Quick Links <i className="feather-zap"></i>
                </span>
              </a>
            </li>
            <li className="nav-item nav-icons">
              <a href="javascript:void(0);">
                <i className="feather-sun"></i>
              </a>
            </li>
            <li className="nav-item dropdown has-arrow notification-dropdown">
              <a
                href="#"
                className="dropdown-toggle nav-link"
                data-bs-toggle="dropdown"
              >
                <i className="feather-bell"></i>
                <span className="badge">3</span>
              </a>
              <div className="dropdown-menu dropdown-menu-end notifications">
                <div className="topnav-dropdown-header">
                  <span className="notification-title">Notifications</span>
                  <a href="javascript:void(0)" className="clear-noti">
                    {" "}
                    Clear All
                  </a>
                </div>
                <div className="noti-content">
                  <ul className="notification-list">
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img
                              alt=""
                              src={avatar1}
                              className="rounded-circle"
                            />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details">
                              <span className="noti-title">John Doe</span>
                              added new task{" "}
                              <span className="noti-title">
                                Patient appointment booking
                              </span>
                            </p>
                            <p className="noti-time">
                              <span className="notification-time">
                                4 mins ago
                              </span>
                            </p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img
                              alt=""
                              src={avatar2}
                              className="rounded-circle"
                            />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details">
                              <span className="noti-title">
                                Tarah Shropshire
                              </span>{" "}
                              changed the task name{" "}
                              <span className="noti-title">
                                Appointment booking with payment gateway
                              </span>
                            </p>
                            <p className="noti-time">
                              <span className="notification-time">
                                6 mins ago
                              </span>
                            </p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img
                              alt=""
                              src={avatar6}
                              className="rounded-circle"
                            />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details">
                              <span className="noti-title">Misty Tison</span>{" "}
                              added{" "}
                              <span className="noti-title">
                                Domenic Houston
                              </span>{" "}
                              and{" "}
                              <span className="noti-title">Claire Mapes</span>{" "}
                              to project{" "}
                              <span className="noti-title">
                                Doctor available module
                              </span>
                            </p>
                            <p className="noti-time">
                              <span className="notification-time">
                                8 mins ago
                              </span>
                            </p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img
                              alt=""
                              src={avatar5}
                              className="rounded-circle"
                            />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details">
                              <span className="noti-title">
                                Rolland Webber
                              </span>{" "}
                              completed task{" "}
                              <span className="noti-title">
                                Patient and Doctor video conferencing
                              </span>
                            </p>
                            <p className="noti-time">
                              <span className="notification-time">
                                12 mins ago
                              </span>
                            </p>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li className="notification-message">
                      <a href="javascript:void(0)">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img
                              alt=""
                              src={avatar3}
                              className="rounded-circle"
                            />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details">
                              <span className="noti-title">
                                Bernardo Galaviz
                              </span>{" "}
                              added new task{" "}
                              <span className="noti-title">
                                Private chat module
                              </span>
                            </p>
                            <p className="noti-time">
                              <span className="notification-time">
                                2 days ago
                              </span>
                            </p>
                          </div>
                        </div>
                      </a>
                    </li>
                  </ul>
                </div>
                <div className="topnav-dropdown-footer">
                  <a href="javascript:void(0)">View all Notifications</a>
                </div>
              </div>
            </li>
            <li className="nav-item nav-icons">
              <a href="javascript:void(0);">
                <i className="feather-settings"></i>
              </a>
            </li>
            <li className="nav-item nav-icons">
              <a href="javascript:void(0);">
                <i className="far fa-circle-question"></i>
              </a>
            </li>
            <li className="nav-item dropdown has-arrow main-drop">
              <a
                href="#"
                className="dropdown-toggle nav-link"
                data-bs-toggle="dropdown"
              >
                <span className="user-img">
                  <img src={avatar1} className="img-rounded" alt="" />
                </span>
              </a>
              <div className="dropdown-menu">
                <a className="dropdown-item" href="javascript:void(0);">
                  <i className="feather-user-plus"></i> My Profile
                </a>
                <a className="dropdown-item" href="javascript:void(0);">
                  <i className="feather-settings"></i> Settings
                </a>
                <a
                  onClick={() => logoutUser()}
                  className="dropdown-item"
                  href="javascript:void(0);"
                >
                  <i className="feather-log-out"></i> Logout
                </a>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </header>

    <div className="page-wrapper">
      <div className="content container">
        <div className="page-header">
          <div className="row align-items-center">
            <div className="col-lg-6 col-md-6">
              <h3 className="page-title">
                Employees <span>({employeeCount})</span>
                <a href="javascript:void(0);">Archived (13)</a>
              </h3>
            </div>
            <div className="col-lg-6 col-md-6 page-header-btns">
              <button onClick={handleClick} className="btn import-btn" data-bs-toggle="modal"
                data-bs-target="#employee-import">
                <img src={cloudicon} alt="" /> Import
              </button>
              <a href="javascript:void(0);" className="btn">
                <img src={gearicon} alt="" />
              </a>
              <a
                className="btn new-employee-btn"
                data-bs-toggle="modal"
                data-bs-target="#staticBackdrop"
              >
                <i className="feather-plus" aria-hidden="true"></i> New
                Employee
              </a>
            </div>
          </div>
        </div>

        <div className="search-filter employee-list-search">
		<div class="row align-items-center">
						<div class="col-lg-6 col-md-6">
							<div class="form-group d-flex justify-content-start">
								<i class="feather-search"></i>
								<input type="text" class="form-control" placeholder=""/>
								<button class="btn btn-transparant">Apply Filter</button>
								{/* <ul class="list-filter d-flex">
									<li class="clearfix"><i class="fa fa-building" aria-hidden="true"></i>Coimbatore Office<i class="fa fa-times" aria-hidden="true"></i></li>
									<li class="clearfix"><i class="fa fa-user" aria-hidden="true"></i>John Walker<i class="fa fa-times" aria-hidden="true"></i></li>
								</ul> */}
							</div>
						</div>
						<div class="col-lg-6 col-md-6">
							<ul class="nav search-btns-info">
								<li>
									<a onClick={() => window.location.reload()} class="btn">
										<img src={clockicon} alt=""/>
									</a>
								</li>
								<li>
									<a onClick={employeeDownload} class="btn">
										<img src={downloadicon} alt=""/>
									</a>
								</li>
								<li>
									<a onClick={employeePrint} class="btn">
										<img src={printericon} alt=""/>
									</a>
								</li>
								<li>
									<Link to="/employeelist" class="btn">
										<img src={baricon} alt=""/>
									</Link>
								</li>
								<li>
									<a href="javascript:void(0);" class="btn active">
										<img src={gridicon} alt=""/>
									</a>
								</li>
							</ul>
						</div>
					</div>
        </div>

        <Modal show={show} className="modal-show">
          <Modal.Body style={{ height: "300px !important" }}>
            <h6>Import Employees</h6>
            <label>Upload a CSV to import Employee data to your CMS. </label>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua.{" "}
            </p>
            <div className="inner-box">
              <p>Employee Template.xlsx</p>
            </div>
          </Modal.Body>
        </Modal>

        <div className="employee-grid">
			<div ref ={componentRef} style={{width:'100%', height:window.innerHeight}}>
          <div className="row">
                      {employeeDetails &&
					  employeeDetails?.map((item) => {
						return (
		  <div class="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3 d-flex">
							<div class="card employee-card flex-fill">
								<div class="card-body">
									<div class="employee-img">
										<a href="javascript:void(0);">
											<img src={item.profile_image} alt=""/>
										</a>
										{item.emp_status === "1" ? (
										<i class="fa-sharp fa-solid fa-circle success"></i>
										) : (<i class="fa-sharp fa-solid fa-circle warning"></i>
										)}
									</div>
									<div class="dropdown profile-action">
										<Link href="#" class="dropdown-toggle action-icon" data-bs-toggle="dropdown">
											<i class="fa-solid fa-ellipsis-vertical"></i>
										</Link>
										<div class="dropdown-menu dropdown-menu-end">
											<a class="dropdown-item" href="javascript:void(0);">
												<i class="fa-solid fa-pencil"></i> Edit
											</a>
											<a class="dropdown-item" href="javascript:void(0);">
												<i class="fa-regular fa-trash-can"></i> Delete
											</a>
											<a class="dropdown-item" href="javascript:void(0);">
												<i class="fa fa-eye-slash" aria-hidden="true"></i> Inactive
											</a>
											<a class="dropdown-item" onClick={() => {Offboardingemp(item)}} data-bs-toggle="modal" data-bs-target="#employee-offboarding" >
												<i class="fa fa-sign-out" aria-hidden="true"></i> Offboarding
											</a>
										</div>
									</div>
									<div class="employee-details">
										<h4 class="user-name text-ellipsis">
											<a onClick={() => {employeeProfile(item)}}>{item.first_name} {item.last_name}</a>
										</h4>
										<h6>{item.job_name}</h6>
										<p>{item.id}</p>
									</div>
									<div class="employee-info">
										<p><i class="feather-mail"></i>{item.emp_email}</p>
										<p><i class="feather-phone-call"></i>{item.emp_phone}</p>
									</div>
								</div>
							</div>
						</div>
						);
						})}
						{employeeDetails?.length === 0 &&
						<div><p>No Employees Records Found</p></div>
						}
          </div>
		  </div>
        </div>

        <footer class="footer">
	                    <div class="container">
	                        <div class="row">
	                            <div class="col-12 col-sm-12 col-md-6 footer-left no-padding">
	                                <p>© 2023 Dreams HRMS <a href="#" class="footer-logo"><img src={footerlogo}/></a></p>
	                            </div>
	                            <div class="col-12 col-sm-12 col-md-6 footer-right no-padding">
	                                <ul>
	                                    <li>
	                                        <a href="javascript:void(0);">Privacy Policy</a>
	                                    </li>
	                                    <li>
	                                        <a href="javascript:void(0);">Terms & Conditions</a>
	                                    </li>
	                                </ul>
	                            </div>
	                        </div>
	                    </div>
	                </footer>
      </div>
    </div>
    {/* MOdal  */}

	{/* <!-- Modal Popup -->				   */}
    <div className="employees-popup">
      <div
        className="modal fade"
        id="staticBackdrop"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex={-1}
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered modal-xl">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title " id="staticBackdropLabel">
                <span className="user-icon">
                  <img src={avataricon} />
                </span>{" "}
                Add Employee
              </h1>
              <button
                onClick={() => setAddnew("field")}
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <i style={{ fontSize: "20px" }} class="bi bi-x-lg"></i>
              </button>
            </div>
            <div className="modal-body">
              <div className="wizard">
                <img src={addnew == "field" ? add_step1 : ""} />
                <img src={addnew == "field-2" ? add_step2 : ""} />
                <img src={addnew == "field-3" ? add_step3 : ""} />
                <img src={addnew == "field-4" ? add_step4 : ""} />
                <img src={addnew == "field-5" ? add_step5 : ""} />
              </div>
              <div className="multistep-form">
                <PersonalModal dal addnew={addnew} setAddnew={setAddnew} />
                <EmployeeInfoModal addnew={addnew} setAddnew={setAddnew} />
                <DependencyModal addnew={addnew} setAddnew={setAddnew} />
                <EducationInfo addnew={addnew} setAddnew={setAddnew} />
                <DocumentModal addnew={addnew} setAddnew={setAddnew} />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
	{/* <!-- Modal Popup --> */}

	{/* <!-- Employee Offboarding Modal --> */}
	<div class="modal onboarding-modal fade" id="employee-offboarding" tabindex="-1" aria-labelledby="employee-offboarding" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title">Offboarding</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
	      </div>
	      <div class="modal-body">
	      	<ul class="nav nav-tabs" id="myTab" role="tablist">
				<li class="nav-item" role="presentation">
					<button class="nav-link active" id="resignation-tab" data-bs-toggle="tab" data-bs-target="#resignation" type="button" role="tab" aria-controls="resignation" aria-selected="true">
						<span></span>
						<h6>Resignation</h6>
					</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="termination-tab" data-bs-toggle="tab" data-bs-target="#termination" type="button" role="tab" aria-controls="termination" aria-selected="false">
						<span></span>
						<h6>Termination</h6>
					</button>
				</li>
			</ul>
			<div class="tab-content" id="myTabContent">
				<div class="tab-pane fade show active" id="resignation" role="tabpanel" aria-labelledby="resignation-tab">
					<form method="POST" onSubmit={resignationSubmit}>
			      		<div class="form-group">
							<label>Resigning Employee <span>*</span></label>
							<select class="container p-2 rounded" name="resigningEmployee" value={formValues.resigningEmployee} onChange={handleResigningEmp}>
								<option>Select Employee</option>
								<option value={resignEmployeeId?.id}>{resignEmployeeId?.first_name} {resignEmployeeId?.last_name}</option>
							</select>
						</div>
						<div class="form-group">
							<label for="noticeDate">Notice Date <span>*</span></label>
			            	<input id="noticeDate" class="form-control" type="date" name="noticeDate" placeholder="Select Date" value={noticedate} onChange={handleNoticeDate}/>
			            	<span id="noticeDateSelected"></span>
			            </div>
			            <div class="form-group">
							<label for="resignationDate">Resignation Date <span>*</span></label>
			            	<input id="resignationDate" class="form-control" type="date" name="resignationDate" placeholder="Select Date" value={resdate} onChange={handleResignationDate}/>
			            	<span id="resignationDateSelected"></span>
			            </div>
			            <div class="form-group note field-icon">
						    <label for="leave">Leave Reason <span>*</span></label>
						    <textarea class="form-control" id="leave" placeholder="Enter Reason" rows="3" name="leaveReason" value={leavereason} onChange={handleLeaveReason}/>
							<img class="icon" src={noteicon} alt=""/>
							<div className="text-danger">{formErrors.leaveReason}</div>
						</div>
						<div class="buttons">
					        <button type="submit" class="btn gradient-btn" >Submit</button>
					        <button type="button" class="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
					    </div>
					</form>
				</div>
				<div class="tab-pane fade" id="termination" role="tabpanel" aria-labelledby="termination-tab">
					<form>
			      		<div class="form-group">
							<label>Terminated Employee <span>*</span></label>
							<select class="container p-2 rounded" value={termEmp} onChange={handleTerminatedEmployee}>
							<option>Select Employee</option>
								<option value={resignEmployeeId?.id}>{resignEmployeeId?.first_name} {resignEmployeeId?.last_name}</option>
							</select>
						</div>
						<div class="form-group">
							<label>Termination Type <span>*</span></label>
							{/* <select class="container p-2 rounded" multiple id="terminationtype-select" name="native-select" placeholder="Select or Add New Type" data-search="false" data-silent-initial-value-set="false" value={termType} onChange={handleTerminatedType}>
								<option value="1">Misconduct</option>
								<option value="2">Low Performance</option>
								<option value="3">Worst Performance</option>
								<option value="4">Bad Behaviour</option>
							</select> */}
							<Multiselect
							isObject={false}
							onRemove={(event)=>{console.log(event)}}
							onSelect={(event)=>{console.log(event)}}
							options={['Misconduct','Low Performance','Worst Performance','Bad Behaviour']}
							showCheckBox
							/>
						</div>
						<div class="form-group">
							<label for="terminationDate">Termination Date <span>*</span></label>
			            	<input id="terminationDate" class="form-control" type="date" name="terminationDate" placeholder="Select Date" value={termDate} onChange={handleTerminatedDate}/>
			            	<span id="terminationDateSelected"></span>
			            </div>
			            <div class="form-group">
							<label for="lastDate">Last Date <span>*</span></label>
			            	<input id="lastDate" class="form-control" type="date" placeholder="Select Date" name="lastDate" value={lastDate} onChange={handleLastDate}/>
			            	<span id="lastDateSelected"></span>
			            </div>
			            <div class="form-group note field-icon">
						    <label for="leave">Leave Reason <span>*</span></label>
						    <textarea class="form-control" id="leave" placeholder="Enter Reason" rows="3" name="leaveReason" value={termLeaveReason} onChange={handleTermLeaveReason}/>
						    <img class="icon" src={noteicon} alt=""/>
						</div>
						<div class="buttons">
					        <button type="button" class="btn gradient-btn" onClick={terminationSubmit}>Submit</button>
					        <button type="button" class="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
					    </div>
					</form>
				</div>
			</div>

	      </div>
	    </div>
	  </div>
	</div>
	{/* <!-- Employee Offboarding Modal --> */}

	{/* <!-- Employee Import Modal --> */}
	<div class="modal fade" id="employee-import" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="employee-import" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between align-items-center">
                    <div>
                    	<h5 class="modal-title">Import Employees</h5>
                    	<span>Upload a CSV to import Employee data to your CMS.</span>
                    </div>
	        			<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
                </div>
                <div class="modal-body">
                	<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                	<a href="#" class="btn btn-light"><img src="assets/img/icons/checklist.svg" class="img-rounded" alt=""/>Employee Template.xlsx</a>
                	<span class="d-block">Choose upload file</span>
                    <div class="drag-drop text-center">
                    	<div class="upload">
	                    	<a href="#"><img src="assets/img/icons/csv.svg" /></a>
	                    	<p>Drop your CSV, .xlx or xlsx files here or <a href="#">Browse</a></p>
	                    	<span>Maximum size: 4MB</span>
	                    </div>
	                    <input type="file" multiple=""/>
                    </div>
                    <div class="buttons d-flex justify-content-between">
                    	<div>
                    		<a href="employee-import-list.html" class="btn btn-transparant flex-shrink-1"><i class="fa fa-eye" aria-hidden="true"></i>View Details</a>
                    	</div>
				        <div>
				        	<button type="button" class="btn gradient-btn"><i class="fa fa-upload" aria-hidden="true"></i>Import</button>
				        	<button type="button" class="btn btn-dull" data-bs-dismiss="modal">cancel</button>
				        </div>
				    </div>
                </div>
            </div>
        </div>
    </div>
    {/* <!-- /Employee Import Modal --> */}

	{/* <!-- Employee Offboarding Modal --> */}
    {/* <div class="modal onboarding-modal fade" id="employee-offboarding" tabindex="-1" aria-labelledby="employee-offboarding" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title">Offboarding</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times" aria-hidden="true"></i></button>
	      </div>
	      <div class="modal-body">
	      	<ul class="nav nav-tabs" id="myTab" role="tablist">
				<li class="nav-item" role="presentation">
					<button class="nav-link active" id="resignation-tab" data-bs-toggle="tab" data-bs-target="#resignation" type="button" role="tab" aria-controls="resignation" aria-selected="true">
						<span></span>
						<h6>Resignation</h6>
					</button>
				</li>
				<li class="nav-item" role="presentation">
					<button class="nav-link" id="termination-tab" data-bs-toggle="tab" data-bs-target="#termination" type="button" role="tab" aria-controls="termination" aria-selected="false">
						<span></span>
						<h6>Termination</h6>
					</button>
				</li>
			</ul>
			<div class="tab-content" id="myTabContent">
				<div class="tab-pane fade show active" id="resignation" role="tabpanel" aria-labelledby="resignation-tab">
					<form>
			      		<div class="form-group">
							<label>Resigning Employee <span>*</span></label>
							<select class="select">
								<option>Select Employee</option>
								<option>OPtion 1</option>
								<option>OPtion 2</option>
							</select>
						</div>
						<div class="form-group">
							<label for="noticeDate">Notice Date <span>*</span></label>
			            	<input id="noticeDate" class="form-control" type="date" placeholder="Select Date"/>
			            	<span id="noticeDateSelected"></span>
			            </div>
			            <div class="form-group">
							<label for="resignationDate">Resignation Date <span>*</span></label>
			            	<input id="resignationDate" class="form-control" type="date" placeholder="Select Date"/>
			            	<span id="resignationDateSelected"></span>
			            </div>
			            <div class="form-group note field-icon">
						    <label for="leave">Leave Reason <span>*</span></label>
						    <textarea class="form-control" id="leave" placeholder="Enter Reason" rows="3"></textarea>
						    <img class="icon" src="assets/img/icons/note-icon.svg" alt=""/>
						</div>
						<div class="buttons">
					        <button type="button" class="btn gradient-btn">Submit</button>
					        <button type="button" class="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
					    </div>
					</form>
				</div>
				<div class="tab-pane fade" id="termination" role="tabpanel" aria-labelledby="termination-tab">
					<form>
			      		<div class="form-group">
							<label>Terminated Employee <span>*</span></label>
							<select class="select">
								<option>Select Employee</option>
								<option>OPtion 1</option>
								<option>OPtion 2</option>
							</select>
						</div>
						<div class="form-group">
							<label>Termination Type <span>*</span></label>
							<select multiple id="terminationtype-select" name="native-select" placeholder="Select or Add New Type" data-search="false" data-silent-initial-value-set="false">
								<option value="1">Misconduct</option>
								<option value="2">Low Performance</option>
								<option value="3">Worst Performance</option>
								<option value="4">Bad Behaviour</option>
							</select>
						</div>
						<div class="form-group">
							<label for="terminationDate">Termination Date <span>*</span></label>
			            	<input id="terminationDate" class="form-control" type="date" placeholder="Select Date"/>
			            	<span id="terminationDateSelected"></span>
			            </div>
			            <div class="form-group">
							<label for="lastDate">Last Date <span>*</span></label>
			            	<input id="lastDate" class="form-control" type="date" placeholder="Select Date"/>
			            	<span id="lastDateSelected"></span>
			            </div>
			            <div class="form-group note field-icon">
						    <label for="leave">Leave Reason <span>*</span></label>
						    <textarea class="form-control" id="leave" placeholder="Enter Reason" rows="3"></textarea>
						    <img class="icon" src="assets/img/icons/note-icon.svg" alt=""/>
						</div>
						<div class="buttons">
					        <button type="button" class="btn gradient-btn">Submit</button>
					        <button type="button" class="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
					    </div>
					</form>
				</div>
			</div>

	      </div>
	    </div>
	  </div>
	</div> */}
	{/* <!-- /Employee Offboarding Modal --> */}
	<ToastContainer />
  </div>

  );
}

export default Employee;


