import React from 'react'

export default function EmployeeLeave() {
  return (
    <div>EmployeeLeave</div>
  )
}
