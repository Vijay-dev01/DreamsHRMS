import React from "react";
import { Button, Col, Modal, Row } from "react-bootstrap";
import union from "../assets/img/union.svg";
import terms from "../assets/img/terms.svg";
import uploadFile from "../assets/img/uploadFile.svg";

function FileIModal({ listmodal, setListmodal }) {
  return (
    <div>
      <Modal
      style={{
        maxHeight: 'calc(100vh - 210px)',
        overflowY: 'auto'
       }}
        show={listmodal}
        onHide={() => setListmodal(false)}
        className="modal-show "
      >
        <Modal.Body>
          <Row className=" d-flex align-items-center justify-content-space-between">
            <Col style={{ justifyContent: "start" }} className="d-flex ">
              <img src={terms} alt="terms" className="" />
              <h5 className="pl-4"> Import Employees</h5>
            </Col>
            <Col className="d-flex justify-content-end">
              <div
                onClick={() => setListmodal(false)}
                className="close-btn mx-5"
                style={{
                  background: "rgba(255, 71, 71, 0.14)",
                  cursor: "pointer",
                }}
              >
                <i
                  class="bi bi-x "
                  style={{ fontSize: "30px", color: "red" }}
                ></i>
              </div>
            </Col>
          </Row>
          <h6></h6>
          <label>Upload a CSV to import Employee data to your CMS. </label>
          <p>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua.{" "}
          </p>
          <div className="inner-box">
            <p>Employee Template.xlsx</p>
          </div>
          <div className="pt-4">
            <div
              className="d-flex align-items-center justify-content-center"
              style={{
                height: "150px",
                flexDirection: "column",
                border: "2px dotted red",
                borderRadius: "0.5rem",
                border: "1px dashed rgba(0, 0, 0, 0.2)"
              }}
            >
              <img src={uploadFile} />
              <p>
                Drop your CSV, .xlx or xlsx files here or<span>browse</span>
              </p>
              <p>Maximum size: 4MB</p>
            </div>
          </div>

          <div className="pt-4">
            <Button
              style={{
                background:
                  "linear-gradient(176.58deg, #40BE54 -13.04%, #00AEEB 123.56%)",
                border: "none",
              }}
            >
              import
            </Button>
            <Button
              style={{ background: "#F2F2F2", border: "none", color: "black" }}
              className="mx-4"
              onClick={() => setListmodal(false)}
            >
              close
            </Button>
          </div>
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default FileIModal;


