
/* EmployeeAttentance images */
export {default as logo} from '../assets/img/logo.svg';
export {default as dashboard} from '../assets/img/icons/dashboard-icon.svg';
export {default as employee} from '../assets/img/icons/employees-icon.svg';
export {default as time} from '../assets/img/icons/time-off-icon.svg';
export {default as Policies} from '../assets/img/icons/policies-icon.svg';
export {default as reports} from '../assets/img/icons/reports-icon.svg';
export {default as shortcut} from '../assets/img/icons/shortcut-icon.svg';
export {default as avatar1} from '../assets/img/profiles/avatar-01.jpg';
export {default as avatar2} from '../assets/img/profiles/avatar-02.jpg';
export {default as avatar6} from '../assets/img/profiles/avatar-06.jpg';
export {default as avatar5} from '../assets/img/profiles/avatar-05.jpg';
export {default as avatar3} from '../assets/img/profiles/avatar-03.jpg';
export {default as avatar15} from '../assets/img/profiles/avatar-15.png';
export {default as profiles} from '../assets/img/icons/edit-profile.svg';
export {default as working} from '../assets/img/icons/avg-working-hrs.svg';
export {default as working1} from '../assets/img/icons/working-hrs.svg';
export {default as overtime} from '../assets/img/icons/over-time.svg';
export {default as daily} from '../assets/img/icons/daily-attendance.svg';
export {default as missing} from '../assets/img/icons/missing-punch.svg';
export {default as late} from '../assets/img/icons/late-login.svg';
export {default as bar} from '../assets/img/icons/bar-icon.svg';
export {default as funnel} from '../assets/img/icons/funnel-icon.svg';
export {default as ascending} from '../assets/img/icons/sort-ascending.svg';
export {default as time1} from '../assets/img/icons/time-tracker.png';


/* Employee Assets */


export {default as empicon} from '../assets/img/icons/employees-icon.svg'
export {default as icon} from '../assets/img/icons/dashboard-icon.svg'
export {default as ticon} from '../assets/img/icons/time-off-icon.svg'
export {default as picon} from '../assets/img/icons/policies-icon.svg'
export {default as ricon} from '../assets/img/icons/reports-icon.svg'
export {default as sicon} from '../assets/img/icons/shortcut-icon.svg'
export {default as assets1} from '../assets/img/icons/asset1.png'
export {default as attach1} from '../assets/img/icons/attachment1.png'
export {default as avatard} from '../assets/img/profiles/avatar-doc-list.png'
export {default as ed} from '../assets/img/icons/edit-profile.svg'
export {default as flogo} from '../assets/img/footer-logo.png'
export {default as upload} from '../assets/img/icons/upload-documents.svg'
export {default as di} from '../assets/img/icons/documents-icon.svg'
export {default as pdf} from '../assets/img/icons/pdf.svg'
export {default as xls} from '../assets/img/icons/xls.svg'
export {default as doc} from '../assets/img/icons/doc.svg'
export {default as cloud} from '../assets/img/icons/cloud-icon.svg'
export {default as gear} from '../assets/img/icons/gear-icon.svg'
export {default as clock} from '../assets/img/icons/clock-icon.svg'
export {default as down} from '../assets/img/icons/download-icon.svg'
export {default as printer} from '../assets/img/icons/printer-icon.svg'
export {default as grid} from '../assets/img/icons/grid-icon.svg'
export {default as avatar} from '../assets/img/icons/avatar-icon.png'
export {default as step1} from '../assets/img/icons/step-1.svg'
export {default as step2} from '../assets/img/icons/step-2.svg'
export {default as step3} from '../assets/img/icons/step-3.svg'
export {default as step4} from '../assets/img/icons/step-4.svg'
export {default as step5} from '../assets/img/icons/step-5.svg'

/* documents */

export {default as education} from '../assets/img/icons/education-pdf.png'
export {default as eduavatar} from '../assets/img/profiles/education-avatar.png'
export {default as edudoc} from '../assets/img/icons/education-doc.png'
export {default as eduxls} from '../assets/img/icons/education-xls.png'
export {default as edunotepad} from '../assets/img/icons/education-notepad.png'
export {default as sidebar} from '../assets/img/icons/sidebar-pdf.svg'
export {default as presentation} from '../assets/img/design-presentation.png'
export {default as drag} from '../assets/img/icons/drag-drop.svg'