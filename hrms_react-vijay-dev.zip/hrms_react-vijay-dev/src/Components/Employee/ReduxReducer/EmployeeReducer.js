import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";

//////////////action/////////////////
// export const login_reducer = createAsyncThunk("sample", async (id) => {
//   let resp ;
//   const response = await postData("login", id, (data, res) => {
//     resp = data.data
//   });
//   console.log(response,"response");
//   return resp
// });

// console.log(login_reducer,"login_reducer")

const Employee_reducer = createSlice({
  name: "Employees",
  initialState: {
    loginData: [],
    loading: false,
    Domain:[]
  },
  reducers: {
    Loginaction: (state, action) => {
      console.log(action, "action");
      state.loginData = action.payload;
    },
    loading: (state, action) => {
      state.loading = action.payload;
    },
    DomainName:(state, action) => {
      state.Domain = action.payload;
    },
  },

  // extraReducers: (builder) => {
  //   // builder.addCase(login_reducer.pending, (state, action) => {
  //   //   state.Loader = true;
  //   // });
  //   // builder.addCase(login_reducer.fulfilled, (state, action) => {
  //   //   console.log(action, "action");
  //   //   state.data = action.payload;
  //   // });
  //   // builder.addCase(login_reducer.rejected, (state, action) => {
  //   //   console.log(action, "action error");
  //   //   state.data = action.payload;
  //   // });
  // },
});
export const { Loginaction, loading,DomainName } = Employee_reducer.actions;

export const selectorProvider = (state) => state.Rootreducer.Employee_reducer;

export default Employee_reducer.reducer;
