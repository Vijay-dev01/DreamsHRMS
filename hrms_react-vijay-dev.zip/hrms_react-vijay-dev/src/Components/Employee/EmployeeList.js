import React, { useEffect, useState, useRef } from "react";
import logo from "../assets/img/logo.svg";
import dashboardicon from "../assets/img/icons/dashboard-icon.svg";
import cloudicon from "../assets/img/icons/cloud-icon.svg";
import employeeicon from "../assets/img/icons/employees-icon.svg";
import timeoff from "../assets/img/icons/time-off-icon.svg";
import policyicon from "../assets/img/icons/policies-icon.svg";
import shortcuticon from "../assets/img/icons/shortcut-icon.svg";
import reporticon from "../assets/img/icons/reports-icon.svg";
import avatar1 from "../assets/img/profiles/avatar-01.jpg";
import avatar2 from "../assets/img/profiles/avatar-02.jpg";
import avatar6 from "../assets/img/profiles/avatar-06.jpg";
import avatar3 from "../assets/img/profiles/avatar-03.jpg";
import gearicon from "../assets/img/icons/gear-icon.svg";
import clockicon from "../assets/img/icons/clock-icon.svg";
import downloadicon from "../assets/img/icons/download-icon.svg";
import printericon from "../assets/img/icons/printer-icon.svg";
import funnelicon from "../assets/img/icons/funnel-icon.svg";
import baricon from "../assets/img/icons/bar-icon.svg";
import gridicon from "../assets/img/icons/grid-icon.svg";
// import gridicon from "../../assets/img/icons/grid-icon.svg";
// import avataricon from "../../assets/img/icons/avatar-icon.png";
// import step1 from "../../assets/img/icons/step-1.svg";
// import step2 from "../../assets/img/icons/step-2.svg";
// import step3 from "../../assets/img/icons/step-3.svg";
// import step4 from "../../assets/img/icons/step-4.svg";
// import step5 from "../../assets/img/icons/step-5.svg";
import "bootstrap/dist/css/bootstrap.min.css";
import axios from "axios";
import { BASEURL } from "../apiPath/baseUrl";
import { Link } from "react-router-dom";
import { Modal } from "react-bootstrap";
import FileIModal from "./FileIModal";
import Pagination from "@mui/material/Pagination";
import { usePagination } from "../Common/pagination";
import { postData, getDecryptedData } from "../services/apiUrl";
import * as XLSX from 'xlsx';
import {useReactToPrint} from 'react-to-print';

function Employee_list() {
  const [listmodal, setListmodal] = useState(false);
  const [employeeList, setEmployeeList] = useState([]);
  const [employeeprint, setEmployeePrint] = useState([]);
  const [download, setDownload] = useState([]);
  const [employeefilter, setEmployeeFilter] = useState([]);
  const [data, setData] = useState([]);
  const [values, setValues] = useState("");
  const [employeeDetails, setEmployeeDetails] = useState();
  const [employeeCount, setEmployeeCount] = useState();
  const [
    totalPages,
    startIndexPage,
    endPageIndex,
    currentPageIndex,
    displayPage,
  ] = usePagination(6, data.length);
  console.log(totalPages, "totalPageRecord");
  console.log(data, "data123");
  
  
	//Print Function
	const componentRef = useRef();
  const employeePrint = useReactToPrint({
content: () => componentRef.current,
documentTitle: "Employee-List"
});

//Excel Download Function
const employeeDownload = () => {
var wb = XLSX.utils.book_new(),
ws = XLSX.utils.json_to_sheet(employeeDetails);

XLSX.utils.book_append_sheet(wb, ws, "Employee Sheet")

XLSX.writeFile(wb, "EmployeeList.xlsx")
};	

  const employeeFilter = async () => {
    try {
      const response = await axios.post(`${BASEURL}employee-list`);
      setEmployeeFilter(response.data);
      console.log(response.data, "response.data");
    } catch (error) {
      console.error(error);
    }
  };
  const employeepagination = async () => {
    try {
      const response = await axios.get("http://localhost:8000/Get");
      const data = await response.data;
      setData(data);
      console.log(data, "input");
      console.log(response.data, "response.data");
    } catch (error) {
      console.error(error);
    }
  };

  const employeelist = () => {
    const emplyeedata = {
      user_id: 1,
    };
    postData("employee-list", emplyeedata, (data, res) => {
      console.log(data.data, "data99999");
	    setEmployeeDetails(data.data.emp_list)
      setEmployeeCount(data.data.emp_count)
    });
  };

  useEffect(() => {
    console.log("employeeDetails",employeeDetails)
    }, [employeeDetails,employeeCount]);

  useEffect(() => {
    employeelist();
    // details();
    // employeepagination();
    // details();
  }, []);
  return (
    <div class="main-wrapper">
      <header class="header header-fixed header-one">
        <nav class="navbar navbar-expand-lg header-nav">
          <div class="navbar-header">
            <a id="mobile_btn" href="javascript:void(0);">
              <span class="bar-icon">
                <span></span>
                <span></span>
                <span></span>
              </span>
            </a>
            <a href="javascript:void(0);" class="navbar-brand logo">
              <img src={logo} class="img-fluid" alt="Logo" />
            </a>
          </div>
          <div class="main-menu-wrapper">
            <ul class="main-nav">
              <li>
                <a href="javascript:void(0);">
                  <img src={dashboardicon} alt="" /> Dashboard
                </a>
              </li>
              <li class="active">
                <a href="employees.html">
                  <img src={employeeicon} alt="" /> Employees
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={timeoff} alt="" /> Time off
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={policyicon} alt="" /> Policies
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={reporticon} alt="" /> Reports
                </a>
              </li>
            </ul>
            <ul class="nav header-navbar-rht">
              <li class="nav-item search-item">
                <div class="top-nav-search">
                  <form action="#">
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Search"
                      onChange={(e) => setValues(e.target.value)}
                    />
                    <button
                      class="btn"
                      type="submit" /* onClick={handleSearch} */
                    >
                      <i class="feather-search"></i>
                    </button>
                    <span>
                      <img src={shortcuticon} alt="" />
                    </span>
                  </form>
                </div>
              </li>
              <li class="nav-item quick-link-item">
                <a class="btn" href="javascript:void(0);">
                  <span>
                    Quick Links <i class="feather-zap"></i>
                  </span>
                </a>
              </li>
              <li class="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i class="feather-sun"></i>
                </a>
              </li>
              <li class="nav-item dropdown has-arrow notification-dropdown">
                <a
                  href="#"
                  class="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <i class="feather-bell"></i>
                  <span class="badge">3</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end notifications">
                  <div class="topnav-dropdown-header">
                    <span class="notification-title">Notifications</span>
                    <a href="javascript:void(0)" class="clear-noti">
                      {" "}
                      Clear All
                    </a>
                  </div>
                  <div class="noti-content">
                    <ul class="notification-list">
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar1}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">John Doe</span>
                                added new task{" "}
                                <span class="noti-title">
                                  Patient appointment booking
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  4 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar2}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Tarah Shropshire</span>{" "}
                                changed the task name{" "}
                                <span class="noti-title">
                                  Appointment booking with payment gateway
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  6 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar6}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Misty Tison</span>{" "}
                                added{" "}
                                <span class="noti-title">Domenic Houston</span>{" "}
                                and <span class="noti-title">Claire Mapes</span>{" "}
                                to project{" "}
                                <span class="noti-title">
                                  Doctor available module
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  8 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar3}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Rolland Webber</span>{" "}
                                completed task{" "}
                                <span class="noti-title">
                                  Patient and Doctor video conferencing
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  12 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar2}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Bernardo Galaviz</span>{" "}
                                added new task{" "}
                                <span class="noti-title">
                                  Private chat module
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  2 days ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="topnav-dropdown-footer">
                    <a href="javascript:void(0)">View all Notifications</a>
                  </div>
                </div>
              </li>
              <li class="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i class="feather-settings"></i>
                </a>
              </li>
              <li class="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i class="far fa-circle-question"></i>
                </a>
              </li>
              <li class="nav-item dropdown has-arrow main-drop">
                <a
                  href="#"
                  class="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <span class="user-img">
                    <img src={avatar1} class="img-rounded" alt="" />
                  </span>
                </a>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="javascript:void(0);">
                    <i class="feather-user-plus"></i> My Profile
                  </a>
                  <a class="dropdown-item" href="javascript:void(0);">
                    <i class="feather-settings"></i> Settings
                  </a>
                  <a class="dropdown-item" href="javascript:void(0);">
                    <i class="feather-log-out"></i> Logout
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </header>

      <div class="page-wrapper">
        <div class="content container">
          <div class="page-header">
            <div class="row align-items-center">
              <div class="col-lg-6 col-md-6">
                <h3 class="page-title">
                  Employees <span>({employeeCount})</span>
                  <a href="javascript:void(0);">Archived (13)</a>
                </h3>
              </div>
              <div
                class="col-lg-6 col-md-6 page-header-btns"
                onClick={() => setListmodal(true)}
              >
                <a href="javascript:void(0);" class="btn import-btn">
                  <img src={cloudicon} alt="" /> Import
                </a>
                <a href="javascript:void(0);" class="btn">
                  <img src={gearicon} alt="" />
                </a>
                <a
                  href="javascript:void(0);"
                  class="btn new-employee-btn"
                  // data-bs-toggle="modal"
                  // data-bs-target="#staticBackdrop"
                >
                  <i class="fa-solid fa-plus"></i> New Employee
                </a>
              </div>
            </div>
          </div>

          <div class="search-filter employee-list-search">
            <div class="row align-items-center">
              <div class="col-lg-6 col-md-6">
                <div class="form-group d-flex justify-content-start">
                  <i class="feather-search"></i>
                  <input type="text" class="form-control" placeholder="" />
                  <button class="btn btn-transparant" onClick={employeeFilter}>
                    Apply Filter
                  </button>
                  {/* <ul class="list-filter d-flex">
                    <li class="clearfix">
                      <i class="fa fa-building" aria-hidden="true"></i>
                      Coimbatore Office
                      <i class="fa fa-times" aria-hidden="true"></i>
                    </li>
                    <li class="clearfix">
                      <i class="fa fa-user" aria-hidden="true"></i>John Walker
                      <i class="fa fa-times" aria-hidden="true"></i>
                    </li>
                  </ul> */}
                </div>
              </div>
              <div class="col-lg-6 col-md-6">
              <ul class="nav search-btns-info">
								<li>
									<a onClick={() => window.location.reload()} class="btn">
										<img src={clockicon} alt=""/>
									</a>
								</li>
								<li>
									<a onClick={employeeDownload} class="btn">
										<img src={downloadicon} alt=""/>
									</a>
								</li>
								<li>
									<a onClick={employeePrint} class="btn">
										<img src={printericon} alt=""/>
									</a>
								</li>
								<li>
									<Link to="/employeelist" class="btn active">
										<img src={baricon} alt=""/>
									</Link>
								</li>
								<li>
									<Link to="/employee" class="btn">
										<img src={gridicon} alt=""/>
									</Link>
								</li>
                </ul>
              </div>
            </div>
          </div>

          {/* <!-- Employee List --> */}
				<div class="employee-list">
        <div ref ={componentRef} style={{width:'100%', height:window.innerHeight}}>
					<div class="row">
						<div class="col-sm-12">
							<div class="card-table">
								<div class="card-body">
									<div class="table-responsive">
										<table class="table table-center table-hover datatable">
											<thead class="thead-light">
												<tr>
													<th>Employee ID</th>
													<th>Employee Name</th>
													<th>Department</th>
													<th>Joining Date</th>
													<th>Employment Type</th>
													<th>Mail ID</th>
													<th>Phone Number</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
                      {employeeDetails &&
                      employeeDetails.map((item) => {
                        return (
												<tr>
													<td class="s-no">{item.id}</td>
													<td>
														<h2 class="table-avatar d-flex">
															<a href="#" class="avatar avatar-md me-2 profile">
																<img class="avatar-img square-circle" src={item.profile_image} alt="User Image"/>
																{item.emp_status === "Active" ? (
										<i class="fa-sharp fa-solid fa-circle success"></i>
										) : (<i class="fa-sharp fa-solid fa-circle warning"></i>
										)}
															</a>
															<a href="#">{item.first_name} {item.last_name}<br/>
															<span>{item.job_name}</span></a>
														</h2>
													</td>
													<td>
														<p>{item.dept_name}</p>
													</td>
													<td>
														<p>{item.join_date}</p>
													</td>
													<td>
														<p>{item.employement_type}</p>
													</td>
													<td>
														<p>
															<a href="mailto:johnsmith@dgthrms.com" class="mail-to">{item.emp_email}</a>
														</p>
													</td>
													<td>
														<p>{item.emp_phone}</p>
													</td>
													<td class="d-flex align-items-center">
														<div class="dropdown dropdown-action">
															<a href="#" class=" btn-action-icon " data-bs-toggle="dropdown" aria-expanded="false"><i class="fas fa-ellipsis-v"></i></a>
															<div class="dropdown-menu dropdown-menu-end">
																<ul>
																	<li>
																		<a class="dropdown-item" href="javascript:void(0);"><i class="far fa-edit me-2"></i>Edit</a>
																	</li>
																	<li>
																		<a class="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i class="far fa-trash-alt me-2"></i>Delete</a>
																	</li>
																	<li>
																		<a class="dropdown-item" href="javascript:void(0);"><i class="far fa-eye me-2"></i>View</a>
																	</li>
																	<li>
																		<a class="dropdown-item" href="javascript:void(0);"><i class="far fa-bell me-2"></i>Active</a>
																	</li>
																	<li>
																		<a class="dropdown-item" href="javascript:void(0);"><i class="far fa-bell-slash me-2"></i>Deactive</a>
																	</li>
																</ul>
															</div>
														</div>
													</td>
                          {employeeDetails?.length === 0 &&
						<div><p>No Employees Records Found</p></div>
						}
												</tr>
                        );
                        })}
                        {employeeDetails?.length === 0 &&
						<div><p>No Employees Records Found</p></div>
						}
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>

					</div>
          </div>
				</div>
				{/* <!-- Employee List --> */}

          <footer class="footer">
            <div class="container">
              <div class="row">
                <div class="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div class="footer-left">
                    <p>© 2023 Dreams HRMS</p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div class="footer-right">
                    <ul>
                      <li>
                        <a href="javascript:void(0);">Privacy Policy</a>
                      </li>
                      <li>
                        <a href="javascript:void(0);">Terms & Conditions</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </footer>
        </div>
      </div>
      <FileIModal listmodal={listmodal} setListmodal={setListmodal} />
    </div>
  );
}

export default Employee_list;


