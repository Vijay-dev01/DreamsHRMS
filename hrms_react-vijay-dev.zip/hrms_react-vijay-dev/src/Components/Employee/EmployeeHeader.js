import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  assets1,
  attach1,
  avatar1,
  avatar15,
  avatar2,
  avatar3,
  avatar5,
  avatar6,
  avatard,
  upload,
  ed,
  empicon,
  flogo,
  icon,
  logo,
  picon,
  ricon,
  sicon,
  ticon,
} from "./EmployeeImages";
import Employee_profile from "./Employee_profile";
import EmployeeAssets from "./EmployeeAssets";
import EmployeeTimesheet from "./EmployeeTimesheet";
import EmployeeTimeOff from "./EmployeeTimeOff";
import Employee_attendance from "./Employee_attendance";
import EmployeeDocument from "./EmployeeDocument";
import EmployeeTeams from "./EmployeeTeams";
import Assets from "./EmployeeAssets";
import { Modal } from "react-bootstrap";
import { postData } from "../services/apiUrl";

function EmployeeHeader() {
  const [data, setdata] = useState("Profile");
  const [profileDetail, setProfileDetail] = useState([]);
  const title = [
    "Profile",
    "Teams",
    "Assets",
    "Time Off",
    "Documents",
    "Attendance",
    "Time Sheet",
  ];

  const personalInfo = async () => {
  
    const preparData ={
      user_id: localStorage.getItem("EmployeeId")
    }
    postData("profile_info", preparData, (data, res) => {
      console.log("data1234",data)
      setProfileDetail(data?.data?.personal[0])

    });
  };

  useEffect(() => {
    personalInfo();
  }, []);

  return (
    <div>
      <div>
        <div className="main-wrapper">
          {/* Header */}
          <header className="header header-fixed header-one">
            <nav className="navbar navbar-expand-lg header-nav">
              <div className="navbar-header">
                <Link id="mobile_btn" to="javascript:void(0);">
                  <span className="bar-icon">
                    <span />
                    <span />
                    <span />
                  </span>
                </Link>
                <Link to="javascript:void(0);" className="navbar-brand logo">
                  <img src={logo} className="img-fluid" alt="Logo" />
                </Link>
              </div>
              <div className="main-menu-wrapper">
                <ul className="main-nav">
                  <li>
                    <Link to="javascript:void(0);">
                      <img src={icon} alt="" /> Dashboard
                    </Link>
                  </li>
                  <li className="active">
                    <Link to="employees.html">
                      <img src={empicon} alt="" /> Employees
                    </Link>
                  </li>
                  <li>
                    <Link to="javascript:void(0);">
                      <img src={ticon} alt="" /* onClick={GetAsset_Data} */ />{" "}
                      Time off
                    </Link>
                  </li>
                  <li>
                    <Link to="javascript:void(0);">
                      <img src={picon} alt="" /> Policies
                    </Link>
                  </li>
                  <li>
                    <Link to="javascript:void(0);">
                      <img src={ricon} alt="" /> Reports
                    </Link>
                  </li>
                </ul>
                <ul className="nav header-navbar-rht">
                  <li className="nav-item search-item">
                    <div className="top-nav-search">
                      <form action="#">
                        <input
                          type="text"
                          className="form-control"
                          placeholder="Search"
                        />
                        <button className="btn" type="submit">
                          <i className="feather-search" />
                        </button>
                        <span>
                          <img src={sicon} alt="" />
                        </span>
                      </form>
                    </div>
                  </li>
                  <li className="nav-item quick-link-item">
                    <Link className="btn" to="javascript:void(0);">
                      <span>
                        Quick Links <i className="feather-zap" />
                      </span>
                    </Link>
                  </li>
                  <li className="nav-item nav-icons">
                    <Link to="javascript:void(0);">
                      <i className="feather-sun" />
                    </Link>
                  </li>
                  <li className="nav-item dropdown has-arrow notification-dropdown">
                    <Link
                      to="#"
                      className="dropdown-toggle nav-link"
                      data-bs-toggle="dropdown"
                    >
                      <i className="feather-bell" />
                      <span className="badge">3</span>
                    </Link>
                    <div className="dropdown-menu dropdown-menu-end notifications">
                      <div className="topnav-dropdown-header">
                        <span className="notification-title">
                          Notifications
                        </span>
                        <Link to="javascript:void(0)" className="clear-noti">
                          {" "}
                          Clear All
                        </Link>
                      </div>
                      <div className="noti-content">
                        <ul className="notification-list">
                          <li className="notification-message">
                            <Link to="javascript:void(0)">
                              <div className="media d-flex">
                                <span className="avatar flex-shrink-0">
                                  <img
                                    alt=""
                                    src={avatar1}
                                    className="rounded-circle"
                                  />
                                </span>
                                <div className="media-body flex-grow-1">
                                  <p className="noti-details">
                                    <span className="noti-title">John Doe</span>
                                    added new task{" "}
                                    <span className="noti-title">
                                      Patient appointment booking
                                    </span>
                                  </p>
                                  <p className="noti-time">
                                    <span className="notification-time">
                                      4 mins ago
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </Link>
                          </li>
                          <li className="notification-message">
                            <Link to="javascript:void(0)">
                              <div className="media d-flex">
                                <span className="avatar flex-shrink-0">
                                  <img
                                    alt=""
                                    src={avatar2}
                                    className="rounded-circle"
                                  />
                                </span>
                                <div className="media-body flex-grow-1">
                                  <p className="noti-details">
                                    <span className="noti-title">
                                      Tarah Shropshire
                                    </span>{" "}
                                    changed the task name{" "}
                                    <span className="noti-title">
                                      Appointment booking with payment gateway
                                    </span>
                                  </p>
                                  <p className="noti-time">
                                    <span className="notification-time">
                                      6 mins ago
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </Link>
                          </li>
                          <li className="notification-message">
                            <Link to="javascript:void(0)">
                              <div className="media d-flex">
                                <span className="avatar flex-shrink-0">
                                  <img
                                    alt=""
                                    src={avatar6}
                                    className="rounded-circle"
                                  />
                                </span>
                                <div className="media-body flex-grow-1">
                                  <p className="noti-details">
                                    <span className="noti-title">
                                      Misty Tison
                                    </span>{" "}
                                    added{" "}
                                    <span className="noti-title">
                                      Domenic Houston
                                    </span>{" "}
                                    and{" "}
                                    <span className="noti-title">
                                      Claire Mapes
                                    </span>{" "}
                                    to project{" "}
                                    <span className="noti-title">
                                      Doctor available module
                                    </span>
                                  </p>
                                  <p className="noti-time">
                                    <span className="notification-time">
                                      8 mins ago
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </Link>
                          </li>
                          <li className="notification-message">
                            <Link to="javascript:void(0)">
                              <div className="media d-flex">
                                <span className="avatar flex-shrink-0">
                                  <img
                                    alt=""
                                    src={avatar5}
                                    className="rounded-circle"
                                  />
                                </span>
                                <div className="media-body flex-grow-1">
                                  <p className="noti-details">
                                    <span className="noti-title">
                                      Rolland Webber
                                    </span>{" "}
                                    completed task{" "}
                                    <span className="noti-title">
                                      Patient and Doctor video conferencing
                                    </span>
                                  </p>
                                  <p className="noti-time">
                                    <span className="notification-time">
                                      12 mins ago
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </Link>
                          </li>
                          <li className="notification-message">
                            <Link to="javascript:void(0)">
                              <div className="media d-flex">
                                <span className="avatar flex-shrink-0">
                                  <img
                                    alt=""
                                    src={avatar3}
                                    className="rounded-circle"
                                  />
                                </span>
                                <div className="media-body flex-grow-1">
                                  <p className="noti-details">
                                    <span className="noti-title">
                                      Bernardo Galaviz
                                    </span>{" "}
                                    added new task{" "}
                                    <span className="noti-title">
                                      Private chat module
                                    </span>
                                  </p>
                                  <p className="noti-time">
                                    <span className="notification-time">
                                      2 days ago
                                    </span>
                                  </p>
                                </div>
                              </div>
                            </Link>
                          </li>
                        </ul>
                      </div>
                      <div className="topnav-dropdown-footer">
                        <Link to="javascript:void(0)">
                          View all Notifications
                        </Link>
                      </div>
                    </div>
                  </li>
                  <li className="nav-item nav-icons">
                    <Link to="javascript:void(0);">
                      <i className="feather-settings" />
                    </Link>
                  </li>
                  <li className="nav-item nav-icons">
                    <Link to="javascript:void(0);">
                      <i className="far fa-circle-question" />
                    </Link>
                  </li>
                  <li className="nav-item dropdown has-arrow main-drop">
                    <Link
                      to="#"
                      className="dropdown-toggle nav-link"
                      data-bs-toggle="dropdown"
                    >
                      <span className="user-img">
                        <img src={avatar1} className="img-rounded" alt="" />
                      </span>
                    </Link>
                    <div className="dropdown-menu">
                      <Link className="dropdown-item" to="javascript:void(0);">
                        <i className="feather-user-plus" /> My Profile
                      </Link>
                      <Link className="dropdown-item" to="javascript:void(0);">
                        <i className="feather-settings" /> Settings
                      </Link>
                      <Link className="dropdown-item" to="javascript:void(0);">
                        <i className="feather-log-out" /> Logout
                      </Link>
                    </div>
                  </li>
                </ul>
              </div>
            </nav>
          </header>
          {/* /Header */}
          {/* Page Wrapper */}
          <div className="page-wrapper employee-profile">
            {/* Page Content */}
            <div className="content container documents">
              {/* breadcrumb */}
              <ul className="breadcrumb">
                <li>
                  <Link to="/employee">Employees</Link>
                </li>
                <li>
                  <Link to="#">Richard</Link>
                </li>
                <li className="active">
                  <Link to="#">Time Off</Link>
                </li>
              </ul>
              {/* breadcrumb */}
              {/* employee-info */}
              <div className="employee-info d-md-flex justify-content-between">
                <div className="info-one d-lg-flex">
                  <Link to="#" className="d-inline-block profile-pic">
                    <img src={avatar15} alt="" />
                    <span className="feather-camera text-center" />
                  </Link>
                  <ul className="">
                    <li>
                      <h3>
                        {profileDetail.first_name} {profileDetail.last_name}<span>FT-0001</span>
                        <img src={ed} alt="" />
                      </h3>
                      <span className="d-block designation">
                      {profileDetail.designation}
                      </span>
                    </li>
                    <li>
                      <span className="d-block">
                        <i className="feather-phone" />
                        {profileDetail.contact}
                      </span>
                      <span className="d-block">
                        <i className="feather-mail" />
                        {profileDetail.email_id}
                      </span>
                    </li>
                  </ul>
                </div>
                <div className="info-two">
                  <ul className="">
                    <li>
                      <span className="d-block head">Department</span>
                      <span className="d-block">{profileDetail.department}</span>
                    </li>
                    <li>
                      <span className="d-block head">Date of Birth</span>
                      <span className="d-block">{profileDetail.dob}</span>
                    </li>
                  </ul>
                </div>
                <div className="info-three">
                  <ul className="">
                    <li>
                      <span className="d-block head">Line Manager</span>
                      <span className="d-block">{profileDetail.line_manager}</span>
                    </li>
                    <li>
                      <span className="d-block head">Joining Date</span>
                      <span className="d-block">{profileDetail.join_date}</span>
                    </li>
                  </ul>
                </div>
                <div className="info-four">
                  <div className="">
                    <div className="text-end">
                      <i className="fas fa-ellipsis-v" />
                    </div>
                    <p className="head">Profile Complete</p>
                    <div className="progress">
                      <div
                        className="progress-bar"
                        role="progressbar"
                        style={{ width: "75%" }}
                        aria-valuenow={75}
                        aria-valuemin={0}
                        aria-valuemax={100}
                      />
                    </div>
                    <p className="profile-completion">
                      Your profile is 81% Completed{" "}
                      <Link to="#">Finish Now</Link>
                    </p>
                  </div>
                </div>
              </div>
              {/* employee-info */}
              <div className="d-lg-flex justify-content-between align-items-center profile-items">
                <h2>{data}</h2>
                <ul class="nav nav-pills">
                  <li onClick={() => setdata("Profile")}>
                    <span href="#1a" data-toggle="tab">
                      Profile
                    </span>
                  </li>
                  <li onClick={() => setdata("Teams")}>
                    <span href="#2a" data-toggle="tab">
                      Teams
                    </span>
                  </li>
                  <li onClick={() => setdata("Assets")}>
                    <span href="#3a" data-toggle="tab">
                      Assets
                    </span>
                  </li>
                  <li onClick={() => setdata("Time Off")}>
                    <span href="#4a" data-toggle="tab">
                      Time Off{" "}
                    </span>
                  </li>
                  <li onClick={() => setdata("Documents")}>
                    <span href="#5a" data-toggle="tab">
                      Documents{" "}
                    </span>
                  </li>
                  <li onClick={() => setdata("Attendance")}>
                    <span href="#6a" data-toggle="tab">
                      Attendance{" "}
                    </span>
                  </li>
                  <li onClick={() => setdata("Time Sheet")}>
                    <span href="#7a" data-toggle="tab">
                      Time Sheet{" "}
                    </span>
                  </li>
                </ul>
                <div>
                  {data === "Profile" ? (
                    <Link to="#" className="btn gradient-btn">
                      <i className="fa fa-plus" aria-hidden="true" />
                      Meassege
                    </Link>
                  ) : (
                    ""
                  )}
                  {data === "" ? (
                    <Link to="#" className="btn gradient-btn">
                      <i className="fa fa-plus" aria-hidden="true" />
                      {data}
                    </Link>
                  ) : (
                    ""
                  )}
                  {data === "Assets" ? (
                    <div>
                      <Link href="#" className="btn gradient-btn">
                        <i className="fa fa-plus" aria-hidden="true" />
                        Add Assets
                      </Link>
                    </div>
                  ) : (
                    ""
                  )}
                  {data === "Time off" ? (
                    <Link to="#" className="btn gradient-btn">
                      <i className="fa fa-plus" aria-hidden="true" />
                    </Link>
                  ) : (
                    ""
                  )}
                  {data === "Documents" ? (
                    <div>
                      <button type="text" className="btn btn-white">
                        <img src={upload} />
                      </button>
                      <button
                        type="text"
                        className="btn gradient-btn"
                        data-bs-toggle="modal"
                        data-bs-target="#upload-doc" /* onClick={handleshow} */
                      >
                        <i className="fa fa-plus" aria-hidden="true"></i>
                        Upload Documents
                      </button>
                      {<Modal />}
                    </div>
                  ) : (
                    ""
                  )}
                  {data === "Attendance" ? (
                    <>
                      <select
                        className="form-select w-auto d-md-inline"
                        aria-label="Default select example"
                      >
                        <option selected="">Day</option>
                        <option value={1}>Week</option>
                        <option value={2}>Month</option>
                        <option value={3}>Year</option>
                      </select>

                      <div className="col-auto d-md-inline">
                        <div className="date-picker btn btn-group btn-sm">
                          <div className="ico left">
                            <i className="fas fa-chevron-left" />
                          </div>
                          <div className="cal-ico center">
                            <input type="date" />
                            {/* <i className="feather-calendar mr-1" /> */}
                            <span>Select Date</span>
                          </div>
                          <div className="ico right">
                            <i className="fas fa-chevron-right" />
                          </div>
                        </div>
                      </div>
                    </>
                  ) : (
                    ""
                  )}
                  {data === "Time Sheet" ? (
                    <div class="form-group float-end search d-inline">
                      <i class="feather-search"></i>
                      <input
                        type="text"
                        class="form-control"
                        placeholder="Search"
                      />
                    </div>
                  ) : (
                    ""
                  )}
                </div>
              </div>

              <div class="tab-content clearfix">
                <div class="tab-pane active" id="1a">
                  <Employee_profile />
                </div>
                <div class="tab-pane" id="2a">
                <EmployeeTeams />
                </div>
                <div class="tab-pane" id="3a">
                  <Assets />
                </div>
                <div class="tab-pane" id="4a">
                  <EmployeeTimeOff />
                </div>
                <div class="tab-pane" id="5a">
                  <EmployeeDocument />
                </div>
                <div class="tab-pane" id="6a">
                  <Employee_attendance />
                </div>
                <div class="tab-pane" id="7a">
                  <EmployeeTimesheet />
                </div>
              </div>
            </div>

            {/* Documents row */}
            {/* <div className="row assets">
                  <h3>All Folders</h3>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                    <div className="white-bg">
                      <div className="d-flex align-items-top head">
                        <div className="flex-grow-1">
                          <div className="d-inline-block document-icon">
                            <i className="d-inline-block text-center">
                              <img src={assets1} />
                            </i>
                          </div>
                          <div className="d-inline-block">
                            <h3 className="d-inline popup-toggle">Key Board</h3>
                            <span className="d-block">ASSET00001</span>
                          </div>
                        </div>
                        <div className="star-ellips">
                          <div className="dropdown dropdown-action d-inline-block">
                            <Link
                              to="#"
                              className="btn-action-icon show"
                              data-bs-toggle="dropdown"
                              aria-expanded="true"
                            >
                              <i className="fas fa-ellipsis-v" />
                            </Link>
                            <div
                              className="dropdown-menu dropdown-menu-end"
                              data-popper-placement="bottom-end"
                              style={{
                                position: "absolute",
                                inset: "0px 0px auto auto",
                                margin: 0,
                                transform: "translate3d(0px, 42px, 0px)",
                              }}
                            >
                              <ul>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="edit-invoice.html"
                                  >
                                    <i className="far fa-edit me-2" />
                                    Edit
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="javascript:void(0);"
                                    data-bs-toggle="modal"
                                    data-bs-target="#delete_modal"
                                  >
                                    <i className="far fa-trash-alt me-2" />
                                    Delete
                                  </Link>
                                </li>
                                <li>
                                  <Link
                                    className="dropdown-item"
                                    to="#"
                                    data-bs-toggle="modal"
                                    data-bs-target="#share"
                                  >
                                    <i
                                      className="fa fa-share-alt"
                                      aria-hidden="true"
                                    />
                                    Share
                                  </Link>
                                </li>
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="users-files">
                        <div className="d-flex justify-content-between align-items-center">
                          <p>
                            <span>Assignee :</span>&nbsp;&nbsp;John Smith
                          </p>
                          <p>
                            <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div> */}
            {/* Documents row */}
            {/* Footer */}
            <footer className="footer">
              <div className="container">
                <div className="row">
                  <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                    <div className="footer-left">
                      <p>
                        © 2023 Dreams HRMS <span>Developed by</span>
                        <Link to="#">
                          <img src={flogo} />
                        </Link>
                      </p>
                    </div>
                  </div>
                  <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                    <div className="footer-right">
                      <ul>
                        <li>
                          <Link to="javascript:void(0);">Privacy Policy</Link>
                        </li>
                        <li>
                          <Link to="javascript:void(0);">
                            Terms &amp; Conditions
                          </Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </footer>
            {/* Footer */}
          </div>
          {/* /Page Content */}
        </div>
        {/* /Page Wrapper */}
      </div>
    </div>
  );
}

export default EmployeeHeader;
