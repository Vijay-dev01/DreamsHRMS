import React, { useState } from 'react'
import { allpolicies, allreports, avatar1, avatar15, avatar2, avatar3, avatar5, avatar6, avatard, drag1, ed, eduavatar, education, edudoc, edunotepad, eduxls, empicon, empmenuicon, flogo, icon, logo, picon, presentation, ricon, shiftschedule, sicon, sidebar, ticon, timeofficon, timesheet, upload } from '../imagepath'
import { Link } from 'react-router-dom';


const Document = () => {
    const [showModal, setShowModel] = useState(false);
    const [show, setShow] = useState(false);
    const [out, setOut] = useState(false);
    const [share, setShare] = useState(false);
    const [modal, setModal] = useState(false);

    const handleShow = () => {
        console.log('Click')
        setShowModel(true);
    }

    const handleClose = () => {
        console.log('Click')
        setShowModel(false);
    }
    console.log(showModal);

    const toggleShow = () => {
        console.log('click')
        setShow(true)
    }

    const toggleClose = () => {
        console.log('click')
        setShow(false)
    }
    console.log(show);

    const threeShow = () => {
        console.log('click')
        setOut(true)
    }

    const threeClose = () => {
        console.log('click')
        setOut(false)
    }
    console.log(out);

    const shareShow = () => {
        console.log('click')
        setShare(true)
    }

    const shareClose = () => {
        console.log('click')
        setShare(false)
    }
    console.log(share);

    const modalShow = () => {
        console.log('click')
        setModal(true)
    }
  
    const modalClose = () => {
        console.log('click')
        setModal(false)
    }
    console.log(modal);
  
      const Employeetab = () => {
        return (
            
            <div onClick={modalClose}>
            <ul className={modal ? "dropdown-menu clearfix show" : "dropdown-menu clearfix"} style={{ display: modal ? 'block' : 'none' }}>
              <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt />Employees</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt />Time Off</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={timesheet} alt />Timesheet</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt />All Policies</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={allreports} alt />Shift &amp; Schedule</Link></li>
              <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt />All Reports</Link></li>
              <li className="w-100 bottom-list-menu">
                <ul className="sub-menu clearfix">
                  <li><Link to="#">Documentation</Link></li>
                  <li><Link to="#">Changelog v1.4.4</Link></li>
                  <li><Link to="#">Components</Link></li>
                  <li><Link to="#">Support</Link></li>
                  <li><Link to="#">Terms &amp; Conditions</Link></li>
                  <li><Link to="#">About</Link></li>
                </ul>
              </li>
            </ul>
            </div>
        )
    }
  


    const Share = () => {
        return (
            <div className={share ? 'modal fade show' : 'modal fade'} style={{ display: share ? 'block' : 'none' }} id="edu-share" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-hidden="true">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Share File</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" onClick={shareClose}></i></button>
                        </div>
                        <div className="modal-body">
                            <div className="form-group required">
                                <label className="label">Share With Team Members</label>
                                <input type="email" className="form-control" />
                            </div>
                            <div className="form-group d-flex align-items-center justify-content-between">
                                <h6>Share Read-Only Link</h6>
                                <div className="status-toggle d-flex align-items-center">
                                    <input id="rating_1" className="check" type="checkbox" />
                                    <label for="rating_1" className="checktoggle checkbox-bg mb-0"></label>
                                </div>
                            </div>
                            <p>Anyone with the link can view this file, but won't be able to edit it.</p>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn gradient-btn">Share File</button>
                            <button type="button" className="btn btn-dull" data-bs-dismiss="modal" onClick={shareClose}>Cancle</button>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

    const Edit = () => {
        return (
            <div className="star-ellips">
                <div className="dropdown dropdown-action d-inline-block" onClick={threeClose} >
                    <Link href="#" className= "btn-action-icon " data-bs-toggle="dropdown" aria-expanded={{ display: share ? "true" : "false" }}>
                        <Share />
                    </Link >
                    <div className=  "dropdown-menu dropdown-menu-end" 
                        data-popper-placement="bottom-end" >
                        <ul>
                            <li>
                                <Link className="dropdown-item" href="edit-invoice.html"><i className="far fa-edit me-2"></i>Edit</Link >
                            </li>
                            <li>
                                <Link className="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2"></i>Delete</Link >
                            </li>
                            <li>
                                <Link className="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#edu-share" onClick={shareShow}>
                                    <i className="fa fa-share-alt" aria-hidden="true" >
                                    </i>Share</Link >
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        )
    }

    const Aside = () => {
        return (
            <div className={show ? 'toggle-sidebar open-sidebar' : 'toggle-sidebar'} style={{ display: show ? 'block' : 'none' }}>
                <div className="d-flex align-items-center justify-content-between head">

                    <i className="d-flex align-items-center text-center justify-content-center icon-bg"><img src={sidebar} /></i>

                    <h5>Design presentation</h5>
                    {/* <button> */}
                        <i className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes" aria-hidden="true" onClick={toggleClose} >

                        </i>
                        {/* </button> */}
                </div>
                <img src={presentation} />
                <h6>File Owner</h6>
                <div className="d-flex align-items-center justify-content-start owner">
                    <img src={eduavatar} />
                    <span>Richard Steve</span>
                </div>
                <h6>Who has Access</h6>
                <div className="row">
                    <div className="col-xs-12 col-sm-6 ">
                        <div className="group-avatar">
                            <span className="avatar">
                                <img src={eduavatar} />
                            </span>
                            <span className="avatar">
                                <img src={eduavatar} />
                            </span>
                            <span className="avatar">
                                <img src={eduavatar} />
                            </span>
                            <span className="avatar">
                                <img src={eduavatar} />
                            </span>
                            <span className="avatar">
                                10+
                            </span>
                        </div>
                    </div>
                    <div className="col-xs-12 col-sm-6 d-flex align-items-center">
                        <span>Member Access </span>
                    </div>
                </div>
                <h6>File Information</h6>
                <ul>
                    <li><span>Created Date:</span>08 Ma 2023, 6:48:31 PM</li>
                    <li><span>Created Date:</span>08 Ma 2023, 6:48:31 PM</li>
                    <li><span>View:</span>15 Members</li>
                </ul>
                <h6>Activity</h6>
                <ul className="activity">
                    <li>
                        <span className="d-block">Yesterday</span>
                        <div className="row">
                            <div className="col-xs-12 col-sm-6 col-md-4">
                                <div className="d-block group-avatar-wrap">
                                    <div className="group-avatar">
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            10+
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                                <div className="">
                                    <span>Richard Shared Edit Access to <Link href="#">John</Link ></span>
                                </div>
                            </div>
                        </div>
                        {/* <!--row--> */}
                    </li>

                    <li>
                        <span className="d-block">Yesterday</span>
                        <div className="row">
                            <div className="col-xs-12 col-sm-6 col-md-4">
                                <div className="d-block group-avatar-wrap">
                                    <div className="group-avatar">
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            10+
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                                <div className="">
                                    <span>Richard Shared Edit Access to <Link href="#">Robert</Link ></span>
                                </div>
                            </div>
                        </div>
                        {/* <!--row--> */}
                    </li>

                    <li>
                        <span className="d-block">Yesterday</span>
                        <div className="row">
                            <div className="col-xs-12 col-sm-6 col-md-4">
                                <div className="d-block group-avatar-wrap">
                                    <div className="group-avatar">
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            <img src={avatard} />
                                        </span>
                                        <span className="avatar">
                                            10+
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                                <div className="">
                                    <span>Richard Changed File Name <Link href="#">Design Presentation</Link ></span>
                                </div>
                            </div>
                        </div>
                        {/* <!--row--> */}
                    </li>
                </ul>
                <div className="">
                    <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><span className="feather-eye toggle-password"></span>View</button>
                    <button type="button" className="btn gradient-btn"><i className="fa fa-download" aria-hidden="true"></i>Download</button>
                </div>

            </div>
        )
    }

    const Modal = () => {
        return (
            
            <div class="modal fade" id="upload-doc" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="newscheduleLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header d-flex justify-content-between align-items-center">
                            <i className="fa fa-download blue-dull-bg d-inline-block text-center" aria-hidden="true"></i>
                            <h5 className="modal-title">Upload Documents</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" onClick={handleClose}>
                                <i className="fa fa-times" aria-hidden="true"></i>
                            </button>
                        </div>
                        <div className="modal-body">
                            <div className="drag-drop text-center">
                                <div className="upload">
                                    <Link href="#"><img src={drag1} /></Link >
                                    <p>Drag & drop your files here or choose file <Link href="#">browse</Link ></p>
                                    <span>Maximum size: 50MB</span>
                                </div>
                            </div>

                            <div className="upload-data">
                                <div className="d-flex justify-content-between align-items-center">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <img src={edudoc} />
                                        <span>Resume-ui.doc</span>
                                    </div>
                                    <div className="d-flex justify-content-between align-items-center action-icon">
                                        <i className="fa fa-check-circle success-icon" aria-hidden="true"></i>
                                        <i className="fa fa-trash" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-100" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                            <div className="upload-data warning">
                                <div className="d-flex justify-content-between align-items-center">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <img src={eduxls} />
                                        <span>Resume-ui.doc</span>
                                    </div>
                                    <div className="d-flex justify-content-between align-items-center action-icon">
                                        <i className="fa fa-exclamation-triangle warning-icon" aria-hidden="true"></i>
                                        <i className="fa fa-trash" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-50" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                            <div className="upload-data">
                                <div className="d-flex justify-content-between align-items-center">
                                    <div className="d-flex justify-content-between align-items-center">
                                        <img src={education} />
                                        <span>Resume-ui.doc</span>
                                    </div>
                                    <div className="d-flex justify-content-between align-items-center action-icon">
                                        <i className="fa fa-pause" aria-hidden="true"></i>
                                        <i className="fa fa-trash" aria-hidden="true"></i>
                                    </div>
                                </div>
                                <div className="progress">
                                    <div className="progress-bar w-25" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                </div>
                )
                }


  return (
    <>
            {/* Main Wrapper */}
            <div className="main-wrapper">
                {/* Header */}
                <header className="header header-fixed header-one">
                    <nav className="navbar navbar-expand-lg header-nav">
                        <div className="navbar-header">
                            <Link id="mobile_btn" href="javascript:void(0);">
                                <span className="bar-icon">
                                    <span />
                                    <span />
                                    <span />
                                </span>
                            </Link>
                            <Link href="javascript:void(0);" className="navbar-brand logo">
                                <img src={logo} className="img-fluid" alt="Logo" />
                            </Link>
                        </div>
                        <div className="main-menu-wrapper">
                            <ul className="main-nav">
                                <li>
                                    <Link href="javascript:void(0);">
                                        <img src={icon} alt="" />{" "}
                                        Dashboard
                                    </Link>
                                </li>
                                <li className="active">
                                    <Link href="employees.html">
                                        <img src={empicon} alt="" />{" "}
                                        Employees
                                    </Link>
                                </li>
                                <li>
                                    <Link href="javascript:void(0);">
                                        <img src={ticon} alt="" /> Time off
                                    </Link>
                                </li>
                                <li>
                                    <Link href="javascript:void(0);">
                                        <img src={picon} alt="" /> Policies
                                    </Link>
                                </li>
                                <li>
                                    <Link href="javascript:void(0);">
                                        <img src={ricon} alt="" /> Reports
                                    </Link>
                                </li>
                            </ul>
                            <ul className="nav header-navbar-rht">
                                <li className="nav-item search-item">
                                    <div className="top-nav-search">
                                        <form action="#">
                                            <input
                                                type="text"
                                                className="form-control"
                                                placeholder="Search"
                                            />
                                            <button className="btn" type="submit">
                                                <i className="feather-search" />
                                            </button>
                                            <span>
                                                <img src={sicon} alt="" />
                                            </span>
                                        </form>
                                    </div>
                                </li>
                                <li className="nav-item quick-link-item">
                                    <Link className="btn" href="javascript:void(0);" onClick={modalShow}>
                                        <span>
                                            Quick Links <i className="feather-zap" />
                                        </span>
                                    </Link>
                                    {<Employeetab/>}
                                </li>
                                <li className="nav-item nav-icons">
                                    <Link href="javascript:void(0);">
                                        <i className="feather-sun" />
                                    </Link>
                                </li>
                                <li className="nav-item dropdown has-arrow notification-dropdown">
                                    <Link
                                        href="#"
                                        className="dropdown-toggle nav-link"
                                        data-bs-toggle="dropdown"
                                    >
                                        <i className="feather-bell" />
                                        <span className="badge">3</span>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-end notifications">
                                        <div className="topnav-dropdown-header">
                                            <span className="notification-title">Notifications</span>
                                            <Link href="javascript:void(0)" className="clear-noti">
                                                {" "}
                                                Clear All
                                            </Link>
                                        </div>
                                        <div className="noti-content">
                                            <ul className="notification-list">
                                                <li className="notification-message">
                                                    <Link href="javascript:void(0)">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img
                                                                    alt=""
                                                                    src={avatar1}
                                                                    className="rounded-circle"
                                                                />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details">
                                                                    <span className="noti-title">John Doe</span>
                                                                    added new task{" "}
                                                                    <span className="noti-title">
                                                                        Patient appointment booking
                                                                    </span>
                                                                </p>
                                                                <p className="noti-time">
                                                                    <span className="notification-time">
                                                                        4 mins ago
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link href="javascript:void(0)">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img
                                                                    alt=""
                                                                    src={avatar2}
                                                                    className="rounded-circle"
                                                                />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details">
                                                                    <span className="noti-title">
                                                                        Tarah Shropshire
                                                                    </span>{" "}
                                                                    changed the task name{" "}
                                                                    <span className="noti-title">
                                                                        Appointment booking with payment gateway
                                                                    </span>
                                                                </p>
                                                                <p className="noti-time">
                                                                    <span className="notification-time">
                                                                        6 mins ago
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link href="javascript:void(0)">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img
                                                                    alt=""
                                                                    src={avatar6}
                                                                    className="rounded-circle"
                                                                />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details">
                                                                    <span className="noti-title">Misty Tison</span>{" "}
                                                                    added{" "}
                                                                    <span className="noti-title">
                                                                        Domenic Houston
                                                                    </span>{" "}
                                                                    and{" "}
                                                                    <span className="noti-title">Claire Mapes</span>{" "}
                                                                    to project{" "}
                                                                    <span className="noti-title">
                                                                        Doctor available module
                                                                    </span>
                                                                </p>
                                                                <p className="noti-time">
                                                                    <span className="notification-time">
                                                                        8 mins ago
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link href="javascript:void(0)">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img
                                                                    alt=""
                                                                    src={avatar5}
                                                                    className="rounded-circle"
                                                                />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details">
                                                                    <span className="noti-title">Rolland Webber</span>{" "}
                                                                    completed task{" "}
                                                                    <span className="noti-title">
                                                                        Patient and Doctor video conferencing
                                                                    </span>
                                                                </p>
                                                                <p className="noti-time">
                                                                    <span className="notification-time">
                                                                        12 mins ago
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link href="javascript:void(0)">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img
                                                                    alt=""
                                                                    src={avatar3}
                                                                    className="rounded-circle"
                                                                />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details">
                                                                    <span className="noti-title">
                                                                        Bernardo Galaviz
                                                                    </span>{" "}
                                                                    added new task{" "}
                                                                    <span className="noti-title">
                                                                        Private chat module
                                                                    </span>
                                                                </p>
                                                                <p className="noti-time">
                                                                    <span className="notification-time">
                                                                        2 days ago
                                                                    </span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="topnav-dropdown-footer">
                                            <Link href="javascript:void(0)">View all Notifications</Link>
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item nav-icons">
                                    <Link href="javascript:void(0);">
                                        <i className="feather-settings" />
                                    </Link>
                                </li>
                                <li className="nav-item nav-icons">
                                    <Link href="javascript:void(0);">
                                        <i className="far fa-circle-question" />
                                    </Link>
                                </li>
                                <li className="nav-item dropdown has-arrow main-drop">
                                    <Link
                                        href="#"
                                        className="dropdown-toggle nav-link"
                                        data-bs-toggle="dropdown"
                                    >
                                        <span className="user-img">
                                            <img
                                                src={avatar1}
                                                className="img-rounded"
                                                alt=""
                                            />
                                        </span>
                                    </Link>
                                    <div className="dropdown-menu">
                                        <Link className="dropdown-item" href="javascript:void(0);">
                                            <i className="feather-user-plus" /> My Profile
                                        </Link>
                                        <Link className="dropdown-item" href="javascript:void(0);">
                                            <i className="feather-settings" /> Settings
                                        </Link>
                                        <Link className="dropdown-item" href="javascript:void(0);">
                                            <i className="feather-log-out" /> Logout
                                        </Link>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header>
                {/* /Header */}
                {/* Page Wrapper */}
                <div className="page-wrapper employee-profile">
                    {/* Page Content */}
                    <div className="content container documents">
                        {/* breadcrumb */}
                        <ul className="breadcrumb">
                            <li>
                                <Link href="#">Employees</Link>
                            </li>
                            <li>
                                <Link href="#">Richard</Link>
                            </li>
                            <li className="active">
                                <Link href="#">Documents</Link>
                            </li>
                        </ul>
                        {/* breadcrumb */}
                        {/* employee-info */}
                        <div className="employee-info d-md-flex justify-content-between">
                            <div className="info-one d-lg-flex">
                                <Link href="#" className="d-inline-block profile-pic">
                                    <img src={avatar15} alt="" />
                                    <span className="feather-camera text-center" />
                                </Link>
                                <ul className="">
                                    <li>
                                        <h3>
                                            Richard Steve <span>FT-0001</span>
                                            <img src={ed} alt="" />
                                        </h3>
                                        <span className="d-block designation">UI/UX Designer</span>
                                    </li>
                                    <li>
                                        <span className="d-block">
                                            <i className="feather-phone" />
                                            (907) 888-0101
                                        </span>
                                        <span className="d-block">
                                            <i className="feather-mail" />
                                            example@email.com
                                        </span>
                                    </li>
                                </ul>
                            </div>
                            <div className="info-two">
                                <ul className="">
                                    <li>
                                        <span className="d-block head">Department</span>
                                        <span className="d-block">Design Team</span>
                                    </li>
                                    <li>
                                        <span className="d-block head">Date of Birth</span>
                                        <span className="d-block">25 May 1996</span>
                                    </li>
                                </ul>
                            </div>
                            <div className="info-three">
                                <ul className="">
                                    <li>
                                        <span className="d-block head">Line Manager</span>
                                        <span className="d-block">John Smith</span>
                                    </li>
                                    <li>
                                        <span className="d-block head">Joining Date</span>
                                        <span className="d-block">15 July 2020</span>
                                    </li>
                                </ul>
                            </div>
                            <div className="info-four">
                                <div className="">
                                    <div className="text-end">
                                        <i className="fas fa-ellipsis-v" />
                                    </div>
                                    <p className="head">Profile Complete</p>
                                    <div className="progress">
                                        <div
                                            className="progress-bar"
                                            role="progressbar"
                                            style={{ width: "75%" }}
                                            aria-valuenow={75}
                                            aria-valuemin={0}
                                            aria-valuemax={100}
                                        />
                                    </div>
                                    <p className="profile-completion">
                                        Your profile is 81% Completed <Link href="#">Finish Now</Link>
                                    </p>
                                </div>
                            </div>
                        </div>
                        {/* employee-info */}
                        <div className="d-lg-flex justify-content-between align-items-center profile-items">
                            <h2>Documents</h2>
                            <ul className="d-sm-flex">
                                <li>
                                    <Link href="employee-profile.html">Profile</Link>
                                </li>
                                <li>
                                    <Link href="employee-teams.html">Teams</Link>
                                </li>
                                <li>
                                    <Link href="employee-assets.html">Assets</Link>
                                </li>
                                <li>
                                    <Link href="employee-time-off.html">Time off</Link>
                                </li>
                                <li className="active">
                                    <Link href="employee-documents.html">Documents</Link>
                                </li>
                                <li>
                                    <Link href="employee-attendance.html">Attendance</Link>
                                </li>
                                <li>
                                    <Link href="employee-timesheet.html">Time Sheet</Link>
                                </li>
                            </ul>
                            <div>
                                <button type="text" className="btn btn-white">
                                    <img src={upload} />
                                </button>
                                <button
                                    type="text"
                                    className="btn gradient-btn"
                                    data-bs-toggle="modal"
                                    data-bs-target="#upload-doc"
                                   onClick={handleShow}
                                >
                                    <i className="fa fa-plus" aria-hidden="true" />
                                    Upload Documents
                                    {<Modal/>}
                                </button>

                            </div>
                        </div>
                        {/* Documents row */}
                        <div className="row education-documents">
                            <h3>Education Documents</h3>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center red-dull-bg">
                                                    <img src={education} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block" onClick={toggleShow}>
                                                <h3 className="d-inline dotted-text popup-toggle">
                                                    Education Documents
                                                </h3>
                                                <span className="d-block">1 Minute ago</span>
                                            </div>
                                            {<Aside />}
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                    onClick={threeShow}
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                    {<Edit />}
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center red-dull-bg">
                                                    <img src={education} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline">Education Documents</h3>
                                                <span className="d-block">4 hrs ago</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center red-dull-bg">
                                                    <img src={education} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline dotted-text">X Marksheet.pdf</h3>
                                                <span className="d-block">yesterday</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center red-dull-bg">
                                                    <img src={education} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline dotted-text">X Marksheet.pdf</h3>
                                                <span className="d-block">07 Mar 2023</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                        </div>
                        {/* Documents row */}
                        {/* Documents row */}
                        <div className="row education-documents">
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center blue-dull-bg">
                                                    <img src={edudoc} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline dotted-text">
                                                    Education Documents
                                                </h3>
                                                <span className="d-block">1 Minute ago</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center green-dull-bg">
                                                    <img src={eduxls} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline">Education Documents</h3>
                                                <span className="d-block">4 hrs ago</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center red-dull-bg">
                                                    <img src={education} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline dotted-text">X Marksheet.pdf</h3>
                                                <span className="d-block">yesterday</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                            <div className="col-sm-12 col-md-6 col-lg-3 document-wrap">
                                <div className="white-bg">
                                    <div className="d-flex align-items-top head">
                                        <div className="flex-grow-1">
                                            <div className="d-inline-block document-icon">
                                                <i className="d-flex align-items-center text-center justify-content-center red-dull-bg">
                                                    <img src={edunotepad} />
                                                </i>
                                            </div>
                                            <div className="d-inline-block">
                                                <h3 className="d-inline dotted-text">X Marksheet.pdf</h3>
                                                <span className="d-block">07 Mar 2023</span>
                                            </div>
                                        </div>
                                        <div className="star-ellips">
                                            <div className="dropdown dropdown-action d-inline-block">
                                                <Link
                                                    href="#"
                                                    className="btn-action-icon show"
                                                    data-bs-toggle="dropdown"
                                                    aria-expanded="true"
                                                >
                                                    <i className="fas fa-ellipsis-v" />
                                                </Link>
                                                <div
                                                    className="dropdown-menu dropdown-menu-end"
                                                    data-popper-placement="bottom-end"
                                                    style={{
                                                        position: "absolute",
                                                        inset: "0px 0px auto auto",
                                                        margin: 0,
                                                        transform: "translate3d(0px, 42px, 0px)"
                                                    }}
                                                >
                                                    <ul>
                                                        <li>
                                                            <Link className="dropdown-item" href="edit-invoice.html">
                                                                <i className="far fa-edit me-2" />
                                                                Edit
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="javascript:void(0);"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#delete_modal"
                                                            >
                                                                <i className="far fa-trash-alt me-2" />
                                                                Delete
                                                            </Link>
                                                        </li>
                                                        <li>
                                                            <Link
                                                                className="dropdown-item"
                                                                href="#"
                                                                data-bs-toggle="modal"
                                                                data-bs-target="#edu-share"
                                                            >
                                                                <i className="fa fa-share-alt" aria-hidden="true" />
                                                                Share
                                                            </Link>
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="row users-files align-items-center">
                                        <div className="col-xs-12 col-sm-6 ">
                                            <div className="d-block">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={eduavatar} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6">
                                            <span>Member Access</span>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </div>
                            </div>
                        </div>
                        {/* Documents row */}
                        {/* document-slide */}
                        <div className="toggle-sidebar">
                            <div className="d-flex align-items-center justify-content-between head">
                                <i className="d-flex align-items-center text-center justify-content-center icon-bg">
                                    <img src={sidebar} />
                                </i>
                                <h5>Design presentation</h5>
                                <i
                                    className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes"
                                    aria-hidden="true"
                                />
                            </div>
                            <img src={presentation} />
                            <h6>File Owner</h6>
                            <div className="d-flex align-items-center justify-content-start owner">
                                <img src={eduavatar} />
                                <span>Richard Steve</span>
                            </div>
                            <h6>Who has Access</h6>
                            <div className="row">
                                <div className="col-xs-12 col-sm-6 ">
                                    <div className="group-avatar">
                                        <span className="avatar">
                                            <img src={eduavatar} />
                                        </span>
                                        <span className="avatar">
                                            <img src={eduavatar} />
                                        </span>
                                        <span className="avatar">
                                            <img src={eduavatar} />
                                        </span>
                                        <span className="avatar">
                                            <img src={eduavatar} />
                                        </span>
                                        <span className="avatar">10+</span>
                                    </div>
                                </div>
                                <div className="col-xs-12 col-sm-6 d-flex align-items-center">
                                    <span>Member Access </span>
                                </div>
                            </div>
                            <h6>File Information</h6>
                            <ul>
                                <li>
                                    <span>Created Date:</span>08 Ma 2023, 6:48:31 PM
                                </li>
                                <li>
                                    <span>Created Date:</span>08 Ma 2023, 6:48:31 PM
                                </li>
                                <li>
                                    <span>View:</span>15 Members
                                </li>
                            </ul>
                            <h6>Activity</h6>
                            <ul className="activity">
                                <li>
                                    <span className="d-block">Yesterday</span>
                                    <div className="row">
                                        <div className="col-xs-12 col-sm-6 col-md-4">
                                            <div className="d-block group-avatar-wrap">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        {/* <img src="assets/img/profiles/avatar-doc-list.png"> */}
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                                            <div className="">
                                                <span>
                                                    Richard Shared Edit Access to <Link href="#">John</Link>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </li>
                                <li>
                                    <span className="d-block">Yesterday</span>
                                    <div className="row">
                                        <div className="col-xs-12 col-sm-6 col-md-4">
                                            <div className="d-block group-avatar-wrap">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        {/* <img src="assets/img/profiles/avatar-doc-list.png"> */}
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                                            <div className="">
                                                <span>
                                                    Richard Shared Edit Access to <Link href="#">Robert</Link>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </li>
                                <li>
                                    <span className="d-block">Yesterday</span>
                                    <div className="row">
                                        <div className="col-xs-12 col-sm-6 col-md-4">
                                            <div className="d-block group-avatar-wrap">
                                                <div className="group-avatar">
                                                    <span className="avatar">
                                                        {/* <img src="assets/img/profiles/avatar-doc-list.png"> */}
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">
                                                        <img src={avatard} />
                                                    </span>
                                                    <span className="avatar">10+</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                                            <div className="">
                                                <span>
                                                    Richard Changed File Name{" "}
                                                    <Link href="#">Design Presentation</Link>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    {/*row*/}
                                </li>
                            </ul>
                            <div className="">
                                <button
                                    type="button"
                                    className="btn btn-dull"
                                    data-bs-dismiss="modal"
                                >
                                    <span className="feather-eye toggle-password" />
                                    View
                                </button>
                                <button type="button" className="btn gradient-btn">
                                    <i className="fa fa-download" aria-hidden="true" />
                                    Download
                                </button>
                            </div>
                        </div>
                        {/* document-slide */}
                        <div className="docs-pages pagination-wrap d-flex justify-content-between">
                            <p>
                                Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;
                                <i className="fa fa-caret-right" aria-hidden="true" />
                            </p>
                            <ul className="d-flex">
                                <li>
                                    <Link href="#">1</Link>
                                </li>
                                <li>
                                    <Link href="#">2</Link>
                                </li>
                                <li>
                                    <Link href="#">3</Link>
                                </li>
                                <li>
                                    <Link href="#">...</Link>
                                </li>
                                <li>
                                    <Link href="#">10</Link>
                                </li>
                                <li>
                                    <Link href="#">11</Link>
                                </li>
                                <li>
                                    <Link href="#">12</Link>
                                </li>
                            </ul>
                            <p>
                                Go to page&nbsp;&nbsp;
                                <i className="fa fa-long-arrow-right" aria-hidden="true" />
                            </p>
                        </div>
                        {/* Footer */}
                        <footer className="footer">
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                                        <div className="footer-left">
                                            <p>
                                                © 2023 Dreams HRMS <span>Developed by</span>
                                                <Link href="#">
                                                    <img src={flogo} />
                                                </Link>
                                            </p>
                                        </div>
                                    </div>
                                    <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                                        <div className="footer-right">
                                            <ul>
                                                <li>
                                                    <Link href="javascript:void(0);">Privacy Policy</Link>
                                                </li>
                                                <li>
                                                    <Link href="javascript:void(0);">Terms &amp; Conditions</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </footer>
                        {/* Footer */}
                    </div>
                    {/* /Page Content */}
                </div>
                {/* /Page Wrapper */}
            </div>
           
        </>
  )
}

export default Document
