import axios from "axios";
import React, { useEffect, useState } from "react";
import teamIcon from "../assets/img/icons/team-icon.png";
import { postData } from "../services/apiUrl";

export default function EmployeeTeams() {

    // const TeamsInfo = async () => {
    
    //     const preparData ={
    //       user_id: localStorage.getItem("EmployeeId"),
    //     }
    //     postData("profile_info", preparData, (data, res) => {
    //       console.log(preparData, "dataprofile99999");
    //     });
    //   };

    useEffect(() => {


      }, []);

      return (
        <div>
    <div class="d-flex justify-content-between align-items-center team-head">
        <div class="d-flex justify-content-between align-items-center">
            <div class="">
                <img src={teamIcon} alt=""/>
            </div>
            <div class="text">
                <h4>UI/UX Designing Team</h4>
                <span>10 Employees</span>
                <span>Active</span>
            </div>
        </div>
        <div class="d-flex justify-content-between align-items-center">
            <div class="group-avatar d-inline-flex">
                  <span class="avatar">
                    <a href="javascript:void(0);"  data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1"><img src="assets/img/profiles/avatar-doc-list.png" alt=""/></a>
                </span>
                  <span class="avatar">
                    <a href="javascript:void(0);"  data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2"><img src="assets/img/profiles/avatar-doc-list.png" alt=""/></a>
                </span>
                  <span class="avatar">
                    <a href="javascript:void(0);"  data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3"><img src="assets/img/profiles/avatar-doc-list.png" alt=""/></a>
                </span>
                  <span class="avatar">
                   <a href="javascript:void(0);"  data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4"><img src="assets/img/profiles/avatar-doc-list.png" alt=""/></a>
                </span>
                <span class="avatar count">
                   <a href="javascript:void(0);" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">10+</a>
                </span>
            </div>
            <div class="">
                <button type="button" class="btn btn-white"><i class="fa fa-search-minus" aria-hidden="true"></i></button>
                <button type="button" class="btn btn-white"><i class="fa fa-search-plus" aria-hidden="true"></i></button>
            </div>
        </div>
    </div>

    <div class="tree">
        <ul>
            <li>
                <div class="info-wrap">
                    <div class="d-flex justify-content-start align-items-center individual-info blue-tree">
                          <div class="profile-pic">
                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                              <i class="active"></i>
                          </div>
                          <div class="">
                              <h5>John Smith</h5>
                              <span>Team Leader</span>
                          </div>
                          <div class="open-close d-flex justify-content-center align-items-center">
                              <i class="fa fa-minus" aria-hidden="true"></i>
                          </div>
                    </div>
                </div>
                <ul class="inn_line">
                    <li>
                        <div class="info-wrap">
                            <div class="d-flex justify-content-start align-items-center individual-info yellow-tree">
                                  <div class="profile-pic">
                                      <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                      <i class="active"></i>
                                  </div>
                                  <div class="">
                                      <h5>John Smith</h5>
                                      <span>Team Leader</span>
                                  </div>
                                  <div class="open-close d-flex justify-content-center align-items-center">
                                      <i class="fa fa-minus" aria-hidden="true"></i>
                                  </div>
                            </div>
                        </div>
                        <ul class="inn_line">
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="de-active"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="de-active"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <div class="info-wrap">
                            <div class="d-flex justify-content-start align-items-center individual-info yellow-tree">
                                  <div class="profile-pic">
                                      <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                      <i class="idle"></i>
                                  </div>
                                  <div class="">
                                      <h5>John Smith</h5>
                                      <span>Team Leader</span>
                                  </div>
                                  <div class="open-close d-flex justify-content-center align-items-center">
                                      <i class="fa fa-minus" aria-hidden="true"></i>
                                  </div>
                            </div>
                        </div>
                        <ul class="inn_line">
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="idle"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="idle"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <div class="info-wrap">
                            <div class="d-flex justify-content-start align-items-center individual-info yellow-tree">
                                  <div class="profile-pic">
                                      <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                      <i class="active"></i>
                                  </div>
                                  <div class="">
                                      <h5>John Smith</h5>
                                      <span>Team Leader</span>
                                  </div>
                                  <div class="open-close d-flex justify-content-center align-items-center">
                                      <i class="fa fa-minus" aria-hidden="true"></i>
                                  </div>
                            </div>
                        </div>
                        <ul class="inn_line">
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="de-active"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="active"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <div class="info-wrap">
                            <div class="d-flex justify-content-start align-items-center individual-info yellow-tree">
                                  <div class="profile-pic">
                                      <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                      <i class="de-active"></i>
                                  </div>
                                  <div class="">
                                      <h5>John Smith</h5>
                                      <span>Team Leader</span>
                                  </div>
                                  <div class="open-close d-flex justify-content-center align-items-center">
                                      <i class="fa fa-minus" aria-hidden="true"></i>
                                  </div>
                            </div>
                        </div>
                        <ul class="inn_line">
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="active"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="info-wrap">
                                    <div class="d-flex justify-content-start align-items-center individual-info green-tree">
                                          <div class="profile-pic">
                                              <img class="avatar-img rounded-circle" src="assets/img/profiles/team1.png" alt="User Image"/>
                                              <i class="de-active"></i>
                                          </div>
                                          <div class="">
                                              <h5>John Smith</h5>
                                              <span>Team Leader</span>
                                          </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    </div>
      );

}