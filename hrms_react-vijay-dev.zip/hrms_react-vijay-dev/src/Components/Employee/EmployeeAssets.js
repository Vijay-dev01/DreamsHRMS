import React, { useEffect, useState } from "react";
import axios from "axios";
import { BASEURL } from "../apiPath/baseUrl";
import { Link } from "react-router-dom";
import {
  assets1,
  attach1,
  avatar1,
  avatar15,
  avatar2,
  avatar3,
  avatar5,
  avatar6,
  avatard,
  ed,
  empicon,
  flogo,
  icon,
  logo,
  picon,
  ricon,
  sicon,
  ticon,
} from "./EmployeeImages";

const Assets = () => {
  const [show, setShow] = useState(false);

  const toggleShow = () => {
    console.log("click");
    setShow(true);
  };

  const toggleClose = () => {
    console.log("click");
    setShow(false);
  };
  console.log(show);
  const [employeeAssets, setEmployeeAssets] = useState([]);

  const Employee_store_Assets = async () => {
    try {
      const response = await axios.get(`${BASEURL}assign_asset`);
      setEmployeeAssets(response.data);
      console.log(response.data, "response");
    } catch (error) {
      console.error(error);
    }
  };
  const delete_asset = async () => {
    try {
      const response = await axios.delete(`${BASEURL}delete_asset`);
      setEmployeeAssets(response.data);
      console.log(response.data, "response");
    } catch (error) {
      console.error(error);
    }
  };
  const assign_asset = async () => {
    try {
      const response = await axios.get(`${BASEURL}assign_details/id:222`);
      setEmployeeAssets(response.data);
      console.log(response.data, "response");
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    // assign_asset();
    // delete_asset();
    // Employee_store_Assets();
  }, []);

  const Aside = () => {
    return (
      <div
        className={
          show ? "toggle-sidebar asset open-sidebar" : "toggle-sidebar asset"
        }
        style={{ display: show ? "block" : "none" }}
      >
        <div className="d-flex align-items-center justify-content-between head">
          <h5>Assets Deatils</h5>
          <i
            className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes"
            aria-hidden="true"
            onClick={toggleClose}
          />
        </div>
        <h6>Asset Info</h6>
        <div className="d-flex align-items-center justify-content-start asset-info">
          <img src={assets1} />
          <span>Key Board</span>
        </div>
        <table className="w-100">
          <tbody>
            <tr>
              <td>
                <span>Asset ID</span>
              </td>
              <td align="right">
                <p>ASSET00001</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Device Type</span>
              </td>
              <td align="right">
                <p>Laptop Accessories</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Brand</span>
              </td>
              <td align="right">
                <p>Zebronics</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Model</span>
              </td>
              <td align="right">
                <p>Zebronics</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Serial Number</span>
              </td>
              <td align="right">
                <p>Nil</p>
              </td>
            </tr>
          </tbody>
        </table>
        <h6>Asset History</h6>
        <table className="w-100">
          <tbody>
            <tr>
              <td>
                <span>Owner</span>
              </td>
              <td align="right">
                <p>Hernandez</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>User</span>
              </td>
              <td align="right">
                <p>Richard Steve</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Brand</span>
              </td>
              <td align="right">
                <p>Zebronics</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Model</span>
              </td>
              <td align="right">
                <p>Zebronics</p>
              </td>
            </tr>
            <tr>
              <td>
                <span>Serial Number</span>
              </td>
              <td align="right">
                <p>Nil</p>
              </td>
            </tr>
          </tbody>
        </table>
        <h6>Attachment</h6>
        <table className="w-100 attachment">
          <tbody>
            <tr>
              <td>
                <Link href="#">
                  <img src={attach1} />
                </Link>
              </td>
              <td>
                <Link href="#">
                  <img src={attach1} />
                </Link>
              </td>
              <td>
                <Link href="#">
                  <img src={attach1} />
                </Link>
              </td>
            </tr>
            <tr>
              <td>
                <Link href="#">
                  <img src={attach1} />
                </Link>
              </td>
              <td>
                <Link href="#">
                  <img src={attach1} />
                </Link>
              </td>
              <td>
                <Link href="#">
                  <img src={attach1} />
                </Link>
              </td>
            </tr>
          </tbody>
        </table>
        <h6>Activity</h6>
        <ul className="activity">
          <li>
            <span className="d-block">Yesterday</span>
            <div className="row">
              <div className="col-xs-12 col-sm-6 col-md-4">
                <div className="d-block group-avatar-wrap">
                  <div className="group-avatar">
                    <span className="avatar">
                      <img src={avatard} />
                    </span>
                    <span className="avatar">
                      <img src={avatard} />
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                <div className="">
                  <span>
                    Richard Shared Edit Access to <Link href="#">John</Link>
                  </span>
                </div>
              </div>
            </div>
            {/* Row */}
          </li>
          <li>
            <span className="d-block">Yesterday</span>
            <div className="row">
              <div className="col-xs-12 col-sm-6 col-md-4">
                <div className="d-block group-avatar-wrap">
                  <div className="group-avatar">
                    <span className="avatar">
                      <img src={avatard} />
                    </span>
                    <span className="avatar">
                      <img src={avatard} />
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                <div className="">
                  <span>
                    Richard Shared Edit Access to <Link href="#">Robert</Link>
                  </span>
                </div>
              </div>
            </div>
            {/* Row */}
          </li>
          <li>
            <span className="d-block">Yesterday</span>
            <div className="row">
              <div className="col-xs-12 col-sm-6 col-md-4">
                <div className="d-block group-avatar-wrap">
                  <div className="group-avatar">
                    <span className="avatar">
                      <img src={avatard} />
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                <div className="">
                  <span>
                    Richard Changed File Name{" "}
                    <Link href="#">Design Presentation</Link>
                  </span>
                </div>
              </div>
            </div>
            {/* Row */}
          </li>
          <li>
            <span className="d-block">Yesterday</span>
            <div className="row">
              <div className="col-xs-12 col-sm-6 col-md-4">
                <div className="d-block group-avatar-wrap">
                  <div className="group-avatar">
                    <span className="avatar">
                      <img src={avatard} />
                    </span>
                  </div>
                </div>
              </div>
              <div className="col-xs-12 col-sm-6 col-md-8 no-padding">
                <div className="">
                  <span>
                    Richard Changed File Name{" "}
                    <Link href="#">Design Presentation</Link>
                  </span>
                </div>
              </div>
            </div>
            {/* Row */}
          </li>
        </ul>
        <div className="">
          <button type="button" className="btn gradient-btn w-100">
            <i className="fa fa-flag" aria-hidden="true" />
            Report Issue
          </button>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="main-wrapper">
        {/* Page Wrapper */}
        <div className="e">
          {/* Page Content */}
          <div className="content container documents">
            <div className="row assets">
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                      {<Aside />}
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
                <div className="white-bg">
                  <div className="d-flex align-items-top head">
                    <div className="flex-grow-1">
                      <div className="d-inline-block document-icon">
                        <i className="d-inline-block text-center">
                          <img src={assets1} />
                        </i>
                      </div>
                      <div className="d-inline-block" onClick={toggleShow}>
                        <h3 className="d-inline popup-toggle">Key Board</h3>
                        <span className="d-block">ASSET00001</span>
                      </div>
                    </div>
                    <div className="star-ellips">
                      <div className="dropdown dropdown-action d-inline-block">
                        <Link
                          href="#"
                          className="btn-action-icon show"
                          data-bs-toggle="dropdown"
                          aria-expanded="true"
                        >
                          <i className="fas fa-ellipsis-v" />
                        </Link>
                        <div
                          className="dropdown-menu dropdown-menu-end"
                          data-popper-placement="bottom-end"
                          style={{
                            position: "absolute",
                            inset: "0px 0px auto auto",
                            margin: 0,
                            transform: "translate3d(0px, 42px, 0px)",
                          }}
                        >
                          <ul>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="edit-invoice.html"
                              >
                                <i className="far fa-edit me-2" />
                                Edit
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="javascript:void(0);"
                                data-bs-toggle="modal"
                                data-bs-target="#delete_modal"
                              >
                                <i className="far fa-trash-alt me-2" />
                                Delete
                              </Link>
                            </li>
                            <li>
                              <Link
                                className="dropdown-item"
                                href="#"
                                data-bs-toggle="modal"
                                data-bs-target="#share"
                              >
                                <i
                                  className="fa fa-share-alt"
                                  aria-hidden="true"
                                />
                                Share
                              </Link>
                            </li>
                          </ul>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="users-files">
                    <div className="d-flex justify-content-between align-items-center">
                      <p>
                        <span>Assignee :</span>&nbsp;&nbsp;John Smith
                      </p>
                      <p>
                        <span>Date :</span>&nbsp;&nbsp;06 Jan 2023
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Page Content */}
        </div>
        {/* /Page Wrapper */}
      </div>
      {/* /Main Wrapper */}
      {/* Document Slide */}

      {/* Document Slide */}
      {/* Modal */}
      <div
        className="modal fade"
        id="share"
        tabIndex={-1}
        aria-labelledby="share"
        aria-hidden="true"
      >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="share">
                Share File
              </h5>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <i className="fa fa-times" aria-hidden="true" />
              </button>
            </div>
            <div className="modal-body">
              <div className="form-group required">
                <label className="label">Share With Team Members</label>
                <input type="email" className="form-control" />
              </div>
              <div className="form-group d-flex align-items-center justify-content-between">
                <h6>Share Read-Only Link</h6>
                <div className="status-toggle d-flex align-items-center">
                  <input id="rating_1" className="check" type="checkbox" />
                  <label
                    htmlFor="rating_1"
                    className="checktoggle checkbox-bg mb-0"
                  />
                </div>
              </div>
              <p>
                Anyone with the link can view this file, but won't be able to
                edit it.
              </p>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn gradient-btn">
                Share File
              </button>
              <button
                type="button"
                className="btn btn-dull"
                data-bs-dismiss="modal"
              >
                Cancle
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Assets;
