import React, { useState,useEffect } from "react";
import axios from "axios";
import {
  logo,
  dashboard,
  employee,
  time,
  Policies,
  reports,
  shortcut,
  avatar1,
  avatar2,
  avatar6,
  avatar5,
  avatar3,
  avatar15,
  profiles,
  working,
  working1,
  overtime,
  daily,
  missing,
  late,
  grid,
  bar,
  ascending,
  time1,
  funnel,
} from "./EmployeeImages";
import { Link } from "react-router-dom";
import Pagination from "@mui/material/Pagination";
import { usePagination } from "../Common/pagination";

function Employee_attendance() {
  const [attendancedata, setAttendancedata] = useState([]);
  console.log(attendancedata, "attendancedata");

  const [
    totalPages,
    startIndexPage,
    endPageIndex,
    currentPageIndex,
    displayPage,
  ] = usePagination(3, attendancedata.length);

  const employeeattendancepagination = async () => {
    try {
      const response = await axios.get("http://localhost:8000/attendance");
      const data = await response.data;
      setAttendancedata(data);
      console.log(data, "input");
      console.log(response.data, "response.data");
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    // employeeattendancepagination();
  }, []);
  return (
    <div className="main-wrapper">
      {/* Header */}
      {/* <header className="header header-fixed header-one">
        <nav className="navbar navbar-expand-lg header-nav">
          <div className="navbar-header">
            <a id="mobile_btn" href="javascript:void(0);">
              <span className="bar-icon">
                <span />
                <span />
                <span />
              </span>
            </a>
            <a href="javascript:void(0);" className="navbar-brand logo">
              <img src={logo} className="img-fluid" alt="Logo" />
            </a>
          </div>
          <div className="main-menu-wrapper">
            <ul className="main-nav">
              <li>
                <a href="javascript:void(0);">
                  <img src={dashboard} alt="" /> Dashboard
                </a>
              </li>
              <li className="active">
                <a href="javascript:void(0);">
                  <img src={employee} alt="" /> Employees
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={time} alt="" /> Time off
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={Policies} alt="" /> Policies
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={reports} alt="" /> Reports
                </a>
              </li>
            </ul>
            <ul className="nav header-navbar-rht">
              <li className="nav-item search-item">
                <div className="top-nav-search">
                  <form action="#">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search"
                    />
                    <button className="btn" type="submit">
                      <i className="feather-search" />
                    </button>
                    <span>
                      <img src={shortcut} alt="" />
                    </span>
                  </form>
                </div>
              </li>
              <li className="nav-item quick-link-item">
                <a className="btn" href="javascript:void(0);">
                  <span>
                    Quick Links <i className="feather-zap" />
                  </span>
                </a>
              </li>
              <li className="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i className="feather-sun" />
                </a>
              </li>
              <li className="nav-item dropdown has-arrow notification-dropdown">
                <a
                  href="javascript:void(0);"
                  className="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <i className="feather-bell" />
                  <span className="badge">3</span>
                </a>
                <div className="dropdown-menu dropdown-menu-end notifications">
                  <div className="topnav-dropdown-header">
                    <span className="notification-title">Notifications</span>
                    <a href="javascript:void(0);" className="clear-noti">
                      {" "}
                      Clear All
                    </a>
                  </div>
                  <div className="noti-content">
                    <ul className="notification-list">
                      <li className="notification-message">
                        <a href="javascript:void(0);">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar1}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">John Doe</span>
                                added new task{" "}
                                <span className="noti-title">
                                  Patient appointment booking
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  4 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li className="notification-message">
                        <a href="javascript:void(0);">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar2}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">
                                  Tarah Shropshire
                                </span>{" "}
                                changed the task name{" "}
                                <span className="noti-title">
                                  Appointment booking with payment gateway
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  6 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li className="notification-message">
                        <a href="javascript:void(0);">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar6}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">Misty Tison</span>{" "}
                                added{" "}
                                <span className="noti-title">
                                  Domenic Houston
                                </span>{" "}
                                and{" "}
                                <span className="noti-title">Claire Mapes</span>{" "}
                                to project{" "}
                                <span className="noti-title">
                                  Doctor available module
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  8 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li className="notification-message">
                        <a href="javascript:void(0);">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar5}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">
                                  Rolland Webber
                                </span>{" "}
                                completed task{" "}
                                <span className="noti-title">
                                  Patient and Doctor video conferencing
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  12 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li className="notification-message">
                        <a href="javascript:void(0);">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar3}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">
                                  Bernardo Galaviz
                                </span>{" "}
                                added new task{" "}
                                <span className="noti-title">
                                  Private chat module
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  2 days ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div className="topnav-dropdown-footer">
                    <a href="javascript:void(0);">View all Notifications</a>
                  </div>
                </div>
              </li>
              <li className="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i className="feather-settings" />
                </a>
              </li>
              <li className="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i className="far fa-circle-question" />
                </a>
              </li>
              <li className="nav-item dropdown has-arrow main-drop">
                <a
                  href="javascript:void(0);"
                  className="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <span className="user-img">
                    <img src={avatar1} className="img-rounded" alt="" />
                  </span>
                </a>
                <div className="dropdown-menu">
                  <a className="dropdown-item" href="javascript:void(0);">
                    <i className="feather-user-plus" /> My Profile
                  </a>
                  <a className="dropdown-item" href="javascript:void(0);">
                    <i className="feather-settings" /> Settings
                  </a>
                  <a className="dropdown-item" href="javascript:void(0);">
                    <i className="feather-log-out" /> Logout
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </header> */}
      {/* /Header */}
      {/* Page Wrapper */}
      <div /* className="page-wrapper employee-profile" */>
        {/* Page Content */}
        <div className="content container">
          {/* breadcrumb */}
          <ul className="breadcrumb">
            {/* <li>
              <a href="javascript:void(0);">Employees</a>
            </li>
            <li>
              <a href="javascript:void(0);">Richard</a>
            </li>
            <li className="active">
              <a href="javascript:void(0);">Attendance</a>
            </li> */}
            {/* <li>
              <i href="#">Employees</i>
            </li>
            <li>
              <i href="#">Richard</i>
            </li>
            <li class="active">
              <i href="#" style={{ fontWeight: "500" }}>
                Attendance
              </i>
            </li> */}
          </ul>
          {/* breadcrumb */}
          {/* employee-info */}
          {/* <div className="employee-info d-md-flex justify-content-between">
            <div className="info-one d-lg-flex">
              <a
                href="javascript:void(0);"
                className="d-inline-block profile-pic"
              >
                <img src={avatar15} alt="" />
                <span className="feather-camera text-center" />
              </a>
              <ul className="">
                <li>
                  <h3>
                    Richard Steve <span>FT-0001</span>
                    <img src={profiles} alt="" />
                  </h3>
                  <span className="d-block designation">UI/UX Designer</span>
                </li>
                <li>
                  <span className="d-block">
                    <i className="feather-phone" />
                    (907) 888-0101
                  </span>
                  <span className="d-block">
                    <i className="feather-mail" />
                    example@email.com
                  </span>
                </li>
              </ul>
            </div>
            <div className="info-two">
              <ul className="">
                <li>
                  <span className="d-block head">Department</span>
                  <span className="d-block">Design Team</span>
                </li>
                <li>
                  <span className="d-block head">Date of Birth</span>
                  <span className="d-block">25 May 1996</span>
                </li>
              </ul>
            </div>
            <div className="info-three">
              <ul className="">
                <li>
                  <span className="d-block head">Line Manager</span>
                  <span className="d-block">John Smith</span>
                </li>
                <li>
                  <span className="d-block head">Joining Date</span>
                  <span className="d-block">15 July 2020</span>
                </li>
              </ul>
            </div>
            <div className="info-four">
              <div className="">
                <div className="text-end">
                  <i className="fas fa-ellipsis-v" />
                </div>
                <p className="head">Profile Complete</p>
                <div className="progress">
                  <div
                    className="progress-bar"
                    role="progressbar"
                    style={{ width: "75%" }}
                    aria-valuenow={75}
                    aria-valuemin={0}
                    aria-valuemax={100}
                  />
                </div>
                <p className="profile-completion">
                  Your profile is 81% Completed{" "}
                  <a href="javascript:void(0);">Finish Now</a>
                </p>
              </div>
            </div>
          </div> */}
          {/* employee-info */}
          <div /* className="d-lg-flex justify-content-between align-items-center profile-items" */
          >
            {/* <h2>Attendance</h2> */}
            {/* <ul className="d-sm-flex">
              <li>
                <Link to={"/employeeprofile"}>Profile</Link>
              </li>
              <li>
                <Link to={"/employeeprofile"}>Teams</Link>
              </li>
              <li className="active">
                <Link to={"/employeeprofile"}>Assets</Link>
              </li>
              <li>
                <Link to={"/employeetime"}>Time off</Link>
              </li>
              <li>
                <Link to={"/employee"}>Documents</Link>
              </li>
              <li>
                <Link to={"/employeeattendance"}>Attendance</Link>
              </li>
              <li>
                <Link to="/employeetime">Time Sheet</Link>
              </li>
            </ul> */}
            {/* <select
              className="form-select w-auto d-md-inline"
              aria-label="Default select example"
            >
              <option selected="">Day</option>
              <option value={1}>Week</option>
              <option value={2}>Month</option>
              <option value={3}>Year</option>
            </select> */}
            {/* datepicker */}
            {/* <div className="col-auto d-md-inline">
              <div className="date-picker btn btn-group btn-sm">
                <div className="ico left">
                  <i className="fas fa-chevron-left" />
                </div>
                <div className="cal-ico center">
                  <i className="feather-calendar mr-1" />
                  <span>Select Date</span>
                </div>
                <div className="ico right">
                  <i className="fas fa-chevron-right" />
                </div>
              </div>
            </div> */}
            {/* /datepicker */}
          </div>
          {/* attendance */}
          <div className="row attendance">
            {/* employee chart */}
            <div className="col-sm-12 col-md-4 live-attendance">
              <div className="white-bg">
                <h3 className="text-capitalize">Live Attendance</h3>
                <div className="time-tracker row">
                  <div className="col-md-12 col-lg-6">
                    <img src={time1} alt="" />
                    {/* Attendance Chart */}
                    <div id="attendance-chart" />
                    {/* /Attendance Chart */}
                  </div>
                  <div className="col-md-12 col-lg-6">
                    <h5>16:20</h5>
                    <span>Monday,03 Mar 2023</span>
                    <ul>
                      <li className="working-hrs">Working Hours</li>
                      <li className="break">Break</li>
                      <li className="remaining-hrs">Remaining hours</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            {/* /employee chart */}
            <div className="col-sm-12 col-md-8">
              <div className="col-sm-12 col-md-6 col-lg-4 list float-start">
                <div className="white-bg">
                  <div className="d-flex avg-working-hrs">
                    <div className="flex-grow-1">
                      <span>Average Working Hours</span>
                      <h4>40 Hours</h4>
                    </div>
                    <i className="text-center">
                      <img src={working} className="align-middle" alt="" />
                    </i>
                  </div>
                  <div className="percentage">
                    <span className="danger-text">-1.48%</span>
                    <span>Since last week</span>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 list float-start">
                <div className="white-bg">
                  <div className="d-flex working-hrs">
                    <div className="flex-grow-1">
                      <span>Working Hours</span>
                      <h4>30 Hours</h4>
                    </div>
                    <i className="text-center">
                      <img src={working1} className="align-middle" alt="" />
                    </i>
                  </div>
                  <div className="percentage">
                    <span className="success-text">+3.48%</span>
                    <span>Since last week</span>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 list float-start">
                <div className="white-bg">
                  <div className="d-flex overtime-hrs">
                    <div className="flex-grow-1">
                      <span>Average Working Hours</span>
                      <h4>40 Hours</h4>
                    </div>
                    <i className="text-center">
                      <img src={overtime} className="align-middle" alt="" />
                    </i>
                  </div>
                  <div className="percentage">
                    <span className="danger-text">-1.48%</span>
                    <span>Since last week</span>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 list float-start">
                <div className="white-bg">
                  <div className="d-flex daily-attendance">
                    <div className="flex-grow-1">
                      <span>Average Working Hours</span>
                      <h4>40 Hours</h4>
                    </div>
                    <i className="text-center">
                      <img src={daily} className="align-middle" alt="" />
                    </i>
                  </div>
                  <div className="percentage">
                    <span className="danger-text">-1.48%</span>
                    <span>Since last week</span>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 list float-start">
                <div className="white-bg">
                  <div className="d-flex missing-punch">
                    <div className="flex-grow-1">
                      <span>Average Working Hours</span>
                      <h4>40 Hours</h4>
                    </div>
                    <i className="text-center">
                      <img src={missing} className="align-middle" alt="" />
                    </i>
                  </div>
                  <div className="percentage">
                    <span className="success-text">+1.48%</span>
                    <span>Since last week</span>
                  </div>
                </div>
              </div>
              <div className="col-sm-12 col-md-6 col-lg-4 list float-start">
                <div className="white-bg">
                  <div className="d-flex late-login">
                    <div className="flex-grow-1">
                      <span>Average Working Hours</span>
                      <h4>40 Hours</h4>
                    </div>
                    <i className="text-center">
                      <img src={late} className="align-middle" alt="" />
                    </i>
                  </div>
                  <div className="percentage">
                    <span className="success-text">+1.48%</span>
                    <span>Since last week</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /row-attendance */}
          <div className="clearfix margin-top-btm-25 sub-head search-filter row align-items-center">
            <div className="col-md-12 col-lg-4">
              <h2>Attendance Logs</h2>
            </div>
            {/* <div class="form-group float-end search d-inline">
    <i class="feather-search"></i>
    <input type="text" class="form-control" placeholder="Search">
</div> */}
            <ul
              className="col-md-12 col-lg-8 nav search-btns-info nav nav-tabs"
              id="myTab"
              role="tablist"
            >
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link btn btn-transparent"
                  id="grid-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#grid"
                  type="button"
                  role="tab"
                  aria-controls="grid"
                  aria-selected="true"
                >
                  <img src={grid} alt="" />
                  &nbsp;&nbsp;Grid View
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link active btn btn-transparent"
                  id="list-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#list"
                  type="button"
                  role="tab"
                  aria-controls="list"
                  aria-selected="true"
                >
                  <img src={bar} alt="" />
                  &nbsp;&nbsp;List View
                </button>
              </li>
              <li className="nav-item" role="presentation">
                <button
                  className="nav-link btn btn-transparent"
                  id="calendar-tab"
                  data-bs-toggle="tab"
                  data-bs-target="#calendar-view"
                  type="button"
                  role="tab"
                  aria-controls="calendar-view"
                  aria-selected="true"
                >
                  <i className="fa fa-calendar" aria-hidden="true" />
                  &nbsp;&nbsp;Calendar View
                </button>
              </li>
              <li>
                <label className="d-inline">Show</label>
                <button className="btn btn-transparent">
                  week
                  <i className="fa fa-chevron-down" aria-hidden="true" />
                </button>
              </li>
              <li>
                <a href="javascript:void(0);" className="btn">
                  <img src={funnel} alt="" />
                </a>
              </li>
              <li>
                <a href="javascript:void(0);" className="btn">
                  <img src={ascending} alt="" />
                </a>
              </li>
              <li>
                <a href="javascript:void(0);" className="btn">
                  <i className="fa fa-search" aria-hidden="true" />
                </a>
              </li>
              <li>
                <a href="javascript:void(0);" className="btn">
                  <i className="fas fa-ellipsis-v" />
                </a>
              </li>
            </ul>
          </div>
          {/* /Attendance Log */}
          {/*tab-contant */}
          <div className="tab-content">
            {/* grid-tab */}
            <div
              className="tab-pane fade"
              id="grid"
              role="tabpanel"
              aria-labelledby="grid-tab"
            >
              grid view shows here
            </div>
            {/* /grid-tab */}
            {/* list-view */}
            <div
              className="employee-attendance-list tab-pane fade show active"
              id="list"
              role="tab-pane"
              aria-labelledby="list-tab"
            >
              <div className="row">
                <div className="col-sm-12">
                  <div className="card-table">
                    <div className="card-body">
                      <div className="table-responsive">
                        <table className="table table-center table-hover datatable">
                          <thead className="thead-light">
                            <tr>
                              <th>
                                #&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Date&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Login Time&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Logout Time&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Break&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Production Hours&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Overtime&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Late Entry&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Attendance&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                              <th>
                                Action&nbsp;&nbsp;
                                <i
                                  className="fa fa-caret-down"
                                  aria-hidden="true"
                                />
                              </th>
                            </tr>
                          </thead>
                          {(() => {
                            const displayPosts = [];
                            for (
                              let i = startIndexPage;
                              i <= endPageIndex;
                              i++
                            ) {
                              displayPosts.push(
                                <tbody>
                                  <tr>
                                    <td>{attendancedata[i]?.id}</td>
                                    <td>
                                      <p>{attendancedata[i]?.Date}</p>
                                      <span>3 Days</span>
                                    </td>
                                   

                                    <td>
                                      <p>03 March 2023</p>
                                      <span>Thursday</span>
                                    </td>
                                    <td>
                                      <p>09:30 AM</p>
                                      <span>Morning Shift</span>
                                    </td>
                                    <td>
                                      <p>06:30 PM</p>
                                    </td>
                                    <td>
                                      <p>1hr</p>
                                    </td>
                                    <td>
                                      <p className="warning-text">
                                        <i className="feather-trending-down" />
                                        07.45 hrs
                                      </p>
                                    </td>
                                    <td>
                                      <p>- - : - -</p>
                                    </td>
                                        <td>
                                      <p className="present success-status">
                                        Present
                                      </p>
                                    </td>
                            
        
                                  <td className="d-flex align-items-center">
                                      <div className="dropdown dropdown-action">
                                        <a
                                          href="javascript:void(0);"
                                          className=" btn-action-icon "
                                          data-bs-toggle="dropdown"
                                          aria-expanded="false"
                                        >
                                          <i className="fas fa-ellipsis-v" />
                                        </a>
                                        <div className="dropdown-menu dropdown-menu-end">
                                          <ul>
                                            <li>
                                              <a
                                                className="dropdown-item"
                                                to="edit-invoice.html"
                                              >
                                                <i className="far fa-edit me-2" />
                                                Edit
                                              </a>
                                            </li>
                                            <li>
                                              <a
                                                className="dropdown-item"
                                                href="javascript:void(0);"
                                                data-bs-toggle="modal"
                                                data-bs-target="#delete_modal"
                                              >
                                                <i className="far fa-trash-alt me-2" />
                                                Delete
                                              </a>
                                            </li>
                                            <li>
                                              <a
                                                className="dropdown-item"
                                                to="invoice-details.html"
                                              >
                                                <i className="far fa-eye me-2" />
                                                View
                                              </a>
                                            </li>
                                            <li>
                                              <a
                                                className="dropdown-item"
                                                to="active-customers.html"
                                              >
                                                <i className="far fa-bell me-2" />
                                                Active
                                              </a>
                                            </li>
                                            <li>
                                              <a
                                                className="dropdown-item"
                                                to="deactive-customers.html"
                                              >
                                                <i className="far fa-bell-slash me-2" />
                                              </a>
                                            </li>
                                          </ul>
                                        </div>
                                      </div>
                                    </td> 
                                  </tr>
                                  {/* <tr>
                              <td>1</td>
                              <td>
                                <p>03 March 2023</p>
                                <span>Thursday</span>
                              </td>
                              <td>
                                <p>09:30 AM</p>
                                <span>Morning Shift</span>
                              </td>
                              <td>
                                <p>06:30 PM</p>
                              </td>
                              <td>
                                <p>1hr</p>
                              </td>
                              <td>
                                <p className="success-text">
                                  <i className="feather-trending-up" />
                                  08.00 hrs
                                </p>
                              </td>
                              <td>
                                <p>- - : - -</p>
                              </td>
                              <td>
                                <p>- - : - -</p>
                              </td>
                              <td>
                                <p className="present success-status">
                                  Present
                                </p>
                              </td>
                              <td className="d-flex align-items-center">
                                <div className="dropdown dropdown-action">
                                  <a
                                    href="javascript:void(0);"
                                    className=" btn-action-icon "
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                  >
                                    <i className="fas fa-ellipsis-v" />
                                  </a>
                                  <div className="dropdown-menu dropdown-menu-end">
                                    <ul>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="edit-invoice.html"
                                        >
                                          <i className="far fa-edit me-2" />
                                          Edit
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          href="javascript:void(0);"
                                          data-bs-toggle="modal"
                                          data-bs-target="#delete_modal"
                                        >
                                          <i className="far fa-trash-alt me-2" />
                                          Delete
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="invoice-details.html"
                                        >
                                          <i className="far fa-eye me-2" />
                                          View
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="active-customers.html"
                                        >
                                          <i className="far fa-bell me-2" />
                                          Active
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="deactive-customers.html"
                                        >
                                          <i className="far fa-bell-slash me-2" />
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </td>
                            </tr>
                            <tr>
                              <td>1</td>
                              <td>
                                <p>03 March 2023</p>
                                <span>Thursday</span>
                              </td>
                              <td>
                                <p>09:30 AM</p>
                                <span>Morning Shift</span>
                              </td>
                              <td>
                                <p>06:30 PM</p>
                              </td>
                              <td>
                                <p>1hr</p>
                              </td>
                              <td>
                                <p className="success-text">
                                  <i className="feather-trending-up" />
                                  08.00 hrs
                                </p>
                              </td>
                              <td>
                                <p>- - : - -</p>
                              </td>
                              <td>
                                <p>- - : - -</p>
                              </td>
                              <td>
                                <p className="present success-status">
                                  Present
                                </p>
                              </td>
                              <td className="d-flex align-items-center">
                                <div className="dropdown dropdown-action">
                                  <a
                                    href="javascript:void(0);"
                                    className=" btn-action-icon "
                                    data-bs-toggle="dropdown"
                                    aria-expanded="false"
                                  >
                                    <i className="fas fa-ellipsis-v" />
                                  </a>
                                  <div className="dropdown-menu dropdown-menu-end">
                                    <ul>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="edit-invoice.html"
                                        >
                                          <i className="far fa-edit me-2" />
                                          Edit
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          href="javascript:void(0);"
                                          data-bs-toggle="modal"
                                          data-bs-target="#delete_modal"
                                        >
                                          <i className="far fa-trash-alt me-2" />
                                          Delete
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="invoice-details.html"
                                        >
                                          <i className="far fa-eye me-2" />
                                          View
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="active-customers.html"
                                        >
                                          <i className="far fa-bell me-2" />
                                          Active
                                        </a>
                                      </li>
                                      <li>
                                        <a
                                          className="dropdown-item"
                                          to="deactive-customers.html"
                                        >
                                          <i className="far fa-bell-slash me-2" />
                                        </a>
                                      </li>
                                    </ul>
                                  </div>
                                </div>
                              </td>
                            </tr> */}
                                </tbody>
                              );
                            }
                            return displayPosts;
                          })()}
                        </table>

                        <div className="pagination-wrap d-flex justify-content-between">
                          <p>
                            Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;
                            <i
                              className="fa fa-caret-right"
                              aria-hidden="true"
                            />
                          </p>
                          <Pagination
                            count={totalPages}
                            onChange={(event, value) => displayPage(value)}
                          />
                          <p>
                            Go to page&nbsp;&nbsp;
                            <i
                              className="fa fa-long-arrow-right"
                              aria-hidden="true"
                            />
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* /List-view */}
            {/* calendar-tab */}
            <div
              className="tab-pane fade"
              id="calendar-view"
              role="tabpane3"
              aria-labelledby="calendar-tab"
            >
              <div id="calendar" />
              {/* datepicker */}
              <div className="col-auto">
                <div className="date-picker btn btn-group btn-sm">
                  <div className="ico left">
                    <i className="fas fa-chevron-left" />
                  </div>
                  <div className="cal-ico center">
                    <i className="feather-calendar mr-1" />
                    <span>Select Date</span>
                  </div>
                  <div className="ico right">
                    <i className="fas fa-chevron-right" />
                  </div>
                </div>
              </div>
              <div
                class="tab-pane fade"
                id="calendar-view"
                role="tabpane3"
                aria-labelledby="calendar-tab"
              >
                <div id="calendar"></div>

                <div class="col-auto">
                  <div class="date-picker btn btn-group btn-sm">
                    <div class="ico left">
                      <i class="fas fa-chevron-left"></i>
                    </div>
                    <div class="cal-ico center">
                      <i class="feather-calendar mr-1"></i>
                      <span>Select Date</span>
                    </div>
                    <div class="ico right">
                      <i class="fas fa-chevron-right"></i>
                    </div>
                  </div>
                </div>
              </div>
              {/* /datepicker */}
            </div>
            {/* /calendar-tab */}
          </div>
          {/* /tab-contant */}
          {/* Footer */}
          {/* <footer className="footer">
            <div className="container">
              <div className="row">
                <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div className="footer-left">
                    <p>© 2023 Dreams HRMS</p>
                  </div>
                </div>
                <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div className="footer-right">
                    <ul>
                      <li>
                        <a href="javascript:void(0);">Privacy Policy</a>
                      </li>
                      <li>
                        <a href="javascript:void(0);">Terms &amp; Conditions</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </footer> */}
          {/* Footer */}
        </div>
        {/* /Page Content */}
      </div>
      {/* /Page Wrapper */}
    </div>
  );
}

export default Employee_attendance;
