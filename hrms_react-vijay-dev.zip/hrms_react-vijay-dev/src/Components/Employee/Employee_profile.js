import React, { useEffect, useState } from "react";
import logo from "../assets/img/logo.svg";
import dashboardicon from "../assets/img/icons/dashboard-icon.svg";
import employeeicon from "../assets/img/icons/employees-icon.svg";
import timeofficon from "../assets/img/icons/time-off-icon.svg";
import policyicon from "../assets/img/icons/policies-icon.svg";
import reporticon from "../assets/img/icons/reports-icon.svg";
import shortcuticon from "../assets/img/icons/shortcut-icon.svg";
import avatar1 from "../assets/img/profiles/avatar-01.jpg";
import avatar2 from "../assets/img/profiles/avatar-02.jpg";
import avatar5 from "../assets/img/profiles/avatar-02.jpg";
import avatar6 from "../assets/img/profiles/avatar-06.jpg";
import avatar3 from "../assets/img/profiles/avatar-03.jpg";
import avatar14 from "../assets/img/profiles/avatar-14.jpg";
import editpro from "../assets/img/icons/edit-profile.svg";
import personalinfo from "../assets/img/icons/personal-info.svg";
import emergencycon from "../assets/img/icons/emergency-contact.svg";
import dependencyicon from "../assets/img/icons/dependency-info.svg";
import educticon from "../assets/img/icons/edu-info.svg";
import workhisticon from "../assets/img/icons/work-history.svg";
// import "../assets/css/style.css";
// import "../assets/css/feather.css";
import { Link, useNavigate } from "react-router-dom";
import EmployeeTimeOff from "./EmployeeTimeOff";
import axios from "axios";
import { BASEURL } from "../apiPath/baseUrl";
import { postData } from "../services/apiUrl";

function Employee_profile() {
  // const navigate = useNavigate()
  const [profileDetail, setProfileDetail] = useState([]);
  const [emergencyDetail, setEmergencyDetail] = useState([]);
  const [dependencyDetail, setDependency] = useState([]);
  const [educationalDetail, setEducational] = useState([]);
  const [workHistoryDetail, setWorkDetail] = useState([]);
  // const emergencyContact = async () => {
  //   try {
  //     const response = await axios.post(`${BASEURL}EmergencyContact`);
  //     setEmergencyDetail(response.data);
  //     console.log(response.data, "response.data");
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };
  const personalInfo = async () => {
  
    const preparData ={
      user_id: localStorage.getItem("EmployeeId")
    }
    postData("profile_info", preparData, (data, res) => {
      console.log(data.data, "dataprofile99999");
      setProfileDetail(data.data?.personal[0])
      setEmergencyDetail(data.data?.emergency)
      setDependency(data.data?.dependents)
      setEducational(data.data?.education)
      setWorkDetail(data.data?.work_log)
      console.log("itemssssss***",data.data?.personal[0])
    });
  };
  // const dependency = async () => {
  //   try {
  //     const response = await axios.post(`${BASEURL}dependents-list`);
  //     setDependency(response.data);
  //     console.log(response.data, "response.data");
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };
  // const educational = async () => {
  //   try {
  //     const response = await axios.post(`${BASEURL}EducationalInfo`);
  //     setEducational(response.data);
  //     console.log(response.data, "response.data");
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };
  // const workHistory = async () => {
  //   try {
  //     const response = await axios.post(`${BASEURL}EducationalInfo`);
  //     setWorkDetail(response.data);
  //     console.log(response.data, "response.data");
  //   } catch (error) {
  //     console.error(error);
  //   }
  // };
  useEffect(() => {
    personalInfo();
  }, []);

  return (
    <div>
      <div>
        <div>
          <div class="row">
            <aside class="col-md-4 col-lg-3">
              <div class="white-bg">
                <h2>
                  <i class="d-inline-block text-center align-middle">
                    <img src={personalinfo} alt="" />
                  </i>
                  Personal Information's
                </h2>
                <h6 class="text-uppercase head">About</h6>
                <ul class="personal-info common-listing">
                  <li>
                    <i class="feather-flag"></i>
                    <span>Grade: </span>{profileDetail?.grade}
                  </li>
                  <li>
                    <i class="feather-sun"></i>
                    <span>Shift: </span>{profileDetail?.shift_name}
                  </li>
                  <li>
                    <i class="feather-clock"></i>
                    <span>Shift Time: </span>{profileDetail?.shift_time}
                  </li>
                  <li>
                    <i class="feather-laptop" aria-hidden="true"></i>{" "}
                    <span>Employment Type: </span>{profileDetail?.employee_type}
                  </li>
                  <li>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <span>Status Type: </span>{profileDetail?.status === "1" ? "Active" : "InActive"}
                  </li>
                  <li>
                    <i class="feather-map-pin"></i>
                    <span>Blood Group: </span>{profileDetail?.blood_group}
                  </li>
                  <li>
                    <i class="feather-users" aria-hidden="true"></i>
                    <span>Marital Status: </span>{profileDetail?.marital_status}
                  </li>
                  <li>
                    <i class="feather-users" aria-hidden="true"></i>
                    <span>Nationality: </span>{profileDetail?.nationality}
                  </li>
                </ul>
                <h6 class="text-uppercase head">Contact</h6>
                <ul class="contact common-listing">
                  <li>
                    <i class="feather-mail" aria-hidden="true"></i>
                    <span>Contact: </span>{profileDetail?.contact}
                  </li>
                  <li>
                    <i class="feather-phone" aria-hidden="true"></i>
                    <span>E-mail: </span>{profileDetail?.email}
                  </li>
                  <li>
                    <i class="feather-map-pin" aria-hidden="true"></i>
                    <span>Address: </span>{profileDetail?.primary_address}
                  </li>
                </ul>
              </div>
            </aside>
            <div class="col-md-8 col-lg-9">
              <div class="emergency-contact">
                <div class="row">
                  <div class="col-sm-6 col-md-7 col-xs-12">
                    <div class="bg">
                      <h2>
                        <i class="d-inline-block text-center align-middle">
                          <img src={emergencycon} alt="" />
                        </i>
                        Emergency Contact
                      </h2>
                      <h6 class="head">Primary</h6>
                      <ul class="primary common-listing">
                        <li>
                          <span>First Name: </span>{emergencyDetail[0]?.first_name}&nbsp;&nbsp;
                          <span>Last Name: </span>{emergencyDetail[0]?.last_name}
                        </li>
                        <li>
                          <span>Relationship: </span>{emergencyDetail[0]?.relationship}
                        </li>
                        <li>
                          <span>Phone: </span>{emergencyDetail[0]?.phone_number}
                        </li>
                        <li>
                          <span>Email: </span>={emergencyDetail[0]?.email_address}
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-sm-6 col-md-5 col-xs-12">
                    <div class="sm-float-end right">
                      <h6 class="head">Primary</h6>
                      <ul class="primary common-listing">
                        <li>
                          <span>First Name: </span>{emergencyDetail[1]?.first_name}&nbsp;&nbsp;
                          <span>Last Name: </span>{emergencyDetail[1]?.last_name}
                        </li>
                        <li>
                          <span>Relationship: </span>{emergencyDetail[1]?.relationship}
                        </li>
                        <li>
                          <span>Phone: </span>{emergencyDetail[1]?.phone_number}
                        </li>
                        <li>
                          <span>Email: </span>={emergencyDetail[1]?.email_address}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div class="dependency-info white-bg">
                <h2>
                  <i class="d-inline-block text-center align-middle">
                    <img src={dependencyicon} alt="" />
                  </i>
                  Dependency Information's
                </h2>
                <div class="row">
                  <div class="col-sm-4 col-xs-12">
                    <div class="purple spacing">
                      <h4>{dependencyDetail[0]?.first_name}</h4>
                      <ul class="primary common-listing">
                        <li>
                          <span>Relationship: </span>{dependencyDetail[0]?.relationship}
                        </li>
                        <li>
                          <span>Phone Number: </span>{dependencyDetail[0]?.phone_number}
                        </li>
                        <li>
                          <span>Date of Birth: </span>{dependencyDetail[0]?.dob}
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-sm-4 col-xs-12">
                    <div class="orange spacing">
                      <h4>{dependencyDetail[1]?.first_name}</h4>
                      <ul class="primary common-listing">
                        <li>
                          <span>Relationship: </span>{dependencyDetail[1]?.relationship}
                        </li>
                        <li>
                          <span>Phone Number: </span>{dependencyDetail[1]?.phone_number}
                        </li>
                        <li>
                          <span>Date of Birth: </span>{dependencyDetail[1]?.dob}
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="col-sm-4 col-xs-12">
                    <div class="green spacing">
                      <h4>{dependencyDetail[2]?.first_name}</h4>
                      <ul class="primary common-listing">
                        <li>
                          <span>Relationship: </span>{dependencyDetail[2]?.relationship}
                        </li>
                        <li>
                          <span>Phone Number: </span>{dependencyDetail[2]?.phone_number}
                        </li>
                        <li>
                          <span>Date of Birth: </span>{dependencyDetail[2]?.dob}
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-lg-6 col-md-12">
                  <div class="white-bg edu-work-wrapper">
                    <h2>
                      <i class="d-inline-block text-center align-middle">
                        <img src={educticon} alt="" />
                      </i>
                      Educational Informations
                    </h2>
                    {educationalDetail?.map((item) => {
						          return (
                    <div class="education-work">
                      <div class="d-flex">
                        <div class="">
                          <span class="text-uppercase degree d-inline-block text-center">
                            {item?.degree}
                          </span>
                        </div>
                        <div class="">
                          <h4>{item?.course_name}</h4>
                          <h5>{item?.dept_name}</h5>
                        </div>
                      </div>
                      <h6>{item?.college_name}</h6>
                      <div class="gpa">
                        <span>{item?.gpa}</span>
                        <span>
                          <i class="fa fa-calendar-o" aria-hidden="true"></i>{item?.start_year} - {item?.end_year}
                        </span>
                      </div>
                    </div>
                    );
                    })}
                  </div>
                </div>

                <div class="col-lg-6 col-md-12">
                  <div class="white-bg edu-work-wrapper">
                    <h2>
                      <i class="d-inline-block text-center align-middle">
                        <img src={workhisticon} alt="" />
                      </i>
                      Work History
                    </h2>
                    {workHistoryDetail?.map((item) => {
						          return (
                    <div class="education-work">
                      <div class="">
                        <h4 class="d-inline-block">{item.position_name}</h4>
                        <span class="float-end time-period">
                          <i class="fa fa-suitcase" aria-hidden="true"></i>{item.total_years}
                        </span>
                      </div>
                      <h5>{item.company_name}</h5>
                      <div class="gpa year">
                        <span>
                          <i class="fa fa-calendar" aria-hidden="true"></i>{item.effective_date}
                        </span>
                        <span class="float-end">
                          <i class="feather-map-pin"></i>{item.location}
                        </span>
                      </div>
                    </div>
                                        );
                                      })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Employee_profile;
