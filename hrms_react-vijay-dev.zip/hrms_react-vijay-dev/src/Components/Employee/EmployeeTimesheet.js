import axios from "axios";
import React, { useEffect, useState } from "react";
import { BASEURL } from "../apiPath/baseUrl";

import logo from "../assets/img/logo.svg";
import dashboardicon from "../assets/img/icons/dashboard-icon.svg";
import cloudicon from "../assets/img/icons/cloud-icon.svg";
import employeeicon from "../assets/img/icons/employees-icon.svg";
import timeoff from "../assets/img/icons/time-off-icon.svg";
import policyicon from "../assets/img/icons/policies-icon.svg";
import shortcuticon from "../assets/img/icons/shortcut-icon.svg";
import reporticon from "../assets/img/icons/reports-icon.svg";
import avatar1 from "../assets/img/profiles/avatar-01.jpg";
import avatar2 from "../assets/img/profiles/avatar-02.jpg";
import avatar6 from "../assets/img/profiles/avatar-06.jpg";
import avatar3 from "../assets/img/profiles/avatar-03.jpg";
import gearicon from "../assets/img/icons/gear-icon.svg";
import clockicon from "../assets/img/icons/clock-icon.svg";
import editpro from "../assets/img/icons/edit-profile.svg";
import downloadicon from "../assets/img/icons/download-icon.svg";
import printericon from "../assets/img/icons/printer-icon.svg";
import funnelicon from "../assets/img/icons/funnel-icon.svg";
import baricon from "../assets/img/icons/bar-icon.svg";
import { Link } from "react-router-dom";

export default function EmployeeTimesheet() {
  const [employeetime, setEmployeeTime] = useState([]);

  const TimeSheet = async () => {
    try {
      const response = await axios.post(`${BASEURL}timesheet`);
      setEmployeeTime(response.data);
      console.log(response.data, "response");
    } catch (error) {
      console.error(error);
    }
  };
  useEffect(() => {
    // TimeSheet();
  }, []);
  return (
    <div>
      <div>
        <div>
        
      {/* <header class="header header-fixed header-one">
        <nav class="navbar navbar-expand-lg header-nav">
          <div class="navbar-header">
            <a id="mobile_btn" href="javascript:void(0);">
              <span class="bar-icon">
                <span></span>
                <span></span>
                <span></span>
              </span>
            </a>
            <a href="javascript:void(0);" class="navbar-brand logo">
              <img src={logo} class="img-fluid" alt="Logo" />
            </a>
          </div>
          <div class="main-menu-wrapper">
            <ul class="main-nav">
              <li>
                <a href="javascript:void(0);">
                  <img src={dashboardicon} alt="" /> Dashboard
                </a>
              </li>
              <li class="active">
                <a href="employees.html">
                  <img src={employeeicon} alt="" /> Employees
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={timeoff} alt="" /> Time off
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={policyicon} alt="" /> Policies
                </a>
              </li>
              <li>
                <a href="javascript:void(0);">
                  <img src={reporticon} alt="" /> Reports
                </a>
              </li>
            </ul>
            <ul class="nav header-navbar-rht">
              <li class="nav-item search-item">
                <div class="top-nav-search">
                  <form action="#">
                    <input
                      type="text"
                      class="form-control"
                      placeholder="Search"
                    />
                    <button class="btn" type="submit">
                      <i class="feather-search"></i>
                    </button>
                    <span>
                      <img src={shortcuticon} alt="" />
                    </span>
                  </form>
                </div>
              </li>
              <li class="nav-item quick-link-item">
                <a class="btn" href="javascript:void(0);">
                  <span>
                    Quick Links <i class="feather-zap"></i>
                  </span>
                </a>
              </li>
              <li class="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i class="feather-sun"></i>
                </a>
              </li>
              <li class="nav-item dropdown has-arrow notification-dropdown">
                <a
                  href="#"
                  class="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <i class="feather-bell"></i>
                  <span class="badge">3</span>
                </a>
                <div class="dropdown-menu dropdown-menu-end notifications">
                  <div class="topnav-dropdown-header">
                    <span class="notification-title">Notifications</span>
                    <a href="javascript:void(0)" class="clear-noti">
                      {" "}
                      Clear All
                    </a>
                  </div>
                  <div class="noti-content">
                    <ul class="notification-list">
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar1}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">John Doe</span>
                                added new task{" "}
                                <span class="noti-title">
                                  Patient appointment booking
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  4 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar2}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Tarah Shropshire</span>{" "}
                                changed the task name{" "}
                                <span class="noti-title">
                                  Appointment booking with payment gateway
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  6 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar6}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Misty Tison</span>{" "}
                                added{" "}
                                <span class="noti-title">Domenic Houston</span>{" "}
                                and <span class="noti-title">Claire Mapes</span>{" "}
                                to project{" "}
                                <span class="noti-title">
                                  Doctor available module
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  8 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar6}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Rolland Webber</span>{" "}
                                completed task{" "}
                                <span class="noti-title">
                                  Patient and Doctor video conferencing
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  12 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                      <li class="notification-message">
                        <a href="javascript:void(0)">
                          <div class="media d-flex">
                            <span class="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar3}
                                class="rounded-circle"
                              />
                            </span>
                            <div class="media-body flex-grow-1">
                              <p class="noti-details">
                                <span class="noti-title">Bernardo Galaviz</span>{" "}
                                added new task{" "}
                                <span class="noti-title">
                                  Private chat module
                                </span>
                              </p>
                              <p class="noti-time">
                                <span class="notification-time">
                                  2 days ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </a>
                      </li>
                    </ul>
                  </div>
                  <div class="topnav-dropdown-footer">
                    <a href="javascript:void(0)">View all Notifications</a>
                  </div>
                </div>
              </li>
              <li class="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i class="feather-settings"></i>
                </a>
              </li>
              <li class="nav-item nav-icons">
                <a href="javascript:void(0);">
                  <i class="far fa-circle-question"></i>
                </a>
              </li>
              <li class="nav-item dropdown has-arrow main-drop">
                <a
                  href="#"
                  class="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <span class="user-img">
                    <img src={avatar1} class="img-rounded" alt="" />
                  </span>
                </a>
                <div class="dropdown-menu">
                  <a class="dropdown-item" href="javascript:void(0);">
                    <i class="feather-user-plus"></i> My Profile
                  </a>
                  <a class="dropdown-item" href="javascript:void(0);">
                    <i class="feather-settings"></i> Settings
                  </a>
                  <a class="dropdown-item" href="javascript:void(0);">
                    <i class="feather-log-out"></i> Logout
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <div class="page-wrapper employee-profile time-sheet">
        {/* <!-- Page Content --> */}
        {/* <div class="content container"> */}
          {/* <!-- breadcrumb --> */}
          {/* <ul class="breadcrumb">
            <li>
              <i href="#">Employees</i>
            </li>
            <li>
              <i href="#">Richard</i>
            </li>
            <li class="active">
              <i href="#">Time Off</i>
            </li>
          </ul>
          {/* <!-- breadcrumb -->
    <!-- employee-info --> */}
          {/* <div class="employee-info d-md-flex justify-content-between">
            <div class="info-one d-lg-flex">
              <a href="#" class="d-inline-block profile-pic">
                <img src={avatar6} alt="" />
                <span class="feather-camera text-center"></span>
              </a>
              <ul class="">
                <li>
                  <h3>
                    Richard Steve <span>FT-0001</span>
                    <img src={editpro} alt="" />
                  </h3>
                  <span class="d-block designation">UI/UX Designer</span>
                </li>
                <li>
                  <span class="d-block">
                    <i class="feather-phone"></i>(907) 888-0101
                  </span>
                  <span class="d-block">
                    <i class="feather-mail"></i>example@email.com
                  </span>
                </li>
              </ul>
            </div>
            <div class="info-two">
              <ul class="">
                <li>
                  <span class="d-block head">Department</span>
                  <span class="d-block">Design Team</span>
                </li>
                <li>
                  <span class="d-block head">Date of Birth</span>
                  <span class="d-block">25 May 1996</span>
                </li>
              </ul>
            </div>
            <div class="info-three">
              <ul class="">
                <li>
                  <span class="d-block head">Line Manager</span>
                  <span class="d-block">John Smith</span>
                </li>
                <li>
                  <span class="d-block head">Joining Date</span>
                  <span class="d-block">15 July 2020</span>
                </li>
              </ul>
            </div>
            <div class="info-four">
              <div class="">
                <div class="text-end">
                  <i class="fas fa-ellipsis-v"></i>
                </div>
                <p class="head">Profile Complete</p>
                <div class="progress">
                  <div
                    class="progress-bar"
                    role="progressbar"
                    aria-valuenow="75"
                    aria-valuemin="0"
                    aria-valuemax="100"
                  ></div>
                </div>
                <p class="profile-completion">
                  Your profile is 81% Completed <a href="#">Finish Now</a>
                </p>
              </div>
            </div>
          </div> */}

          {/* <div class="d-lg-flex justify-content-between align-items-center profile-items">
            <h2>Time Sheet</h2>
            <ul class="d-sm-flex">
              <li>
              <li><Link to={"/employeeprofile"}>Profile</Link></li>
              </li>
              <li>
                <a href="employee-teams.html">Teams</a>
              </li>
              <li>
                <Link to={"/employeeassets"}>Assets</Link>
              </li>
              <li>
                <Link to={"/employeetime"}>Time off</Link>
              </li>
              <li>
              <li><Link to={"/employeedocument"}>Documents</Link></li>
              </li>
              <li>
                <Link to={"/employeeattendance"}>Attendance</Link>
              </li>
              <li>
                <Link to={"/employeesheet"} onClick={TimeSheet}>
                  Time Sheet
                </Link>
              </li>
            </ul>
            <div>
              <div class="form-group float-end search d-inline">
                <i class="feather-search"></i>
                <input type="text" class="form-control" placeholder="Search" />
              </div>
            </div>
          </div>   */}

          <div class="date-time d-lg-flex justify-content-between align-items-center">
            <div>
              <select
                class="form-select w-auto d-md-inline"
                aria-label="Default select example"
              >
                <option selected="">Today</option>
                <option value="1">Week</option>
                <option value="2">Month</option>
                <option value="3">Year</option>
              </select>
              <div class="col-auto d-md-inline">
                <div class="date-picker btn btn-group btn-sm">
                  <div class="ico left">
                    <i class="fas fa-chevron-left"></i>
                  </div>
                  <div class="cal-ico center">
                    <i class="feather-calendar mr-1"></i>
                    <span>3/28/2023 - 4/3/2023</span>
                  </div>
                  <div class="ico right">
                    <i class="fas fa-chevron-right"></i>
                  </div>
                </div>
              </div>
              <select
                class="form-select w-auto d-md-inline"
                aria-label="Default select example"
              >
                <option selected="">Month</option>
                <option value="1">Day</option>
                <option value="2">Week</option>
                <option value="3">Year</option>
              </select>
            </div>
            <button type="text" class="btn gradient-btn float-end">
              <i class="fa fa-download" aria-hidden="true"></i>Export
            </button>
          </div>

          <div class="col-sm-12">
            <div class="card-table">
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-center table-hover datatable">
                    <thead class="thead-light">
                      <tr>
                        <th>Employees</th>
                        <th>
                          1 <br></br> Mon
                        </th>
                        <th>
                          2<br></br>Mon
                        </th>
                        <th>
                          3<br></br>Mon
                        </th>
                        <th>
                          4<br></br>Mon
                        </th>
                        <th>
                          5<br></br>Mon
                        </th>
                        <th class="warning">
                          6<br></br>Mon
                        </th>
                        <th class="warning">
                          7<br></br>Mon
                        </th>
                        <th>
                          8<br></br>Mon
                        </th>
                        <th>
                          9<br></br>Mon
                        </th>
                        <th>
                          10<br></br>Mon
                        </th>
                        <th>
                          11<br></br>Mon
                        </th>
                        <th>
                          12<br></br>Mon
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <h2 class="table-avatar d-flex">
                            <a
                              href="profile.html"
                              class="avatar avatar-md me-2"
                            >
                              <img
                                class="avatar-img rounded-circle"
                                src={avatar2}
                                alt="User Image"
                              />
                            </a>
                            <a href="profile.html">
                              John Smith <br />
                              <span>UI/UX Team Lead</span>
                            </a>
                          </h2>
                        </td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>-- : --</td>
                        <td>-- : --</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                      </tr>
                      <tr>
                        <td>
                          <h2 class="table-avatar d-flex">
                            <a
                              href="profile.html"
                              class="avatar avatar-md me-2"
                            >
                              <img
                                class="avatar-img rounded-circle"
                                src={avatar2}
                                alt="User Image"
                              />
                            </a>
                            <a href="profile.html">
                              John Smith <br />
                              <span>UI/UX Team Lead</span>
                            </a>
                          </h2>
                        </td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>-- : --</td>
                        <td>-- : --</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                      </tr>
                      <tr>
                        <td>
                          <h2 class="table-avatar d-flex">
                            <a
                              href="profile.html"
                              class="avatar avatar-md me-2"
                            >
                              <img
                                class="avatar-img rounded-circle"
                                src={avatar2}
                                alt="User Image"
                              />
                            </a>
                            <a href="profile.html">
                              John Smith <br />
                              <span>UI/UX Team Lead</span>
                            </a>
                          </h2>
                        </td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>-- : --</td>
                        <td>-- : --</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                        <td>08h 00m</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>

          {/* <footer class="footer">
            <div class="container">
              <div class="row">
                <div class="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div class="footer-left">
                    <p>© 2023 Dreams HRMS</p>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div class="footer-right">
                    <ul>
                      <li>
                        <a href="javascript:void(0);">Privacy Policy</a>
                      </li>
                      <li>
                        <a href="javascript:void(0);">Terms & Conditions</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </footer> */}
        </div>
      </div>
    </div>
  );
}
