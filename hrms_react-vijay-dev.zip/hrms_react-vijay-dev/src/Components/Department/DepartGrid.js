import React from 'react'
import { avatar1, avatar2, avatar3, avatar5, avatar6, chart, depart, empicon, grid1, icon, logo, logotitle, main, picon, ricon, sicon, step1, step2, step3, step4, step5, ticon, zoomin, zoomout } from '../imagepath'
// import '../assets/js/bootstrap.bundle.min.js'
import { Link } from 'react-router-dom'
import Header from '../Header'

const DepartGrid = () => {
  return (
    <>
    <div className="main-wrapper">
      {/* Header */}
      {/* <header className="header header-fixed header-one">
        <nav className="navbar navbar-expand-lg header-nav">
          <div className="navbar-header">
            <Link id="mobile_btn" href="javascript:void(0);">
              <span className="bar-icon">
                <span />
                <span />
                <span />
              </span>
            </Link>
            <Link href="javascript:void(0);" className="navbar-brand logo">
              <img src={logo} className="img-fluid" alt="Logo" />
            </Link>
          </div>
          <div className="main-menu-wrapper">
            <ul className="main-nav">
              <li>
                <Link href="javascript:void(0);">
                  <img src={icon} alt="" />{" "}
                  Dashboard
                </Link>
              </li>
              <li className="active">
                <Link href="employees.html">
                  <img src={empicon} alt="" />{" "}
                  Employees
                </Link>
              </li>
              <li>
                <Link href="javascript:void(0);">
                  <img src={ticon} alt="" /> Time off
                </Link>
              </li>
              <li>
                <Link href="javascript:void(0);">
                  <img src={picon} alt="" /> Policies
                </Link>
              </li>
              <li>
                <Link href="javascript:void(0);">
                  <img src={ricon} alt="" /> Reports
                </Link>
              </li>
            </ul>
            <ul className="nav header-navbar-rht">
              <li className="nav-item search-item">
                <div className="top-nav-search">
                  <form action="#">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Search"
                    />
                    <button className="btn" type="submit">
                      <i className="feather-search" />
                    </button>
                    <span>
                      <img src={sicon} alt="" />
                    </span>
                  </form>
                </div>
              </li>
              <li className="nav-item quick-link-item">
                <Link className="btn" href="javascript:void(0);">
                  <span>
                    Quick Links <i className="feather-zap" />
                  </span>
                </Link>
              </li>
              <li className="nav-item nav-icons">
                <Link href="javascript:void(0);">
                  <i className="feather-sun" />
                </Link>
              </li>
              <li className="nav-item dropdown has-arrow notification-dropdown">
                <Link
                  href="#"
                  className="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <i className="feather-bell" />
                  <span className="badge">3</span>
                </Link>
                <div className="dropdown-menu dropdown-menu-end notifications">
                  <div className="topnav-dropdown-header">
                    <span className="notification-title">Notifications</span>
                    <Link href="javascript:void(0)" className="clear-noti">
                      {" "}
                      Clear All
                    </Link>
                  </div>
                  <div className="noti-content">
                    <ul className="notification-list">
                      <li className="notification-message">
                        <Link href="javascript:void(0)">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar1}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">John Doe</span>
                                added new task{" "}
                                <span className="noti-title">
                                  Patient appointment booking
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  4 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </Link>
                      </li>
                      <li className="notification-message">
                        <Link href="javascript:void(0)">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar2}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">
                                  Tarah Shropshire
                                </span>{" "}
                                changed the task name{" "}
                                <span className="noti-title">
                                  Appointment booking with payment gateway
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  6 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </Link>
                      </li>
                      <li className="notification-message">
                        <Link href="javascript:void(0)">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar6}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">Misty Tison</span>{" "}
                                added{" "}
                                <span className="noti-title">
                                  Domenic Houston
                                </span>{" "}
                                and{" "}
                                <span className="noti-title">Claire Mapes</span>{" "}
                                to project{" "}
                                <span className="noti-title">
                                  Doctor available module
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  8 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </Link>
                      </li>
                      <li className="notification-message">
                        <Link href="javascript:void(0)">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar5}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">Rolland Webber</span>{" "}
                                completed task{" "}
                                <span className="noti-title">
                                  Patient and Doctor video conferencing
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  12 mins ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </Link>
                      </li>
                      <li className="notification-message">
                        <Link href="javascript:void(0)">
                          <div className="media d-flex">
                            <span className="avatar flex-shrink-0">
                              <img
                                alt=""
                                src={avatar3}
                                className="rounded-circle"
                              />
                            </span>
                            <div className="media-body flex-grow-1">
                              <p className="noti-details">
                                <span className="noti-title">
                                  Bernardo Galaviz
                                </span>{" "}
                                added new task{" "}
                                <span className="noti-title">
                                  Private chat module
                                </span>
                              </p>
                              <p className="noti-time">
                                <span className="notification-time">
                                  2 days ago
                                </span>
                              </p>
                            </div>
                          </div>
                        </Link>
                      </li>
                    </ul>
                  </div>
                  <div className="topnav-dropdown-footer">
                    <Link href="javascript:void(0)">View all Notifications</Link>
                  </div>
                </div>
              </li>
              <li className="nav-item nav-icons">
                <Link href="javascript:void(0);">
                  <i className="feather-settings" />
                </Link>
              </li>
              <li className="nav-item nav-icons">
                <Link href="javascript:void(0);">
                  <i className="far fa-circle-question" />
                </Link>
              </li>
              <li className="nav-item dropdown has-arrow main-drop">
                <Link
                  href="#"
                  className="dropdown-toggle nav-link"
                  data-bs-toggle="dropdown"
                >
                  <span className="user-img">
                    <img
                      src={avatar1}
                      className="img-rounded"
                      alt=""
                    />
                  </span>
                </Link>
                <div className="dropdown-menu">
                  <Link className="dropdown-item" href="javascript:void(0);">
                    <i className="feather-user-plus" /> My Profile
                  </Link>
                  <Link className="dropdown-item" href="javascript:void(0);">
                    <i className="feather-settings" /> Settings
                  </Link>
                  <Link className="dropdown-item" href="javascript:void(0);">
                    <i className="feather-log-out" /> Logout
                  </Link>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </header> */}
      <Header />
      {/* /Header */}
      {/* Page Wrapper */}
      <div className="page-wrapper department-page">
        {/* Page Content */}
        <div className="content container">
          {/* Page Header */}
          <div className="page-header">
            <div className="row align-items-center">
              <div className="col-lg-6 col-md-6">
                <h3 className="page-title">Departments</h3>
              </div>
              <div className="col-lg-6 col-md-6 page-header-btns">
                <Link href="javascript:void(0);" className="btn new-employee-btn">
                  <i className="fa-solid fa-plus" /> Add Department
                </Link>
              </div>
            </div>
          </div>
          {/* /Page Header */}
          {/* Search Filter */}
          <div className="search-filter">
            <div className="row align-items-center">
              <div className="col-lg-6 col-md-6">
                <div className="depart-filter">
                  <div className="depart-logo">
                    <img src={main} />
                    <div className="title-content">
                      <h4>Dreamguy's Technologies</h4>
                      <p>30 Departments</p>
                    </div>
                  </div>
                  <div className="depart-team">
                    <div className="depart-group">
                      <div className="depart-avatar">
                        <img
                          src={avatar1}
                          className="avatar-img rounded-circle border border-white "
                        />
                      </div>
                      <div className="depart-avatar">
                        <img
                          src={avatar2}
                          className="avatar-img rounded-circle border border-white "
                        />
                      </div>
                      <div className="depart-avatar">
                        <img
                          src={avatar3}
                          className="avatar-img rounded-circle border border-white "
                        />
                      </div>
                      <div className="depart-avatar">
                        <span className="avatar-title rounded-circle border border-white">
                          CF
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-6">
                <ul className="nav search-btns-info">
                  <li>
                    <Link href="javascript:void(0);" className="btn title active ">
                      <img src={grid1} alt="" />
                      Grid view
                    </Link>
                  </li>
                  <li>
                    <Link href="javascript:void(0);" className="btn title  ">
                      <img src={chart} alt="" />
                      chart view
                    </Link>
                  </li>
                  <li>
                    <Link href="javascript:void(0);" className="btn">
                      <img src={zoomout} alt="" />
                    </Link>
                  </li>
                  <li>
                    <Link href="javascript:void(0);" className="btn ">
                      <img src={zoomin} alt="" />
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          {/* /Search Filter */}
          {/* Department Grid */}
          <div className="department-grid-view">
            <div className="row">
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>HR</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_1" className="check" />
                        <label htmlFor="status_1" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Management</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_12" className="check" />
                        <label htmlFor="status_12" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Marketing</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_2" className="check" />
                        <label htmlFor="status_2" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>UI / UX</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_3" className="check" />
                        <label htmlFor="status_3" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>IT</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_4" className="check" />
                        <label htmlFor="status_4" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Accounts</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_5" className="check" />
                        <label htmlFor="status_5" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Admin</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_6" className="check" />
                        <label htmlFor="status_6" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Design</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_7" className="check" />
                        <label htmlFor="status_7" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Development</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_8" className="check" />
                        <label htmlFor="status_8" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Sales</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_9" className="check" />
                        <label htmlFor="status_9" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Analysis</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_10" className="check" />
                        <label htmlFor="status_10" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-4 col-sm-6 col-12 col-lg-4 col-xl-3">
                <div className="department-card">
                  <div className="card-body">
                    <div className="card-header">
                      <h4>Marketing</h4>
                      <div className="status-toggle ">
                        <input type="checkbox" id="status_11" className="check" />
                        <label htmlFor="status_11" className="checktoggle">
                          checkbox
                        </label>
                      </div>
                    </div>
                    <div className="card-detail">
                      <p>Employees</p>
                      <div className="depart-team">
                        <div className="depart-group">
                          <div className="depart-avatar">
                            <img
                              src={avatar1}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar2}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <img
                              src={avatar3}
                              className="avatar-img rounded-circle border border-white "
                            />
                          </div>
                          <div className="depart-avatar">
                            <span className="avatar-title rounded-circle border border-white">
                              35+
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="card-footer">
                      <p>Parent Department</p>
                      <h5>Dreamguy’s Tech</h5>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /Department Grid */}
          {/* Footer */}
          <footer className="footer department_footer">
            <div className="container">
              <div className="row">
                <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div className="footer-left">
                    <p>
                      © 2023 Dreams HRMS <span>Developed by</span>{" "}
                    </p>
                    <img src={logotitle} />
                  </div>
                </div>
                <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                  <div className="footer-right">
                    <ul>
                      <li>
                        <Link href="javascript:void(0);">Privacy Policy</Link>
                      </li>
                      <li>
                        <Link href="javascript:void(0);">Terms &amp; Conditions</Link>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </footer>
          {/* Footer */}
        </div>
        {/* /Page Content */}
      </div>
      {/* /Page Wrapper */}
    </div>
    {/* /Main Wrapper */}
    {/* Modal Popup */}
    {/* Button trigger modal */}
    {/* Modal */}
    <div className="employees-popup ">
      <div
        className="modal fade"
        id="staticBackdrop"
        data-bs-backdrop="static"
        data-bs-keyboard="false"
        tabIndex={-1}
        aria-labelledby="staticBackdropLabel"
        aria-hidden="true"
      >
        <div className="modal-dialog modal-dialog-centered modal-xl">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title" id="staticBackdropLabel">
                Add Employee
              </h1>
              <button
                type="button"
                className="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              >
                <img src={depart} />{" "}
              </button>
            </div>
            <div className="modal-body">
              <div className="wizard">
                <ul className="form-wizard-steps" id="progressbar">
                  <li className="progress-active">
                    <div className="profile-step">
                      <span className="profile-box">
                        <img src={step1} />
                      </span>
                      <div className="step-section">
                        <p>Step 1/5</p>
                        <h4>Personal Informations</h4>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="profile-step">
                      <span className="profile-box">
                        <img src='{step2}' />
                      </span>
                      <div className="step-section">
                        <p>Step 2/5</p>
                        <h4>Employee Informations</h4>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="profile-step">
                      <span className="profile-box">
                        <img src='{step3}' />
                      </span>
                      <div className="step-section">
                        <p>Step 3/5</p>
                        <h4>Dependency Informations</h4>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="profile-step">
                      <span className="profile-box">
                        <img src={step4}/>
                      </span>
                      <div className="step-section">
                        <p>Step 4/5</p>
                        <h4>Educational Informations</h4>
                      </div>
                    </div>
                  </li>
                  <li>
                    <div className="profile-step">
                      <span className="profile-box profile-box-one">
                        <img src='{step5}' />
                      </span>
                      <div className="step-section">
                        <p>Step 5/5</p>
                        <h4>Documents Information</h4>
                      </div>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="multistep-form">
                <fieldset className="form-inner" id="first">
                  <div className="form-area">
                    <h2>Personal Information</h2>
                    <div className="form-details ">
                      <h4>Basic Information</h4>
                      <form action="#">
                        <div className="row">
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                First Name <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Emp First Name"
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Last Name <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Emp Last Name"
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Gender <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Gender</option>
                                <option value={1}>One</option>
                                <option value={2}>Two</option>
                                <option value={3}>Three</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Marital Status{" "}
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Marital Status</option>
                                <option value={1}>Single</option>
                                <option value={2}>Married</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">Nationality </label>
                              <select className="form-select select">
                                <option selected="">Select Nationality</option>
                                <option value={1}>Indian</option>
                                <option value={2}>Others</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area date-select">
                              <label className="form-label">
                                Date of Birth <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control datetimepicker"
                                placeholder="DDMMYY"
                              />
                              <span className="icon">
                                {" "}
                                <i className="feather-calendar" />{" "}
                              </span>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">District </label>
                              <select className="form-select select">
                                <option selected="">Select District</option>
                                <option value={1}>Mumbai</option>
                                <option value={2}>Chennai</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">City</label>
                              <select className="form-select select">
                                <option selected="">Select City</option>
                                <option value={1}>Mumbai</option>
                                <option value={2}>Chennai</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Phone Number <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Mobile Number"
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Personal Email <span>*</span>
                              </label>
                              <input
                                type="email"
                                className="form-control"
                                placeholder="Enter Email Address "
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Address 1 <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Your Address "
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Address 2 <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Your Address "
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                PIN <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Your PIN "
                                required=""
                              />
                            </div>
                          </div>
                          <div className="title-btn">
                            <h4>Emergency Information</h4>
                            <Link href="javascript:void(0);" className="add-links2">
                              <i className="fa-solid fa-plus" /> Add More
                            </Link>
                          </div>
                          <div className="employee_form">
                            <div className="row personal_form_count">
                              <div className="col-12 col-md-10 col-lg-11">
                                <div className="row">
                                  <div className="col-lg-4 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Full Name
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Full Name"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                  <div className="col-lg-4 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Phone Number
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Phone Number"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                  <div className="col-lg-4 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Relationship
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Relationship"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className="add-form-btn widget-next-btn submit-btn">
                    <div className="btn-left">
                      <Link className="btn  main-btn next_btn">Save &amp; Next</Link>
                      <Link className="btn close-btn me-0">Cancel</Link>
                    </div>
                  </div>
                </fieldset>
                <fieldset className="form-inner">
                  <div className="form-area">
                    <h2>Employee Informations</h2>
                    <div className="form-details ">
                      <h4>Basic Information</h4>
                      <form action="#">
                        <div className="row">
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Employee ID <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control"
                                placeholder="Enter Emp ID"
                                required=""
                              />
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area date-select">
                              <label className="form-label">
                                Effective Date <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control datetimepicker"
                                placeholder="DDMMYY"
                              />
                              <span className="icon">
                                {" "}
                                <i className="feather-calendar" />{" "}
                              </span>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Walk-in Type <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Walk-in Type</option>
                                <option value={1}>One</option>
                                <option value={2}>Two</option>
                                <option value={3}>Three</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Probation Period
                                <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">
                                  Select Probation Period
                                </option>
                                <option value={1}>1 Month</option>
                                <option value={2}>2 Month</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area date-select">
                              <label className="form-label">
                                Probation Start Date
                                <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control datetimepicker"
                                placeholder="DDMMYY"
                              />
                              <span className="icon">
                                {" "}
                                <i className="feather-calendar" />{" "}
                              </span>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area date-select">
                              <label className="form-label">
                                Probation End Date
                                <span>*</span>
                              </label>
                              <input
                                type="text"
                                className="form-control datetimepicker"
                                placeholder="DDMMYY"
                              />
                              <span className="icon">
                                {" "}
                                <i className="feather-calendar" />{" "}
                              </span>
                            </div>
                          </div>
                          <div className="title-btn">
                            <h4>JOB Information</h4>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Job Title <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Job Title</option>
                                <option value={1}>Designer</option>
                                <option value={2}>Developer</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Position Type <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Position Type</option>
                                <option value={1}>Senior</option>
                                <option value={2}>Junior</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Line Manager <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Line Manager</option>
                                <option value={1}>1</option>
                                <option value={2}>2</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Employment Type <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">
                                  Select Employment Type
                                </option>
                                <option value={1}>Senior</option>
                                <option value={2}>Hunior</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Designation <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Designation</option>
                                <option value={1}>PHP Developer</option>
                                <option value={2}>Frontend Developer</option>
                                <option value={3}>Graphic Designer</option>
                              </select>
                            </div>
                          </div>
                          <div className="col-lg-4 col-md-6 col-sm-6 ">
                            <div className="input-area">
                              <label className="form-label">
                                Department <span>*</span>
                              </label>
                              <select className="form-select select">
                                <option selected="">Select Department</option>
                                <option value={1}>HR Department</option>
                                <option value={2}>Designing Department</option>
                              </select>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className="add-form-btn widget-next-btn submit-btn">
                    <div className="btn-left">
                      <Link className="btn  main-btn next_btn">Save &amp; Next</Link>
                      <Link className="btn close-btn me-0">Cancel</Link>
                    </div>
                    <div className="btn-right">
                      <Link className="btn close-btn prev_btn back-btn me-0">
                        <i className="feather-chevron-left" /> Back
                      </Link>
                    </div>
                  </div>
                </fieldset>
                <fieldset className="form-inner">
                  <div className="form-area">
                    <h2>Dependency Information</h2>
                    <div className="form-details ">
                      <div className="title-btn">
                        <h4>Basic Information</h4>
                        <Link href="javascript:void(0);" className="add-links">
                          <i className="fa-solid fa-plus" /> Add More
                        </Link>
                      </div>
                      <form action="#">
                        <div className="dependency_form">
                          <div className="row form_count">
                            <div className="col-12 col-md-10 col-lg-11">
                              <div className="row">
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Full Name
                                      <span>*</span>
                                    </label>
                                    <input
                                      type="text"
                                      className="form-control"
                                      placeholder="Enter Full Name"
                                      required=""
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Gender
                                      <span>*</span>
                                    </label>
                                    <select className="form-select select">
                                      <option selected="">Select Gender</option>
                                      <option value={1}>Men</option>
                                      <option value={2}>Female</option>
                                      <option value={3}>Other</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Relationship
                                      <span>*</span>
                                    </label>
                                    <select className="form-select select">
                                      <option selected="">
                                        Select Relationship
                                      </option>
                                      <option value={1}>Single</option>
                                      <option value={2}>Married</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Nationality
                                      <span>*</span>
                                    </label>
                                    <select className="form-select select">
                                      <option selected="">
                                        Select Nationality
                                      </option>
                                      <option value={1}>Indian</option>
                                      <option value={2}>Srilankan</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area date-select">
                                    <label className="form-label">
                                      Date of Birth
                                      <span>*</span>
                                    </label>
                                    <input
                                      type="text"
                                      className="form-control datetimepicker"
                                      placeholder="DDMMYY"
                                    />
                                    <span className="icon">
                                      {" "}
                                      <i className="feather-calendar" />
                                    </span>
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      Phone Number
                                      <span>*</span>
                                    </label>
                                    <input
                                      type="text"
                                      className="form-control "
                                      placeholder="Enter Mobile Number"
                                    />
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">
                                      District{" "}
                                    </label>
                                    <select className="form-select select">
                                      <option selected="">Select District</option>
                                      <option value={1}>Mumbai</option>
                                      <option value={2}>Chennai</option>
                                    </select>
                                  </div>
                                </div>
                                <div className="col-lg-3 col-md-6 col-sm-6 ">
                                  <div className="input-area">
                                    <label className="form-label">City</label>
                                    <select className="form-select select">
                                      <option selected="">Select City</option>
                                      <option value={1}>Mumbai</option>
                                      <option value={2}>Chennai</option>
                                    </select>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className="add-form-btn widget-next-btn submit-btn">
                    <div className="btn-left">
                      <Link className="btn  main-btn next_btn">Save &amp; Next</Link>
                      <Link className="btn close-btn me-0">Cancel</Link>
                    </div>
                    <div className="btn-right">
                      <Link className="btn close-btn prev_btn back-btn me-0">
                        <i className="feather-chevron-left" /> Back
                      </Link>
                    </div>
                  </div>
                </fieldset>
                <fieldset className="form-inner">
                  <div className="form-area">
                    <h2>Educational Information</h2>
                    <div className="form-details ">
                      <div className="title-btn">
                        <h4>Education Qualification</h4>
                        <Link href="javascript:void(0);" className="add-count">
                          <i className="fa-solid fa-plus" /> Add More
                        </Link>
                      </div>
                      <form action="#">
                        <div className="row">
                          <div className="education_form">
                            <div className="row educatioin_count">
                              <div className="col-12 col-md-10 col-lg-11">
                                <div className="row">
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Institution Name
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Name of Institution"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Certificate/Diploma/UG/PG
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter your Academic course"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area date-select">
                                      <label className="form-label">
                                        Start Date Academic
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control datetimepicker"
                                        placeholder="DDMMYY"
                                      />
                                      <span className="icon">
                                        {" "}
                                        <i className="feather-calendar" />
                                      </span>
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area date-select">
                                      <label className="form-label">
                                        End Date Academic
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control datetimepicker"
                                        placeholder="DDMMYY"
                                      />
                                      <span className="icon">
                                        {" "}
                                        <i className="feather-calendar" />
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="title-btn">
                            <h4>Work History</h4>
                            <Link
                              href="javascript:void(0);"
                              className="add-work-count"
                            >
                              <i className="fa-solid fa-plus" /> Add More
                            </Link>
                          </div>
                          <div className="work_history_form">
                            <div className="row work_count">
                              <div className="col-12 col-md-10 col-lg-11">
                                <div className="row">
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Company Name
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Name of Company"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Position
                                        <span>*</span>
                                      </label>
                                      <input
                                        type="text"
                                        className="form-control"
                                        placeholder="Enter Position"
                                        required=""
                                      />
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Experience
                                        <span>*</span>
                                      </label>
                                      <select className="form-select select">
                                        <option selected="">
                                          No of Experience
                                        </option>
                                        <option value={1}>1</option>
                                        <option value={2}>2</option>
                                        <option value={3}>3</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area">
                                      <label className="form-label">
                                        Location
                                        <span>*</span>
                                      </label>
                                      <select className="form-select select">
                                        <option selected="">
                                          Select Location
                                        </option>
                                        <option value={1}>Mumbai</option>
                                        <option value={2}>Chennai</option>
                                        <option value={3}>Pune</option>
                                      </select>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className="add-form-btn widget-next-btn submit-btn">
                    <div className="btn-left">
                      <Link className="btn  main-btn next_btn">Save &amp; Next</Link>
                      <Link className="btn close-btn me-0">Cancel</Link>
                    </div>
                    <div className="btn-right">
                      <Link className="btn close-btn prev_btn back-btn me-0">
                        <i className="feather-chevron-left" />
                        Back
                      </Link>
                    </div>
                  </div>
                </fieldset>
                <fieldset className="form-inner">
                  <div className="form-area">
                    <h2>Documents</h2>
                    <div className="form-details ">
                      <div className="title-btn">
                        <h4>Personal identity proof</h4>
                        <Link
                          href="javascript:void(0);"
                          className="add-document-count"
                        >
                          <i className="fa-solid fa-plus" /> Add More
                        </Link>
                      </div>
                      <form action="#">
                        <div className="row">
                          <div className="document-file">
                            <div className="row document_count">
                              <div className="col-12 col-md-10 col-lg-11">
                                <div className="row">
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area file-choose">
                                      <label className="form-label">
                                        ID Proof
                                        <span>*</span>
                                      </label>
                                      <input
                                        className="form-control file-input"
                                        type="file"
                                        id="formFile"
                                      />
                                      <input
                                        type="hidden"
                                        name="MAX_FILE_SIZE"
                                        defaultValue={10485760}
                                      />
                                      <span className="choose-file">
                                        Choose file
                                        <span className="choose-btn">
                                          Choose file
                                        </span>
                                      </span>
                                      <div className="upload-message">
                                        <div>
                                          <h5>
                                            <i className="fa-solid fa-check" />
                                            PAN-001.jpg
                                            <span>uploaded successfully!!!</span>
                                          </h5>
                                        </div>
                                        <div className="download-icon">
                                          <i className="feather-download" />
                                          <i className="feather-trash" />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area file-choose">
                                      <label className="form-label">
                                        Address Proof
                                        <span>*</span>
                                      </label>
                                      <input
                                        className="form-control file-input"
                                        type="file"
                                        id="formFile"
                                      />
                                      <input
                                        type="hidden"
                                        name="MAX_FILE_SIZE"
                                        defaultValue={10485760}
                                      />
                                      <span className="choose-file">
                                        Choose file
                                        <span className="choose-btn">
                                          Choose File
                                        </span>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="title-btn">
                            <h4>Work Experience certificate</h4>
                            <Link
                              href="javascript:void(0);"
                              className="add-experience-count"
                            >
                              <i className="fa-solid fa-plus" /> Add More
                            </Link>
                          </div>
                          <div className="certificate-file">
                            <div className="row work_exprience_count">
                              <div className="col-12 col-md-10 col-lg-11">
                                <div className="row">
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area file-choose">
                                      <label className="form-label">
                                        Letter of Indent
                                        <span>*</span>
                                      </label>
                                      <input
                                        className="form-control file-input"
                                        type="file"
                                        id="formFile"
                                      />
                                      <input
                                        type="hidden"
                                        name="MAX_FILE_SIZE"
                                        defaultValue={10485760}
                                      />
                                      <span className="choose-file">
                                        Choose file
                                        <span className="choose-btn">
                                          Choose File
                                        </span>
                                      </span>
                                      <div className="upload-message">
                                        <div>
                                          <h5>
                                            <i className="fa-solid fa-check" />
                                            PAN-001.jpg
                                            <span>uploaded successfully!!!</span>
                                          </h5>
                                        </div>
                                        <div className="download-icon">
                                          <i className="feather-download" />
                                          <i className="feather-trash" />
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area file-choose">
                                      <label className="form-label">
                                        Experience Certificate
                                        <span>*</span>
                                      </label>
                                      <input
                                        className="form-control file-input"
                                        type="file"
                                        id="formFile"
                                      />
                                      <input
                                        type="hidden"
                                        name="MAX_FILE_SIZE"
                                        defaultValue={10485760}
                                      />
                                      <span className="choose-file">
                                        Choose file
                                        <span className="choose-btn">
                                          Choose File
                                        </span>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="title-btn">
                            <h4>Educational Certificate</h4>
                            <Link
                              href="javascript:void(0);"
                              className="add-degree-count"
                            >
                              <i className="fa-solid fa-plus" /> Add More
                            </Link>
                          </div>
                          <div className="degree-file">
                            <div className="row degree_count">
                              <div className="col-12 col-md-10 col-lg-11">
                                <div className="row">
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area file-choose">
                                      <label className="form-label">
                                        Certificate/Diploma/Degress Certificate{" "}
                                        <span>*</span>
                                      </label>
                                      <input
                                        className="form-control file-input"
                                        type="file"
                                        id="formFile"
                                      />
                                      <input
                                        type="hidden"
                                        name="MAX_FILE_SIZE"
                                        defaultValue={10485760}
                                      />
                                      <span className="choose-file">
                                        Choose file
                                        <span className="choose-btn">
                                          Choose File
                                        </span>
                                      </span>
                                    </div>
                                  </div>
                                  <div className="col-lg-6 col-md-6 col-sm-6 ">
                                    <div className="input-area file-choose">
                                      <label className="form-label">
                                        Course Completion Copy
                                        <span>*</span>
                                      </label>
                                      <input
                                        className="form-control file-input"
                                        type="file"
                                        id="formFile"
                                      />
                                      <input
                                        type="hidden"
                                        name="MAX_FILE_SIZE"
                                        defaultValue={10485760}
                                      />
                                      <span className="choose-file">
                                        Choose file
                                        <span className="choose-btn">
                                          Choose File
                                        </span>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div className="add-form-btn widget-next-btn submit-btn">
                    <div className="btn-left">
                      <Link
                        className="btn  main-btn "
                        data-bs-dismiss="modal"
                        aria-label="Close"
                      >
                        Save &amp; Next
                      </Link>
                      <Link className="btn close-btn me-0">Cancel</Link>
                    </div>
                    <div className="btn-right">
                      <Link className="btn close-btn prev_btn back-btn me-0">
                        <i className="feather-chevron-left" /> Back
                      </Link>
                    </div>
                  </div>
                </fieldset>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
  
  )
}

export default DepartGrid
