import React, { useState } from 'react'
import { avatar1, avatar2, avatar3, avatar5, avatar6, chart, close, depart, div1, div2, div4, div5, div6, div7, div8, div9, empicon, grid, icon, logo, logotitle, main, picon, plus, ricon, sicon, ticon, zoomin, zoomout } from '../imagepath';
import { Link } from 'react-router-dom'
import Header from '../Header';
// import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch'


const Depart = () => {
    const [show, setShow] = useState(false);
    const [view, setView] = useState(false);
    const [part, setPart] = useState(false);

    // const toggleShow = () => {
    //     console.log('click')
    //     setShow(true)
    // }

    // const toggleClose = () => {
    //     console.log('click')
    //     setShow(false)
    // }
    // console.log(show);

    // const Aside = () => {
    //     return (
    //         <div id="sub-branch-hr">
    //             <ul>
    //                 <li>
    //                     <div className="department-box sub-division" style={{ display: show ? 'block' : 'none' }}>
    //                         <div className="department-content">
    //                             <div className="depart-img lite_orange">
    //                                 <img src={div6} />
    //                             </div>
    //                             <div className="depart-content">
    //                                 <h4>Accounts</h4>
    //                                 <p>4 Employees</p>
    //                             </div>
    //                         </div>
    //                         <div className="depart-btn">
    //                             <Link to="#" className="add-btn"><img src={plus} /> </Link>
    //                         </div>
    //                     </div>
    //                 </li>
    //                 <li>
    //                     <div className="department-box sub-division">
    //                         <div className="department-content">
    //                             <div className="depart-img lite_orange">
    //                                 <img src={div7} />
    //                             </div>
    //                             <div className="depart-content">
    //                                 <h4>Admin</h4>
    //                                 <p>5 Employees</p>
    //                             </div>
    //                         </div>
    //                         <div className="depart-btn">
    //                             <Link to="#" className="add-btn"><img src={plus} /> </Link>
    //                         </div>
    //                     </div>
    //                 </li>
    //             </ul>
    //         </div>
    //     )
    // }

    return (
        <div>
            <div className="main-wrapper">
                {/* Header */}
                {/* <header className="header header-fixed header-one">
                    <nav className="navbar navbar-expand-lg header-nav">
                        <div className="navbar-header">
                            <Link id="mobile_btn" to="#">
                                <span className="bar-icon">
                                    <span />
                                    <span />
                                    <span />
                                </span>
                            </Link>
                            <Link to="#" className="navbar-brand logo">
                                <img src={logo} className="img-fluid" alt="Logo" />
                            </Link>
                        </div>
                        <div className="main-menu-wrapper">
                            <ul className="main-nav">
                                <li>
                                    <Link to="#">
                                        <img src={icon} alt="image" /> Dashboard
                                    </Link>
                                </li>
                                <li className="active">
                                    <Link to="employees.html">
                                        <img src={empicon} alt="image" /> Employees
                                    </Link>
                                </li>
                                <li>
                                    <Link to="#">
                                        <img src={ticon} alt="image" /> Time off
                                    </Link>
                                </li>
                                <li>
                                    <Link to="#">
                                        <img src={picon} alt="image" /> Policies
                                    </Link>
                                </li>
                                <li>
                                    <Link to="#">
                                        <img src={ricon} alt="image" /> Reports
                                    </Link>
                                </li>
                            </ul>
                            <ul className="nav header-navbar-rht">
                                <li className="nav-item search-item">
                                    <div className="top-nav-search">
                                        <form action="#">
                                            <input type="text" className="form-control" placeholder="Search" />
                                            <button className="btn" type="submit"><i className="feather-search" /></button>
                                            <span><img src={sicon} alt="image" /></span>
                                        </form>
                                    </div>
                                </li>
                                <li className="nav-item quick-link-item">
                                    <Link className="btn" to="#">
                                        <span>Quick Links <i className="feather-zap" /></span>
                                    </Link>
                                </li>
                                <li className="nav-item nav-icons">
                                    <Link to="#">
                                        <i className="feather-sun" />
                                    </Link>
                                </li>
                                <li className="nav-item dropdown has-arrow notification-dropdown">
                                    <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                                        <i className="feather-bell" />
                                        <span className="badge">3</span>
                                    </Link>
                                    <div className="dropdown-menu dropdown-menu-end notifications">
                                        <div className="topnav-dropdown-header">
                                            <span className="notification-title">Notifications</span>
                                            <Link to="#" className="clear-noti"> Clear All</Link>
                                        </div>
                                        <div className="noti-content">
                                            <ul className="notification-list">
                                                <li className="notification-message">
                                                    <Link to="#">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img alt="image" src={avatar1} className="rounded-circle" />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details"><span className="noti-title">John Doe</span>
                                                                    added new task <span className="noti-title">Patient appointment
                                                                        booking</span></p>
                                                                <p className="noti-time"><span className="notification-time">4 mins
                                                                    ago</span></p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link to="#">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img alt="image" src={avatar2} className="rounded-circle" />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details"><span className="noti-title">Tarah
                                                                    Shropshire</span> changed the task name <span className="noti-title">Appointment booking with payment
                                                                        gateway</span></p>
                                                                <p className="noti-time"><span className="notification-time">6 mins
                                                                    ago</span></p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link to="#">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img alt="image" src={avatar6} className="rounded-circle" />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details"><span className="noti-title">Misty
                                                                    Tison</span> added <span className="noti-title">Domenic
                                                                        Houston</span> and <span className="noti-title">Claire
                                                                            Mapes</span> to project <span className="noti-title">Doctor
                                                                                available module</span></p>
                                                                <p className="noti-time"><span className="notification-time">8 mins
                                                                    ago</span></p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link to="#">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img alt="image" src={avatar5} className="rounded-circle" />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details"><span className="noti-title">Rolland
                                                                    Webber</span> completed task <span className="noti-title">Patient and Doctor video
                                                                        conferencing</span></p>
                                                                <p className="noti-time"><span className="notification-time">12 mins
                                                                    ago</span></p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                                <li className="notification-message">
                                                    <Link to="#">
                                                        <div className="media d-flex">
                                                            <span className="avatar flex-shrink-0">
                                                                <img alt="image" src={avatar3} className="rounded-circle" />
                                                            </span>
                                                            <div className="media-body flex-grow-1">
                                                                <p className="noti-details"><span className="noti-title">Bernardo
                                                                    Galaviz</span> added new task <span className="noti-title">Private chat module</span></p>
                                                                <p className="noti-time"><span className="notification-time">2 days
                                                                    ago</span></p>
                                                            </div>
                                                        </div>
                                                    </Link>
                                                </li>
                                            </ul>
                                        </div>
                                        <div className="topnav-dropdown-footer">
                                            <Link to="#">View all Notifications</Link>
                                        </div>
                                    </div>
                                </li>
                                <li className="nav-item nav-icons">
                                    <Link to="#">
                                        <i className="feather-settings" />
                                    </Link>
                                </li>
                                <li className="nav-item nav-icons">
                                    <Link to="#">
                                        <i className="far fa-circle-question" />
                                    </Link>
                                </li>
                                <li className="nav-item dropdown has-arrow main-drop">
                                    <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                                        <span className="user-img">
                                            <img src={avatar1} className="img-rounded" alt="image" />
                                        </span>
                                    </Link>
                                    <div className="dropdown-menu">
                                        <Link className="dropdown-item" to="#">
                                            <i className="feather-user-plus" /> My Profile
                                        </Link>
                                        <Link className="dropdown-item" to="#">
                                            <i className="feather-settings" /> Settings
                                        </Link>
                                        <Link className="dropdown-item" to="#">
                                            <i className="feather-log-out" /> Logout
                                        </Link>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </header> */}
                <Header />
                {/* /Header */}
                {/* Page Wrapper */}
                <div className="page-wrapper department-page">
                    {/* Page Content */}
                    <div className="content container">
                        {/* Page Header */}
                        <div className="page-header">
                            <div className="row align-items-center">
                                <div className="col-lg-6 col-md-6">
                                    <h3 className="page-title">Departments</h3>
                                </div>
                                <div className="col-lg-6 col-md-6 page-header-btns">
                                    <Link to="#" className="outline-btn"><span>
                                        <i className="feather-flag" /> Positions</span>
                                    </Link>
                                    <Link to="#" className="btn new-employee-btn " data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                        <i className="fa-solid fa-plus" /> Add Department
                                    </Link>
                                </div>
                            </div>
                        </div>
                        {/* /Page Header */}
                        {/* Search Filter */}
                        <div className="search-filter">
                            <div className="row align-items-center">
                                <div className="col-lg-6 col-md-6">
                                    <div className="depart-filter">
                                        <div className="depart-logo">
                                            <img src={main} />
                                            <div className="title-content">
                                                <h4>Dreamguy's Technologies</h4>
                                                <p>30 Departments</p>
                                            </div>
                                        </div>
                                        <div className="depart-team">
                                            <div className="depart-group">
                                                <div className="depart-avatar">
                                                    <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                                                </div>
                                                <div className="depart-avatar">
                                                    <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                                                </div>
                                                <div className="depart-avatar">
                                                    <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                                                </div>
                                                <div className="depart-avatar">
                                                    <span className="avatar-title rounded-circle border border-white">CF</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-6 col-md-6">
                                    <ul className="nav search-btns-info">
                                        <li>
                                            <Link to="#" className="btn title ">
                                                <img src={grid} alt="image" />
                                                Grid view
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to="#" className="btn title active ">
                                                <img src={chart} alt="image" />
                                                chart view
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to="#" className="btn zoom-out ">
                                                <img src={zoomout} alt="image" />
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to="#" className="btn zoom">
                                                <img src={zoomin} alt="image" />
                                            </Link>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        {/* /Search Filter */}
                        {/* Department Grid */}
                        {/* <TransformWrapper
                            initialScale={1}
                            initialPositionX={200}
                            initialPositionY={100}
                        >
                            {({ zoomIn, zoomOut, resetTransform, ...rest }) => (
                                <React.Fragment>
                                    <div className="tools">
                                        <button onClick={() => zoomIn()}>+</button>
                                        <button onClick={() => zoomOut()}>-</button>
                                        <button onClick={() => resetTransform()}>x</button>
                                    </div>
                                    <TransformComponent> */}
                                        <div className="zoom_outer target ">
                                            <div id="zoom">
                                                <ul className="department chart ">
                                                    <div className="row">
                                                        <li>
                                                            <div className="department-box main-division mt-0">
                                                                <div className="department-content">
                                                                    <div className="depart-img">
                                                                        <img src={main} />
                                                                    </div>
                                                                    <div className="depart-content">
                                                                        <h4>Dreamguy's Technologies</h4>
                                                                        <p>500 Employees</p>
                                                                    </div>
                                                                </div>
                                                                <div className="depart-btn">
                                                                    <Link to="#" className="add-btn"><img src={plus} alt='img' /> </Link>
                                                                </div>
                                                            </div>
                                                            <ul>
                                                                <li className="first-depart">
                                                                    <div className="department-box division">
                                                                        <div className="department-content">
                                                                            <div className="depart-img lite_blue">
                                                                                <img src={div1} alt='img' />
                                                                            </div>
                                                                            <div className="depart-content">
                                                                                <h4>Management</h4>
                                                                                <p>10 Employees</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="depart-btn">
                                                                            <Link to="#" className="add-btn"><img src={plus} alt='img' /> </Link>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li className="second-depart">
                                                                    <Link to="#" className="open-button" onclick="openForm()">
                                                                    </Link><div className="department-box division"><Link to="#" className="open-button" onclick="openForm()">
                                                                        <div className="department-content" onClick={() => setPart((s) => !s)}>
                                                                            <div className="depart-img lite_orange">
                                                                                <img src={div2} alt='img' />
                                                                            </div>
                                                                            <div className="depart-content" >
                                                                                <h4>HR</h4>
                                                                                <p>08 Employees</p>
                                                                            </div>
                                                                        </div>
                                                                    </Link><div className="depart-btn"><Link to="#" className="open-button" onclick="openForm()">
                                                                    </Link><Link to="#" className="add-btn" id="sub-branch-hr-btn"><img src={plus} alt='img' onClick={() => setShow((s) => !s)} />  </Link>
                                                                            <div id="sub-branch-hr">
                                                                                <ul >
                                                                                    <li>
                                                                                        <div className="department-box sub-division" >
                                                                                            <div className="department-content">
                                                                                                <div className="depart-img lite_orange">
                                                                                                    <img src={div6} alt='img' />
                                                                                                </div>
                                                                                                <div className="depart-content">
                                                                                                    <h4>Accounts</h4>
                                                                                                    <p>4 Employees</p>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div className="depart-btn">
                                                                                                <Link to="#" className="add-btn"><img src={plus} alt='img' /> </Link>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                    <li>
                                                                                        <div className="department-box sub-division">
                                                                                            <div className="department-content">
                                                                                                <div className="depart-img lite_orange">
                                                                                                    <img src={div7} alt='img' />
                                                                                                </div>
                                                                                                <div className="depart-content">
                                                                                                    <h4>Admin</h4>
                                                                                                    <p>5 Employees</p>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div className="depart-btn">
                                                                                                <Link to="#" className="add-btn"><img src={plus} alt='img' /> </Link>
                                                                                            </div>
                                                                                        </div>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div id="sub-branch-hr" style={{ display: show ? 'block' : 'none' }}>
                                                                        <ul>
                                                                            <li>
                                                                                <div className="department-box sub-division">
                                                                                    <div className="department-content">
                                                                                        <div className="depart-img lite_orange">
                                                                                            <img src={div6} />
                                                                                        </div>
                                                                                        <div className="depart-content">
                                                                                            <h4>Accounts</h4>
                                                                                            <p>4 Employees</p>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className="depart-btn">
                                                                                        <Link to="#" className="add-btn"><img src={plus} /> </Link>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div className="department-box sub-division">
                                                                                    <div className="department-content">
                                                                                        <div className="depart-img lite_orange">
                                                                                            <img src={div7} />
                                                                                        </div>
                                                                                        <div className="depart-content">
                                                                                            <h4>Admin</h4>
                                                                                            <p>5 Employees</p>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className="depart-btn">
                                                                                        <Link to="#" className="add-btn"><img src={plus} /> </Link>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </li>
                                                                <li className="third-depart">
                                                                    <div className="department-box division">
                                                                        <div className="department-content">
                                                                            <div className="depart-img lite_green">
                                                                                <img src={div4} alt='img' />
                                                                            </div>
                                                                            <div className="depart-content">
                                                                                <h4>Marketing</h4>
                                                                                <p>24 Employees</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="depart-btn">
                                                                            <Link to="#" className="add-btn"><img src={plus} alt='img' /> </Link>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                                <li className="fourth-depart">
                                                                    <div className="department-box division">
                                                                        <div className="department-content">
                                                                            <div className="depart-img lite_pink">
                                                                                <img src={div5} alt='img' />
                                                                            </div>
                                                                            <div className="depart-content">
                                                                                <h4>UI / UX</h4>
                                                                                <p>12 Employees</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="depart-btn">
                                                                            <Link to="#" className="add-btn" id="sub-branch-ui-btn"><img src={plus} alt='img' onClick={() => setView((s) => !s)} /> </Link>
                                                                        </div>
                                                                    </div>
                                                                    <div id="sub-branch-ui" style={{ display: view ? 'block' : 'none' }}>
                                                                        <ul>
                                                                            <li>
                                                                                <div className="department-box sub-division">
                                                                                    <div className="department-content">
                                                                                        <div className="depart-img lite_pink">
                                                                                            <img src={div8} alt='img' />
                                                                                        </div>
                                                                                        <div className="depart-content">
                                                                                            <h4>Design</h4>
                                                                                            <p>15 Employees</p>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className="depart-btn">
                                                                                        <Link to="#" className="add-btn"><img src={plus} />
                                                                                        </Link>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                            <li>
                                                                                <div className="department-box sub-division">
                                                                                    <div className="department-content">
                                                                                        <div className="depart-img lite_pink">
                                                                                            <img src={div9} />
                                                                                        </div>
                                                                                        <div className="depart-content">
                                                                                            <h4>Development</h4>
                                                                                            <p>30 Employees</p>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div className="depart-btn">
                                                                                        <Link to="#" className="add-btn"><img src={plus} />
                                                                                        </Link>
                                                                                    </div>
                                                                                </div>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </li>
                                                                <li className="fifth-depart">
                                                                    <div className="department-box division">
                                                                        <div className="department-content">
                                                                            <div className="depart-img lite_purple">
                                                                                <img src={div6} />
                                                                            </div>
                                                                            <div className="depart-content">
                                                                                <h4>IT</h4>
                                                                                <p>50 Employees</p>
                                                                            </div>
                                                                        </div>
                                                                        <div className="depart-btn">
                                                                            <Link to="#" className="add-btn"><img src={plus} /> </Link>
                                                                        </div>
                                                                    </div>
                                                                </li>
                                                            </ul>
                                                        </li>
                                                    </div>
                                                </ul>
                                            </div>
                                            <div className="employees-popup department-popup" >
                                                <div className="modal1 form-popup" id="myForm" style={{ display: part ? 'block' : 'none' }}>
                                                    <div className="form-container">
                                                        <div className="popup-content">
                                                            <div className="header">
                                                                <h1 className="title " id="staticBackdropLabel"> HR Department</h1>
                                                                <button type="button" className="btn-close" onclick="closeForm()" data-bs-dismiss="modal" aria-label="Close" onClick={() => setPart((s) => !s)}><img src={depart} /> </button>
                                                            </div>
                                                            <div className="body">
                                                                <div className="department-card">
                                                                    <div className="card-body">
                                                                        <div className="card-detail">
                                                                            <p>Employees</p>
                                                                            <div className="depart-team">
                                                                                <div className="depart-group">
                                                                                    <div className="depart-avatar">
                                                                                        <img src={avatar1} className="avatar-img rounded-circle border border-white " />
                                                                                    </div>
                                                                                    <div className="depart-avatar">
                                                                                        <img src={avatar2} className="avatar-img rounded-circle border border-white " />
                                                                                    </div>
                                                                                    <div className="depart-avatar">
                                                                                        <img src={avatar3} className="avatar-img rounded-circle border border-white " />
                                                                                    </div>
                                                                                    <div className="depart-avatar">
                                                                                        <span className="avatar-title rounded-circle border border-white">35+</span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div className="card-footer">
                                                                            <p>Head of Department</p>
                                                                            <h5>Dreamguy’s Tech</h5>
                                                                        </div>
                                                                        <div className="card-header">
                                                                            <p>Active</p>
                                                                            <div className="status-toggle ">
                                                                                <input type="checkbox" id="status_11" className="check" />
                                                                                <label htmlFor="status_11" className="checktoggle">checkbox</label>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    {/* </TransformComponent>
                                </React.Fragment>
                            )}
                        </TransformWrapper> */}
                        

                        {/* /Department Grid */}
                        {/* Footer */}
                        <footer className="footer department_footer">
                            <div className="container">
                                <div className="row">
                                    <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                                        <div className="footer-left">
                                            <p>© 2023 Dreams HRMS <span>Developed by</span> </p>
                                            <img src={logotitle} />
                                        </div>
                                    </div>
                                    <div className="col-md-6 col-sm-6 col-12 col-lg-6 col-xl-6 p-0">
                                        <div className="footer-right">
                                            <ul>
                                                <li>
                                                    <Link to="#">Privacy Policy</Link>
                                                </li>
                                                <li>
                                                    <Link to="#">Terms &amp; Conditions</Link>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </footer>
                        {/* Footer */}
                    </div>
                    {/* /Page Content */}
                </div>
                {/* /Page Wrapper */}
            </div>
            {/* /Main Wrapper */}
            {/* Modal Popup */}
            <div className="employees-popup add-department ">
                <div className="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabIndex={-1} aria-labelledby="staticBackdropLabel" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h1 className="modal-title" id="staticBackdropLabel">Add Department</h1>
                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><img src={close} /> </button>
                            </div>
                            <div className="modal-body">
                                <div className="multistep-form">
                                    <fieldset className="form-inner" id="first">
                                        <div className="form-area">
                                            <div className="form-details ">
                                                <form action="#">
                                                    <div className="row">
                                                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                                                            <div className="input-area">
                                                                <label className="form-label">Department Name <span>*</span></label>
                                                                <input type="text" className="form-control" placeholder="Enter Department Name" required />
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                                                            <div className="input-area">
                                                                <label className="form-label">Parent Department <span className="sml-msg">(Leave this empty for parent)</span> </label>
                                                                <select className="form-select select">
                                                                    <option selected>Select Parent Department</option>
                                                                    <option value={1}>One</option>
                                                                    <option value={2}>Two</option>
                                                                    <option value={3}>Three</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                                                            <div className="input-area">
                                                                <label className="form-label">Description </label>
                                                                <textarea type="text" className="form-control textarea-cls" placeholder="Enter Description" required defaultValue={""} />
                                                            </div>
                                                        </div>
                                                        <div className="col-lg-12 col-md-6 col-sm-6 ">
                                                            <div className="input-area">
                                                                <label className="form-label">Department Icon</label>
                                                                <div className="employee-upload-img">
                                                                    <p>Drop your files here or <span>Browse</span></p>
                                                                    <h6>Maximum size: 50MB</h6>
                                                                    <input type="file" className="form-control" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div className="add-form-btn widget-next-btn submit-btn">
                                            <div className="btn-left">
                                                <Link className="btn main-btn ">Save</Link>
                                                <Link className="btn close-btn me-0" data-bs-dismiss="modal" aria-label="Close">Cancel</Link>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default Depart
