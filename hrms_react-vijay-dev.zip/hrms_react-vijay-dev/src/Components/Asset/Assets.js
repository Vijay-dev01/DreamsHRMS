import React from 'react'
import { Link } from 'react-router-dom'
import Header from '../Header'
import { asset1, assets1, attach1, avatard, bar, clock, down, drag1, funnel, grid, printer, searchbtn, sortascending } from '../imagepath'
import Footer from '../Footer'
import { useState } from 'react'

const Asset = () => {
    const [show, setShow] = useState(false);
    const [aside, setAside] = useState(false);

    const toggleShow = () => {
        console.log('click')
        setShow(true)
    }

    const toggleClose = () => {
        console.log('click')
        setShow(false)
    }
    console.log(show);

    const handleShow = () => {
        console.log('click')
        setAside(true)
    }

    const handleClose = () => {
        console.log('click')
        setAside(false)
    }
    console.log(aside);

  return (
    <div>
  <div className="main-wrapper">
    {/* Header */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper admin-assets">
      {/* Page Content */}
      <div className="content container">
        <div className="d-lg-flex justify-content-between align-items-center search-filter">
          <div className="d-lg-flex justify-content-start align-items-center policy-bg">
            <h2>Assets</h2>
          </div>
          <div className="mixed-buttons">
            <button type="button" className="btn btn-transparent"><img src={clock} alt /></button>
            <button type="button" className="btn btn-transparent"><img src={searchbtn} alt /></button>
            <button type="button" className="btn btn-transparent"><img src={sortascending} alt /></button>
            <button type="button" className="btn btn-transparent filter-popup-toggle" onClick={toggleShow}><img src={funnel} alt /></button>
            <button type="button" className="btn btn-transparent"><img src={down} alt /></button>
            <button type="button" className="btn btn-transparent"><img src={printer} alt /></button>
            <Link to="/asset" className="btn btn-transparent"><img src={bar} alt /></Link>
            <Link to="/assetgrid" className="btn btn-transparent"><img src={grid} alt /></Link>
            <button type="button" className="btn gradient-btn text asset-assign" data-bs-toggle="modal" data-bs-target="#assign-assets">
              <span className="gradient-border"><span className="gradient-text"><i className="fa fa-user-plus" aria-hidden="true" />Asset Assign</span></span>
            </button>
            <button type="button" className="btn gradient-btn text" data-bs-toggle="modal" data-bs-target="#add-assets"><i className="fa fa-plus" aria-hidden="true" />Add Assets</button>
          </div>
        </div>
        {/* Table Start */}
        <div className="col-sm-12">
          <div className="card-table">
            <div className="card-body">
              <div className="table-responsive">
                <table className="table table-center table-hover datatable checklist">
                  <thead className="thead-light">
                    <tr>
                      <th>#</th>
                      <th>Asset ID</th>
                      <th>Asset Name</th>
                      <th>Asset Categories</th>
                      <th>Purchase Date</th>
                      <th>Supplier</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT A101</p></td>
                      <td className="popup-toggle">
                        <div className="d-flex justify-content-between align-items-center assets">
                          <h2 className="d-flex justify-content-start align-items-center" onClick={handleShow}>
                            <Link to="#"><img src={asset1} alt="Asset Image" /></Link>
                            <Link to="#">ThinkPad E15 G4</Link>
                          </h2>
                        </div>
                      </td>
                      <td><p>Laptop</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><p>Amazon</p></td>
                      <td>
                        <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><span className="success status"><i className="fa-sharp fa-solid fa-circle" />Active</span></Link>
                        <div className="dropdown-menu dropdown-menu-end">
                          <ul>
                            <li>
                              <Link className="dropdown-item" to="#">Active</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Archived</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Broken</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Being Repaired</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Pending</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Ready to Deploy</Link>
                            </li>
                          </ul>
                        </div>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action action-icons">
                          <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="fa fa-user-plus me-2" aria-hidden="true" />Asset Assign</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT A101</p></td>
                      <td className="popup-toggle">
                        <div className="d-flex justify-content-between align-items-center assets">
                          <h2 className="d-flex justify-content-start align-items-center" onClick={handleShow}>
                            <Link to="#"><img src={asset1} alt="Asset Image" /></Link>
                            <Link to="#">ThinkPad E15 G4</Link>
                          </h2>
                        </div>
                      </td>
                      <td><p>Laptop</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><p>Amazon</p></td>
                      <td>
                        <Link to="#" data-bs-toggle="dropdown" aria-expanded="false">
                          <span className="deployed status"><i className="fa-sharp fa-solid fa-circle" />Deployed</span>
                        </Link>
                        <div className="dropdown-menu dropdown-menu-end">
                          <ul>
                            <li>
                              <Link className="dropdown-item" to="#">Active</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Archived</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Broken</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Being Repaired</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Pending</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Ready to Deploy</Link>
                            </li>
                          </ul>
                        </div>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action action-icons">
                          <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="fa fa-user-plus me-2" aria-hidden="true" />Asset Assign</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT A101</p></td>
                      <td className="popup-toggle">
                        <div className="d-flex justify-content-between align-items-center assets">
                          <h2 className="d-flex justify-content-start align-items-center" onClick={handleShow}>
                            <Link to="#"><img src={asset1} alt="Asset Image" /></Link>
                            <Link to="#">ThinkPad E15 G4</Link>
                          </h2>
                        </div>
                      </td>
                      <td><p>Laptop</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><p>Amazon</p></td>
                      <td>
                        <Link to="#" data-bs-toggle="dropdown" aria-expanded="false">
                          <span className="archived status">
                            <i className="fa-sharp fa-solid fa-circle" />
                            Archived
                          </span>
                        </Link>
                        <div className="dropdown-menu dropdown-menu-end">
                          <ul>
                            <li>
                              <Link className="dropdown-item" to="#">Active</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Archived</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Broken</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Being Repaired</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Pending</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Ready to Deploy</Link>
                            </li>
                          </ul>
                        </div>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action action-icons">
                          <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="fa fa-user-plus me-2" aria-hidden="true" />Asset Assign</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT A101</p></td>
                      <td className="popup-toggle">
                        <div className="d-flex justify-content-between align-items-center assets">
                          <h2 className="d-flex justify-content-start align-items-center" onClick={handleShow}>
                            <Link to="#"><img src={asset1} alt="Asset Image" /></Link>
                            <Link to="#">ThinkPad E15 G4</Link>
                          </h2>
                        </div>
                      </td>
                      <td><p>Laptop</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><p>Amazon</p></td>
                      <td>
                        <Link to="#" data-bs-toggle="dropdown" aria-expanded="false">
                          <span className="warning status">
                            <i className="fa-sharp fa-solid fa-circle" />
                            Broken
                          </span>
                        </Link>
                        <div className="dropdown-menu dropdown-menu-end">
                          <ul>
                            <li>
                              <Link className="dropdown-item" to="#">Active</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Archived</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Broken</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Being Repaired</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Pending</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Ready to Deploy</Link>
                            </li>
                          </ul>
                        </div>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action action-icons">
                          <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="fa fa-user-plus me-2" aria-hidden="true" />Asset Assign</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT A101</p></td>
                      <td className="popup-toggle">
                        <div className="d-flex justify-content-between align-items-center assets">
                          <h2 className="d-flex justify-content-start align-items-center" onClick={handleShow}>
                            <Link to="#"><img src={asset1} alt="Asset Image" /></Link>
                            <Link to="#">ThinkPad E15 G4</Link>
                          </h2>
                        </div>
                      </td>
                      <td><p>Laptop</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><p>Amazon</p></td>
                      <td>
                        <Link to="#" data-bs-toggle="dropdown" aria-expanded="false">
                          <span className="warning status">
                            <i className="fa-sharp fa-solid fa-circle" />
                            Being Repaired
                          </span>
                        </Link>
                        <div className="dropdown-menu dropdown-menu-end">
                          <ul>
                            <li>
                              <Link className="dropdown-item" to="#">Active</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Archived</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Broken</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Being Repaired</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Pending</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Ready to Deploy</Link>
                            </li>
                          </ul>
                        </div>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action action-icons">
                          <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="fa fa-user-plus me-2" aria-hidden="true" />Asset Assign</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td><p>1</p></td>
                      <td><p>DGT A101</p></td>
                      <td className="popup-toggle">
                        <div className="d-flex justify-content-between align-items-center assets">
                          <h2 className="d-flex justify-content-start align-items-center" onClick={handleShow}>
                            <Link to="#"><img src={asset1} alt="Asset Image" /></Link>
                            <Link to="#">ThinkPad E15 G4</Link>
                          </h2>
                        </div>
                      </td>
                      <td><p>Laptop</p></td>
                      <td>
                        <p>30 March 2023</p>
                        <span>Thursday</span>
                      </td>
                      <td><p>Amazon</p></td>
                      <td>
                        <Link to="#" data-bs-toggle="dropdown" aria-expanded="false">
                          <span className="pending status">
                            <i className="fa-sharp fa-solid fa-circle" />
                            pending
                          </span>
                        </Link>
                        <div className="dropdown-menu dropdown-menu-end">
                          <ul>
                            <li>
                              <Link className="dropdown-item" to="#">Active</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Archived</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Broken</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Being Repaired</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Pending</Link>
                            </li>
                            <li>
                              <Link className="dropdown-item" to="#">Ready to Deploy</Link>
                            </li>
                          </ul>
                        </div>
                      </td>
                      <td>
                        <div className="dropdown dropdown-action action-icons">
                          <Link to="#" data-bs-toggle="dropdown" aria-expanded="false"><i className="fas fa-ellipsis-v" /></Link>
                          <div className="dropdown-menu dropdown-menu-end">
                            <ul>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-edit me-2" />Edit</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-trash-alt me-2" />Delete</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="fa fa-user-plus me-2" aria-hidden="true" />Asset Assign</Link>
                              </li>
                              <li>
                                <Link className="dropdown-item" to="#"><i className="far fa-eye me-2" />View</Link>
                              </li>
                            </ul>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        {/* /Table End */}
        {/* Footer */}
        <Footer />
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Assets Modal */}
  <div className="modal fade onboarding-modal" id="add-assets" tabIndex={-1} aria-labelledby="add-assets" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Assets</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Assets Info</h6>
          <form>
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset Name <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select or Add New Name</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset ID <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Select or Add New Name" required />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Device Categories</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Category</option>
                    <option selected>Enter Asset ID</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Brand</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Brand</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Model</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Model</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="ExpirationDate">Warranty Expiration Date</label>
                  <input id="ExpirationDate" className="form-control" type="date" />
                  <span id="expirationDateSelected" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Assets Status</label>
                  <input type="text" className="form-control" placeholder="Select Status" required />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Serial Number</label>
                  <input type="text" className="form-control" placeholder="Enter Serial Number" required />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Supplier</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Supplier</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="purchaseDate">Purchase Date</label>
                  <input id="purchaseDate" className="form-control" type="date" />
                  <span id="purchaseDateSelected" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="validationCustomUsername" className="form-label">Purchase Amount</label>
                  <div className="input-group has-validation">
                    <span className="input-group-text" id="inputGroupPrepend">$</span>
                    <input type="text" className="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" placeholder="Enter Amount" />
                    <div className="invalid-feedback">
                      Enter Amount
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Notes</label>
                  <input type="text" className="form-control" placeholder="Enter Notes" required />
                </div>
              </div>
            </div>
            <h6>Attachment</h6>
            <label className="form-label">Image</label>
            <div className="drag-drop text-center">
              <div className="upload">
                <Link to="#"><img src={drag1} alt /></Link>
                <p>Drag &amp; drop your files here or choose file <Link to="#">browse</Link></p>
                <span>Maximum size: 50MB</span>
              </div>
              <input type="file" multiple />
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Add Assets Modal */}
  {/* Assign Asset Modal */}
  <div className="modal fade onboarding-modal" id="assign-assets" tabIndex={-1} aria-labelledby="assign-assets" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Assets Assign</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Assets Info</h6>
          <form>
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset Name <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select or Add New Name</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset ID <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Select or Add New Name" required />
                </div>
              </div>
              <div className="col-12">
                <div className="mb-3">
                  <label className="form-label">Assigned To</label>
                  <select className="form-select select">
                    <option selected>Select Employee</option>
                    <option selected>Enter Asset ID</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Department <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select Department</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Position <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select Position</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="assignDate">Assign Date <span>*</span></label>
                  <input id="assignDate" className="form-control" type="date" />
                  <span id="assignDateSelected" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="expectedDate">Expected Return Date</label>
                  <input id="expectedDate" className="form-control" type="date" />
                  <span id="expectedDateSelected" />
                </div>
              </div>
              <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                <div className="form-check form-switch">
                  <input className="form-check-input dull" type="checkbox" role="switch" id="send-mail" />
                  <label className="form-check-label" htmlFor="send-mail">Send an email notification to employee</label>
                </div>
              </div>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Assign Asset Modal */}
  {/*Asset Details */}
  <div className={ aside ? "for-admin toggle-sidebar asset open-sidebar" : "for-admin toggle-sidebar asset"} style={{ display: aside ? 'block' : 'none'}}>
    <div className="d-flex align-items-center justify-content-between head">
      <h5>Assets Deatils</h5>
      <i className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes" aria-hidden="true" onClick={handleClose} />
    </div>
    <h6>Asset Info</h6>
    <div className="d-flex align-items-center justify-content-start asset-info">
      <img src={assets1} alt />
      <span>Key Board</span>
    </div>
    <table className="w-100">
      <tbody><tr>
          <td><span>Asset ID</span></td>
          <td align="right"><p>ASSET00001</p></td>
        </tr>
        <tr>
          <td><span>Device Type</span></td>
          <td align="right"><p>Laptop Accessories</p></td>
        </tr>
        <tr>
          <td><span>Brand</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Model</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Serial Number</span></td>
          <td align="right"><p>Nil</p></td>
        </tr>
      </tbody></table>
    <h6>Asset Assign Details</h6>
    <table className="w-100">
      <tbody><tr>
          <td><span>Owner</span></td>
          <td align="right"><p>Hernandez</p></td>
        </tr>
        <tr>
          <td><span>User</span></td>
          <td align="right"><p>Richard Steve</p></td>
        </tr>
        <tr>
          <td><span>Brand</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Model</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Serial Number</span></td>
          <td align="right"><p>Nil</p></td>
        </tr>
      </tbody></table>
    <h6>Attachment</h6>
    <table className="w-100 attachment">
      <tbody><tr>
          <td><Link to="#"><img src={attach1} alt /></Link></td>
          <td><Link to="#"><img src={attach1} alt /></Link></td>
          <td><Link to="#"><img src={attach1} alt /></Link></td>
        </tr>
        <tr>
          <td><Link to="#"><img src={attach1} alt /></Link></td>
          <td><Link to="#"><img src={attach1} alt /></Link></td>
          <td><Link to="#"><img src={attach1} alt /></Link></td>
        </tr>
      </tbody></table>
    <h6>Activity</h6>
    <ul className="activity">
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-3 no-padding-right">
            <div className="d-block">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt />
                  </Link>
                </span>
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                    <img src={avatard} alt />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-9 no-padding no-padding-right">
            <div className="text">
              <span>Richard Shared Edit Access to <Link to="#">John</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-3 no-padding-right">
            <div className="d-block group-avatar-wrap">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt />
                  </Link>
                </span>
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                    <img src={avatard} alt />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-9 no-padding">
            <div className="text">
              <span>Richard Shared Edit Access to <Link to="#">Robert</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-2 no-padding-right">
            <div className="d-block group-avatar-wrap">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-10 no-padding">
            <div className="text">
              <span>Richard Changed File Name <Link to="#">Design Presentation</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-2">
            <div className="d-block group-avatar-wrap">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-10 no-padding">
            <div className="text">
              <span>Richard Changed File Name <Link to="#">Design Presentation</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
    </ul>
    <div className>
      <button type="button" className="btn gradient-btn w-100"><i className="fa fa-flag" aria-hidden="true" />Report Issue</button>
    </div>
  </div>
  {/*/Asset Details */}
  {/*Asset Filter */}
  <div className={show ? "filter-toggle-sidebar timesheet filter-open-sidebar" : "filter-toggle-sidebar timesheet"} style={{ display: show ? 'block' : 'none'}}>
    <div className="d-flex align-items-center justify-content-between head">
      <h5>Filter</h5>
      
    </div>
    <form>
      <div className="form-group search">
        <i className="feather-search" />
        <input type="text" className="form-control" placeholder="Search Employee" />
        <i
        className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes"
        aria-hidden="true"
        onClick={toggleClose}
      />
      </div>
      <ul>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Product</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="product1" />
                <label className="form-check-label" htmlFor="product1">Macbook Pro 16"</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="product2" />
                <label className="form-check-label" htmlFor="product2">ThinkPad E15 G4</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="product3" />
                <label className="form-check-label" htmlFor="product3">XPS 13</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="product4" />
                <label className="form-check-label" htmlFor="product4">iPhone 13 Pro Max</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="product5" />
                <label className="form-check-label" htmlFor="product5">Keyboard</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Status</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="status1" />
                <label className="form-check-label" htmlFor="status1">Active</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="status2" />
                <label className="form-check-label" htmlFor="status2">Archived</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="status3" />
                <label className="form-check-label" htmlFor="status3">Broken</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="status4" />
                <label className="form-check-label" htmlFor="status4">Being Repaired</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="status5" />
                <label className="form-check-label" htmlFor="status5">Pending</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Category</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="category1" />
                <label className="form-check-label" htmlFor="category1">Laptop</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="category2" />
                <label className="form-check-label" htmlFor="category2">Computer Accessories</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="category3" />
                <label className="form-check-label" htmlFor="category3">i Phone</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="category4" />
                <label className="form-check-label" htmlFor="category4">Printer</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="category5" />
                <label className="form-check-label" htmlFor="category5">Tablets</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>					
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Brand</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="brand1" />
                <label className="form-check-label" htmlFor="brand1">Adobe</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="brand2" />
                <label className="form-check-label" htmlFor="brand2">Apple</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="brand3" />
                <label className="form-check-label" htmlFor="brand3">Canon</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="brand4" />
                <label className="form-check-label" htmlFor="brand4">Dell</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="brand5" />
                <label className="form-check-label" htmlFor="brand5">Lenovo</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>					
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Supplier</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="supplier1" />
                <label className="form-check-label" htmlFor="supplier1">Amazon</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="supplier2" />
                <label className="form-check-label" htmlFor="supplier2">Staples</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="supplier3" />
                <label className="form-check-label" htmlFor="supplier3">Newegg</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="supplier4" />
                <label className="form-check-label" htmlFor="supplier4">Flipkart</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue id="supplier5" />
                <label className="form-check-label" htmlFor="supplier5">Store</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>					
          </ul>
        </li>
      </ul>
      <div className="button-row">
        <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-reply" aria-hidden="true" />Reset</button>
        <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Apply</button>
      </div>
    </form>
  </div>
</div>

  )
}

export default Asset
