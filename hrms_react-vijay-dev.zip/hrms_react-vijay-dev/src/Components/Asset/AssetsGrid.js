import React, { useState } from 'react'
import Header from '../Header'
import { asset1, assets1, attach1, avatard, bar, clock, down, drag1, funnel, grid, printer, searchbtn, sortascending } from '../imagepath'
import { Link } from 'react-router-dom'

const AssetsGrid = () => {
    const [show, setShow] = useState(false);

    const toggleShow = () => {
        console.log('click')
        setShow(true)
    }

    const toggleClose = () => {
        console.log('click')
        setShow(false)
    }
    console.log(show);

  return (
   <div>
  <div className="main-wrapper admin-assets">
    {/* Header */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper grid-assets">
      {/* Page Content */}
      <div className="content container">
        <div className="d-lg-flex justify-content-between align-items-center search-filter">
          <div className="d-lg-flex justify-content-start align-items-center">
            <h2>Assets</h2>
          </div>
          <div className="mixed-buttons">
            <button type="button" className="btn btn-transparent"><img src={clock} alt="" /></button>
            <button type="button" className="btn btn-transparent"><img src={searchbtn} alt="" /></button>
            <button type="button" className="btn btn-transparent"><img src={sortascending} alt="" /></button>
            <button type="button" className="btn btn-transparent filter-popup-toggle"><img src={funnel} alt="" /></button>
            <button type="button" className="btn btn-transparent"><img src={down} alt="" /></button>
            <button type="button" className="btn btn-transparent"><img src={printer} alt="" /></button>
            <Link to="/asset" className="btn btn-transparent"><img src={bar} alt="" /></Link>
            <Link to="/assetgrid" className="btn btn-transparent"><img src={grid} alt="" /></Link>
            <button type="button" className="btn gradient-btn text asset-assign" data-bs-toggle="modal" data-bs-target="#assign-assets">
              <span className="gradient-border"><span className="gradient-text"><i className="fa fa-user-plus" aria-hidden="true" />Asset Assign</span></span>
            </button>
            <button type="button" className="btn gradient-btn text" data-bs-toggle="modal" data-bs-target="#add-assets"><i className="fa fa-plus" aria-hidden="true" />Add Assets</button>
          </div>
        </div>
        {/*Assets Row*/}
        <div className="row assets">
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="success status"><i className="fa-sharp fa-solid fa-circle" />Active</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="deployed status"><i className="fa-sharp fa-solid fa-circle" />Deployed</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="archived status"><i className="fa-sharp fa-solid fa-circle" />Archived</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="warning status"><i className="fa-sharp fa-solid fa-circle" />Broken</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="success status"><i className="fa-sharp fa-solid fa-circle" />Active</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="warning status"><i className="fa-sharp fa-solid fa-circle" />Being Repaired</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="pending status"><i className="fa-sharp fa-solid fa-circle" />Pending</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="success status"><i className="fa-sharp fa-solid fa-circle" />Active</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="archived status"><i className="fa-sharp fa-solid fa-circle" />Archived</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="warning status"><i className="fa-sharp fa-solid fa-circle" />Being Repaired</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt="" /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="archived status"><i className="fa-sharp fa-solid fa-circle" />Archived</span></Link>
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-12 col-md-6 col-lg-4 document-wrap">
            <div className="white-bg">
              <div className="d-flex align-items-top head">
                <div className="d-flex justify-content-between align-items-top">
                  <div className="d-inline-block document-icon"><i className="d-inline-block text-center"><img src={asset1} alt='' /></i></div>
                  <div className="d-inline-block text">
                    <h3 className="d-inline popup-toggle" onClick={toggleShow}>Key Board</h3>
                    <span className="d-block">DGT A101</span>
                  </div>
                </div>
                <div className="star-ellips">
                  <div className="dropdown dropdown-action d-inline-block">
                    <Link to="#" className="btn-action-icon show" data-bs-toggle="dropdown" aria-expanded="true"><i className="fas fa-ellipsis-v" /></Link>
                    <div className="dropdown-menu dropdown-menu-end" data-popper-placement="bottom-end" style={{position: 'absolute', inset: '0px 0px auto auto', margin: 0, transform: 'translate3d(0px, 42px, 0px)'}}>
                      <ul>
                        <li>
                          <Link className="dropdown-item" to="edit-invoice.html"><i className="far fa-edit me-2" />Edit</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#delete_modal"><i className="far fa-trash-alt me-2" />Delete</Link>
                        </li>
                        <li>
                          <Link className="dropdown-item" to="#" data-bs-toggle="modal" data-bs-target="#share"><i className="fa fa-share-alt" aria-hidden="true" />Share</Link>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
              <div className="users-files">
                <div className="d-sm-flex justify-content-between align-items-center">
                  <p><span>Date :</span>&nbsp;&nbsp;06 Jan 2023</p>
                  <Link to="#"><span className="deployed status"><i className="fa-sharp fa-solid fa-circle" />Deployed</span></Link>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* /Assets Row */}
        <div className="docs-pages pagination-wrap d-flex justify-content-between">
          <p>Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
          <ul className="d-flex">
            <li className="active"><Link to="#">1</Link></li>
            <li><Link to="#">2</Link></li>
            <li><Link to="#">3</Link></li>
            <li><Link to="#">...</Link></li>
            <li><Link to="#">10</Link></li>
            <li><Link to="#">11</Link></li>
            <li><Link to="#">12</Link></li>
          </ul>
          <p>Go to page&nbsp;&nbsp;<i className="fa fa-long-arrow-right" aria-hidden="true" /></p>
        </div>
        {/* Footer */}
        <footer className="footer">
          <div className="container">
            <div className="row">
              <div className="d-flex justify-content-between align-items-center no-padding">
                <div className="footer-left">
                  <p>© 2023 Dreams HRMS <Link to="#" className="footer-logo"><img src="assets/img/footer-logo.svg" alt="footer-logo" /></Link></p>
                </div>
                <div className="footer-right">
                  <ul>
                    <li>
                      <Link to="#">Privacy Policy</Link>
                    </li>
                    <li>
                      <Link to="#">Terms &amp; Conditions</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </footer>
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Assets Modal */}
  <div className="modal fade onboarding-modal" id="add-assets" tabIndex={-1} aria-labelledby="add-assets" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Assets</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Assets Info</h6>
          <form>
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset Name <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select or Add New Name</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset ID <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Select or Add New Name" required />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Device Categories</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Category</option>
                    <option selected>Enter Asset ID</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Brand</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Brand</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Model</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Model</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="ExpirationDate">Warranty Expiration Date</label>
                  <input id="ExpirationDate" className="form-control" type="date" />
                  <span id="expirationDateSelected" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Assets Status</label>
                  <input type="text" className="form-control" placeholder="Select Status" required />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Serial Number</label>
                  <input type="text" className="form-control" placeholder="Enter Serial Number" required />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Supplier</label>
                  <select className="form-select select">
                    <option selected>Select or Add New Supplier</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="purchaseDate">Purchase Date</label>
                  <input id="purchaseDate" className="form-control" type="date" />
                  <span id="purchaseDateSelected" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="validationCustomUsername" className="form-label">Purchase Amount</label>
                  <div className="input-group has-validation">
                    <span className="input-group-text" id="inputGroupPrepend">$</span>
                    <input type="text" className="form-control" id="validationCustomUsername" aria-describedby="inputGroupPrepend" placeholder="Enter Amount" />
                    <div className="invalid-feedback">
                      Enter Amount
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Notes</label>
                  <input type="text" className="form-control" placeholder="Enter Notes" required />
                </div>
              </div>
            </div>
            <h6>Attachment</h6>
            <label className="form-label">Image</label>
            <div className="drag-drop text-center">
              <div className="upload">
                <Link to="#"><img src={drag1} alt="" /></Link>
                <p>Drag &amp; drop your files here or choose file <Link to="#">browse</Link></p>
                <span>Maximum size: 50MB</span>
              </div>
              <input type="file" multiple />
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Add Assets Modal */}
  {/* Assign Asset Modal */}
  <div className="modal fade onboarding-modal" id="assign-assets" tabIndex={-1} aria-labelledby="assign-assets" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Assets Assign</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Assets Info</h6>
          <form>
            <div className="row">
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset Name <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select or Add New Name</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Asset ID <span>*</span></label>
                  <input type="text" className="form-control" placeholder="Select or Add New Name" required />
                </div>
              </div>
              <div className="col-12">
                <div className="mb-3">
                  <label className="form-label">Assigned To</label>
                  <select className="form-select select">
                    <option selected>Select Employee</option>
                    <option selected>Enter Asset ID</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Department <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select Department</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label className="form-label">Position <span>*</span></label>
                  <select className="form-select select">
                    <option selected>Select Position</option>
                    <option value={1}>Option 1</option>
                    <option value={2}>OPtion 2</option>
                    <option value={2}>OPtion 3</option>
                  </select>
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="assignDate">Assign Date <span>*</span></label>
                  <input id="assignDate" className="form-control" type="date" />
                  <span id="assignDateSelected" />
                </div>
              </div>
              <div className="col-lg-6 col-md-6 col-sm-6">
                <div className="mb-3">
                  <label htmlFor="expectedDate">Expected Return Date</label>
                  <input id="expectedDate" className="form-control" type="date" />
                  <span id="expectedDateSelected" />
                </div>
              </div>
              <div className="col-12 col-sm-12 col-md-12 col-lg-12">
                <div className="form-check form-switch">
                  <input className="form-check-input dull" type="checkbox" role="switch" id="send-mail" />
                  <label className="form-check-label" htmlFor="send-mail">Send an email notification to employee</label>
                </div>
              </div>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Assign Asset Modal */}
  {/*Asset Details */}
  <div className={show ? "for-admin toggle-sidebar asset open-sidebar" : "for-admin toggle-sidebar asset"} style={{ display: show ? 'block' : 'none'}}>
    <div className="d-flex align-items-center justify-content-between head">
      <h5>Assets Deatils</h5>
      <i className="fa fa-times round align-items-center d-flex justify-content-center sidebar-closes" aria-hidden="true"  onClick={toggleClose}/>
    </div>
    <h6>Asset Info</h6>
    <div className="d-flex align-items-center justify-content-start asset-info">
      <img src={asset1} alt="" />
      <span>Key Board</span>
    </div>
    <table className="w-100">
      <tbody><tr>
          <td><span>Asset ID</span></td>
          <td align="right"><p>ASSET00001</p></td>
        </tr>
        <tr>
          <td><span>Device Type</span></td>
          <td align="right"><p>Laptop Accessories</p></td>
        </tr>
        <tr>
          <td><span>Brand</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Model</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Serial Number</span></td>
          <td align="right"><p>Nil</p></td>
        </tr>
      </tbody></table>
    <h6>Asset Assign Details</h6>
    <table className="w-100">
      <tbody><tr>
          <td><span>Owner</span></td>
          <td align="right"><p>Hernandez</p></td>
        </tr>
        <tr>
          <td><span>User</span></td>
          <td align="right"><p>Richard Steve</p></td>
        </tr>
        <tr>
          <td><span>Brand</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Model</span></td>
          <td align="right"><p>Zebronics</p></td>
        </tr>
        <tr>
          <td><span>Serial Number</span></td>
          <td align="right"><p>Nil</p></td>
        </tr>
      </tbody></table>
    <h6>Attachment</h6>
    <table className="w-100 attachment">
      <tbody><tr>
          <td><Link to="#"><img src={attach1} alt="" /></Link></td>
          <td><Link to="#"><img src={attach1} alt="" /></Link></td>
          <td><Link to="#"><img src={attach1} alt="" /></Link></td>
        </tr>
        <tr>
          <td><Link to="#"><img src={attach1} alt="" /></Link></td>
          <td><Link to="#"><img src={attach1} alt="" /></Link></td>
          <td><Link to="#"><img src={attach1} alt="" /></Link></td>
        </tr>
      </tbody></table>
    <h6>Activity</h6>
    <ul className="activity">
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-3 no-padding-right">
            <div className="d-block">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt="" />
                  </Link>
                </span>
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                    <img src={avatard} alt="" />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-9 no-padding no-padding-right">
            <div className="text">
              <span>Richard Shared Edit Access to <Link to="#">John</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-3 no-padding-right">
            <div className="d-block group-avatar-wrap">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt="" />
                  </Link>
                </span>
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                    <img src={avatard} alt="" />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-9 no-padding">
            <div className="text">
              <span>Richard Shared Edit Access to <Link to="#">Robert</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-2 no-padding-right">
            <div className="d-block group-avatar-wrap">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt="" />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-10 no-padding">
            <div className="text">
              <span>Richard Changed File Name <Link to="#">Design Presentation</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
      <li>
        <span className="d-block">Yesterday</span>
        <div className="row">
          <div className="col-xs-12 col-sm-6 col-md-4 col-lg-2">
            <div className="d-block group-avatar-wrap">
              <div className="group-avatar">
                <span className="avatar">
                  <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                    <img src={avatard} alt="" />
                  </Link>
                </span>
              </div>
            </div>
          </div>
          <div className="col-xs-12 col-sm-6 col-md-8 col-lg-10 no-padding">
            <div className="text">
              <span>Richard Changed File Name <Link to="#">Design Presentation</Link></span>
            </div>
          </div>
        </div>
        {/* Row */}
      </li>
    </ul>
    <div className>
      <button type="button" className="btn gradient-btn w-100"><i className="fa fa-flag" aria-hidden="true" />Report Issue</button>
    </div>
  </div>
  {/*/Asset Details */}
  {/*Asset Filter */}
  <div className="filter-toggle-sidebar timesheet">
    <div className="d-flex align-items-center justify-content-between head">
      <h5>Filter</h5>
      <i className="fa fa-times round align-items-center d-flex justify-content-center filter-sidebar-closes" aria-hidden="true" />
    </div>
    <form>
      <div className="form-group search">
        <i className="feather-search" />
        <input type="text" className="form-control" placeholder="Search Employee" />
      </div>
      <ul>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Product</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Macbook Pro 16" id="product1" />
                <label className="form-check-label" htmlFor="product1">Macbook Pro 16"</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="ThinkPad E15 G4" id="product2" />
                <label className="form-check-label" htmlFor="product2">ThinkPad E15 G4</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="XPS 13" id="product3" />
                <label className="form-check-label" htmlFor="product3">XPS 13</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="iPhone 13 Pro Max" id="product4" />
                <label className="form-check-label" htmlFor="product4">iPhone 13 Pro Max</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Keyboard" id="product5" />
                <label className="form-check-label" htmlFor="product5">Keyboard</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Status</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Active" id="status1" />
                <label className="form-check-label" htmlFor="status1">Active</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Archived" id="status2" />
                <label className="form-check-label" htmlFor="status2">Archived</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Broken" id="status3" />
                <label className="form-check-label" htmlFor="status3">Broken</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Being Repaired" id="status4" />
                <label className="form-check-label" htmlFor="status4">Being Repaired</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Pending" id="status5" />
                <label className="form-check-label" htmlFor="status5">Pending</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Category</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Laptop" id="category1" />
                <label className="form-check-label" htmlFor="category1">Laptop</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Computer Accessories" id="category2" />
                <label className="form-check-label" htmlFor="category2">Computer Accessories</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="i Phone" id="category3" />
                <label className="form-check-label" htmlFor="category3">i Phone</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Printer" id="category4" />
                <label className="form-check-label" htmlFor="category4">Printer</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Tablets" id="category5" />
                <label className="form-check-label" htmlFor="category5">Tablets</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>					
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Brand</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Adobe" id="brand1" />
                <label className="form-check-label" htmlFor="brand1">Adobe</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Apple" id="brand2" />
                <label className="form-check-label" htmlFor="brand2">Apple</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Canon" id="brand3" />
                <label className="form-check-label" htmlFor="brand3">Canon</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Dell" id="brand4" />
                <label className="form-check-label" htmlFor="brand4">Dell</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Lenovo" id="brand5" />
                <label className="form-check-label" htmlFor="brand5">Lenovo</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>					
          </ul>
        </li>
        <li>
          <div className="d-flex align-items-center justify-content-start head">
            <h6 className="flex-grow-1">Supplier</h6>
            <i className="fa fa-angle-up float-end" aria-hidden="true" />
          </div>
          <ul>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Amazon" id="supplier1" />
                <label className="form-check-label" htmlFor="supplier1">Amazon</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Staples" id="supplier2" />
                <label className="form-check-label" htmlFor="supplier2">Staples</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Newegg" id="supplier3" />
                <label className="form-check-label" htmlFor="supplier3">Newegg</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Flipkart" id="supplier4" />
                <label className="form-check-label" htmlFor="supplier4">Flipkart</label>
              </div>
            </li>
            <li>
              <div className="form-check">
                <input className="form-check-input" type="checkbox" defaultValue="Store" id="supplier5" />
                <label className="form-check-label" htmlFor="supplier5">Store</label>
              </div>
            </li>
            <li>
              <hr />
              <button type="button" className="btn btn-view-all">view all<i className="fa fa-angle-double-right" aria-hidden="true" /></button>
            </li>					
          </ul>
        </li>
      </ul>
      <div className="button-row">
        <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-reply" aria-hidden="true" />Reset</button>
        <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Apply</button>
      </div>
    </form>
  </div>
</div>

  )
}

export default AssetsGrid
