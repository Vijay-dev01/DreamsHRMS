import React from 'react'
import { Link } from 'react-router-dom'
import {  checksqure, copy, flogo, noteicon, pencil, pencildarticon,  uploadicon } from '../imagepath'
import { useState } from 'react'
import Header from '../Header'



const Onboardingsetting = () => {

    const[addbutton, setAddbutton] = useState(false);
  return (
   
	<div>
  <div className="main-wrapper">
    {/* Header */}
    {/* <header className="header header-fixed header-one">
      <nav className="navbar navbar-expand-lg header-nav">
        <div className="navbar-header">
          <Link id="mobile_btn" to="#">
            <span className="bar-icon">
              <span />
              <span />
              <span />
            </span>
          </Link>
          <Link to="#" className="navbar-brand logo">
            <img src={logo} className="img-fluid" alt="Logo" />
          </Link>
        </div>
        <div className="main-menu-wrapper">
          <ul className="main-nav">
            <li>
              <Link to="#">
                <img src={icon} alt="User img"/> Dashboard
              </Link>
            </li>
            <li className="active">
              <Link to="employees.html">
                <img src={empicon} alt="User img"/> Employees
              </Link>
            </li>
            <li>
              <Link to="#">
                <img src={ticon} alt="User img"/> Time off
              </Link>
            </li>
            <li>
              <Link to="#">
                <img src={picon} alt="User img"/> Policies
              </Link>
            </li>
            <li>
              <Link to="#">
                <img src={ricon} alt="User img"/> Reports
              </Link>
            </li>
          </ul>
          <ul className="nav header-navbar-rht">
            <li className="nav-item search-item">
              <div className="top-nav-search">
                <form action="#">
                  <input type="text" className="form-control" placeholder="Search" />
                  <button className="btn" type="submit"><i className="feather-search" /></button>
                  <span><img src={sicon} alt="User img"/></span>
                </form>
              </div>
            </li>
            <li className="nav-item quick-link-item dropdown">
              <Link className="btn dropdown-toggle" data-bs-toggle="dropdown" to="#" role="button" aria-expanded="false">
                <span>Quick Links <i className="feather-zap" /></span>
              </Link>
              <ul className="dropdown-menu clearfix">
                <li><Link className="dropdown-item" to="#"><img src={empmenuicon} alt="User img"/>Employees</Link></li>
                <li><Link className="dropdown-item" to="#"><img src={timeofficon} alt="User img"/>Time Off</Link></li>
                <li><Link className="dropdown-item" to="#"><img src={timesheet} alt="User img"/>Timesheet</Link></li>
                <li><Link className="dropdown-item" to="#"><img src={allpolicies} alt="User img"/>All Policies</Link></li>
                <li><Link className="dropdown-item" to="#"><img src={allreports} alt="User img"/>Shift &amp; Schedule</Link></li>
                <li><Link className="dropdown-item" to="#"><img src={shiftschedule} alt="User img"/>All Reports</Link></li>
                <li className="w-100 bottom-list-menu">
                  <ul className="sub-menu clearfix">
                    <li><Link to="#">Documentation</Link></li>
                    <li><Link to="#">Changelog v1.4.4</Link></li>
                    <li><Link to="#">Components</Link></li>
                    <li><Link to="#">Support</Link></li>
                    <li><Link to="#">Terms &amp; Conditions</Link></li>
                    <li><Link to="#">About</Link></li>
                  </ul>
                </li>
              </ul>
            </li>
            <li className="nav-item nav-icons">
              <Link to="#">
                <i className="feather-sun" />
              </Link>
            </li>
            <li className="nav-item dropdown has-arrow notification-dropdown">
              <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <i className="feather-bell" />
                <span className="badge">3</span>
              </Link>
              <div className="dropdown-menu dropdown-menu-end notifications">
                <div className="topnav-dropdown-header">
                  <span className="notification-title">Notifications</span>
                  <Link to="#" className="clear-noti"> Clear All</Link>
                </div>
                <div className="noti-content">
                  <ul className="notification-list">
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt="User img"src={avatar1} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">John Doe</span>
                              added new task <span className="noti-title">Patient appointment
                                booking</span></p>
                            <p className="noti-time"><span className="notification-time">4 mins
                                ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt="User img"src={avatar2} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Tarah
                                Shropshire</span> changed the task name <span className="noti-title">Appointment booking with payment
                                gateway</span></p>
                            <p className="noti-time"><span className="notification-time">6 mins
                                ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt="User img"src={avatar6} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Misty
                                Tison</span> added <span className="noti-title">Domenic
                                Houston</span> and <span className="noti-title">Claire
                                Mapes</span> to project <span className="noti-title">Doctor
                                available module</span></p>
                            <p className="noti-time"><span className="notification-time">8 mins
                                ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt="User img"src={avatar5} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Rolland
                                Webber</span> completed task <span className="noti-title">Patient and Doctor video
                                conferencing</span></p>
                            <p className="noti-time"><span className="notification-time">12 mins
                                ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                    <li className="notification-message">
                      <Link to="#">
                        <div className="media d-flex">
                          <span className="avatar flex-shrink-0">
                            <img alt="User img"src={avatar3} className="rounded-circle" />
                          </span>
                          <div className="media-body flex-grow-1">
                            <p className="noti-details"><span className="noti-title">Bernardo
                                Galaviz</span> added new task <span className="noti-title">Private chat module</span></p>
                            <p className="noti-time"><span className="notification-time">2 days
                                ago</span></p>
                          </div>
                        </div>
                      </Link>
                    </li>
                  </ul>
                </div>
                <div className="topnav-dropdown-footer">
                  <Link to="#">View all Notifications</Link>
                </div>
              </div>
            </li>
            <li className="nav-item nav-icons">
              <Link to="#">
                <i className="feather-settings" />
              </Link>
            </li>
            <li className="nav-item nav-icons">
              <Link to="#">
                <i className="far fa-circle-question" />
              </Link>
            </li>
            <li className="nav-item dropdown has-arrow main-drop">
              <Link to="#" className="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                <span className="user-img">
                  <img src={avatar1} className="img-rounded" alt="User img"/>
                </span>
              </Link>
              <div className="dropdown-menu">
                <Link className="dropdown-item" to="#">
                  <i className="feather-user-plus" /> My Profile
                </Link>
                <Link className="dropdown-item" to="#">
                  <i className="feather-settings" /> Settings
                </Link>
                <Link className="dropdown-item" to="#">
                  <i className="feather-log-out" /> Logout
                </Link>
              </div>
            </li>
          </ul>
        </div>
      </nav>
    </header> */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper onboarding onboarding-setting">
      {/* Page Content */}
      <div className="content container">
        <div className="d-lg-flex justify-content-between align-items-center search-filter">
          <h2>Onboarding Setting</h2>
          <div className="mixed-buttons">
            <button type="text" className="btn btn-transparent"><i className="fa fa-search" aria-hidden="true" /></button>
            <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-template"><i className="fa fa-plus" aria-hidden="true" />Add Templates</button>
          </div>
        </div>
        <h3>Onboarding Templates</h3>
        {/* Onboarding Settings Tab */}
        <div className="accordion accordion-flush" id="onboarding-setting">
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingOne">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne" onClick={() => setAddbutton(true)}>
                <div className="d-block head">
                  <div className="text">
                    <h4>Onboarding 1</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className={`btn gradient-btn float-end ${
                                addbutton
                                    ? "d-block "
                                    : "d-none"
                                }`} data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true"  />Add Task</button>
                </div>
              </div>

            </div>
            <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingTwo">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                <div className="d-block head">
                  <div className="text">
                    <h4>Onboarding 2</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className={`btn gradient-btn float-end ${
                                addbutton
                                    ? "d-block "
                                    : "d-none"
                                }`} data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseTwo" className="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingThree">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                <div className="d-block head">
                  <div className="text">
                    <h4>Onboarding 3</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className={`btn gradient-btn float-end ${
                                addbutton
                                    ? "d-block "
                                    : "d-none"
                                }`} data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseThree" className="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingFour">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFour" aria-expanded="false" aria-controls="flush-collapseFour">
                <div className="d-block head">
                  <div className="text">
                    <h4>Onboarding 4</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className={`btn gradient-btn float-end ${
                                addbutton
                                    ? "d-block "
                                    : "d-none"
                                }`} data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseFour" className="accordion-collapse collapse" aria-labelledby="flush-headingFour" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
          <div className="accordion-item">
            <div className="accordion-header d-flex justify-content-between align-items-center" id="flush-headingFive">
              <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseFive" aria-expanded="false" aria-controls="flush-collapseFive">
                <div className="d-block head">
                  <div className="text">
                    <h4>Onboarding 5</h4>
                    <p className="d-block">Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                  </div>
                </div>
              </button>
              <div className="d-flex justify-content-end align-items-center buttons">
                <button type="text" className="btn btn-default"><img src={copy} alt="User img"/></button>
                <button type="text" className="btn btn-default"><img src={pencil} alt="User img"/></button>
                <button type="text" className="btn btn-default"><i className="fa fa-trash" aria-hidden="true" /></button>
                <div>
                  <button type="text" className={`btn gradient-btn float-end ${
                                addbutton
                                    ? "d-block "
                                    : "d-none"
                                }`} data-bs-toggle="modal" data-bs-target="#add-task"><i className="fa fa-plus" aria-hidden="true" />Add Task</button>
                </div>
              </div>
            </div>
            <div id="flush-collapseFive" className="accordion-collapse collapse" aria-labelledby="flush-headingFive" data-bs-parent="#onboarding-setting">
              <div className="accordion-body">
                <p>Lorem ipsum dolor sit amet, elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua</p>
                <ul>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={checksqure} className="img-rounded" alt="User img"/>Sed ut perspiciatis unde omnis iste natus</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={pencildarticon} alt="User img"/>Nemo enim ipsam voluptatem quia voluptas</li>
                  <li className="d-flex justify-content-start align-items-center" data-bs-toggle="modal" data-bs-target="#kit-info"><img src={uploadicon} alt="User img"/>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        {/* /Onboarding Settings Tab */}
        {/* Footer */}
        <footer className="footer">
          <div className="container">
            <div className="row">
              <div className="d-flex justify-content-between align-items-center no-padding">
                <div className="footer-left">
                  <p>© 2023 Dreams HRMS <Link to="#" className="footer-logo"><img src={flogo} alt='' /></Link></p>
                </div>
                <div className="footer-right">
                  <ul>
                    <li>
                      <Link to="#">Privacy Policy</Link>
                    </li>
                    <li>
                      <Link to="#">Terms &amp; Conditions</Link>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </footer>
        {/* Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Template Modal */}
  <div className="modal fade onboarding-modal settings" id="add-template" tabIndex={-1} aria-labelledby="add-template" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Templates</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Template Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Template Name" />
            </div>
            <div className="form-group note field-icon">
              <label htmlFor="description">Description</label>
              <textarea className="form-control" id="description" placeholder="Note" rows={3} defaultValue={""} />
              <img className="icon" src={noteicon} alt="User img"/>
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Add Template Modal */}
  {/* Add Task */}
  <div className="modal fade onboarding-modal settings" id="add-task" tabIndex={-1} aria-labelledby="add-task" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Add Task</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <form>
            <div className="form-group">
              <label className="label">Task Name <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Primary Address" />
            </div>
            <div className="form-group">
              <label>Task Type <span>*</span></label>
              <select className="container p-2 rounded">
                <option>Select Task Type</option>
                <option>Option1</option>
                <option>Option2</option>
              </select>
            </div>
            <div className="form-group">
              <label>Task Role <span>*</span></label>
              <select className="container p-2 rounded">
                <option>Select Task Role</option>
                <option>Option1</option>
                <option>Option2</option>
              </select>
            </div>
            <div className="row">
              <label className="bold">Due Date <span>*</span></label>
              <div className="col">
                <div className="form-group">
                  <label>Day </label>
                  <select className="container p-2 rounded">
                    <option>Select Assign</option>
                    <option>Option1</option>
                    <option>Option2</option>
                  </select>
                </div>
              </div>
              <div className="col">
                <div className="form-group">
                  <label>Join Date <span>*</span></label>
                  <select className="container p-2 rounded">
                    <option>Before</option>
                    <option>Option1</option>
                    <option>Option2</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="form-group mb-0">
              <label className="add-course-label">Description</label>
              <div id="editor" />
            </div>
            <div className="buttons">
              <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Save</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal">Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /End Modal */}
  {/* Kit Info Modal */}
  <div className="modal fade onboarding-modal settings" id="kit-info" tabIndex={-1} aria-labelledby="kit-info" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Company Welcome Kit Details</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <ul>
            <li className="d-flex justify-content-between align-items-top"><span>Task Type:</span><p><i className="fa fa-check-square" aria-hidden="true" /> Checkbox</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Document Size:</span><p>2MB</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Task Name:</span><p>Company Welcome Kit</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Assignee:</span><p>Hr-in-charge</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Due Date:</span><p>2 day before join date</p></li>
            <li className="d-flex justify-content-between align-items-top"><span>Description:</span><p>Lorem ipsum dolor consectetur adipiscing ut et eiusmod dolore magna aliqua. </p></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

  )
}

export default Onboardingsetting
