// import { Auth } from 'aws-amplify-react';
// import * as Amplify from '@aws-amplify/ui';
//          Amplify.configure({
//           Auth:{
//             identityPoolId: 'us-east-1:186128823741',
//             region: 'us-east-1',
//             identityPoolRegion: 'us-east-1',
//             userPoolId: 'eu-west-1_v2yAhog2m',
//             userPoolWebClientId: '1d1v8248oophjfpmh6mbn83t0s',
//             mandatorySignIn: false,
//             signUpVerificationMethod: 'token', // 'code' | 'link'
//             oauth: {
//                 domain:'https://dreamshrms.auth.us-east-1.amazoncognito.com',
//                 redirectSignIn: 'api.dreamshrms.com',
//                 redirectSignOut: 'api.dreamshrms.com',
//                 responseType: 'token' // or 'token', note that REFRESH token will only be generated when the responseType is code
//             }
//         }}
//         )
   
        
//         export const currentConfiguration = Auth.configure()
