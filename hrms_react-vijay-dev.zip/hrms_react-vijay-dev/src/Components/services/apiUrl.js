import API from './axiosservice'
import nacl_factory from 'js-nacl';
import { SodiumPlus, CryptographyKey } from 'sodium-plus';
import { Buffer } from "buffer";
// import _sodiumPlus from 'libsodium-wrappers';
// import { keyEnv, nonceEnv } from '../assets/constants/config'

// export const nonceEnv = "c88529b087036c035be110e0fa5b6b63041ede30e2e69e90";
// export const keyEnv =
//   "89def69f0bdddc995078037539dc6ef4f0bdbdd3fa04ef2d11eea30779d72ac6";
// const nonceEnv = 'c88529b087036c035be110e0fa5b6b63041ede30e2e69e90'
// const keyEnv = '89def69f0bdddc995078037539dc6ef4f0bdbdd3fa04ef2d11eea30779d72ac6'

const keyEnv ="20f52cbd78033da9905ecb7891e7c9b8dad0c79b30177ffe87cec59ab337d783";
const nonceEnv="5c27c449e7531dd3e439cb7fb14a253675328661555ed8f6";


async function decryptMessage(ciphertextHex, nonceHex, keyHex) {
  let sodium
  if (!sodium) sodium = await SodiumPlus.auto()
  let ciphertext = Buffer.from(ciphertextHex, 'hex')
  let nonce = Buffer.from(nonceHex, 'hex')
  let key = CryptographyKey.from(keyHex, 'hex')
  return sodium.crypto_secretbox_open(ciphertext, nonce, key)
}

export const postData = async (url, data, sucessCallBack) => {
   nacl_factory.instantiate(function (sodium) {
    const formData = new FormData()
    if (Object.keys(data)?.length > 0) {
      var keyUtf8 = sodium.from_hex(
       keyEnv,
        'hex',
      )
      var nonceUtf8 = sodium.from_hex(
        nonceEnv,
        'hex',
      )
      var dataUtf8 = sodium.encode_utf8(JSON.stringify(data))
      var encrypted = sodium.crypto_secretbox(dataUtf8, nonceUtf8, keyUtf8)
      const encryptedHex = sodium.to_hex(encrypted)
      // console.log(encrypteedHex,"encrypteedHex");
      formData.append('request_data', encryptedHex)
    }

    return new Promise((resolve, reject) => {
      API.post(url, formData)
        .then((res) => {
          console.log(res,"ans")
          if (res?.data && res?.data.length > 0)
            getData(res?.data, sucessCallBack, res)
          else {

            sucessCallBack('No data', res)
          }
        })
        .catch((error) => {
          sucessCallBack('error', error)
          reject(error)
        })
    })
  })
}

export const getData = (data, sucessCallBack, res) => {
  const nonceHex = nonceEnv
  const keyHex = keyEnv
  return new Promise((resolve, reject) => {
    try {
      decryptMessage(data, nonceHex, keyHex).then((plaintext) => {
        const result = new TextDecoder().decode(plaintext)
        sucessCallBack(JSON.parse(result), res)
        resolve(JSON.parse(result))
      })
    } catch (error) {
      sucessCallBack('error', error)
      reject(error)
    }
  })
}

export const DataEncrpt = async (data, sucessCallBack) => {
  nacl_factory.instantiate(function (sodium) {
    if (Object.keys(data)?.length > 0) {
      var keyUtf8 = sodium.from_hex(
        process.env.REACT_APP_KEY_CODE || keyEnv,
        'hex',
      )
      var nonceUtf8 = sodium.from_hex(
        nonceEnv,
        'hex',
      )
      var dataUtf8 = sodium.encode_utf8(JSON.stringify(data))
      var encrypted = sodium.crypto_secretbox(dataUtf8, nonceUtf8, keyUtf8)
      const encryptedHex = sodium.to_hex(encrypted)
      sucessCallBack(encryptedHex)
    }
  })
}
export const getDecryptedData = (data, sucessCallBack) => {
  return new Promise((resolve, reject) => {
    try {
      decryptMessage(data, nonceEnv, keyEnv).then((plaintext) => {
        const result = new TextDecoder().decode(plaintext)
        sucessCallBack(JSON.parse(result))
        resolve(JSON.parse(result))
      })
    } catch (error) {
      sucessCallBack('error', error)
      reject(error)
    }
  })
}
