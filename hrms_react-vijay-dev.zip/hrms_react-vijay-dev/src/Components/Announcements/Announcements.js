import React from 'react';
import Header from '../Header';
import { Link } from 'react-router-dom';
import { announcements, birthdaybanner, drag1, empshareavatar, smiley } from '../imagepath';
import Footer from '../Footer';

const Announcements = () => {
  return (
   <div>
  <div className="main-wrapper">
    {/* Header */}
    <Header />
    {/* /Header */}
    {/* Page Wrapper */}
    <div className="page-wrapper announcements">
      {/* Page Content */}
      <div className="content container">
        <div className="d-flex justify-content-between align-items-center title-row">
          <h2>Announcements</h2>
          <div className="mixed-buttons">
            <button type="text" className="btn gradient-btn float-end" data-bs-toggle="modal" data-bs-target="#add-announcement"><i className="fa fa-plus" aria-hidden="true" />Add Announcements</button>
          </div>
        </div>
        <div className="row">
          <div className="col-sm-12">
            <div className="card-table">
              <div className="card-body">
                <div className="table-responsive">
                  <table className="table table-center table-hover">
                    <thead className="thead-light">
                      <tr>
                        <th>#<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Subject<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Message<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Send To<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Status<i className="fa fa-caret-down" aria-hidden="true" /></th>
                        <th>Date<i className="fa fa-caret-down" aria-hidden="true" /></th>												   
                        <th>Action<i className="fa fa-caret-down" aria-hidden="true" /></th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr data-bs-toggle="modal" data-bs-target="#birthday1">
                        <td>1</td>
                        <td><h6>Birthday Wishes</h6></td>
                        <td><p>We wish you many more happy returns of the day.</p></td>
                        <td>
                          <div className="group-avatar">
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                                <img src={announcements} alt="" />
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar count">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
                            </span>
                          </div>
                        </td>
                        <td><p>Published</p></td>
                        <td>
                          <p>3 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr data-bs-toggle="modal" data-bs-target="#birthday2">
                        <td>2</td>
                        <td><h6>Birthday Wishes</h6></td>
                        <td><p>We wish you many more happy returns of the day.</p></td>
                        <td>
                          <div className="group-avatar">
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar count">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
                            </span>
                          </div>
                        </td>
                        <td><p>Published</p></td>
                        <td>
                          <p>3 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td><h6>Birthday Wishes</h6></td>
                        <td><p>We wish you many more happy returns of the day.</p></td>
                        <td>
                          <div className="group-avatar">
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar count">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
                            </span>
                          </div>
                        </td>
                        <td><p>Published</p></td>
                        <td>
                          <p>3 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td><h6>Birthday Wishes</h6></td>
                        <td><p>We wish you many more happy returns of the day.</p></td>
                        <td>
                          <div className="group-avatar">
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar count">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
                            </span>
                          </div>
                        </td>
                        <td><p>Published</p></td>
                        <td>
                          <p>3 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td><h6>Birthday Wishes</h6></td>
                        <td><p>We wish you many more happy returns of the day.</p></td>
                        <td>
                          <div className="group-avatar">
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                                <img src={announcements} alt=""/>
                              </Link>
                            </span>
                            <span className="avatar count">
                              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
                            </span>
                          </div>
                        </td>
                        <td><p>Published</p></td>
                        <td>
                          <p>3 March 2023</p>
                          <span>Thursday</span>
                        </td>
                        <td>
                          <div className="action-icons d-flex justify-content-start align-items-center">
                            <Link to="#" className="text-center">
                              <i className="fa fa-pencil" aria-hidden="true" />
                            </Link>
                            <Link to="#" className="text-center">
                              <i className="far fa-trash-alt" data-bs-toggle="modal" data-bs-target="#delete-task" />
                            </Link>
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <div className="pagination-wrap d-flex justify-content-between">
                    <p>Rows Per page&nbsp;&nbsp;<span>3</span>&nbsp;&nbsp;<i className="fa fa-caret-right" aria-hidden="true" /></p>
                    <ul className="d-flex">
                      <li className="active"><Link to="#">1</Link></li>
                      <li><Link to="#">2</Link></li>
                      <li><Link to="#">3</Link></li>
                      <li><Link to="#">...</Link></li>
                      <li><Link to="#">10</Link></li>
                      <li><Link to="#">11</Link></li>
                      <li><Link to="#">12</Link></li>
                    </ul>
                    <p>Go to page&nbsp;&nbsp;<Link to="#"><i className="fa fa-long-arrow-right" aria-hidden="true" /></Link></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Footer */}
       <Footer />
        {/* /Footer */}
      </div>
      {/* /Page Content */}
    </div>
    {/* /Page Wrapper */}
  </div>
  {/* /Main Wrapper */}
  {/* Add Template Modal */}
  <div className="modal onboarding-modal fade" id="add-announcement" tabIndex={-1} aria-labelledby="add-announcement" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Create an announcement</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <ul className="steps d-flex justify-content-between align-items-center">
            <li className="d-flex justify-content-between align-items-center active">
              <span className="text-center">1</span>
              <p>Information</p>
            </li>
            <li className="d-flex justify-content-between align-items-center">
              <span className="text-center">2</span>
              <p>Members</p>
            </li>
          </ul>
          <form>
            <div className="form-group">
              <label className="label">Subject <span>*</span></label>
              <input type="text" className="form-control" placeholder="Enter Subject" />
            </div>
            <div className="form-group field-icon">
              <label className="label">Message <span>*</span></label>
              <textarea className="form-control" id="description" placeholder="Enter Message" rows={3} defaultValue={""} />
              <img className="icon" src={smiley} alt="" />
            </div>
            <div className="form-group">
              <label className="label">Attachment <span>*</span></label>
              <div className="drag-drop text-center">
                <div className="upload">
                  <Link to="#"><img src={drag1} alt='alt=""'/></Link>
                  <p>Drag &amp; drop your files here or choose file <Link to="#">browse</Link></p>
                  <span>Maximum size: 50MB</span>
                </div>
                <input type="file" multiple />
              </div>
            </div>
            {/* <div class="form-check">
          <input class="form-check-input" type="radio" name="exampleRadios" id="no-action" value="option1" checked onclick="options_wrap_hide()">
          <label class="form-check-label" for="no-action">No action required</label>
      </div>
      <div class="form-check">
          <input class="form-check-input" type="radio" name="exampleRadios" id="poll" value="option2" onclick="options_wrap_show()">
          <label class="form-check-label" for="poll">Poll</label>
      </div>
      <div id="options_wrap">
          <div class="form-group field-icon">
              <label class="label">Option 1 <span>*</span></label>
              <input type="text" class="form-control" placeholder="I Agree">
              <img class="icon" src="assets/img/icons/smiley-icon.svg" alt="">
          </div>
          <div class="form-group field-icon">
              <label class="label">Option 2</label>
              <input type="text" class="form-control" placeholder="I Disagree">
              <img class="icon" src="assets/img/icons/smiley-icon.svg" alt="">
          </div>
          <button type="text" class="btn btn-transparent add-answer"><i class="fa fa-plus-circle" aria-hidden="true"></i> Add Answer</button>
          <div class="form-group answer">
              <label class="label">Option 3</label>
              <input type="text" class="form-control" placeholder="Enter Option 3">
          </div>
      </div> */}
            <div className="buttons">
              <button type="button" className="btn gradient-btn" data-bs-toggle="modal" data-bs-target="#members"><i className="fa fa-check" aria-hidden="true" />Next</button>
              <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-close" aria-hidden="true" />Cancel</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  {/* /Add Branches Modal */}
  {/* Members Modal */}
  <div className="modal onboarding-modal fade" id="members" tabIndex={-1} aria-labelledby="add-announcement" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Create an announcement</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <ul className="steps d-flex justify-content-between align-items-center">
            <li className="d-flex justify-content-between align-items-center active">
              <span className="text-center">1</span>
              <p>Information</p>
            </li>
            <li className="d-flex justify-content-between align-items-center active">
              <span className="text-center">2</span>
              <p>Members</p>
            </li>
          </ul>
          <ul className="nav nav-tabs align-items-center justify-content-center" id="myTab" role="tablist">
            <li className="nav-item" role="presentation">
              <button className="nav-link active" id="employees-tab" data-bs-toggle="tab" data-bs-target="#employees" type="button" role="tab" aria-controls="employees" aria-selected="true">
                <i className="fa fa-user" aria-hidden="true" />
                <h6>Employees</h6>
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button className="nav-link" id="department-tab" data-bs-toggle="tab" data-bs-target="#department" type="button" role="tab" aria-controls="department" aria-selected="false">
                <i className="fa fa-building" aria-hidden="true" />
                <h6>Department</h6>
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button className="nav-link" id="position-tab" data-bs-toggle="tab" data-bs-target="#position" type="button" role="tab" aria-controls="position" aria-selected="false">
                <i className="fa fa-flag" aria-hidden="true" />
                <h6>Positions</h6>
              </button>
            </li>
            {/* <li class="nav-item" role="presentation">
          <button class="nav-link" id="location-tab" data-bs-toggle="tab" data-bs-target="#location" type="button" role="tab" aria-controls="location" aria-selected="false">
              <i class="fa fa-map-marker" aria-hidden="true"></i>
              <h6>Locations</h6>
          </button>
      </li> */}
          </ul>
          <div className="tab-content" id="myTabContent">
            <div className="tab-pane fade show active" id="employees" role="tabpanel" aria-labelledby="employees-tab">
              <form>
                <div className="form-group search field-icon">
                  <input type="text" className="form-control" placeholder="Search" />
                  <i className="feather-search" />
                </div>
                <div className="checkbox select-all">
                  <input id="select-employees" type="checkbox" />
                  <label htmlFor="select-employees">Select all employees</label>
                </div>
                <div className="lists">
                  <div className="checkbox rows employee-row d-flex justify-content-start align-items-center">
                    <input id="box1" type="checkbox" />
                    <label htmlFor="box1">
                      <div className="profile d-flex justify-content-start align-items-center">
                        <div className>
                          <img src={empshareavatar} alt=""/>
                        </div>
                        <div className="text">
                          <h4>John Smith</h4>
                          <span>DGT-365</span>
                        </div>
                      </div>
                    </label>
                  </div>
                  <div className="checkbox rows employee-row d-flex justify-content-start align-items-center">
                    <input id="box2" type="checkbox" />
                    <label htmlFor="box2">
                      <div className="profile d-flex justify-content-start align-items-center">
                        <div className>
                          <img src={empshareavatar} alt=""/>
                        </div>
                        <div className="text">
                          <h4>John Smith</h4>
                          <span>DGT-365</span>
                        </div>
                      </div>
                    </label>
                  </div>
                  <div className="checkbox rows employee-row d-flex justify-content-start align-items-center">
                    <input id="box3" type="checkbox" />
                    <label htmlFor="box3">
                      <div className="profile d-flex justify-content-start align-items-center">
                        <div className>
                          <img src={empshareavatar} alt=""/>
                        </div>
                        <div className="text">
                          <h4>John Smith</h4>
                          <span>DGT-365</span>
                        </div>
                      </div>
                    </label>
                  </div>
                  <div className="checkbox rows employee-row d-flex justify-content-start align-items-center">
                    <input id="box4" type="checkbox" />
                    <label htmlFor="box4">
                      <div className="profile d-flex justify-content-start align-items-center">
                        <div className>
                          <img src={empshareavatar} alt=""/>
                        </div>
                        <div className="text">
                          <h4>John Smith</h4>
                          <span>DGT-365</span>
                        </div>
                      </div>
                    </label>
                  </div>
                  <div className="checkbox rows employee-row d-flex justify-content-start align-items-center">
                    <input id="box5" type="checkbox" />
                    <label htmlFor="box5">
                      <div className="profile d-flex justify-content-start align-items-center">
                        <div className>
                          <img src={empshareavatar} alt=""/>
                        </div>
                        <div className="text">
                          <h4>John Smith</h4>
                          <span>DGT-365</span>
                        </div>
                      </div>
                    </label>
                  </div>
                  <div className="checkbox rows employee-row d-flex justify-content-start align-items-center">
                    <input id="box6" type="checkbox" />
                    <label htmlFor="box6">
                      <div className="profile d-flex justify-content-start align-items-center">
                        <div className>
                          <img src={empshareavatar} alt=""/>
                        </div>
                        <div className="text">
                          <h4>John Smith</h4>
                          <span>DGT-365</span>
                        </div>
                      </div>
                    </label>
                  </div>
                </div>
                <div className="buttons">
                  <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Publish</button>
                  <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-close" aria-hidden="true" />Draft</button>
                </div>
              </form>
            </div>
            <div className="tab-pane fade" id="department" role="tabpanel" aria-labelledby="department-tab">
              <form>
                <div className="form-group search">
                  <input type="text" className="form-control" placeholder="Search" />
                  <i className="feather-search" />
                </div>
                <div className="checkbox select-all">
                  <input id="select-department" type="checkbox" />
                  <label htmlFor="select-department">Select all Department</label>
                </div>
                <div className="lists">
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box7" type="checkbox" />
                    <label htmlFor="box7">
                      HR
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box8" type="checkbox" />
                    <label htmlFor="box8">
                      UI/UX 
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box9" type="checkbox" />
                    <label htmlFor="box9">
                      Marketing
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box10" type="checkbox" />
                    <label htmlFor="box10">
                      Development
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box11" type="checkbox" />
                    <label htmlFor="box11">
                      HR
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box12" type="checkbox" />
                    <label htmlFor="box12">
                      UI/UX 
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box13" type="checkbox" />
                    <label htmlFor="box13">
                      Marketing
                    </label>
                  </div>
                  <div className="checkbox rows department-row d-flex justify-content-start align-items-center">
                    <input id="box14" type="checkbox" />
                    <label htmlFor="box14">
                      Development
                    </label>
                  </div>
                </div>
                <div className="buttons">
                  <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Publish</button>
                  <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-close" aria-hidden="true" />Draft</button>
                </div>
              </form>
            </div>
            <div className="tab-pane fade" id="position" role="tabpanel" aria-labelledby="position-tab">
              <form>
                <div className="form-group search">
                  <input type="text" className="form-control" placeholder="Search" />
                  <i className="feather-search" />
                </div>
                <div className="checkbox select-all">
                  <input id="select-position" type="checkbox" />
                  <label htmlFor="select-position">Select all Department</label>
                </div>
                <div className="lists">
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box15" type="checkbox" />
                    <label htmlFor="box15">
                      HR
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box16" type="checkbox" />
                    <label htmlFor="box16">
                      UI/UX 
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box17" type="checkbox" />
                    <label htmlFor="box17">
                      Marketing
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box18" type="checkbox" />
                    <label htmlFor="box18">
                      Development
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box19" type="checkbox" />
                    <label htmlFor="box19">
                      HR
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box20" type="checkbox" />
                    <label htmlFor="box20">
                      UI/UX 
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box21" type="checkbox" />
                    <label htmlFor="box21">
                      Marketing
                    </label>
                  </div>
                  <div className="checkbox rows position-row d-flex justify-content-start align-items-center">
                    <input id="box22" type="checkbox" />
                    <label htmlFor="box22">
                      Development
                    </label>
                  </div>
                </div>
                <div className="buttons">
                  <button type="button" className="btn gradient-btn"><i className="fa fa-check" aria-hidden="true" />Publish</button>
                  <button type="button" className="btn btn-dull" data-bs-dismiss="modal"><i className="fa fa-close" aria-hidden="true" />Draft</button>
                </div>
              </form>
            </div>
            {/* <div class="tab-pane fade" id="location" role="tabpanel" aria-labelledby="location-tab">
          <p>Locations</p>
      </div> */}
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* /Members Modal */}
  {/* Birthday1 Wishes Modal */}
  <div className="modal onboarding-modal birthday fade" id="birthday1" tabIndex={-1} aria-labelledby="birthday1" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Birthday Wishes</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Send To</h6>
          <div className="group-avatar">
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar count">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
            </span>
          </div>
          <h6>Message</h6>
          <p>Hi John Smith</p>
          <p className="dull">We wish you many more happy returns of the day. We value your special day just as much as we value you. On your birthday, we send you our warmest and most heartfelt wishes. We are thrilled to be able to share this great day with you, and glad to have you as a valuable member of the DGT Family.</p>
          <Link to="#" className="announcement-seen" data-bs-toggle="modal" data-bs-target="#views"><i className="fa fa-eye" aria-hidden="true" />10 member / 80</Link>
        </div>
      </div>
    </div>
  </div>
  {/* /Birthday1 Wishes Modal */}
  {/* Birthday2 Wishes Modal */}
  <div className="modal onboarding-modal birthday fade" id="birthday2" tabIndex={-1} aria-labelledby="birthday2" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Birthday Wishes</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <h6>Send To</h6>
          <div className="group-avatar">
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 1">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 2">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 3">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 4">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 5">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 6">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 7">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Member 8">
                <img src={announcements} alt=""/>
              </Link>
            </span>
            <span className="avatar count">
              <Link to="#" data-bs-toggle="tooltip" data-bs-placement="right" title="Total Count">50+</Link>
            </span>
          </div>
          <h6>Message</h6>
          <p>Hi John Smith</p>
          <p className="dull">We wish you many more happy returns of the day. We value your special day just as much as we value you. On your birthday, we send you our warmest and most heartfelt wishes. We are thrilled to be able to share this great day with you, and glad to have you as a valuable member of the DGT Family.</p>
          <div className="banner">
            <Link to="#"><img src={birthdaybanner} alt="" /></Link>
          </div>
          <Link to="#" className="announcement-seen" data-bs-toggle="modal" data-bs-target="#views"><i className="fa fa-eye" aria-hidden="true" />10 member / 80</Link>
        </div>
      </div>
    </div>
  </div>
  {/* /Birthday2 Wishes Modal */}
  {/* Views Modal */}
  <div className="modal onboarding-modal fade" id="views" tabIndex={-1} aria-labelledby="views" aria-hidden="true">
    <div className="modal-dialog">
      <div className="modal-content">
        <div className="modal-header">
          <h5 className="modal-title">Announcement seen by 10 member / 80</h5>
          <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"><i className="fa fa-times" aria-hidden="true" /></button>
        </div>
        <div className="modal-body">
          <ul className="nav nav-tabs align-items-center justify-content-center" id="viewsTab" role="tablist">
            <li className="nav-item" role="presentation">
              <button className="nav-link active" id="viewed-tab" data-bs-toggle="tab" data-bs-target="#viewed" type="button" role="tab" aria-controls="viewed" aria-selected="true">
                <i className="fa fa-eye" aria-hidden="true" />
                <h6 className="d-inline">Viewed (10)</h6>
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button className="nav-link" id="notviewed-tab" data-bs-toggle="tab" data-bs-target="#notviewed" type="button" role="tab" aria-controls="notviewed" aria-selected="false">
                <i className="fa fa-eye-slash" aria-hidden="true" />
                <h6 className="d-inline">Not Viewed (70)</h6>
              </button>
            </li>
          </ul>
          <div className="tab-content" id="viewsTabContent">
            <div className="tab-pane fade show active" id="viewed" role="tabpanel" aria-labelledby="viewed-tab">
              <form>
                <div className="form-group search">
                  <input type="text" className="form-control" placeholder="Search" />
                  <i className="feather-search" />
                </div>
                <div className="lists">
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                  <div className="profile d-flex justify-content-start align-items-center">
                    <div className>
                      <img src={empshareavatar} alt=""/>
                    </div>
                    <div className="text">
                      <h4>John Smith</h4>
                      <span>DGT-365</span>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div className="tab-pane fade" id="notviewed" role="tabpanel" aria-labelledby="notviewed-tab">
              <form>
                <div className="form-group search">
                  <input type="text" className="form-control" placeholder="Search" />
                  <i className="feather-search" />
                </div>
                <div className="profile d-flex justify-content-start align-items-center">
                  <div className>
                    <img src={empshareavatar} alt=""/>
                  </div>
                  <div className="text">
                    <h4>John Smith</h4>
                    <span>DGT-365</span>
                  </div>
                </div>
                <div className="profile d-flex justify-content-start align-items-center">
                  <div className>
                    <img src={empshareavatar} alt=""/>
                  </div>
                  <div className="text">
                    <h4>John Smith</h4>
                    <span>DGT-365</span>
                  </div>
                </div>
                <div className="profile d-flex justify-content-start align-items-center">
                  <div className>
                    <img src={empshareavatar} alt=""/>
                  </div>
                  <div className="text">
                    <h4>John Smith</h4>
                    <span>DGT-365</span>
                  </div>
                </div>
                <div className="profile d-flex justify-content-start align-items-center">
                  <div className>
                    <img src={empshareavatar} alt=""/>
                  </div>
                  <div className="text">
                    <h4>John Smith</h4>
                    <span>DGT-365</span>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

  );
}

export default Announcements;
