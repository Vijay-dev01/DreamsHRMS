import Dashboard from './Components/Dashboard';
import Login from './Components/Login/Login';
import Organizationdetails from './Components/Organizationdetails';
import Register from './Components/Register';
import Forgetpassword from './Components/Forgetpassword';
import { BrowserRouter as Router, Route, Routes, Navigate,Outlet } from "react-router-dom"
import Setpassword from './Components/Setpassword';
import Signup from './Components/Signup';
import Employee_list from './Components/Employee/EmployeeList';
import Employee from './Components/Employee/Employee';
import Employee_profile from './Components/Employee/Employee_profile';
import Employee_attendance from './Components/Employee/Employee_attendance';
import EmployeeTimeOff from './Components/Employee/EmployeeTimeOff';
// import EmplyeeTimesheet from './Components/Employee/EmployeeTimesheet';
import EmployeeTimesheet from './Components/Employee/EmployeeTimesheet';
import EmployeeAssets from './Components/Employee/EmployeeAssets';
import EmployeeDocument from './Components/Employee/EmployeeDocument';
import EmployeeHeader from './Components/Employee/EmployeeHeader';
import Onboarding from './Components/Onboarding/Onboarding';
import Onboardingsetting from './Components/Onboarding/Onboardingsetting';
import Depart from './Components/Department/Department';
import DepartGrid from './Components/Department/DepartGrid';
import Leave from './Components/Leave/Leave';
import Holiday from './Components/Leave/Holiday';
import Timeoff from './Components/Employee/EmployeeTimeOff';
import Assets from './Components/Employee/EmployeeAssets';
import Document from './Components/Employee/EmployeeDocument';
import EmpImport from './Components/Employee/EmpImport';
import EmpImportfirst from './Components/Employee/EmpImportfirst';
import Header from './Components/Header';
import Offboarding from './Components/Offboarding/Offboarding';
import Offboardingsetting from './Components/Offboarding/Offboardingsetting';
import Setting from './Components/Setting/Setting';
import Companysetting from './Components/Setting/Companysetting';
import Systemsetting from './Components/Setting/Systemsetting';
import Notificationsetting from './Components/Setting/Notificationsetting';
import Privilegessetting from './Components/Setting/Privilegessetting';
import Leavesetting from './Components/Setting/Leavesetting';
import AdminDashboardsetting from './Components/Setting/Dashboard/AdminDashboardsetting';
import HrDashboardsetting from './Components/Setting/Dashboard/HrDashboardsetting';
import Empdashboardsetting from './Components/Setting/Dashboard/Empdashboardsetting';
import Approvalsetting from './Components/Setting/Approval/Approvalsetting';
import LeaveApproval from './Components/Setting/Approval/LeaveApproval';
import OfferApproval from './Components/Setting/Approval/OfferApproval';
import ResignationNotice from './Components/Setting/Approval/ResignationNotice';
import Branches from './Components/Branches/Branches';
import Announcements from './Components/Announcements/Announcements';
import Policies from './Components/Policies/Policies';
import Promotion from './Components/Policies/Promotion';
import Asset from './Components/Asset/Assets';
import AssetsGrid from './Components/Asset/AssetsGrid';
import Ticket from './Components/Ticket/Ticket';
import ShiftAndSchedule from "./Components/ShiftAndSchedule/shiftAndSchedule";
import Schedule from "./Components/ShiftAndSchedule/Schedule";
import Themesetting from './Components/Setting/Themesetting';
import AdminDashbord from './Components/AdminDashbord/AdminDashbord';
import HrDashboard from './Components/AdminDashbord/HrDashboard';
import EmployeeDashboard from './Components/AdminDashbord/EmployeeDashboard';
import AdminActivity from './Components/ActivityLog/AdminActivity';
import IndividualsActivity from './Components/ActivityLog/IndividualsActivity';


window.Buffer = window.Buffer || require("buffer").Buffer;

const PrivateRoute = ({ auth: { isAuthenticated }, children }) => {
  return isAuthenticated ? children : <Navigate to="/" />;
};

const PrivateWrapper = ({ auth: { isAuthenticated } }) => {
  return isAuthenticated ? <Outlet /> : <Navigate to="/" />;
};

function App() {

  return (
    <div className="App">
      <Router>
        {/* public rouder */}
        <Routes>
          <Route path="/" element={<Login />}></Route>
          <Route path="/forgetpassword" element={<Forgetpassword />} />

          <Route path="/setpassword/:token/:email/" element={<Setpassword />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/register" element={<Register />} />
        </Routes>
        {/* private rouder */}
        <Routes>
          <Route
            path="/Schedule"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                {" "}
                <Schedule />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/shift"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                {" "}
                <ShiftAndSchedule />
              </PrivateRoute>
            }
          />
          <Route
            path="/organizationdetails"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                {" "}
                <Organizationdetails />{" "}
              </PrivateRoute>
            }
          />

          <Route
            path="/employeeHeader"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                {" "}
                <EmployeeHeader />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeelist"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                {" "}
                <Employee_list />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employee"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <Employee />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeeprofile"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <Employee_profile />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeeattendance"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <Employee_attendance />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeetime"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <EmployeeTimeOff />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeesheet"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <EmployeeTimesheet />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeeassets"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <EmployeeAssets />{" "}
              </PrivateRoute>
            }
          />
          <Route
            path="/employeedocument"
            element={
              <PrivateRoute auth={{ isAuthenticated: true }}>
                <EmployeeDocument />{" "}
              </PrivateRoute>
            }
          ></Route>
      
          <Route path='/' element={<Login />}></Route>
          <Route path='/register' element={<Register />}></Route>
          <Route path='/dashboard' element={<Dashboard />}></Route>
          <Route path='/forgetpassword' element={<Forgetpassword />}></Route>
          <Route path='/setpassword' element={<Setpassword />}></Route>
          <Route path='/signup' element={<Signup />}></Route>
          <Route path="/emptimeoff" element={<Timeoff/>}></Route>
          <Route path ="/employeeimportfirst" element={<EmpImportfirst/>}></Route>
          <Route path ="/employeeimport" element={<EmpImport/>}></Route>

          <Route path ="/onboarding" element={<Onboarding/>}></Route>
          <Route path ="/onboardingsetting" element={<Onboardingsetting/>}></Route>

          <Route path ="/depart" element={<Depart/>}></Route>
          <Route path ="/departgrid" element={<DepartGrid/>}></Route>

          <Route path ="/leave" element={<Leave/>}></Route>
          <Route path ="/holiday" element={<Holiday/>}></Route>

          <Route path ="/offboarding" element={<Offboarding/>}></Route>
          <Route path ="/offboardingsetting" element={<Offboardingsetting/>}></Route>

          <Route path ="/setting" element={<Setting/>}></Route>
          <Route path ="/company-setting" element={<Companysetting/>}></Route>
          <Route path ="/system-setting" element={<Systemsetting/>}></Route>
          <Route path ="/notification-setting" element={<Notificationsetting/>}></Route>
          <Route path ="/privileges-setting" element={<Privilegessetting/>}></Route>
          <Route path ="/Leave-setting" element={<Leavesetting/>}></Route>
          <Route path ="/admin-dashboard-setting" element={<AdminDashboardsetting/>}></Route>
          <Route path ="/hr-dashboard-setting" element={<HrDashboardsetting/>}></Route>
          <Route path ="/employee-dashboard-setting" element={<Empdashboardsetting/>}></Route>
          <Route path ="/approval-setting" element={<Approvalsetting/>}></Route>
          <Route path ="/Leave-approval-setting" element={<LeaveApproval/>}></Route>
          <Route path ="/offer-approval-setting" element={<OfferApproval/>}></Route>
          <Route path ="/resignation-notice" element={<ResignationNotice/>}></Route>
          <Route path ="/theme-setting" element={<Themesetting/>}></Route>

          <Route path ="/branches" element={<Branches/>}></Route>

          <Route path ="/announcements" element={<Announcements/>}></Route>

          <Route path ="/policies" element={<Policies/>}></Route>
          <Route path ="/promotion" element={<Promotion/>}></Route>

          <Route path ="/asset" element={<Asset/>}></Route>
          <Route path ="/assetgrid" element={<AssetsGrid/>}></Route>

          <Route path ="/ticket" element={<Ticket/>}></Route>

          <Route path ="/admin-dashboard" element={<AdminDashbord/>}></Route>
          <Route path ="/hr-dashboard" element={<HrDashboard/>}></Route>
          <Route path ="/employee-dashboard" element={<EmployeeDashboard/>}></Route>

          <Route path ="/admin-activity" element={<AdminActivity/>}></Route>
          <Route path ="/individuals-activity" element={<IndividualsActivity/>}></Route>

        </Routes>
        </Router>
    </div>
  );
}

export default App;
